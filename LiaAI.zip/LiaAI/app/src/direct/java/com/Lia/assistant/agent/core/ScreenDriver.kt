package com.Lia.assistant.agent.core

enum class DriverResult { OK, FAILED, STALE, NOT_FOUND, UNSUPPORTED }

enum class ScrollDirection { UP, DOWN, LEFT, RIGHT }

/**
 * The ONLY boundary between the agent and the device. Everything above it is plain Kotlin that a
 * scripted fake can stand in for. Methods never throw for device problems: they report a [DriverResult].
 */
interface ScreenDriver {
    /** Reads the active window; null when there is none (or screen control is off). */
    suspend fun capture(): ScreenObservation?

    /** Clicks [element] of [observation]. STALE if that observation is no longer the latest. */
    suspend fun clickElement(observation: ScreenObservation, element: UiElement): DriverResult

    suspend fun gestureTap(x: Int, y: Int): DriverResult

    /** Replaces the text of the focused field. */
    suspend fun setText(text: String): DriverResult

    suspend fun scroll(direction: ScrollDirection): DriverResult

    suspend fun back(): DriverResult

    suspend fun home(): DriverResult

    // Getting into an app is part of the same boundary.

    suspend fun launchApp(packageName: String): DriverResult

    /** Opens a link in the first of [packageNames] that is installed. */
    suspend fun openLink(url: String, packageNames: List<String>): DriverResult

    /** Hands [mediaUri] (a content:// URI) to [packageName]'s share screen. */
    suspend fun shareMedia(packageName: String, mediaUri: String, mimeType: String?, caption: String?): DriverResult
}
