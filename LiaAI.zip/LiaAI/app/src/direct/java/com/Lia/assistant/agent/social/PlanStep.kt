package com.Lia.assistant.agent.social

import com.Lia.assistant.agent.core.Expectation
import com.Lia.assistant.agent.core.FailureReason
import com.Lia.assistant.agent.core.ScrollDirection
import com.Lia.assistant.agent.core.TargetSpec

enum class StepKind { LAUNCH_APP, OPEN_LINK, SHARE_MEDIA, CLICK, TYPE, WAIT_FOR, EXTRACT, BACK, SCROLL }

/**
 * One thing to do. [irreversible] steps (publish, send) wait for the user's yes first. A step with
 * [optional] set is skipped when its target is not there. The [finalStep] decides how the task ends: if
 * its effect cannot be verified the task finishes as SUBMITTED_UNVERIFIED.
 */
data class PlanStep(
    val id: String,
    val description: String,
    val kind: StepKind,
    val target: TargetSpec? = null,
    val text: String? = null,
    val expect: Expectation = Expectation.None,
    val irreversible: Boolean = false,
    val optional: Boolean = false,
    val finalStep: Boolean = false,
    val packages: List<String> = emptyList(),
    val url: String? = null,
    val mediaUri: String? = null,
    val mimeType: String? = null,
    val scroll: ScrollDirection? = null,
    /** What to report when this step's target matches several elements. */
    val ambiguousAs: FailureReason = FailureReason.TARGET_AMBIGUOUS,
)
