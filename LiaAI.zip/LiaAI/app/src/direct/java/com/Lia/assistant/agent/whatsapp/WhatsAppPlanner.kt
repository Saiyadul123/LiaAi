package com.Lia.assistant.agent.whatsapp

import com.Lia.assistant.agent.core.Expectation
import com.Lia.assistant.agent.core.FailureReason
import com.Lia.assistant.agent.social.PlanStep
import com.Lia.assistant.agent.social.StepKind
import java.net.URLEncoder

object WhatsAppPlanner {

    /** The steps for every action except READ_UNREAD (which needs no screen). */
    fun plan(request: WhatsAppRequest): List<PlanStep> = when (request.action) {
        WhatsAppAction.READ_UNREAD -> emptyList()
        WhatsAppAction.SEND_MESSAGE -> sendSteps(request)
        WhatsAppAction.READ_CHAT -> openChat(request) + extract("read_messages", "Read the chat")
        WhatsAppAction.SEARCH_CHAT -> searchSteps(request.query.orEmpty()) + extract("read_results", "Read the results")
        WhatsAppAction.MUTE_CHAT -> openChat(request) + muteSteps(request)
        WhatsAppAction.UNMUTE_CHAT -> openChat(request) + unmuteSteps()
        WhatsAppAction.MARK_READ -> openChat(request) + PlanStep(
            // opening a chat marks it read; going back leaves things as they were
            id = "back", description = "Go back", kind = StepKind.BACK, finalStep = true, expect = WhatsAppSelectors.inWhatsApp,
        )
    }

    /** What the user is asked to say yes to. */
    fun summary(request: WhatsAppRequest): String = when (request.action) {
        WhatsAppAction.SEND_MESSAGE -> "Send this WhatsApp message to +${request.phone}: “${request.message.orEmpty().take(200)}”"
        else -> "Do ${request.action.id.replace('_', ' ')} in WhatsApp"
    }

    private fun sendSteps(request: WhatsAppRequest): List<PlanStep> {
        val phone = request.phone.orEmpty()
        val message = request.message.orEmpty()
        val url = "https://wa.me/$phone?text=" + URLEncoder.encode(message, "UTF-8").replace("+", "%20")
        return listOf(
            // straight into the chat by number, with the text already in the box
            PlanStep(
                id = "open_chat", description = "Open the chat", kind = StepKind.OPEN_LINK,
                packages = WhatsAppSelectors.PACKAGES, url = url, expect = WhatsAppSelectors.inWhatsApp,
            ),
            PlanStep(
                id = "wait_chat", description = "Wait for the chat", kind = StepKind.WAIT_FOR,
                expect = Expectation.TargetPresent(WhatsAppSelectors.sendButton),
            ),
            PlanStep(
                id = "send", description = "Send the message", kind = StepKind.CLICK, target = WhatsAppSelectors.sendButton,
                irreversible = true, finalStep = true,
                // the Send button turns into the microphone, and the text is now in a bubble, not in the box
                expect = Expectation.AllOf(
                    listOf(
                        Expectation.TargetGone(WhatsAppSelectors.sendButton),
                        Expectation.TextPresent(message, excludeEditable = true),
                    )
                ),
            ),
        )
    }

    /** Gets to one chat: by number if we have it, otherwise through search (two matches stop the task). */
    private fun openChat(request: WhatsAppRequest): List<PlanStep> {
        if (request.phone != null) {
            return listOf(
                PlanStep(
                    id = "open_chat", description = "Open the chat", kind = StepKind.OPEN_LINK,
                    packages = WhatsAppSelectors.PACKAGES, url = "https://wa.me/${request.phone}",
                    expect = WhatsAppSelectors.inWhatsApp,
                ),
                waitForChat(),
            )
        }
        val name = request.contact.orEmpty()
        return searchSteps(name) + listOf(
            PlanStep(
                id = "pick_chat", description = "Open the chat with $name", kind = StepKind.CLICK,
                target = WhatsAppSelectors.chatResult(name), ambiguousAs = FailureReason.CONTACT_AMBIGUOUS,
                expect = Expectation.TargetPresent(WhatsAppSelectors.messageInput),
            ),
        )
    }

    private fun searchSteps(text: String): List<PlanStep> = listOf(
        PlanStep(
            id = "open_app", description = "Open WhatsApp", kind = StepKind.LAUNCH_APP,
            packages = WhatsAppSelectors.PACKAGES, expect = WhatsAppSelectors.inWhatsApp,
        ),
        PlanStep(
            id = "open_search", description = "Open search", kind = StepKind.CLICK, target = WhatsAppSelectors.searchButton,
            expect = Expectation.TargetPresent(WhatsAppSelectors.searchField),
        ),
        PlanStep(
            id = "type_search", description = "Type the name", kind = StepKind.TYPE, target = WhatsAppSelectors.searchField, text = text,
        ),
    )

    private fun waitForChat() = PlanStep(
        id = "wait_chat", description = "Wait for the chat", kind = StepKind.WAIT_FOR,
        expect = Expectation.TargetPresent(WhatsAppSelectors.messageInput),
    )

    private fun extract(id: String, description: String) = PlanStep(id = id, description = description, kind = StepKind.EXTRACT)

    private fun menuStep() = PlanStep(
        id = "menu", description = "Open the chat menu", kind = StepKind.CLICK, target = WhatsAppSelectors.moreOptions,
        expect = Expectation.AnyOf(
            listOf(
                Expectation.TargetPresent(WhatsAppSelectors.muteItem),
                Expectation.TargetPresent(WhatsAppSelectors.unmuteItem),
            )
        ),
    )

    private fun muteSteps(request: WhatsAppRequest): List<PlanStep> = listOf(
        menuStep(),
        PlanStep(
            id = "mute", description = "Choose Mute notifications", kind = StepKind.CLICK, target = WhatsAppSelectors.muteItem,
            expect = Expectation.TargetPresent(WhatsAppSelectors.okButton),
        ),
        PlanStep(
            id = "duration", description = "Choose ${request.duration.label}", kind = StepKind.CLICK,
            target = WhatsAppSelectors.duration(request.duration),
        ),
        PlanStep(
            id = "ok", description = "Confirm the mute", kind = StepKind.CLICK, target = WhatsAppSelectors.okButton,
            finalStep = true, expect = Expectation.TargetGone(WhatsAppSelectors.okButton),
        ),
    )

    private fun unmuteSteps(): List<PlanStep> = listOf(
        menuStep(),
        PlanStep(
            id = "unmute", description = "Choose Unmute notifications", kind = StepKind.CLICK,
            target = WhatsAppSelectors.unmuteItem, finalStep = true,
            expect = Expectation.TargetGone(WhatsAppSelectors.unmuteItem),
        ),
    )
}
