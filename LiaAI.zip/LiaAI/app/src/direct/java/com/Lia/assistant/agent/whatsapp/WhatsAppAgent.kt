package com.Lia.assistant.agent.whatsapp

import com.Lia.assistant.agent.core.ScreenDriver
import com.Lia.assistant.agent.social.AgentTaskRegistry
import com.Lia.assistant.agent.social.BlockerDetector
import com.Lia.assistant.agent.social.SocialTaskService
import com.Lia.assistant.agent.social.TaskMode
import com.Lia.assistant.agent.social.TaskRunner
import com.Lia.assistant.agent.social.UserSignal
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/**
 * The WhatsApp tools. Reading unread messages uses notifications only and never opens the app. Sending
 * goes straight to the chat by phone number and waits for the user's yes. Anything that needs picking a
 * contact by name stops with "contact_ambiguous" when two contacts match, rather than guessing.
 */
class WhatsAppAgent(
    private val driver: ScreenDriver,
    private val notifications: NotificationSource,
    private val registry: AgentTaskRegistry = AgentTaskRegistry(),
    private val config: TaskRunner.RunnerConfig = TaskRunner.RunnerConfig(),
    private val waiter: suspend (Long) -> Unit = { delay(it) },
) {
    suspend fun execute(args: JSONObject, signal: UserSignal): JSONObject {
        val request = when (val parsed = WhatsAppRequest.parse(args)) {
            is WhatsAppParse.Invalid -> return JSONObject().put("error", parsed.code).put("message", parsed.message)
            is WhatsAppParse.Valid -> parsed.request
        }
        if (request.action == WhatsAppAction.READ_UNREAD) return readUnread()

        registry.active()?.let { return SocialTaskService.busy(it) }
        val runner = TaskRunner(
            taskId = registry.nextId("whatsapp"),
            kind = "whatsapp",
            mode = TaskMode.PUBLISH, // "irreversible" steps (sending) wait for a yes
            appLabel = "WhatsApp",
            plan = WhatsAppPlanner.plan(request),
            driver = driver,
            blockerCheck = BlockerDetector::detect,
            confirmationSummary = WhatsAppPlanner.summary(request),
            config = config,
            waiter = waiter,
        )
        registry.put(runner)
        return runner.start(signal).toJson()
    }

    suspend fun control(args: JSONObject, signal: UserSignal): JSONObject =
        SocialTaskService.controlTask(registry, args, signal, "whatsapp")

    /** Unread messages from notifications, grouped by sender. */
    private fun readUnread(): JSONObject = when (val result = notifications.unread()) {
        UnreadResult.AccessDisabled -> JSONObject()
            .put("result", "notification_access_disabled")
            .put("message", "Notification access is off. The user can switch it on in Android settings so unread messages can be read without opening WhatsApp.")
        is UnreadResult.Ok -> {
            val chats = result.messages.groupBy { it.sender }.entries
                .sortedByDescending { entry -> entry.value.maxOf { it.postedAtMillis } }
                .take(MAX_CHATS)
            val array = JSONArray()
            chats.forEach { (sender, messages) ->
                array.put(
                    JSONObject()
                        .put("sender", sender)
                        .put("count", messages.size)
                        .put("messages", JSONArray(messages.takeLast(MAX_PER_CHAT).map { it.text }))
                )
            }
            JSONObject()
                .put("result", "ok")
                .put("total", result.messages.size)
                .put("chats", array)
        }
    }

    private companion object {
        const val MAX_CHATS = 15
        const val MAX_PER_CHAT = 5
    }
}
