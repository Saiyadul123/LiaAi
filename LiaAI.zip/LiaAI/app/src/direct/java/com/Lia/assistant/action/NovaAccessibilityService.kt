package com.Lia.assistant.action

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** DIRECT flavor only: reads and operates the screen on the user's behalf. */
class NovaAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    // ---- Screen reading ---------------------------------------------------------------------

    /** BFS over visible nodes: unique lines like "[input] Search", "[button] Send", "[text] Hello". */
    fun readScreen(maxElements: Int = 40, maxLabelLength: Int = 40): String {
        val root = rootInActiveWindow ?: return ""
        val collector = ScreenLineCollector(maxElements, maxLabelLength)
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty() && !collector.isFull) {
            val node = queue.removeFirst()
            if (node.isVisibleToUser) {
                val role = when {
                    node.isEditable -> "input"
                    node.isClickable || node.isCheckable -> "button"
                    else -> "text"
                }
                val label = if (node.isEditable) {
                    firstNonBlank(node.text, node.hintText, node.contentDescription)
                } else {
                    firstNonBlank(node.text, node.contentDescription)
                }
                collector.add(role, label)
                for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
            }
            recycle(node)
        }
        queue.forEach { recycle(it) }
        return collector.toText()
    }

    // ---- Actions ----------------------------------------------------------------------------

    /** Clicks the best node whose text/description matches [text] (or its clickable ancestor). */
    fun tapText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val matches = root.findAccessibilityNodeInfosByText(text).orEmpty()
        val ranked = matches.sortedBy { TapMatching.tier(text, it.text, it.contentDescription) }
        var tapped = false
        for (node in ranked) {
            if (!tapped) tapped = clickSelfOrAncestor(node)
        }
        ranked.forEach { recycle(it) }
        recycle(root)
        return tapped
    }

    /** Replaces the text of the currently focused input field. */
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        val typed = focused != null && focused.isEditable && focused.performAction(
            AccessibilityNodeInfo.ACTION_SET_TEXT,
            Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        )
        focused?.let { recycle(it) }
        recycle(root)
        return typed
    }

    /** direction: up, down, left or right. Tries scrollable nodes until one accepts the action. */
    fun scroll(direction: String): Boolean {
        val action = when (direction.trim().lowercase()) {
            "up" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP.id
            "left" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT.id
            "right" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT.id
            else -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.id
        }
        val root = rootInActiveWindow ?: return false
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var scrolled = false
        while (queue.isNotEmpty() && !scrolled) {
            val node = queue.removeFirst()
            if (node.isScrollable && node.performAction(action)) scrolled = true
            if (!scrolled) for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
            recycle(node)
        }
        queue.forEach { recycle(it) }
        return scrolled
    }

    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    // ---- Helpers ----------------------------------------------------------------------------

    private fun clickSelfOrAncestor(start: AccessibilityNodeInfo): Boolean {
        var node: AccessibilityNodeInfo? = start
        var depth = 0
        while (node != null && depth < 8) {
            if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            node = node.parent
            depth++
        }
        return false
    }

    private fun firstNonBlank(vararg values: CharSequence?): CharSequence? =
        values.firstOrNull { !it.isNullOrBlank() }

    @Suppress("DEPRECATION")
    private fun recycle(node: AccessibilityNodeInfo) {
        if (Build.VERSION.SDK_INT < 33) node.recycle()
    }

    companion object {
        /** Set in onServiceConnected, cleared when the service goes away. */
        @Volatile
        var instance: NovaAccessibilityService? = null

        /** True if the service is switched on in Settings > Accessibility. */
        fun isEnabled(context: Context): Boolean = ServiceListing.isListed(
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES),
            context.packageName,
            NovaAccessibilityService::class.java.name,
        )
    }
}
