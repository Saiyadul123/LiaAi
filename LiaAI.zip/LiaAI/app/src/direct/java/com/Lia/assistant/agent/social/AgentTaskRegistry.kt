package com.Lia.assistant.agent.social

/** The tasks of this session. Only one task runs at a time (they share the one screen). */
class AgentTaskRegistry {
    private val tasks = LinkedHashMap<String, TaskRunner>()
    private var counter = 0

    @Synchronized fun nextId(prefix: String): String = "$prefix-${++counter}"

    @Synchronized
    fun put(runner: TaskRunner) {
        tasks[runner.taskId] = runner
        // keep only the last few finished tasks around
        val finished = tasks.values.filter { it.isFinished }
        if (finished.size > 10) finished.dropLast(10).forEach { tasks.remove(it.taskId) }
    }

    /** The task with this id, or the running one when no id is given. */
    @Synchronized fun get(id: String?): TaskRunner? = if (id.isNullOrBlank()) active() ?: tasks.values.lastOrNull() else tasks[id]

    @Synchronized fun active(): TaskRunner? = tasks.values.lastOrNull { !it.isFinished }

    @Synchronized fun size(): Int = tasks.size
}
