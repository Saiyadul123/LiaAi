package com.Lia.assistant.action

/** Collects unique "[role] label" lines for read_screen, capped in count and label length. */
class ScreenLineCollector(
    private val maxElements: Int = 40,
    private val maxLabelLength: Int = 40,
) {
    private val lines = LinkedHashSet<String>()

    val isFull: Boolean get() = lines.size >= maxElements

    /** Returns true if a new line was added (blank labels, duplicates and overflow are skipped). */
    fun add(role: String, label: CharSequence?): Boolean {
        if (isFull) return false
        val clean = label?.toString()?.replace(WHITESPACE, " ")?.trim().orEmpty()
        if (clean.isEmpty()) return false
        val shown = if (clean.length > maxLabelLength) clean.take(maxLabelLength - 1).trimEnd() + "…" else clean
        return lines.add("[$role] $shown")
    }

    fun lines(): List<String> = lines.toList()
    fun toText(): String = lines.joinToString("\n")

    private companion object {
        val WHITESPACE = Regex("\\s+")
    }
}

/** Ranks accessibility nodes for tap_text: exact label < starts with < contains. */
object TapMatching {
    fun tier(query: String, vararg labels: CharSequence?): Int {
        val q = query.trim().lowercase()
        val ls = labels.mapNotNull { it?.toString()?.trim()?.lowercase()?.takeIf { s -> s.isNotEmpty() } }
        return when {
            ls.any { it == q } -> 0
            ls.any { it.startsWith(q) } -> 1
            ls.any { it.contains(q) } -> 2
            else -> 3
        }
    }
}

/** Parsing of Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES ("pkg/cls:pkg/.Cls:..."). */
object ServiceListing {
    fun isListed(setting: String?, packageName: String, className: String): Boolean =
        setting.orEmpty().split(':').any { entry ->
            val slash = entry.indexOf('/')
            if (slash <= 0) {
                false
            } else {
                val pkg = entry.substring(0, slash).trim()
                var cls = entry.substring(slash + 1).trim()
                if (cls.startsWith(".")) cls = pkg + cls
                pkg.equals(packageName, ignoreCase = true) && cls.equals(className, ignoreCase = true)
            }
        }
}
