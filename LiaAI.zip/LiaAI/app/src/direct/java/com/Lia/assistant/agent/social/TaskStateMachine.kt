package com.Lia.assistant.agent.social

enum class TaskState(val isTerminal: Boolean = false) {
    IDLE, OPENING_APP, OBSERVING, RESOLVING_TARGET, VALIDATING_TARGET, EXECUTING_ACTION, WAITING_FOR_UI,
    VERIFYING, NEXT_STEP, RETRY, REOBSERVE, WAITING_FOR_CONFIRMATION, WAITING_FOR_USER,
    COMPLETED(true), FAILED(true), CANCELLED(true),
}

class IllegalTransitionException(val from: TaskState, val to: TaskState) :
    IllegalStateException("illegal task transition: $from -> $to")

data class Transition(val from: TaskState, val to: TaskState, val atMillis: Long, val note: String?)

/**
 * The life of a task. Moves are checked: an illegal one throws. FAILED and CANCELLED can be reached from
 * every state that is not final, and a final state never leaves. Every move is kept in [history].
 */
class TaskStateMachine(
    initial: TaskState = TaskState.IDLE,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    var state: TaskState = initial
        private set

    private val moves = ArrayList<Transition>()
    val history: List<Transition> get() = moves.toList()
    val isTerminal: Boolean get() = state.isTerminal

    fun canMoveTo(next: TaskState): Boolean = next in legalTargets(state)

    /** Moves to [next] or throws [IllegalTransitionException]. */
    fun moveTo(next: TaskState, note: String? = null) {
        if (!canMoveTo(next)) throw IllegalTransitionException(state, next)
        moves += Transition(state, next, clock(), note)
        state = next
    }

    companion object {
        private val FORWARD: Map<TaskState, Set<TaskState>> = mapOf(
            TaskState.IDLE to setOf(TaskState.OPENING_APP),
            TaskState.OPENING_APP to setOf(TaskState.WAITING_FOR_UI, TaskState.OBSERVING, TaskState.RETRY),
            TaskState.OBSERVING to setOf(
                TaskState.RESOLVING_TARGET, TaskState.EXECUTING_ACTION, TaskState.NEXT_STEP,
                TaskState.WAITING_FOR_USER, TaskState.RETRY,
            ),
            TaskState.RESOLVING_TARGET to setOf(
                TaskState.VALIDATING_TARGET, TaskState.NEXT_STEP, TaskState.RETRY, TaskState.REOBSERVE,
                TaskState.WAITING_FOR_USER,
            ),
            TaskState.VALIDATING_TARGET to setOf(
                TaskState.EXECUTING_ACTION, TaskState.WAITING_FOR_CONFIRMATION, TaskState.RETRY, TaskState.REOBSERVE,
            ),
            TaskState.WAITING_FOR_CONFIRMATION to setOf(TaskState.EXECUTING_ACTION),
            TaskState.EXECUTING_ACTION to setOf(
                TaskState.WAITING_FOR_UI, TaskState.VERIFYING, TaskState.RETRY, TaskState.WAITING_FOR_USER,
            ),
            TaskState.WAITING_FOR_UI to setOf(
                TaskState.VERIFYING, TaskState.OBSERVING, TaskState.REOBSERVE, TaskState.RETRY, TaskState.WAITING_FOR_USER,
            ),
            TaskState.VERIFYING to setOf(
                TaskState.NEXT_STEP, TaskState.RETRY, TaskState.REOBSERVE, TaskState.WAITING_FOR_USER,
            ),
            TaskState.NEXT_STEP to setOf(TaskState.OBSERVING, TaskState.OPENING_APP, TaskState.COMPLETED),
            TaskState.RETRY to setOf(TaskState.OBSERVING, TaskState.REOBSERVE, TaskState.OPENING_APP),
            TaskState.REOBSERVE to setOf(TaskState.OBSERVING, TaskState.RESOLVING_TARGET, TaskState.WAITING_FOR_USER),
            TaskState.WAITING_FOR_USER to setOf(TaskState.REOBSERVE, TaskState.OBSERVING, TaskState.OPENING_APP),
            TaskState.COMPLETED to emptySet(),
            TaskState.FAILED to emptySet(),
            TaskState.CANCELLED to emptySet(),
        )

        /** Where [from] may go next. Final states go nowhere; everything else may also fail or be cancelled. */
        fun legalTargets(from: TaskState): Set<TaskState> =
            if (from.isTerminal) emptySet()
            else (FORWARD.getValue(from) + TaskState.FAILED + TaskState.CANCELLED)
    }
}
