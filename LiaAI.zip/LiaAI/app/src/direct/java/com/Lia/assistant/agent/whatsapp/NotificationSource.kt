package com.Lia.assistant.agent.whatsapp

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat
import java.util.concurrent.ConcurrentHashMap

data class UnreadMessage(val sender: String, val text: String, val postedAtMillis: Long)

sealed interface UnreadResult {
    /** The user has not switched on notification access for the assistant. */
    data object AccessDisabled : UnreadResult
    data class Ok(val messages: List<UnreadMessage>) : UnreadResult
}

/** Where unread WhatsApp messages come from: notifications, never the app itself. */
interface NotificationSource {
    fun unread(): UnreadResult
}

object WhatsAppNotificationParser {
    private const val MAX_TEXT = 200
    private val SUMMARY_TEXT = Regex("^\\d+ (new )?messages?( from \\d+ chats?)?$", RegexOption.IGNORE_CASE)
    private val SYSTEM_TEXT = listOf(
        "checking for new messages", "backup in progress", "whatsapp web is currently active",
        "incoming voice call", "incoming video call", "ongoing voice call", "ongoing video call",
    )

    /** A message from a notification, or null for summaries, calls and housekeeping notices. */
    fun parse(title: String, text: String, isGroupSummary: Boolean, postedAtMillis: Long): UnreadMessage? {
        if (isGroupSummary) return null
        val sender = title.trim()
        val body = text.trim()
        if (sender.isEmpty() || body.isEmpty()) return null
        if (SUMMARY_TEXT.matches(body)) return null
        if (SYSTEM_TEXT.any { body.contains(it, ignoreCase = true) }) return null
        return UnreadMessage(sender, body.take(MAX_TEXT), postedAtMillis)
    }
}

/** Unread messages seen in notifications. Kept in memory only and dropped when the listener disconnects. */
object WhatsAppNotificationStore {
    private const val MAX = 100
    private val byKey = ConcurrentHashMap<String, UnreadMessage>()

    fun put(key: String, message: UnreadMessage) {
        byKey[key] = message
        if (byKey.size > MAX) {
            byKey.entries.minByOrNull { it.value.postedAtMillis }?.let { byKey.remove(it.key) }
        }
    }

    fun remove(key: String) {
        byKey.remove(key)
    }

    fun snapshot(): List<UnreadMessage> = byKey.values.sortedBy { it.postedAtMillis }

    fun clear() = byKey.clear()
}

/** The production source: whatever the notification listener has collected, if access is on. */
class NotificationListenerSource(private val context: Context) : NotificationSource {
    override fun unread(): UnreadResult =
        if (isEnabled(context)) UnreadResult.Ok(WhatsAppNotificationStore.snapshot()) else UnreadResult.AccessDisabled

    companion object {
        fun isEnabled(context: Context): Boolean =
            NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
    }
}

/** Collects WhatsApp notifications while the user has granted notification access. */
class LiaNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        activeNotifications?.forEach { onNotificationPosted(it) }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in WhatsAppSelectors.PACKAGES) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val summary = (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0
        WhatsAppNotificationParser.parse(title, text, summary, sbn.postTime)
            ?.let { WhatsAppNotificationStore.put(sbn.key, it) }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        WhatsAppNotificationStore.remove(sbn.key)
    }

    override fun onListenerDisconnected() {
        WhatsAppNotificationStore.clear()
        super.onListenerDisconnected()
    }
}
