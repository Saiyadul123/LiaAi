package com.Lia.assistant.agent.social

import com.Lia.assistant.agent.core.ActionResult
import com.Lia.assistant.agent.core.Blocker
import com.Lia.assistant.agent.core.DriverResult
import com.Lia.assistant.agent.core.ExecConfig
import com.Lia.assistant.agent.core.Expectation
import com.Lia.assistant.agent.core.ExpectationChecker
import com.Lia.assistant.agent.core.FailureReason
import com.Lia.assistant.agent.core.Region
import com.Lia.assistant.agent.core.Resolution
import com.Lia.assistant.agent.core.ScreenDriver
import com.Lia.assistant.agent.core.ScreenObservation
import com.Lia.assistant.agent.core.ScrollDirection
import com.Lia.assistant.agent.core.TargetResolver
import com.Lia.assistant.agent.core.TextInputExecutor
import com.Lia.assistant.agent.core.UiActionExecutor
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Runs a plan against an app, one step at a time, through the [TaskStateMachine].
 *
 * It runs until it has to wait for a person (a blocker, or a confirmation) or until it is finished. [start]
 * and [control] both return the task as it then stands, so a tool call can simply report it.
 *
 * Rules it enforces:
 *  - an irreversible step (publish, send) only runs after CONFIRM, and CONFIRM only works after the user spoke
 *    a yes since the question was asked ([ConfirmationGate]);
 *  - in DRAFT mode an irreversible step is refused outright, so a draft can never publish;
 *  - a blocker (login, CAPTCHA, a code ...) pauses the task for the user, who then says RESUME;
 *  - a delivered click is never repeated, and if the effect of the final step cannot be seen the task ends
 *    as SUBMITTED_UNVERIFIED and says so.
 */
class TaskRunner(
    val taskId: String,
    val kind: String,
    val mode: TaskMode,
    private val appLabel: String,
    private val plan: List<PlanStep>,
    driver: ScreenDriver,
    private val blockerCheck: (ScreenObservation) -> Blocker?,
    private val confirmationSummary: String,
    private val config: RunnerConfig = RunnerConfig(),
    private val waiter: suspend (Long) -> Unit = { delay(it) },
    clock: () -> Long = System::currentTimeMillis,
) {
    data class RunnerConfig(
        val launchWaitMs: Long = 1500,
        val pollAttempts: Int = 6,
        val pollIntervalMs: Long = 500,
        val optionalPolls: Int = 2,
        val maxStepRetries: Int = 2,
        val retryDelayMs: Long = 600,
        val maxExtract: Int = 40,
        val exec: ExecConfig = ExecConfig(),
    )

    private enum class StepOutcome { NEXT, RETRYING, PAUSED, DONE }
    private enum class Resume { NONE, EXECUTE, SKIP_STEP }

    private val driver: ScreenDriver = driver
    val machine = TaskStateMachine(clock = clock)
    private val gate = ConfirmationGate()
    private val executor = UiActionExecutor(driver, blockerCheck, waiter, config.exec)
    private val typer = TextInputExecutor(driver, blockerCheck, waiter, config.exec)
    private val mutex = Mutex()

    private var index = 0
    private var retries = 0
    private var confirmed = false
    private var resume = Resume.NONE
    private var status = TaskStatus.PENDING
    private var message = "Not started yet"
    private var failure: FailureReason? = null
    private var blocker: Blocker? = null
    private var verified: Boolean? = null
    private val data = ArrayList<String>()

    val isFinished: Boolean get() = machine.isTerminal

    fun report(): TaskReport = TaskReport(
        taskId = taskId, kind = kind, status = status, state = machine.state, message = message,
        stepsDone = index.coerceAtMost(plan.size), stepsTotal = plan.size, blocker = blocker, failure = failure,
        confirmationSummary = if (status == TaskStatus.AWAITING_CONFIRMATION) confirmationSummary else null,
        data = data.toList(), verified = verified,
    )

    suspend fun start(signal: UserSignal): TaskReport = mutex.withLock {
        if (machine.state != TaskState.IDLE) return@withLock report()
        status = TaskStatus.RUNNING
        message = "Working on it"
        machine.moveTo(TaskState.OPENING_APP, "start")
        if (plan.isEmpty()) fail(FailureReason.INVALID_INPUT, "there is nothing to do") else runLoop(signal)
        report()
    }

    suspend fun control(command: ControlCommand, signal: UserSignal): ControlOutcome = mutex.withLock {
        when (command) {
            ControlCommand.STATUS -> accepted()

            ControlCommand.CANCEL ->
                if (machine.isTerminal) refused("already_finished", null)
                else {
                    cancel("Cancelled. Nothing more will be done.")
                    accepted()
                }

            ControlCommand.REJECT ->
                if (machine.state != TaskState.WAITING_FOR_CONFIRMATION) refused("not_waiting_for_confirmation", null)
                else {
                    cancel("The user said no, so nothing was ${if (kind == "whatsapp") "sent" else "published"}.")
                    accepted()
                }

            ControlCommand.CONFIRM ->
                if (machine.state != TaskState.WAITING_FOR_CONFIRMATION) {
                    refused("not_waiting_for_confirmation", "There is nothing waiting for a yes.")
                } else {
                    when (gate.evaluate(signal)) {
                        ConfirmCheck.NOT_PENDING ->
                            refused("not_waiting_for_confirmation", "There is nothing waiting for a yes.")
                        ConfirmCheck.NO_USER_REPLY ->
                            refused("confirmation_not_given", "Ask the user and wait for their answer: only confirm after they explicitly say yes.")
                        ConfirmCheck.NOT_AFFIRMATIVE ->
                            refused("confirmation_not_given", "The user's last reply was not a clear yes. Ask again, and only confirm after an explicit yes.")
                        ConfirmCheck.ALLOWED -> {
                            gate.clear()
                            confirmed = true
                            resume = Resume.EXECUTE
                            status = TaskStatus.RUNNING
                            message = "Confirmed, carrying on"
                            machine.moveTo(TaskState.EXECUTING_ACTION, "confirmed")
                            runLoop(signal)
                            accepted()
                        }
                    }
                }

            ControlCommand.RESUME ->
                if (machine.state != TaskState.WAITING_FOR_USER) refused("not_waiting_for_user", null)
                else {
                    blocker = null
                    status = TaskStatus.RUNNING
                    message = "Carrying on"
                    machine.moveTo(TaskState.REOBSERVE, "user resumed")
                    runLoop(signal)
                    accepted()
                }
        }
    }

    private fun accepted() = ControlOutcome(true, null, null, report())
    private fun refused(code: String, hint: String?) = ControlOutcome(false, code, hint, report())

    // ---- the loop -----------------------------------------------------------------------------

    private suspend fun runLoop(signal: UserSignal) {
        while (!machine.isTerminal && !isPaused()) {
            val step = plan.getOrNull(index)
            if (step == null) {
                fail(FailureReason.INVALID_INPUT, "the plan ended without finishing")
                return
            }
            when (runStep(step, signal)) {
                StepOutcome.NEXT, StepOutcome.RETRYING -> Unit
                StepOutcome.PAUSED, StepOutcome.DONE -> return
            }
        }
    }

    private fun isPaused(): Boolean =
        machine.state == TaskState.WAITING_FOR_USER || machine.state == TaskState.WAITING_FOR_CONFIRMATION

    private suspend fun runStep(step: PlanStep, signal: UserSignal): StepOutcome {
        if (resume == Resume.SKIP_STEP) { // the user dealt with a blocker that appeared while this step launched the app
            resume = Resume.NONE
            enterObserving()
            return advance(verified = true)
        }
        return when (step.kind) {
            StepKind.LAUNCH_APP, StepKind.OPEN_LINK, StepKind.SHARE_MEDIA -> runLaunch(step)
            StepKind.CLICK -> runClick(step, signal)
            StepKind.TYPE -> runType(step)
            StepKind.WAIT_FOR -> runWait(step)
            StepKind.EXTRACT -> runExtract(step)
            StepKind.BACK, StepKind.SCROLL -> runNavigate(step)
        }
    }

    private fun enterObserving() {
        if (machine.state != TaskState.OBSERVING) machine.moveTo(TaskState.OBSERVING)
    }

    // ---- steps --------------------------------------------------------------------------------

    private suspend fun runLaunch(step: PlanStep): StepOutcome {
        if (machine.state != TaskState.OPENING_APP) machine.moveTo(TaskState.OPENING_APP, step.id)
        val pkg = step.packages.firstOrNull()
        val result = when (step.kind) {
            StepKind.LAUNCH_APP ->
                if (step.packages.any { driver.launchApp(it) == DriverResult.OK }) DriverResult.OK else DriverResult.FAILED
            StepKind.OPEN_LINK -> step.url?.let { driver.openLink(it, step.packages) } ?: DriverResult.FAILED
            else -> {
                val uri = step.mediaUri
                if (uri == null || pkg == null) DriverResult.FAILED else driver.shareMedia(pkg, uri, step.mimeType, step.text)
            }
        }
        if (result != DriverResult.OK) {
            return retryOrFail(FailureReason.APP_NOT_AVAILABLE, "could not open $appLabel", viaReobserve = false)
        }

        machine.moveTo(TaskState.WAITING_FOR_UI)
        waiter(config.launchWaitMs)
        for (attempt in 0 until config.pollAttempts) {
            if (attempt > 0) waiter(config.pollIntervalMs)
            val observation = driver.capture() ?: continue
            blockerCheck(observation)?.let {
                resume = Resume.SKIP_STEP
                return pauseForBlocker(it)
            }
            if (step.expect == Expectation.None || ExpectationChecker.check(step.expect, null, observation)) {
                machine.moveTo(TaskState.VERIFYING)
                return advance(verified = true)
            }
        }
        return fail(FailureReason.TIMEOUT, "$appLabel did not come up")
    }

    private suspend fun runClick(step: PlanStep, signal: UserSignal): StepOutcome {
        val target = step.target ?: return fail(FailureReason.INVALID_INPUT, "step ${step.id} has no target")
        // A draft must never publish, whatever the plan says.
        if (step.irreversible && mode == TaskMode.DRAFT) return fail(FailureReason.DRAFT_WOULD_PUBLISH, step.description)

        if (resume == Resume.EXECUTE) {
            resume = Resume.NONE // confirmed: straight to the action (the executor looks at the screen again itself)
        } else {
            enterObserving()
            var observation: ScreenObservation? = null
            var resolution: Resolution = Resolution.NotFound
            val attempts = if (step.optional) config.optionalPolls else 1
            for (attempt in 0 until attempts) {
                if (attempt > 0) waiter(config.pollIntervalMs)
                val seen = driver.capture() ?: continue
                blockerCheck(seen)?.let { return pauseForBlocker(it) }
                observation = seen
                resolution = TargetResolver.resolve(seen, target)
                if (resolution !is Resolution.NotFound) break
            }
            val screen = observation ?: return retryOrFail(FailureReason.NO_WINDOW, "no window to read")

            machine.moveTo(TaskState.RESOLVING_TARGET)
            val element = when (val r = resolution) {
                is Resolution.Found -> r.element
                is Resolution.Ambiguous -> return fail(step.ambiguousAs, step.description)
                Resolution.NotFound ->
                    return if (step.optional) skipOptional() else retryOrFail(FailureReason.TARGET_NOT_FOUND, step.description)
            }

            machine.moveTo(TaskState.VALIDATING_TARGET)
            val usable = element.enabled && !element.bounds.isEmpty && element.bounds.intersectsScreen(screen.screenWidth, screen.screenHeight)
            if (!usable) return retryOrFail(FailureReason.TARGET_NOT_FOUND, "${step.description} is not usable right now")

            if (step.irreversible && !confirmed) {
                machine.moveTo(TaskState.WAITING_FOR_CONFIRMATION)
                gate.request(signal)
                status = TaskStatus.AWAITING_CONFIRMATION
                message = "Ready to ${step.description.lowercase()}. Ask the user for a clear yes before confirming."
                return StepOutcome.PAUSED
            }
            machine.moveTo(TaskState.EXECUTING_ACTION)
        }
        return handleResult(step, executor.click(target, step.expect), idempotent = false)
    }

    private suspend fun runType(step: PlanStep): StepOutcome {
        val target = step.target ?: return fail(FailureReason.INVALID_INPUT, "step ${step.id} has no target")
        val text = step.text ?: return fail(FailureReason.INVALID_INPUT, "step ${step.id} has no text")

        enterObserving()
        val screen = driver.capture() ?: return retryOrFail(FailureReason.NO_WINDOW, "no window to read")
        blockerCheck(screen)?.let { return pauseForBlocker(it) }
        machine.moveTo(TaskState.RESOLVING_TARGET)
        when (TargetResolver.resolve(screen, target.copy(requireEditable = true))) {
            is Resolution.Found -> Unit
            is Resolution.Ambiguous -> return fail(step.ambiguousAs, step.description)
            Resolution.NotFound ->
                return if (step.optional) skipOptional() else retryOrFail(FailureReason.TARGET_NOT_FOUND, step.description)
        }
        machine.moveTo(TaskState.VALIDATING_TARGET)
        machine.moveTo(TaskState.EXECUTING_ACTION)
        return handleResult(step, typer.type(target, text), idempotent = true)
    }

    private suspend fun runWait(step: PlanStep): StepOutcome {
        enterObserving()
        for (attempt in 0 until config.pollAttempts) {
            if (attempt > 0) waiter(config.pollIntervalMs)
            val observation = driver.capture() ?: continue
            blockerCheck(observation)?.let { return pauseForBlocker(it) }
            if (ExpectationChecker.check(step.expect, null, observation)) return advance(verified = true)
        }
        return if (step.optional) advance(verified = false) else fail(FailureReason.TIMEOUT, step.description)
    }

    private suspend fun runExtract(step: PlanStep): StepOutcome {
        enterObserving()
        val observation = driver.capture() ?: return retryOrFail(FailureReason.NO_WINDOW, "no window to read")
        blockerCheck(observation)?.let { return pauseForBlocker(it) }
        // the message / result area: readable text between the top bar and the bottom bar, not input fields
        val texts = observation.elements
            .filter { it.text.isNotBlank() && !it.editable }
            .filter { e ->
                val f = e.bounds.centerY.toFloat() / observation.screenHeight.coerceAtLeast(1)
                f >= 0.18f && f <= 0.78f
            }
            .map { it.text.trim() }
            .distinct()
            .take(config.maxExtract)
        data.clear()
        data.addAll(texts)
        return advance(verified = true)
    }

    private suspend fun runNavigate(step: PlanStep): StepOutcome {
        enterObserving()
        val observation = driver.capture() ?: return retryOrFail(FailureReason.NO_WINDOW, "no window to read")
        blockerCheck(observation)?.let { return pauseForBlocker(it) }
        machine.moveTo(TaskState.EXECUTING_ACTION)
        val result = if (step.kind == StepKind.BACK) driver.back() else driver.scroll(step.scroll ?: ScrollDirection.DOWN)
        if (result != DriverResult.OK) return retryOrFail(FailureReason.ACTION_REJECTED, step.description)

        machine.moveTo(TaskState.WAITING_FOR_UI)
        waiter(config.exec.settleMs)
        if (step.expect != Expectation.None) {
            var seen = false
            for (attempt in 0 until config.exec.verifyAttempts) {
                if (attempt > 0) waiter(config.exec.verifyIntervalMs)
                val after = driver.capture() ?: continue
                blockerCheck(after)?.let { return pauseForBlocker(it) }
                if (ExpectationChecker.check(step.expect, observation, after)) {
                    seen = true
                    break
                }
            }
            if (!seen) {
                if (!step.finalStep) return fail(FailureReason.NOT_VERIFIED, step.description)
                machine.moveTo(TaskState.VERIFYING)
                return finishUnverified(step)
            }
        }
        machine.moveTo(TaskState.VERIFYING)
        return advance(verified = step.expect != Expectation.None)
    }

    // ---- results ------------------------------------------------------------------------------

    private suspend fun handleResult(step: PlanStep, result: ActionResult, idempotent: Boolean): StepOutcome = when (result) {
        is ActionResult.Success -> {
            machine.moveTo(TaskState.WAITING_FOR_UI)
            machine.moveTo(TaskState.VERIFYING)
            // a final step whose effect could not even be checked is reported as unverified
            if (step.finalStep && step.expect == Expectation.None) finishUnverified(step)
            else advance(verified = step.expect != Expectation.None)
        }
        is ActionResult.Blocked -> pauseForBlocker(result.blocker)
        is ActionResult.Failed -> {
            val reason = result.reason
            when {
                reason == FailureReason.NOT_VERIFIED && step.finalStep -> {
                    machine.moveTo(TaskState.WAITING_FOR_UI)
                    machine.moveTo(TaskState.VERIFYING)
                    finishUnverified(step)
                }
                reason == FailureReason.NOT_VERIFIED && step.optional -> {
                    machine.moveTo(TaskState.WAITING_FOR_UI)
                    machine.moveTo(TaskState.VERIFYING)
                    advance(verified = false)
                }
                // typing replaces the field's text, so doing it again is harmless; a delivered click is never repeated
                reason == FailureReason.NOT_VERIFIED && idempotent -> retryOrFail(reason, result.detail)
                reason == FailureReason.NOT_VERIFIED -> fail(reason, step.description)
                reason in RETRYABLE -> retryOrFail(reason, result.detail)
                else -> fail(reason, result.detail)
            }
        }
    }

    private fun advance(verified: Boolean): StepOutcome {
        retries = 0
        confirmed = false
        resume = Resume.NONE
        index++
        machine.moveTo(TaskState.NEXT_STEP)
        if (index < plan.size) return StepOutcome.NEXT

        machine.moveTo(TaskState.COMPLETED)
        this.verified = verified
        status = if (mode == TaskMode.DRAFT && kind == "social") TaskStatus.DRAFT_SAVED else TaskStatus.COMPLETED
        message = when {
            status == TaskStatus.DRAFT_SAVED -> "Saved as a draft in $appLabel. Nothing was published."
            verified -> "Done in $appLabel."
            else -> "Done in $appLabel, though I could not confirm the last step on screen."
        }
        return StepOutcome.DONE
    }

    private fun finishUnverified(step: PlanStep): StepOutcome {
        index = plan.size
        machine.moveTo(TaskState.NEXT_STEP, "unverified")
        machine.moveTo(TaskState.COMPLETED, "unverified")
        status = TaskStatus.SUBMITTED_UNVERIFIED
        verified = false
        message = "I did '${step.description.lowercase()}' in $appLabel but could not confirm that it worked. " +
            "Please check $appLabel yourself before trying again."
        return StepOutcome.DONE
    }

    private fun skipOptional(): StepOutcome {
        when (machine.state) {
            TaskState.OBSERVING, TaskState.RESOLVING_TARGET -> Unit
            TaskState.RETRY, TaskState.REOBSERVE -> machine.moveTo(TaskState.OBSERVING)
            else -> {
                machine.moveTo(TaskState.RETRY)
                machine.moveTo(TaskState.OBSERVING)
            }
        }
        return advance(verified = false)
    }

    private suspend fun retryOrFail(reason: FailureReason, detail: String?, viaReobserve: Boolean = true): StepOutcome {
        if (retries >= config.maxStepRetries) {
            return if (plan.getOrNull(index)?.optional == true) skipOptional() else fail(reason, detail)
        }
        retries++
        machine.moveTo(TaskState.RETRY, reason.code)
        waiter(config.retryDelayMs)
        if (viaReobserve) machine.moveTo(TaskState.REOBSERVE)
        return StepOutcome.RETRYING
    }

    private fun pauseForBlocker(found: Blocker): StepOutcome {
        machine.moveTo(TaskState.WAITING_FOR_USER, found.name)
        blocker = found
        status = TaskStatus.AWAITING_USER
        message = blockerMessage(found)
        return StepOutcome.PAUSED
    }

    private fun blockerMessage(b: Blocker): String = when (b) {
        Blocker.LOGIN -> "$appLabel is asking you to log in. Please log in yourself, then tell me to continue."
        Blocker.CAPTCHA -> "$appLabel is showing a CAPTCHA. Please solve it yourself, then tell me to continue."
        Blocker.TWO_FACTOR -> "$appLabel wants a security code. Please enter it yourself, then tell me to continue."
        Blocker.SECURITY_CHECK -> "$appLabel is running a security check. Please deal with it yourself, then tell me to continue."
        Blocker.PERMISSION_PROMPT -> "Android is asking for a permission. Please answer it yourself, then tell me to continue."
    }

    private fun fail(reason: FailureReason, detail: String?): StepOutcome {
        machine.moveTo(TaskState.FAILED, reason.code)
        status = TaskStatus.FAILED
        failure = reason
        message = failureMessage(reason, detail)
        return StepOutcome.DONE
    }

    private fun cancel(text: String) {
        machine.moveTo(TaskState.CANCELLED)
        status = TaskStatus.CANCELLED
        message = text
    }

    private fun failureMessage(reason: FailureReason, detail: String?): String {
        val what = detail?.takeIf { it.isNotBlank() }?.let { " ($it)" }.orEmpty()
        return when (reason) {
            FailureReason.CONTACT_AMBIGUOUS -> "More than one contact matches. Ask the user which one, by full name or phone number."
            FailureReason.TARGET_AMBIGUOUS -> "Several things on the screen matched$what, so I did not guess."
            FailureReason.TARGET_NOT_FOUND -> "I could not find what I needed on the screen$what. The app may look different from what I expect."
            FailureReason.NO_WINDOW -> "I cannot see the screen. Is screen control switched on?"
            FailureReason.APP_NOT_AVAILABLE -> "I could not open $appLabel. Is it installed?"
            FailureReason.DRAFT_WOULD_PUBLISH -> "This was a draft, so I refused to publish."
            FailureReason.TIMEOUT -> "Timed out waiting for $appLabel$what."
            FailureReason.NOT_VERIFIED -> "I did it but could not see it work$what."
            FailureReason.UNSUPPORTED -> "Screen control is not available right now."
            FailureReason.ACTION_REJECTED -> "The app did not accept the tap$what."
            FailureReason.STALE_OBSERVATION -> "The screen kept changing under me$what."
            FailureReason.INVALID_INPUT -> "Something was wrong with the request$what."
        }
    }

    private companion object {
        val RETRYABLE = setOf(
            FailureReason.TARGET_NOT_FOUND, FailureReason.NO_WINDOW,
            FailureReason.ACTION_REJECTED, FailureReason.STALE_OBSERVATION,
        )
    }
}
