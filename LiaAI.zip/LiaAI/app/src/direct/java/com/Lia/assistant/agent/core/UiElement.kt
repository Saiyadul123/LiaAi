package com.Lia.assistant.agent.core

data class Bounds(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
    val centerX: Int get() = (left + right) / 2
    val centerY: Int get() = (top + bottom) / 2
    val isEmpty: Boolean get() = width <= 0 || height <= 0
    fun intersectsScreen(screenWidth: Int, screenHeight: Int): Boolean =
        right > 0 && bottom > 0 && left < screenWidth && top < screenHeight
}

/** One node as read from the device, before it is filtered and numbered. */
data class RawNode(
    val text: String,
    val contentDescription: String,
    val hint: String,
    val viewId: String,
    val className: String,
    val bounds: Bounds,
    val clickable: Boolean,
    val editable: Boolean,
    val scrollable: Boolean,
    val enabled: Boolean,
    val focused: Boolean,
    val checked: Boolean?,
    /** Child indexes from the window root, so the live node can be found again. */
    val path: List<Int>,
    /** True when an ancestor is clickable and this node is not (clicking it clicks the ancestor). */
    val clickableAncestor: Boolean,
    val visibleToUser: Boolean,
)

/** A raw read of the active window. */
data class CapturedScreen(
    val packageName: String,
    val windowClass: String,
    val nodes: List<RawNode>,
    val screenWidth: Int,
    val screenHeight: Int,
    val windowStamp: Long,
)

data class UiElement(
    val id: Int,
    val text: String,
    val contentDescription: String,
    val hint: String,
    val viewId: String,
    val className: String,
    val bounds: Bounds,
    val clickable: Boolean,
    val editable: Boolean,
    val scrollable: Boolean,
    val enabled: Boolean,
    val focused: Boolean,
    val checked: Boolean?,
    val path: List<Int>,
    val clickableAncestor: Boolean = false,
) {
    /** What a person would call this element. */
    val label: String get() = text.ifEmpty { contentDescription }.ifEmpty { hint }
    val isTappable: Boolean get() = clickable || clickableAncestor
}

/** What is on screen right now. [observationId] grows with every observation: only the latest is trusted. */
data class ScreenObservation(
    val observationId: Long,
    val packageName: String,
    val windowClass: String,
    val elements: List<UiElement>,
    val screenWidth: Int,
    val screenHeight: Int,
    val windowStamp: Long,
) {
    /** All readable text on screen (texts, descriptions and hints). */
    fun allText(): List<String> = elements.flatMap { listOf(it.text, it.contentDescription, it.hint) }.filter { it.isNotBlank() }
}
