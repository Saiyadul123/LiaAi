package com.Lia.assistant.agent.social

import com.Lia.assistant.agent.core.Expectation
import com.Lia.assistant.agent.core.TargetSpec

/**
 * What to look for on each platform's screens. These are text-based and written for the English app; the
 * apps change their screens often, so expect to adjust them. A wrong guess ends the task with a clear
 * "could not find" instead of a wrong tap.
 */
class PlatformSelectors(
    val destinationFeed: TargetSpec,
    val destinationReel: TargetSpec,
    val destinationStory: TargetSpec,
    val next: TargetSpec,
    val captionField: TargetSpec,
    val publish: TargetSpec,
    val saveDraft: TargetSpec,
    val composeEntry: TargetSpec,
    /** Words that show up while or after a post is going out. */
    val publishedMarkers: List<String>,
) {
    fun destination(action: SocialAction): TargetSpec = when (action) {
        SocialAction.CREATE_POST, SocialAction.TEXT_POST -> destinationFeed
        SocialAction.CREATE_REEL -> destinationReel
        SocialAction.CREATE_STORY -> destinationStory
    }

    /** The publish button is gone AND the app says something about posting. */
    val publishedExpectation: Expectation = Expectation.AllOf(
        listOf(
            Expectation.TargetGone(publish),
            Expectation.AnyOf(publishedMarkers.map { Expectation.TextPresent(it) }),
        )
    )
}

object SocialSelectors {
    private fun tappable(vararg labels: String, description: String) =
        TargetSpec(labels = labels.toList(), requireTappable = true, description = description)

    val instagram = PlatformSelectors(
        destinationFeed = tappable("Feed", "New post", description = "the Feed option"),
        destinationReel = tappable("Reels", "Reel", "New reel", description = "the Reels option"),
        destinationStory = tappable("Your story", "Story", description = "the Story option"),
        next = tappable("Next", description = "the Next button"),
        captionField = TargetSpec(
            labels = listOf("Write a caption", "Add a caption"),
            viewIds = listOf("caption_text_view"),
            requireEditable = true,
            description = "the caption field",
        ),
        publish = tappable("Share", "Post", description = "the Share button"),
        saveDraft = tappable("Save draft", "Save as draft", description = "the Save draft option"),
        composeEntry = tappable("New post", description = "the new post button"),
        publishedMarkers = listOf("sharing", "posting", "shared", "uploading", "your post", "your reel"),
    )

    val facebook = PlatformSelectors(
        destinationFeed = tappable("News Feed", "Feed", description = "the News Feed option"),
        destinationReel = tappable("Reels", "Reel", description = "the Reels option"),
        destinationStory = tappable("Your story", "Story", description = "the Story option"),
        next = tappable("Next", description = "the Next button"),
        captionField = TargetSpec(
            labels = listOf("Say something about this", "What's on your mind"),
            requireEditable = true,
            description = "the text field",
        ),
        publish = tappable("Post", "Share now", description = "the Post button"),
        saveDraft = tappable("Save as draft", "Save draft", description = "the Save as draft option"),
        composeEntry = tappable("What's on your mind", description = "the \"What's on your mind?\" box"),
        publishedMarkers = listOf("posting", "posted", "shared", "uploading", "your post"),
    )

    fun forPlatform(platform: Platform): PlatformSelectors = when (platform) {
        Platform.INSTAGRAM -> instagram
        Platform.FACEBOOK -> facebook
    }
}
