package com.Lia.assistant.agent.core

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.Lia.assistant.action.AppLauncher
import com.Lia.assistant.action.CommIntents
import com.Lia.assistant.action.NovaAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * The production [ScreenDriver]: reads and operates the screen through [NovaAccessibilityService]. When the
 * service is not running every device action reports UNSUPPORTED. Reads and taps run off the main thread.
 * (Launching an app from the background can be refused by Android; that shows up as FAILED.)
 */
class AccessibilityScreenDriver(
    private val context: Context,
    private val service: () -> NovaAccessibilityService? = { NovaAccessibilityService.instance },
    val observer: ScreenObserver = ScreenObserver(),
) : ScreenDriver {

    override suspend fun capture(): ScreenObservation? = withContext(Dispatchers.IO) {
        service()?.captureScreen()?.let { observer.observe(it) }
    }

    override suspend fun clickElement(observation: ScreenObservation, element: UiElement): DriverResult =
        withContext(Dispatchers.IO) {
            val s = service() ?: return@withContext DriverResult.UNSUPPORTED
            if (!observer.isLatest(observation)) return@withContext DriverResult.STALE
            if (s.clickAtPath(element.path)) DriverResult.OK else DriverResult.FAILED
        }

    override suspend fun gestureTap(x: Int, y: Int): DriverResult {
        val s = service() ?: return DriverResult.UNSUPPORTED
        return if (s.tapAt(x.toFloat(), y.toFloat())) DriverResult.OK else DriverResult.FAILED
    }

    override suspend fun setText(text: String): DriverResult = withContext(Dispatchers.IO) {
        val s = service() ?: return@withContext DriverResult.UNSUPPORTED
        if (s.typeText(text)) DriverResult.OK else DriverResult.FAILED
    }

    override suspend fun scroll(direction: ScrollDirection): DriverResult = withContext(Dispatchers.IO) {
        val s = service() ?: return@withContext DriverResult.UNSUPPORTED
        if (s.scroll(direction.name.lowercase())) DriverResult.OK else DriverResult.FAILED
    }

    override suspend fun back(): DriverResult {
        val s = service() ?: return DriverResult.UNSUPPORTED
        return if (s.back()) DriverResult.OK else DriverResult.FAILED
    }

    override suspend fun home(): DriverResult {
        val s = service() ?: return DriverResult.UNSUPPORTED
        return if (s.home()) DriverResult.OK else DriverResult.FAILED
    }

    override suspend fun launchApp(packageName: String): DriverResult =
        if (AppLauncher.launch(context, packageName)) DriverResult.OK else DriverResult.FAILED

    override suspend fun openLink(url: String, packageNames: List<String>): DriverResult {
        val installed = packageNames.firstOrNull { CommIntents.isInstalled(context, it) } ?: return DriverResult.NOT_FOUND
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        intent.setPackage(installed)
        return if (CommIntents.start(context, intent)) DriverResult.OK else DriverResult.FAILED
    }

    override suspend fun shareMedia(packageName: String, mediaUri: String, mimeType: String?, caption: String?): DriverResult {
        if (!CommIntents.isInstalled(context, packageName)) return DriverResult.NOT_FOUND
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = mimeType ?: "*/*"
        intent.putExtra(Intent.EXTRA_STREAM, Uri.parse(mediaUri))
        if (!caption.isNullOrBlank()) intent.putExtra(Intent.EXTRA_TEXT, caption)
        intent.setPackage(packageName)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return if (CommIntents.start(context, intent)) DriverResult.OK else DriverResult.FAILED
    }
}
