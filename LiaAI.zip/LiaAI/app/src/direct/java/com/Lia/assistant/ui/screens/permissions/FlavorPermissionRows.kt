package com.Lia.assistant.ui.screens.permissions

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.Lia.assistant.action.NovaAccessibilityService
import com.Lia.assistant.ui.components.NovaSettingsRow
import com.Lia.assistant.ui.fx.OverlayEdgeGlowController
import com.Lia.assistant.ui.screens.common.RowDivider

/** DIRECT flavor: screen control and the "display over other apps" permission. */
@Composable
fun FlavorPermissionRows(refreshKey: Int, assistantName: String, onOpenDisclosure: () -> Unit) {
    val context = LocalContext.current
    val screenControl = remember(refreshKey) { NovaAccessibilityService.isEnabled(context) }
    val overlay = remember(refreshKey) { OverlayEdgeGlowController.canDraw(context) }

    RowDivider()
    NovaSettingsRow(
        title = "Screen control",
        icon = Icons.Rounded.AccessibilityNew,
        subtitle = "Lets $assistantName read, tap and type for you",
        value = if (screenControl) "On" else "Off",
        onClick = onOpenDisclosure,
    )
    RowDivider()
    NovaSettingsRow(
        title = "Display over other apps",
        icon = Icons.Rounded.Layers,
        subtitle = "Shows the listening glow above other apps",
        value = if (overlay) "Allowed" else "Off",
        onClick = {
            OverlayEdgeGlowController.permissionIntent(context)?.let { context.startActivity(it) }
        },
    )
}
