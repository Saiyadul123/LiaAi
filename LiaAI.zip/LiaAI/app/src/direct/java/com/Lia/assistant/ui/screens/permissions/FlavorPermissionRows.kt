package com.Lia.assistant.ui.screens.permissions

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.NotificationsActive
import android.content.Intent
import android.provider.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.Lia.assistant.action.NovaAccessibilityService
import com.Lia.assistant.agent.whatsapp.NotificationListenerSource
import com.Lia.assistant.ui.fx.OverlayEdgeGlowController
import com.Lia.assistant.ui.screens.common.RowDivider

/** DIRECT flavor: screen control and the "display over other apps" permission, with the same status lights. */
@Composable
fun FlavorPermissionRows(refreshKey: Int, assistantName: String, onOpenDisclosure: () -> Unit) {
    val context = LocalContext.current
    val screenControl = remember(refreshKey) { NovaAccessibilityService.isEnabled(context) }
    val overlay = remember(refreshKey) { OverlayEdgeGlowController.canDraw(context) }
    val notificationAccess = remember(refreshKey) { NotificationListenerSource.isEnabled(context) }

    RowDivider()
    PermissionRow(
        title = "Screen control",
        subtitle = "Lets $assistantName read, tap and type for you",
        icon = Icons.Rounded.AccessibilityNew,
        light = if (screenControl) PermissionLight.GRANTED else PermissionLight.CAN_ASK,
        onClick = onOpenDisclosure,
    )
    RowDivider()
    PermissionRow(
        title = "Display over other apps",
        subtitle = "Shows the listening glow above other apps",
        icon = Icons.Rounded.Layers,
        light = if (overlay) PermissionLight.GRANTED else PermissionLight.CAN_ASK,
        onClick = { OverlayEdgeGlowController.permissionIntent(context)?.let { context.startActivity(it) } },
    )
    RowDivider()
    PermissionRow(
        title = "Notification access",
        subtitle = "Lets $assistantName read unread WhatsApp messages without opening the app",
        icon = Icons.Rounded.NotificationsActive,
        light = if (notificationAccess) PermissionLight.GRANTED else PermissionLight.CAN_ASK,
        onClick = {
            val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        },
    )
}
