package com.Lia.assistant.agent.social

enum class ControlCommand {
    /** The user said yes: carry out the irreversible step. */
    CONFIRM,
    /** The user said no. */
    REJECT,
    /** The user dealt with a blocker (logged in, entered a code ...). */
    RESUME,
    CANCEL,
    STATUS;

    companion object {
        fun parse(value: String?): ControlCommand? = entries.firstOrNull { it.name.equals(value?.trim(), ignoreCase = true) }
    }
}

/**
 * What the app knows about the user's speech: how many things the user has said so far and the last of them.
 * It is how a confirmation is checked against an actual "yes".
 */
data class UserSignal(val userTurns: Int, val lastUserText: String)

object ConsentCheck {
    private val NO_WORDS = setOf(
        "no", "nope", "nah", "not", "dont", "don't", "stop", "cancel", "wait", "hold", "nahi", "nahin", "mat", "reject",
    )
    private val YES_WORDS = setOf(
        "yes", "yeah", "yep", "yup", "sure", "ok", "okay", "confirm", "confirmed", "haan", "haa", "han", "ha",
        "bilkul", "theek", "thik", "publish", "proceed", "हाँ", "हां", "ठीक", "बिल्कुल",
    )
    private val YES_PHRASES = listOf("go ahead", "do it", "post it", "send it", "kar do", "kardo", "karo", "कर दो", "करो")

    /** A clear yes, and no "no" anywhere in the same sentence. */
    fun isAffirmative(text: String): Boolean {
        val normalized = text.lowercase().replace('\u2019', '\'').replace(Regex("[^\\p{L}\\p{M}\\p{N}' ]"), " ").replace(Regex("\\s+"), " ").trim()
        if (normalized.isEmpty()) return false
        val words = normalized.split(' ')
        if (words.any { it in NO_WORDS }) return false
        return words.any { it in YES_WORDS } || YES_PHRASES.any { normalized.contains(it) }
    }
}

enum class ConfirmCheck { ALLOWED, NOT_PENDING, NO_USER_REPLY, NOT_AFFIRMATIVE }

/**
 * Lets a confirmation through only when the user has spoken since it was asked for AND what they said
 * was a yes. A model that calls "confirm" on its own is refused.
 */
class ConfirmationGate {
    private var turnsWhenAsked: Int? = null

    fun request(signal: UserSignal) {
        turnsWhenAsked = signal.userTurns
    }

    fun evaluate(signal: UserSignal): ConfirmCheck {
        val asked = turnsWhenAsked ?: return ConfirmCheck.NOT_PENDING
        if (signal.userTurns <= asked) return ConfirmCheck.NO_USER_REPLY
        return if (ConsentCheck.isAffirmative(signal.lastUserText)) ConfirmCheck.ALLOWED else ConfirmCheck.NOT_AFFIRMATIVE
    }

    fun clear() {
        turnsWhenAsked = null
    }
}
