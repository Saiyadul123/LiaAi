package com.Lia.assistant.agent.whatsapp

import com.Lia.assistant.agent.core.Expectation
import com.Lia.assistant.agent.core.Region
import com.Lia.assistant.agent.core.TargetSpec

/** What to look for in WhatsApp (English UI, best effort: the app changes its screens now and then). */
object WhatsAppSelectors {
    val PACKAGES = listOf("com.whatsapp", "com.whatsapp.w4b")

    private fun tappable(vararg labels: String, description: String, region: Region? = null) =
        TargetSpec(labels = labels.toList(), requireTappable = true, region = region, description = description)

    val searchButton = tappable("Search", description = "the search button", region = Region.TOP_BAR)

    val searchField = TargetSpec(
        labels = listOf("Search"), viewIds = listOf("search_input"), requireEditable = true,
        description = "the search box",
    )

    /** A chat in the results. Two chats matching equally well are reported as ambiguous. */
    fun chatResult(name: String) = TargetSpec(
        labels = listOf(name), requireTappable = true, excludeEditable = true, requireUnique = true,
        region = Region.BELOW_TOP_BAR, description = "the chat with $name",
    )

    val messageInput = TargetSpec(
        labels = listOf("Type a message", "Message"), requireEditable = true, description = "the message box",
    )

    val sendButton = tappable("Send", description = "the Send button")
    val moreOptions = tappable("More options", description = "the menu", region = Region.TOP_BAR)
    val muteItem = tappable("Mute notifications", "Mute", description = "Mute notifications")
    val unmuteItem = tappable("Unmute notifications", "Unmute", description = "Unmute notifications")
    val okButton = tappable("OK", description = "the OK button")

    fun duration(d: MuteDuration) = tappable(d.label, description = d.label)

    val inWhatsApp: Expectation = Expectation.AnyOf(PACKAGES.map { Expectation.PackageIs(it) })
}
