package com.Lia.assistant.agent.social

import com.Lia.assistant.agent.core.Blocker
import com.Lia.assistant.agent.core.FailureReason
import org.json.JSONArray
import org.json.JSONObject

/** A snapshot of a task, in the form the model reads. */
data class TaskReport(
    val taskId: String,
    val kind: String,
    val status: TaskStatus,
    val state: TaskState,
    val message: String,
    val stepsDone: Int,
    val stepsTotal: Int,
    val blocker: Blocker? = null,
    val failure: FailureReason? = null,
    val confirmationSummary: String? = null,
    val data: List<String> = emptyList(),
    /** True: the effect was seen. False: the last step was done but could not be confirmed. Null: not finished. */
    val verified: Boolean? = null,
) {
    val needsUser: Boolean get() = status == TaskStatus.AWAITING_USER || status == TaskStatus.AWAITING_CONFIRMATION

    fun toJson(): JSONObject {
        val json = JSONObject()
            .put("result", status.code)
            .put("task_id", taskId)
            .put("state", state.name.lowercase())
            .put("message", message)
            .put("steps_done", stepsDone)
            .put("steps_total", stepsTotal)
        blocker?.let { json.put("blocker", it.name.lowercase()) }
        failure?.let { json.put("reason", it.code) }
        confirmationSummary?.let { json.put("confirmation_summary", it) }
        if (needsUser) json.put("needs_user", true)
        if (data.isNotEmpty()) json.put("data", JSONArray(data))
        verified?.let { json.put("verified", it) }
        return json
    }
}

/** The answer to a control command: whether it was accepted, why not, and the task as it now stands. */
data class ControlOutcome(
    val accepted: Boolean,
    val error: String?,
    val hint: String?,
    val report: TaskReport,
) {
    fun toJson(): JSONObject {
        val json = report.toJson()
        if (!accepted) {
            json.put("accepted", false)
            error?.let { json.put("error", it) }
            hint?.let { json.put("hint", it) }
        }
        return json
    }
}
