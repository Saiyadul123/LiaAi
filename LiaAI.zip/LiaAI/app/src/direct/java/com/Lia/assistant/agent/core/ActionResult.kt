package com.Lia.assistant.agent.core

sealed interface ActionResult {
    data class Success(val method: ActionMethod, val observation: ScreenObservation?) : ActionResult
    data class Failed(val reason: FailureReason, val detail: String? = null) : ActionResult
    /** Something only the user can do is in the way. */
    data class Blocked(val blocker: Blocker) : ActionResult
}
