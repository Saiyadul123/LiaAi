package com.Lia.assistant.agent.social

/**
 * The files the user has shared to Lia (through the Android share sheet, see ShareToLiaActivity). Held in
 * memory only, so they last as long as the app process does.
 */
object SharedMedia {
    data class Entry(val uri: String, val mimeType: String?, val displayName: String, val addedAtMillis: Long)

    private const val MAX = 20
    private val entries = LinkedHashMap<String, Entry>()

    @Synchronized
    fun register(uri: String, mimeType: String?, displayName: String, now: Long = System.currentTimeMillis()) {
        entries.remove(uri)
        entries[uri] = Entry(uri, mimeType, displayName, now)
        while (entries.size > MAX) entries.remove(entries.keys.first())
    }

    @Synchronized fun get(uri: String): Entry? = entries[uri]
    @Synchronized fun latest(): Entry? = entries.values.lastOrNull()
    @Synchronized fun clear() = entries.clear()
}

/**
 * Decides which media the agent may use: only content:// URIs that were shared to Lia. Anything else
 * (file paths, web links, URIs from other apps) is refused.
 */
class MediaResolver(private val lookup: (String) -> SharedMedia.Entry? = SharedMedia::get, private val latest: () -> SharedMedia.Entry? = SharedMedia::latest) {

    sealed interface Result {
        data class Allowed(val uri: String, val mimeType: String?, val displayName: String) : Result
        data class Rejected(val code: String, val message: String) : Result
    }

    /** [uri] is a content:// URI, or "latest" for the file shared most recently. */
    fun resolve(uri: String?): Result {
        val wanted = uri?.trim().orEmpty()
        if (wanted.isEmpty()) return Result.Rejected("media_required", "this action needs media_uri: ask the user to share the file to the assistant first")
        val entry = if (wanted.equals("latest", ignoreCase = true)) {
            latest() ?: return Result.Rejected("media_not_shared", "nothing has been shared yet: ask the user to share the file to the assistant")
        } else {
            if (!wanted.startsWith("content://")) {
                return Result.Rejected("media_not_content_uri", "media_uri must be a content:// URI of a file shared to the assistant")
            }
            lookup(wanted) ?: return Result.Rejected("media_not_shared", "that file was not shared to the assistant: ask the user to share it")
        }
        return Result.Allowed(entry.uri, entry.mimeType, entry.displayName)
    }
}
