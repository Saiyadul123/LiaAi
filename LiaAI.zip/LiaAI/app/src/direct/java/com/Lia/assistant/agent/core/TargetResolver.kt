package com.Lia.assistant.agent.core

/** Rough area of the screen an element must be in, by the vertical position of its centre. */
enum class Region { TOP_BAR, BOTTOM_BAR, BELOW_TOP_BAR, ABOVE_BOTTOM_BAR }

/**
 * What to look for. [labels] are alternative wordings (any of them), [viewIds] resource ids without the
 * package prefix. With [requireUnique], two equally good matches are reported as ambiguous instead of
 * picking one.
 */
data class TargetSpec(
    val labels: List<String> = emptyList(),
    val viewIds: List<String> = emptyList(),
    val classNames: List<String> = emptyList(),
    val requireEditable: Boolean = false,
    val requireTappable: Boolean = false,
    /** Skip input fields (so a search box holding the typed name is not mistaken for a result). */
    val excludeEditable: Boolean = false,
    val packageName: String? = null,
    val region: Region? = null,
    val requireUnique: Boolean = false,
    val description: String = "",
)

sealed interface Resolution {
    data class Found(val element: UiElement, val score: Int) : Resolution
    data object NotFound : Resolution
    data class Ambiguous(val candidates: List<UiElement>) : Resolution
}

object TargetResolver {
    private const val SCORE_VIEW_ID = 100
    private const val SCORE_EXACT = 80
    private const val SCORE_PREFIX = 50
    private const val SCORE_CONTAINS = 25
    private const val SCORE_CLASS = 10

    fun resolve(observation: ScreenObservation, spec: TargetSpec): Resolution {
        if (spec.packageName != null && observation.packageName != spec.packageName) return Resolution.NotFound
        val scored = observation.elements.mapNotNull { e -> score(e, observation, spec)?.let { e to it } }
        if (scored.isEmpty()) return Resolution.NotFound

        val best = scored.maxOf { it.second }
        val top = scored.filter { it.second == best }.map { it.first }.distinctBy { it.bounds }
        if (spec.requireUnique && top.size > 1) return Resolution.Ambiguous(top)
        // equally good: prefer the smaller (more specific) element, then the higher, then the leftmost
        val chosen = top.sortedWith(
            compareBy<UiElement>({ it.bounds.width * it.bounds.height }, { it.bounds.top }, { it.bounds.left })
        ).first()
        return Resolution.Found(chosen, best)
    }

    private fun score(e: UiElement, obs: ScreenObservation, spec: TargetSpec): Int? {
        if (spec.requireEditable && !e.editable) return null
        if (spec.excludeEditable && e.editable) return null
        if (spec.requireTappable && (!e.isTappable || !e.enabled)) return null
        if (!inRegion(e, obs, spec.region)) return null

        val idScore = if (spec.viewIds.any { idMatches(e.viewId, it) }) SCORE_VIEW_ID else 0
        val labelScore = labelScore(e, spec.labels)
        val needsMatch = spec.labels.isNotEmpty() || spec.viewIds.isNotEmpty()
        if (needsMatch && idScore == 0 && labelScore == 0) return null

        var total = idScore + labelScore
        if (spec.classNames.isNotEmpty()) {
            if (spec.classNames.any { e.className.contains(it, ignoreCase = true) }) total += SCORE_CLASS
            else if (!needsMatch) return null
        }
        if (!needsMatch && spec.classNames.isEmpty() && !spec.requireEditable && !spec.requireTappable) return null
        return total + (if (e.isTappable) 5 else 0) + 1
    }

    private fun idMatches(viewId: String, wanted: String): Boolean =
        viewId.isNotEmpty() && (viewId == wanted || viewId.endsWith(":id/$wanted") || viewId.endsWith("/$wanted"))

    private fun labelScore(e: UiElement, labels: List<String>): Int {
        if (labels.isEmpty()) return 0
        val fields = listOf(e.text, e.contentDescription, e.hint).map { TextMatch.normalize(it) }.filter { it.isNotEmpty() }
        var best = 0
        for (raw in labels) {
            val label = TextMatch.normalize(raw)
            if (label.isEmpty()) continue
            for (field in fields) {
                val s = when {
                    field == label -> SCORE_EXACT
                    field.startsWith(label) -> SCORE_PREFIX
                    label.length >= 3 && field.contains(label) -> SCORE_CONTAINS
                    else -> 0
                }
                if (s > best) best = s
            }
        }
        return best
    }

    private fun inRegion(e: UiElement, obs: ScreenObservation, region: Region?): Boolean {
        if (region == null || obs.screenHeight <= 0) return true
        val f = e.bounds.centerY.toFloat() / obs.screenHeight
        return when (region) {
            Region.TOP_BAR -> f < 0.18f
            Region.BOTTOM_BAR -> f > 0.78f
            Region.BELOW_TOP_BAR -> f >= 0.18f
            Region.ABOVE_BOTTOM_BAR -> f <= 0.78f
        }
    }
}
