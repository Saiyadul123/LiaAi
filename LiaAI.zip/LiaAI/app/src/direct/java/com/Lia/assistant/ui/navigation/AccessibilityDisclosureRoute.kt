package com.Lia.assistant.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.screens.accessibility.AccessibilityDisclosureScreen

/** DIRECT flavor: the prominent disclosure for the accessibility service. */
fun NavGraphBuilder.registerAccessibilityDisclosureRoute(navController: NavHostController, appState: NovaAppState) {
    composable(NovaRoutes.ACCESSIBILITY_DISCLOSURE) {
        AccessibilityDisclosureScreen(appState = appState, onBack = { navController.popBackStack() })
    }
}
