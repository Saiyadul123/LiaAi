package com.Lia.assistant.agent.social

import com.Lia.assistant.agent.core.Expectation

/** Turns a validated request into the steps that carry it out. */
object SocialPlanner {

    fun plan(request: SocialTaskRequest): List<PlanStep> {
        val selectors = SocialSelectors.forPlatform(request.platform)
        val app = request.platform.packageName
        val steps = ArrayList<PlanStep>()

        if (request.action.needsMedia) {
            steps += PlanStep(
                id = "share_media", description = "Open ${request.platform.displayName} with your file",
                kind = StepKind.SHARE_MEDIA, packages = listOf(app),
                mediaUri = request.mediaUri, mimeType = request.mimeType, expect = Expectation.PackageIs(app),
            )
            steps += PlanStep(
                id = "destination", description = "Choose where to share it", kind = StepKind.CLICK,
                target = selectors.destination(request.action), optional = true, expect = Expectation.ScreenChanged,
            )
            // the share flow has up to two "Next" screens (crop, edit)
            repeat(2) { n ->
                steps += PlanStep(
                    id = "next_${n + 1}", description = "Continue", kind = StepKind.CLICK,
                    target = selectors.next, optional = true, expect = Expectation.ScreenChanged,
                )
            }
        } else {
            steps += PlanStep(
                id = "open_app", description = "Open ${request.platform.displayName}", kind = StepKind.LAUNCH_APP,
                packages = listOf(app), expect = Expectation.PackageIs(app),
            )
            steps += PlanStep(
                id = "compose", description = "Open the composer", kind = StepKind.CLICK,
                target = selectors.composeEntry, expect = Expectation.ScreenChanged,
            )
        }

        if (request.caption.isNotBlank()) {
            steps += PlanStep(
                id = "caption", description = "Write the text", kind = StepKind.TYPE,
                target = selectors.captionField, text = request.caption,
            )
        }

        when (request.mode) {
            TaskMode.PUBLISH -> steps += PlanStep(
                id = "publish", description = "Publish it", kind = StepKind.CLICK, target = selectors.publish,
                irreversible = true, finalStep = true, expect = selectors.publishedExpectation,
            )
            TaskMode.DRAFT -> {
                // a draft is saved by leaving the composer; there is no publish step at all
                steps += PlanStep(
                    id = "leave_composer", description = "Leave the composer", kind = StepKind.BACK,
                    expect = Expectation.TargetPresent(selectors.saveDraft),
                )
                steps += PlanStep(
                    id = "save_draft", description = "Save it as a draft", kind = StepKind.CLICK,
                    target = selectors.saveDraft, finalStep = true, expect = Expectation.TargetGone(selectors.saveDraft),
                )
            }
        }
        return steps
    }

    /** What the user is asked to say yes to. */
    fun summary(request: SocialTaskRequest): String {
        val what = when (request.action) {
            SocialAction.CREATE_POST -> "a post"
            SocialAction.CREATE_REEL -> "a reel"
            SocialAction.CREATE_STORY -> "a story"
            SocialAction.TEXT_POST -> "a text post"
        }
        val caption = if (request.caption.isBlank()) "no caption" else "the caption “${request.caption.take(120)}”"
        val file = request.mediaName?.let { ", file: $it" }.orEmpty()
        val account = request.targetAccount?.let {
            " Account: $it (I cannot switch accounts, so please check that this is the one that is logged in)."
        }.orEmpty()
        return "Publish $what to ${request.platform.displayName} with $caption$file.$account"
    }
}
