package com.Lia.assistant.agent

import android.content.Context
import com.Lia.assistant.action.NovaAccessibilityService
import com.Lia.assistant.action.PhoneActions
import com.Lia.assistant.agent.core.AccessibilityScreenDriver
import com.Lia.assistant.agent.social.AgentTaskRegistry
import com.Lia.assistant.agent.social.SocialTaskService
import com.Lia.assistant.agent.social.UserSignal
import com.Lia.assistant.agent.whatsapp.NotificationListenerSource
import com.Lia.assistant.agent.whatsapp.WhatsAppAgent
import com.Lia.assistant.voice.ToolDeclaration
import com.Lia.assistant.voice.VoiceSessionManager
import com.Lia.assistant.voice.functionDecl
import org.json.JSONObject

/**
 * The four agent tools (direct flavor only) and the glue between a tool call and the agent.
 * Confirmations are checked against what the user actually said ([UserSignal]).
 */
object AgentTools {
    const val SOCIAL_EXECUTE = "execute_social_media_task"
    const val SOCIAL_CONTROL = "social_media_task_control"
    const val WHATSAPP_EXECUTE = "execute_whatsapp_task"
    const val WHATSAPP_CONTROL = "whatsapp_task_control"

    val NAMES = setOf(SOCIAL_EXECUTE, SOCIAL_CONTROL, WHATSAPP_EXECUTE, WHATSAPP_CONTROL)

    private const val CONFIRM_RULE = "Only call confirm after the user explicitly said yes."

    fun declarations(): List<ToolDeclaration> = listOf(
        functionDecl(
            SOCIAL_EXECUTE,
            "Make a post, reel, story or text post on Instagram or Facebook by operating the app on screen. " +
                "Media must be a photo or video the user shared to this assistant: media_uri is its content:// URI, " +
                "or \"latest\" for the most recent one. Publishing always pauses for the user's confirmation " +
                "(read out the confirmation_summary, then use social_media_task_control). " +
                "mode draft saves a draft and never publishes. target_account is only shown to the user: " +
                "the assistant cannot switch accounts. The task may also pause when the app asks the user " +
                "to log in or enter a code.",
            mapOf(
                "platform" to "instagram or facebook",
                "action" to "create_post, create_reel, create_story or text_post (text_post is Facebook only)",
                "media_uri" to "content:// URI of a file shared to the assistant, or \"latest\". Not needed for text_post",
                "caption" to "The caption, or the text of a text post",
                "mode" to "publish (default) or draft",
                "target_account" to "The account the user means, shown to them when asking for confirmation",
            ),
            listOf("platform", "action"),
        ),
        functionDecl(
            SOCIAL_CONTROL,
            "Steer a social media task that is waiting. confirm: the user said yes to the summary, go ahead. " +
                "reject: the user said no. resume: the user dealt with a login, CAPTCHA or code themselves. " +
                "cancel: stop. status: check progress. $CONFIRM_RULE Never confirm on your own.",
            mapOf(
                "command" to "confirm, reject, resume, cancel or status",
                "task_id" to "The task_id from the earlier result (defaults to the running task)",
            ),
            listOf("command"),
        ),
        functionDecl(
            WHATSAPP_EXECUTE,
            "Work with WhatsApp. read_unread reads unread messages from notifications and never opens the app. " +
                "send_message goes straight to the chat by phone number and waits for the user's confirmation " +
                "(use whatsapp_task_control). read_chat, search_chat, mute_chat, unmute_chat and mark_read operate " +
                "the app; if two contacts match a name the task stops with contact_ambiguous and the user must say " +
                "which one.",
            mapOf(
                "action" to "read_unread, send_message, read_chat, search_chat, mute_chat, unmute_chat or mark_read",
                "phone" to "Full number with country code, for example +919876543210 (required for send_message)",
                "contact" to "A contact or chat name (for read_chat, mute_chat, unmute_chat, mark_read)",
                "message" to "The text to send (send_message)",
                "query" to "What to search for (search_chat)",
                "duration" to "For mute_chat: 8_hours, 1_week or always (default)",
            ),
            listOf("action"),
        ),
        functionDecl(
            WHATSAPP_CONTROL,
            "Steer a WhatsApp task that is waiting. confirm: the user said yes, send it. reject: the user said no. " +
                "resume: the user dealt with something in the app themselves. cancel: stop. status: check progress. " +
                "$CONFIRM_RULE Never confirm on your own.",
            mapOf(
                "command" to "confirm, reject, resume, cancel or status",
                "task_id" to "The task_id from the earlier result (defaults to the running task)",
            ),
            listOf("command"),
        ),
    )

    private class Services(val social: SocialTaskService, val whatsapp: WhatsAppAgent)

    private var services: Services? = null

    @Synchronized
    private fun services(context: Context): Services = services ?: run {
        val app = context.applicationContext
        val driver = AccessibilityScreenDriver(app) // one driver, so observation ids stay in order across tool calls
        val registry = AgentTaskRegistry()
        Services(SocialTaskService(driver, registry), WhatsAppAgent(driver, NotificationListenerSource(app), registry))
            .also { services = it }
    }

    suspend fun execute(context: Context, name: String, args: JSONObject): JSONObject {
        val signal = UserSignal(VoiceSessionManager.userTurnCount(), VoiceSessionManager.lastUserText())
        val s = services(context)
        return when (name) {
            SOCIAL_EXECUTE -> if (screenControlReady(context)) s.social.execute(args, signal) else notEnabled()
            SOCIAL_CONTROL -> s.social.control(args, signal)
            // reading unread messages needs notification access, not screen control
            WHATSAPP_EXECUTE ->
                if (isReadUnread(args) || screenControlReady(context)) s.whatsapp.execute(args, signal) else notEnabled()
            WHATSAPP_CONTROL -> s.whatsapp.control(args, signal)
            else -> PhoneActions.unknownTool(name)
        }
    }

    private fun isReadUnread(args: JSONObject): Boolean =
        !args.isNull("action") && args.optString("action").trim().equals("read_unread", ignoreCase = true)

    private fun screenControlReady(context: Context): Boolean =
        NovaAccessibilityService.instance != null && NovaAccessibilityService.isEnabled(context)

    private fun notEnabled(): JSONObject = PhoneActions.result("accessibility_not_enabled")
}
