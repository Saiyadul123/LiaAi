package com.Lia.assistant.agent.core

import kotlinx.coroutines.delay

data class ExecConfig(
    val settleMs: Long = 400,
    val verifyAttempts: Int = 4,
    val verifyIntervalMs: Long = 400,
    val maxReobserve: Int = 2,
    val methods: List<ActionMethod> = listOf(
        ActionMethod.ACCESSIBILITY_CLICK,
        ActionMethod.GESTURE_ON_ELEMENT_BOUNDS,
        ActionMethod.VISION_TAP,
    ),
)

data class TapPoint(val x: Int, val y: Int)

/**
 * Clicks a target and then checks that something actually happened. Methods are tried in order, but only
 * while the click did not go through: once a click has been delivered it is never repeated by another
 * method (a second tap could do the thing twice). A stale observation is re-taken instead of acted on.
 */
class UiActionExecutor(
    private val driver: ScreenDriver,
    private val blockerCheck: (ScreenObservation) -> Blocker? = { null },
    private val waiter: suspend (Long) -> Unit = { delay(it) },
    private val config: ExecConfig = ExecConfig(),
    private val visionTap: (suspend (ScreenObservation, TargetSpec) -> TapPoint?)? = null,
    private val onPhase: (ExecPhase) -> Unit = {},
) {
    suspend fun click(target: TargetSpec, expect: Expectation): ActionResult {
        var reobserves = 0
        outer@ while (true) {
            onPhase(ExecPhase.OBSERVE)
            val observation = driver.capture() ?: return ActionResult.Failed(FailureReason.NO_WINDOW)
            blockerCheck(observation)?.let { return ActionResult.Blocked(it) }

            onPhase(ExecPhase.RESOLVE)
            val element = when (val resolution = TargetResolver.resolve(observation, target)) {
                is Resolution.Found -> resolution.element
                is Resolution.Ambiguous -> return ActionResult.Failed(FailureReason.TARGET_AMBIGUOUS, target.description)
                Resolution.NotFound -> return ActionResult.Failed(FailureReason.TARGET_NOT_FOUND, target.description)
            }

            var rejected = false
            var notFound = false
            var unsupported = false
            for (method in config.methods) {
                onPhase(ExecPhase.ACT)
                val result = when (method) {
                    ActionMethod.ACCESSIBILITY_CLICK -> driver.clickElement(observation, element)
                    ActionMethod.GESTURE_ON_ELEMENT_BOUNDS -> driver.gestureTap(element.bounds.centerX, element.bounds.centerY)
                    ActionMethod.VISION_TAP -> {
                        val point = visionTap?.invoke(observation, target)
                        if (point == null) DriverResult.UNSUPPORTED else driver.gestureTap(point.x, point.y)
                    }
                    ActionMethod.SET_TEXT -> DriverResult.UNSUPPORTED
                }
                when (result) {
                    DriverResult.STALE -> {
                        if (++reobserves > config.maxReobserve) return ActionResult.Failed(FailureReason.STALE_OBSERVATION)
                        continue@outer // look again, then act on the fresh observation
                    }
                    DriverResult.OK -> return verify(observation, method, expect)
                    DriverResult.NOT_FOUND -> notFound = true
                    DriverResult.FAILED -> rejected = true
                    DriverResult.UNSUPPORTED -> unsupported = true
                }
            }
            val reason = when {
                rejected -> FailureReason.ACTION_REJECTED
                notFound -> FailureReason.TARGET_NOT_FOUND
                unsupported -> FailureReason.UNSUPPORTED
                else -> FailureReason.ACTION_REJECTED
            }
            return ActionResult.Failed(reason, target.description)
        }
    }

    /** After a delivered click: wait for the screen to settle, then look for the expected effect. */
    private suspend fun verify(before: ScreenObservation, method: ActionMethod, expect: Expectation): ActionResult {
        onPhase(ExecPhase.WAIT)
        waiter(config.settleMs)
        if (expect == Expectation.None) return ActionResult.Success(method, null)

        onPhase(ExecPhase.VERIFY)
        for (attempt in 0 until config.verifyAttempts) {
            if (attempt > 0) waiter(config.verifyIntervalMs)
            val after = driver.capture() ?: continue
            blockerCheck(after)?.let { return ActionResult.Blocked(it) }
            if (ExpectationChecker.check(expect, before, after)) return ActionResult.Success(method, after)
        }
        return ActionResult.Failed(FailureReason.NOT_VERIFIED, "the click was delivered but its effect was not seen")
    }
}
