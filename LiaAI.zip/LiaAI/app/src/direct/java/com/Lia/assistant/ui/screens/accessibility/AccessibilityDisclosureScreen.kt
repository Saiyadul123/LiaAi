package com.Lia.assistant.ui.screens.accessibility

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.Lia.assistant.action.NovaAccessibilityService
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaSectionHeader
import com.Lia.assistant.ui.screens.common.NovaListScreen
import com.Lia.assistant.ui.screens.common.rememberLifecycleTick
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme

/**
 * DIRECT flavor. Says plainly what the accessibility service does, before sending the user to the
 * system screen where they switch it on. Nothing is enabled from here.
 */
@Composable
fun AccessibilityDisclosureScreen(appState: NovaAppState, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val name = appState.assistantName
    val tick = rememberLifecycleTick()
    val enabled = remember(tick) { NovaAccessibilityService.isEnabled(context) }

    NovaListScreen(title = "Screen control", subtitle = if (enabled) "Currently on" else "Currently off", onBack = onBack, modifier = modifier) {
        item {
            NovaGlassCard(Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg)) {
                Text("What this does", style = type.title, color = colors.textPrimary)
                Spacer(Modifier.height(NovaSpacing.sm))
                Text(
                    "With your permission, $name uses Android's accessibility service to read the text and controls " +
                        "on your screen, and to tap, type, scroll and press Back or Home for you.",
                    style = type.body, color = colors.textSecondary,
                )
                Spacer(Modifier.height(NovaSpacing.md))
                Text("When it is used", style = type.title, color = colors.textPrimary)
                Spacer(Modifier.height(NovaSpacing.sm))
                Text(
                    "Only while a voice session is running and only when you ask $name to do something on screen. " +
                        "It does not watch your screen in the background.",
                    style = type.body, color = colors.textSecondary,
                )
                Spacer(Modifier.height(NovaSpacing.md))
                Text("What leaves your phone", style = type.title, color = colors.textPrimary)
                Spacer(Modifier.height(NovaSpacing.sm))
                Text(
                    "When you ask $name to read or act on the screen, the text it can see is sent to Google's Gemini " +
                        "service, using your own API key, so it can answer. Nothing else is collected or stored.",
                    style = type.body, color = colors.textSecondary,
                )
                Spacer(Modifier.height(NovaSpacing.md))
                Text("You stay in control", style = type.title, color = colors.textPrimary)
                Spacer(Modifier.height(NovaSpacing.sm))
                Text(
                    "You can turn it off at any time in Android Settings > Accessibility. Messages are only sent when " +
                        "you ask for them, and $name confirms the text with you first.",
                    style = type.body, color = colors.textSecondary,
                )
            }
        }
        item {
            Column(Modifier.padding(horizontal = NovaSpacing.lg), verticalArrangement = Arrangement.spacedBy(NovaSpacing.sm)) {
                NovaButton(
                    text = if (enabled) "Open accessibility settings" else "Continue to settings",
                    onClick = {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = Icons.Rounded.AccessibilityNew,
                )
                NovaButton("Not now", onBack, Modifier.fillMaxWidth(), style = NovaButtonStyle.TEXT)
            }
        }
    }
}
