package com.Lia.assistant.agent.core

import java.util.concurrent.atomic.AtomicLong

/** Turns a raw capture into an observation, numbering it so stale ones can be told apart. */
class ScreenObserver {
    private val counter = AtomicLong(0)

    @Volatile
    var latestId: Long = 0L
        private set

    fun observe(captured: CapturedScreen): ScreenObservation {
        val id = counter.incrementAndGet()
        val kept = captured.nodes.filter { node ->
            node.visibleToUser &&
                !node.bounds.isEmpty &&
                node.bounds.intersectsScreen(captured.screenWidth, captured.screenHeight) &&
                (node.text.isNotEmpty() || node.contentDescription.isNotEmpty() || node.hint.isNotEmpty() ||
                    node.clickable || node.editable || node.scrollable)
        }
        val elements = kept.mapIndexed { index, n ->
            UiElement(
                id = index, text = n.text, contentDescription = n.contentDescription, hint = n.hint,
                viewId = n.viewId, className = n.className, bounds = n.bounds, clickable = n.clickable,
                editable = n.editable, scrollable = n.scrollable, enabled = n.enabled, focused = n.focused,
                checked = n.checked, path = n.path, clickableAncestor = n.clickableAncestor,
            )
        }
        latestId = id
        return ScreenObservation(
            observationId = id,
            packageName = captured.packageName,
            windowClass = captured.windowClass,
            elements = elements,
            screenWidth = captured.screenWidth,
            screenHeight = captured.screenHeight,
            windowStamp = captured.windowStamp,
        )
    }

    /** Only the most recent observation may be acted on. */
    fun isLatest(observation: ScreenObservation): Boolean = observation.observationId == latestId
}
