package com.Lia.assistant.ui.fx

import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.WindowManager
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.ViewTreeSavedStateRegistryOwner
import com.Lia.assistant.data.NovaPreferences
import com.Lia.assistant.data.ThemeMode
import com.Lia.assistant.ui.components.ListeningEdgeGlow
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.voice.NovaOrbState
import com.Lia.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * DIRECT flavor: shows the same [ListeningEdgeGlow] in a TYPE_APPLICATION_OVERLAY window so it is
 * visible over other apps while a voice session runs. Needs the "display over other apps" permission
 * (see [permissionIntent]); without it, [start] silently does nothing. The same object exists in
 * src/play as a no-op. Call from the main thread (the foreground service does).
 */
object OverlayEdgeGlowController {
    private val _showing = MutableStateFlow(false)
    val showing: StateFlow<Boolean> = _showing.asStateFlow()

    private val main = Handler(Looper.getMainLooper())
    private var view: ComposeView? = null
    private var windowManager: WindowManager? = null
    private var owner: OverlayOwner? = null

    fun canDraw(context: Context): Boolean = Settings.canDrawOverlays(context)

    /** Opens the system screen where the user grants "display over other apps". */
    fun permissionIntent(context: Context): Intent? {
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return intent
    }

    fun start(context: Context) {
        val app = context.applicationContext
        runOnMain { show(app) }
    }

    fun stop() {
        runOnMain { hide() }
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post(block)
    }

    private fun show(app: Context) {
        if (view != null || !canDraw(app)) return
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val lifecycleOwner = OverlayOwner()
        val compose = ComposeView(app).apply {
            ViewTreeLifecycleOwner.set(this, lifecycleOwner)
            ViewTreeSavedStateRegistryOwner.set(this, lifecycleOwner)
            setContent {
                NovaTheme(
                    mode = ThemeMode.DARK,
                    reducedMotion = NovaPreferences.getBoolean(app, NovaPreferences.Keys.REDUCED_MOTION, false),
                ) {
                    val active by VoiceSessionManager.isActive.collectAsState()
                    val state by VoiceSessionManager.state.collectAsState()
                    val amplitude by VoiceSessionManager.amplitude.collectAsState()
                    ListeningEdgeGlow(
                        state = if (active) state else NovaOrbState.IDLE,
                        amplitude = amplitude,
                    )
                }
            }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        try {
            wm.addView(compose, params)
        } catch (_: RuntimeException) { // BadTokenException, SecurityException, IllegalStateException
            lifecycleOwner.destroy()
            return
        }
        lifecycleOwner.resume()
        view = compose
        windowManager = wm
        owner = lifecycleOwner
        _showing.value = true
    }

    private fun hide() {
        val v = view ?: return
        try {
            windowManager?.removeViewImmediate(v)
        } catch (_: RuntimeException) {
            // already gone
        }
        owner?.destroy()
        view = null
        windowManager = null
        owner = null
        _showing.value = false
    }

    /** Minimal lifecycle + saved-state owner so Compose can run outside an Activity. */
    private class OverlayOwner : LifecycleOwner, SavedStateRegistryOwner {
        private val registry = LifecycleRegistry(this)
        private val controller = SavedStateRegistryController.create(this)

        init {
            controller.performAttach()
            controller.performRestore(null)
            registry.currentState = Lifecycle.State.CREATED
        }

        override val lifecycle: Lifecycle get() = registry
        override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry

        fun resume() {
            registry.currentState = Lifecycle.State.RESUMED
        }

        fun destroy() {
            registry.currentState = Lifecycle.State.DESTROYED
        }
    }
}
