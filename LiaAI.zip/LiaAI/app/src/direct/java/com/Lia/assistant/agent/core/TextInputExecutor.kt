package com.Lia.assistant.agent.core

import kotlinx.coroutines.delay

/**
 * Types into an editable field: focus it, replace its text, then check that the text really is there.
 * Replacing is idempotent, so retrying a typing step is safe.
 */
class TextInputExecutor(
    private val driver: ScreenDriver,
    private val blockerCheck: (ScreenObservation) -> Blocker? = { null },
    private val waiter: suspend (Long) -> Unit = { delay(it) },
    private val config: ExecConfig = ExecConfig(),
) {
    suspend fun type(field: TargetSpec, text: String): ActionResult {
        if (text.isBlank()) return ActionResult.Failed(FailureReason.INVALID_INPUT, "nothing to type")
        val spec = field.copy(requireEditable = true)
        var reobserves = 0
        while (true) {
            val observation = driver.capture() ?: return ActionResult.Failed(FailureReason.NO_WINDOW)
            blockerCheck(observation)?.let { return ActionResult.Blocked(it) }

            val element = when (val resolution = TargetResolver.resolve(observation, spec)) {
                is Resolution.Found -> resolution.element
                is Resolution.Ambiguous -> return ActionResult.Failed(FailureReason.TARGET_AMBIGUOUS, spec.description)
                Resolution.NotFound -> return ActionResult.Failed(FailureReason.TARGET_NOT_FOUND, spec.description)
            }

            // focus: accessibility click first, a gesture on the field's bounds as the fallback
            var focus = if (element.focused) DriverResult.OK else driver.clickElement(observation, element)
            if (focus == DriverResult.FAILED || focus == DriverResult.UNSUPPORTED || focus == DriverResult.NOT_FOUND) {
                focus = driver.gestureTap(element.bounds.centerX, element.bounds.centerY)
            }
            if (focus == DriverResult.STALE) {
                if (++reobserves > config.maxReobserve) return ActionResult.Failed(FailureReason.STALE_OBSERVATION)
                continue
            }
            if (focus != DriverResult.OK) return ActionResult.Failed(FailureReason.ACTION_REJECTED, "could not focus the field")

            waiter(config.settleMs)
            when (driver.setText(text)) {
                DriverResult.OK -> Unit
                DriverResult.UNSUPPORTED -> return ActionResult.Failed(FailureReason.UNSUPPORTED)
                DriverResult.STALE -> {
                    if (++reobserves > config.maxReobserve) return ActionResult.Failed(FailureReason.STALE_OBSERVATION)
                    continue
                }
                else -> return ActionResult.Failed(FailureReason.ACTION_REJECTED, "the field refused the text")
            }

            for (attempt in 0 until config.verifyAttempts) {
                if (attempt > 0) waiter(config.verifyIntervalMs)
                val after = driver.capture() ?: continue
                blockerCheck(after)?.let { return ActionResult.Blocked(it) }
                if (ExpectationChecker.check(Expectation.TextPresent(text), observation, after)) {
                    return ActionResult.Success(ActionMethod.SET_TEXT, after)
                }
            }
            return ActionResult.Failed(FailureReason.NOT_VERIFIED, "the typed text was not found in the field")
        }
    }
}
