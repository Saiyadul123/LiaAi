package com.Lia.assistant.agent.social

import org.json.JSONObject

enum class Platform(val id: String, val packageName: String, val displayName: String, val captionLimit: Int) {
    INSTAGRAM("instagram", "com.instagram.android", "Instagram", 2200),
    FACEBOOK("facebook", "com.facebook.katana", "Facebook", 63206);

    companion object {
        fun parse(value: String?): Platform? = entries.firstOrNull { it.id == value?.trim()?.lowercase() }
    }
}

enum class SocialAction(val id: String, val needsMedia: Boolean, val supportsDraft: Boolean) {
    CREATE_POST("create_post", needsMedia = true, supportsDraft = true),
    CREATE_REEL("create_reel", needsMedia = true, supportsDraft = true),
    CREATE_STORY("create_story", needsMedia = true, supportsDraft = false),
    /** A post with only text. Facebook has them, Instagram does not. */
    TEXT_POST("text_post", needsMedia = false, supportsDraft = true);

    fun supportedOn(platform: Platform): Boolean = this != TEXT_POST || platform == Platform.FACEBOOK

    companion object {
        fun parse(value: String?): SocialAction? = entries.firstOrNull { it.id == value?.trim()?.lowercase() }
    }
}

enum class TaskMode(val id: String) {
    /** Publishes, but only after the user has said yes. */
    PUBLISH("publish"),
    /** Saves a draft. Never publishes. */
    DRAFT("draft");

    companion object {
        fun parse(value: String?): TaskMode? = entries.firstOrNull { it.id == value?.trim()?.lowercase() }
    }
}

enum class TaskStatus(val code: String, val isFinal: Boolean) {
    PENDING("pending", false),
    RUNNING("running", false),
    AWAITING_CONFIRMATION("awaiting_confirmation", false),
    AWAITING_USER("awaiting_user", false),
    COMPLETED("completed", true),
    DRAFT_SAVED("draft_saved", true),
    /** The last tap was made but the app never showed that it worked. */
    SUBMITTED_UNVERIFIED("submitted_unverified", true),
    FAILED("failed", true),
    CANCELLED("cancelled", true),
}

sealed interface ParseResult {
    data class Valid(val request: SocialTaskRequest) : ParseResult
    data class Invalid(val code: String, val message: String) : ParseResult
}

/** A validated social task. Built only through [parse], so a task never exists for bad arguments. */
data class SocialTaskRequest(
    val platform: Platform,
    val action: SocialAction,
    val mediaUri: String?,
    val mimeType: String?,
    val mediaName: String?,
    val caption: String,
    val mode: TaskMode,
    val targetAccount: String?,
) {
    companion object {
        private fun str(args: JSONObject, key: String): String = if (args.isNull(key)) "" else args.optString(key).trim()

        fun parse(args: JSONObject, media: MediaResolver = MediaResolver()): ParseResult {
            val platform = Platform.parse(str(args, "platform"))
                ?: return invalid("invalid_platform", "platform must be instagram or facebook")
            val action = SocialAction.parse(str(args, "action"))
                ?: return invalid("invalid_action", "action must be create_post, create_reel, create_story or text_post")
            if (!action.supportedOn(platform)) {
                return invalid("action_not_supported", "${platform.displayName} does not have ${action.id}")
            }
            val modeText = str(args, "mode")
            val mode = if (modeText.isEmpty()) TaskMode.PUBLISH else TaskMode.parse(modeText)
                ?: return invalid("invalid_mode", "mode must be publish or draft")
            if (mode == TaskMode.DRAFT && !action.supportsDraft) {
                return invalid("draft_not_supported", "${action.id} cannot be saved as a draft")
            }

            val caption = str(args, "caption")
            if (caption.length > platform.captionLimit) {
                return invalid("caption_too_long", "${platform.displayName} captions are at most ${platform.captionLimit} characters")
            }
            if (action == SocialAction.TEXT_POST && caption.isEmpty()) {
                return invalid("caption_required", "a text post needs the text in caption")
            }

            var mediaUri: String? = null
            var mime: String? = null
            var mediaName: String? = null
            if (action.needsMedia) {
                when (val resolved = media.resolve(str(args, "media_uri"))) {
                    is MediaResolver.Result.Rejected -> return invalid(resolved.code, resolved.message)
                    is MediaResolver.Result.Allowed -> {
                        mediaUri = resolved.uri
                        mime = resolved.mimeType
                        mediaName = resolved.displayName
                    }
                }
            }

            return ParseResult.Valid(
                SocialTaskRequest(
                    platform = platform, action = action, mediaUri = mediaUri, mimeType = mime, mediaName = mediaName,
                    caption = caption, mode = mode, targetAccount = str(args, "target_account").ifEmpty { null },
                )
            )
        }

        private fun invalid(code: String, message: String) = ParseResult.Invalid(code, message)
    }
}
