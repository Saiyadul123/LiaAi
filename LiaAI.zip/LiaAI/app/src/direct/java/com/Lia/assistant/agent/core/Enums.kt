package com.Lia.assistant.agent.core

/** Where an action is while the executor works on it (for progress and logs). */
enum class ExecPhase { OBSERVE, RESOLVE, ACT, WAIT, VERIFY }

enum class ActionMethod {
    /** Ask the accessibility service to click the node. */
    ACCESSIBILITY_CLICK,
    /** Tap the centre of the element's bounds with a gesture. */
    GESTURE_ON_ELEMENT_BOUNDS,
    /** Tap coordinates chosen by a vision model (only when a provider is installed). */
    VISION_TAP,
    /** Put text into the focused field. */
    SET_TEXT,
}

/** Things only the user can do. The agent pauses and waits; it never tries to get past them. */
enum class Blocker { LOGIN, CAPTCHA, TWO_FACTOR, SECURITY_CHECK, PERMISSION_PROMPT }

enum class FailureReason(val code: String) {
    NO_WINDOW("no_window"),
    TARGET_NOT_FOUND("target_not_found"),
    TARGET_AMBIGUOUS("target_ambiguous"),
    CONTACT_AMBIGUOUS("contact_ambiguous"),
    ACTION_REJECTED("action_rejected"),
    STALE_OBSERVATION("stale_observation"),
    /** The action was performed but its expected effect could not be confirmed. */
    NOT_VERIFIED("not_verified"),
    TIMEOUT("timeout"),
    UNSUPPORTED("unsupported"),
    INVALID_INPUT("invalid_input"),
    APP_NOT_AVAILABLE("app_not_available"),
    DRAFT_WOULD_PUBLISH("draft_would_publish"),
}
