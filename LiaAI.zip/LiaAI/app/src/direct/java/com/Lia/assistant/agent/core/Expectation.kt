package com.Lia.assistant.agent.core

/** What should be true after an action. Checked against a fresh observation. */
sealed interface Expectation {
    /** Nothing to check: the effect cannot be verified. */
    data object None : Expectation
    data class TargetGone(val spec: TargetSpec) : Expectation
    data class TargetPresent(val spec: TargetSpec) : Expectation
    /** The text appears on screen; with [excludeEditable] only outside input fields (it has left the box it was typed in). */
    data class TextPresent(val text: String, val excludeEditable: Boolean = false) : Expectation
    data class PackageIs(val packageName: String) : Expectation
    /** The window, package or visible labels differ from before the action. */
    data object ScreenChanged : Expectation
    data class AnyOf(val options: List<Expectation>) : Expectation
    data class AllOf(val options: List<Expectation>) : Expectation
}

object TextMatch {
    /** Lower case, whitespace collapsed, trailing ellipsis and punctuation dropped. */
    fun normalize(text: String): String =
        text.lowercase().replace('\u2019', '\'').replace(Regex("\\s+"), " ").trim().trimEnd('.', '…', ':', ' ')

    /** True if [needle] (its first 60 characters) appears in [haystack], ignoring case and spacing. */
    fun contains(haystack: String, needle: String): Boolean {
        val n = normalize(needle).take(60)
        return n.isNotEmpty() && normalize(haystack).contains(n)
    }
}

object ExpectationChecker {
    fun check(expectation: Expectation, before: ScreenObservation?, after: ScreenObservation): Boolean = when (expectation) {
        Expectation.None -> true
        is Expectation.TargetGone -> TargetResolver.resolve(after, expectation.spec) is Resolution.NotFound
        is Expectation.TargetPresent -> TargetResolver.resolve(after, expectation.spec) !is Resolution.NotFound
        is Expectation.TextPresent -> after.elements
            .filter { !expectation.excludeEditable || !it.editable }
            .any {
                TextMatch.contains(it.text, expectation.text) ||
                    TextMatch.contains(it.contentDescription, expectation.text) ||
                    TextMatch.contains(it.hint, expectation.text)
            }
        is Expectation.PackageIs -> after.packageName == expectation.packageName
        Expectation.ScreenChanged -> before == null ||
            after.windowStamp != before.windowStamp ||
            after.windowClass != before.windowClass ||
            after.packageName != before.packageName ||
            labels(after) != labels(before)
        is Expectation.AnyOf -> expectation.options.any { check(it, before, after) }
        is Expectation.AllOf -> expectation.options.all { check(it, before, after) }
    }

    private fun labels(o: ScreenObservation): Set<String> = o.elements.map { it.label }.filter { it.isNotEmpty() }.toSet()
}
