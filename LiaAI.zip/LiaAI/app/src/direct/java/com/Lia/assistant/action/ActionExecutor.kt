package com.Lia.assistant.action

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import org.json.JSONObject

/**
 * DIRECT flavor: everything in src/play plus screen control through NovaAccessibilityService, and
 * message_contact additionally taps Send. The same object exists in src/play.
 */
object ActionExecutor {
    internal const val SEND_TRIES = 12
    internal const val SEND_WAIT_MS = 400L

    suspend fun execute(context: Context, name: String, args: JSONObject): JSONObject = try {
        when (name) {
            "open_app" -> PhoneActions.openApp(context, args)
            "call_contact" -> PhoneActions.callContact(context, args)
            "message_contact" -> messageContact(context, args)
            "read_screen", "tap_text", "type_text", "scroll_screen", "go_back", "go_home" ->
                screenTool(context, name, args)
            else -> PhoneActions.unknownTool(name)
        }
    } catch (e: CancellationException) {
        throw e
    } catch (_: Exception) {
        PhoneActions.error("Tool failed: $name")
    }

    private fun service(context: Context): NovaAccessibilityService? =
        NovaAccessibilityService.instance?.takeIf { NovaAccessibilityService.isEnabled(context) }

    private suspend fun messageContact(context: Context, args: JSONObject): JSONObject {
        val opened = when (val c = PhoneActions.openComposer(context, args)) {
            is PhoneActions.Composer.Failed -> return c.json
            is PhoneActions.Composer.Opened -> c
        }
        // Without the accessibility service this behaves like the Play build: the user taps Send.
        val svc = service(context) ?: return PhoneActions.composerOpenedJson(opened)
        val sent = autoTapSend(
            isWhatsApp = opened.app == CommIntents.MessageApp.WHATSAPP,
            tap = { svc.tapText(it) },
        )
        return PhoneActions.composerOpenedJson(opened, if (sent) "sent" else "composer_opened_send_not_found")
    }

    /**
     * Up to [SEND_TRIES] tries, each after [SEND_WAIT_MS]: (WhatsApp) tap "Continue to chat" if it
     * is there, then tap "Send". True once Send was tapped.
     */
    internal suspend fun autoTapSend(
        isWhatsApp: Boolean,
        tap: (String) -> Boolean,
        wait: suspend (Long) -> Unit = { delay(it) },
    ): Boolean {
        repeat(SEND_TRIES) {
            wait(SEND_WAIT_MS)
            if (isWhatsApp) tap("Continue to chat")
            if (tap("Send")) return true
        }
        return false
    }

    private fun screenTool(context: Context, name: String, args: JSONObject): JSONObject {
        val svc = service(context) ?: return PhoneActions.result("accessibility_not_enabled")
        return when (name) {
            "read_screen" -> {
                val screen = svc.readScreen(maxElements = 40, maxLabelLength = 40)
                PhoneActions.result(if (screen.isEmpty()) "empty" else "ok", "screen" to screen)
            }
            "tap_text" -> {
                val text = args.optString("text").trim()
                if (text.isEmpty()) PhoneActions.error("Missing parameter: text")
                else PhoneActions.result(if (svc.tapText(text)) "tapped" else "element_not_found")
            }
            "type_text" -> {
                val text = args.optString("text")
                if (text.isEmpty()) PhoneActions.error("Missing parameter: text")
                else PhoneActions.result(if (svc.typeText(text)) "typed" else "no_focused_field")
            }
            "scroll_screen" -> {
                val direction = args.optString("direction").trim().lowercase().ifEmpty { "down" }
                if (direction !in setOf("up", "down", "left", "right")) {
                    PhoneActions.error("Invalid direction: $direction (use up, down, left or right)")
                } else {
                    PhoneActions.result(if (svc.scroll(direction)) "scrolled" else "nothing_scrollable")
                }
            }
            "go_back" -> PhoneActions.result(if (svc.back()) "done" else "failed")
            else -> PhoneActions.result(if (svc.home()) "done" else "failed") // go_home
        }
    }
}
