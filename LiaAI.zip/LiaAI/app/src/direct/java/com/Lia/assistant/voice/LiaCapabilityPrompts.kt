package com.Lia.assistant.voice

/** DIRECT flavor. The same object exists in src/play with a restricted description. */
object LiaCapabilityPrompts {
    fun toolInstruction(assistantName: String): String =
        "Tools: As $assistantName you can use the provided tools to act on the user's phone: place " +
            "calls, look up contacts, open apps, and operate the screen (tap, type, scroll, read what " +
            "is shown) when asked. Use a tool only when the user requests an action. Confirm first " +
            "before anything irreversible or costly, such as sending a message, paying or deleting " +
            "data. Afterwards say briefly what you did, and never claim an action succeeded unless " +
            "the tool result confirms it. Do not read out passwords or private on-screen content " +
            "unless asked."
}
