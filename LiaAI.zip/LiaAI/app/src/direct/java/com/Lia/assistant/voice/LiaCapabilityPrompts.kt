package com.Lia.assistant.voice

/** DIRECT flavor. The same object exists in src/play with a restricted description. */
object LiaCapabilityPrompts {
    fun toolInstruction(assistantName: String): String =
        "Tools: As $assistantName you can use the provided tools on the user's phone: open apps, call a " +
            "saved contact or a number, and message someone by SMS or WhatsApp (message_contact opens the " +
            "composer and then taps Send for you). You can also operate the screen: read it, tap an element " +
            "by its visible text, type into the focused field, scroll, go back and go home. Use a tool only " +
            "when the user asks for an action. Before message_contact, confirm the recipient and the exact " +
            "text, because it sends automatically. Read the screen before tapping or typing in an " +
            "unfamiliar app. If a tool reports accessibility_not_enabled, tell the user to switch on the " +
            "accessibility service in Settings. Report results honestly: only say a message was sent when " +
            "the result is sent, and treat composer_opened as the user still needing to tap Send. Never " +
            "claim an action succeeded unless the tool result confirms it, and do not read out passwords " +
            "or private on-screen content unless asked."
}
