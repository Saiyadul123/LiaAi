package com.Lia.assistant.agent.social

import com.Lia.assistant.agent.core.ScreenDriver
import kotlinx.coroutines.delay
import org.json.JSONObject

/**
 * The two social tools. [execute] validates the arguments BEFORE any task exists: bad arguments get an
 * error and leave nothing behind. [control] steers a task the model started.
 */
class SocialTaskService(
    private val driver: ScreenDriver,
    private val registry: AgentTaskRegistry = AgentTaskRegistry(),
    private val media: MediaResolver = MediaResolver(),
    private val config: TaskRunner.RunnerConfig = TaskRunner.RunnerConfig(),
    private val waiter: suspend (Long) -> Unit = { delay(it) },
) {
    suspend fun execute(args: JSONObject, signal: UserSignal): JSONObject {
        val request = when (val parsed = SocialTaskRequest.parse(args, media)) {
            is ParseResult.Invalid -> return JSONObject().put("error", parsed.code).put("message", parsed.message)
            is ParseResult.Valid -> parsed.request
        }
        registry.active()?.let { return busy(it) }

        val runner = TaskRunner(
            taskId = registry.nextId("social"),
            kind = "social",
            mode = request.mode,
            appLabel = request.platform.displayName,
            plan = SocialPlanner.plan(request),
            driver = driver,
            blockerCheck = BlockerDetector::detect,
            confirmationSummary = SocialPlanner.summary(request),
            config = config,
            waiter = waiter,
        )
        registry.put(runner)
        return runner.start(signal).toJson()
    }

    suspend fun control(args: JSONObject, signal: UserSignal): JSONObject = controlTask(registry, args, signal, "social")

    companion object {
        fun busy(running: TaskRunner): JSONObject = JSONObject()
            .put("error", "task_in_progress")
            .put("task_id", running.taskId)
            .put("message", "Another task is still running. Finish or cancel it first.")

        /** Shared by the social and WhatsApp control tools. */
        suspend fun controlTask(registry: AgentTaskRegistry, args: JSONObject, signal: UserSignal, kind: String): JSONObject {
            val command = ControlCommand.parse(if (args.isNull("command")) "" else args.optString("command"))
                ?: return JSONObject().put("error", "invalid_command").put("message", "command must be confirm, reject, resume, cancel or status")
            val id = if (args.isNull("task_id")) null else args.optString("task_id").trim().ifEmpty { null }
            val runner = registry.get(id)
            if (runner == null || runner.kind != kind) {
                return JSONObject().put("error", "unknown_task").put("message", "There is no such $kind task.")
            }
            return runner.control(command, signal).toJson()
        }
    }
}
