package com.Lia.assistant.voice

/** DIRECT flavor: phone actions plus screen control. The same object exists in src/play with 3 tools. */
object LiaToolCatalog {
    fun declarations(): List<ToolDeclaration> = listOf(
        functionDecl(
            "open_app", "Open an installed app by its name.",
            mapOf("app_name" to "Name of the app, for example YouTube"),
            listOf("app_name"),
        ),
        functionDecl(
            "call_contact", "Call a saved contact by name, or a phone number.",
            mapOf("contact" to "Contact name or phone number"),
            listOf("contact"),
        ),
        functionDecl(
            "message_contact",
            "Send a message by SMS or WhatsApp: opens the composer with the text filled in and taps Send.",
            mapOf(
                "contact" to "Contact name or phone number",
                "message" to "Text of the message",
                "app" to "sms or whatsapp (default sms)",
            ),
            listOf("contact", "message"),
        ),
        functionDecl("read_screen", "Read the visible text and controls on the current screen."),
        functionDecl(
            "tap_text", "Tap the element on screen whose text or description matches.",
            mapOf("text" to "Visible text or description of the element to tap"),
            listOf("text"),
        ),
        functionDecl(
            "type_text", "Type text into the focused input field, replacing its content.",
            mapOf("text" to "Text to type"),
            listOf("text"),
        ),
        functionDecl(
            "scroll_screen", "Scroll the current screen.",
            mapOf("direction" to "up, down, left or right (default down)"),
        ),
        functionDecl("go_back", "Press the system Back button."),
        functionDecl("go_home", "Go to the home screen."),
    )
}
