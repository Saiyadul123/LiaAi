package com.Lia.assistant.voice

/** DIRECT flavor: full phone control. The same object exists in src/play with a reduced set. */
object LiaToolCatalog {
    fun declarations(): List<ToolDeclaration> = listOf(
        ToolDeclaration(
            "call_contact", "Place a phone call to a saved contact by name.",
            listOf(ToolParam("name", "Contact name to call"))
        ),
        ToolDeclaration(
            "open_app", "Open an installed app by its display name.",
            listOf(ToolParam("app_name", "Name of the app, e.g. YouTube"))
        ),
        ToolDeclaration("read_screen", "Read the text currently visible on the screen."),
        ToolDeclaration(
            "tap", "Tap a visible element on the screen.",
            listOf(ToolParam("target", "Visible text or description of the element to tap"))
        ),
        ToolDeclaration(
            "type_text", "Type text into the focused input field.",
            listOf(ToolParam("text", "Text to type"))
        ),
        ToolDeclaration(
            "scroll", "Scroll the current screen.",
            listOf(ToolParam("direction", "One of: up, down, left, right"))
        ),
        ToolDeclaration("go_back", "Press the system Back button."),
        ToolDeclaration("go_home", "Go to the home screen."),
    )
}
