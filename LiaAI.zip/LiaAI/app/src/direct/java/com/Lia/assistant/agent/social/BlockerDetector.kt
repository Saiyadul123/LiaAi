package com.Lia.assistant.agent.social

import com.Lia.assistant.agent.core.Blocker
import com.Lia.assistant.agent.core.ScreenObservation
import com.Lia.assistant.agent.core.TextMatch

/**
 * Spots screens only the user can deal with (login, CAPTCHA, a security code, a security check, a system
 * permission dialog). The agent stops there and waits; it never tries to get past them.
 */
object BlockerDetector {
    private val CAPTCHA = listOf(
        "captcha", "i'm not a robot", "i am not a robot", "verify you are human", "verify you're human",
        "prove you're human", "select all images", "select all squares",
    )
    private val TWO_FACTOR = listOf(
        "two-factor", "two factor", "2-factor", "6-digit code", "security code", "confirmation code",
        "login code", "verification code", "authentication app", "enter the code",
    )
    private val SECURITY_CHECK = listOf(
        "suspicious", "unusual activity", "security check", "verify your identity", "confirm it's you",
        "confirm that it's you", "confirm you own this account", "help us confirm", "temporarily locked",
    )
    /** Whole-label matches only, so a sentence that merely mentions "log in" does not count. */
    private val LOGIN_LABELS = listOf(
        "log in", "login", "sign in", "forgot password", "create new account", "create account",
        "don't have an account", "already have an account",
    )

    fun detect(observation: ScreenObservation): Blocker? {
        if (observation.packageName.contains("permissioncontroller") || observation.windowClass.endsWith("GrantPermissionsActivity")) {
            return Blocker.PERMISSION_PROMPT
        }
        val text = observation.allText().map { TextMatch.normalize(it) }
        if (text.any { t -> CAPTCHA.any { t.contains(it) } }) return Blocker.CAPTCHA
        if (text.any { t -> TWO_FACTOR.any { t.contains(it) } }) return Blocker.TWO_FACTOR
        if (text.any { t -> SECURITY_CHECK.any { t.contains(it) } }) return Blocker.SECURITY_CHECK
        if (text.any { raw -> val t = raw.trimEnd('?', '!'); LOGIN_LABELS.any { t == it || t.startsWith("$it ") } }) return Blocker.LOGIN
        return null
    }
}
