package com.Lia.assistant.agent.social

import android.content.ContentResolver
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.content.FileProvider
import androidx.core.content.IntentCompat
import androidx.lifecycle.lifecycleScope
import com.Lia.assistant.data.NovaPreferences
import com.Lia.assistant.data.SettingsFallback
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * The share-sheet entry: photos and videos shared to the assistant are copied into its own storage and
 * registered in [SharedMedia] under a content:// URI that only this app serves. That is the only media the
 * social agent will use.
 */
class ShareToLiaActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uris = sharedUris(intent)
        if (uris.isEmpty()) {
            finish()
            return
        }
        val app = applicationContext
        lifecycleScope.launch {
            val saved = withContext(Dispatchers.IO) { uris.take(MAX_FILES).mapNotNull { copyIntoShared(app, it) } }
            val name = SettingsFallback.assistantName(
                NovaPreferences.getString(app, NovaPreferences.Keys.ASSISTANT_NAME), null
            )
            val text = if (saved.isEmpty()) "Couldn't read that file" else "Shared with $name"
            Toast.makeText(app, text, Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun sharedUris(intent: Intent): List<Uri> = when (intent.action) {
        Intent.ACTION_SEND -> listOfNotNull(IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java))
        Intent.ACTION_SEND_MULTIPLE ->
            IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java).orEmpty()
        else -> emptyList()
    }

    private fun copyIntoShared(context: android.content.Context, source: Uri): String? {
        val resolver: ContentResolver = context.contentResolver
        val mime = resolver.getType(source)
        if (mime == null || !(mime.startsWith("image/") || mime.startsWith("video/"))) return null
        val extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "bin"

        val dir = File(context.cacheDir, "shared").apply { mkdirs() }
        dir.listFiles()?.sortedBy { it.lastModified() }?.dropLast(KEEP_FILES - 1)?.forEach { it.delete() }

        val file = File(dir, "share-${System.currentTimeMillis()}.$extension")
        try {
            resolver.openInputStream(source)?.use { input -> file.outputStream().use { input.copyTo(it) } } ?: return null
        } catch (_: java.io.IOException) {
            file.delete()
            return null
        } catch (_: SecurityException) {
            file.delete()
            return null
        }
        val shared = FileProvider.getUriForFile(context, "${context.packageName}.direct.fileprovider", file)
        SharedMedia.register(shared.toString(), mime, displayName(resolver, source) ?: file.name)
        return shared.toString()
    }

    private fun displayName(resolver: ContentResolver, uri: Uri): String? = try {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: RuntimeException) {
        null
    }

    private companion object {
        const val MAX_FILES = 5
        const val KEEP_FILES = 20
    }
}
