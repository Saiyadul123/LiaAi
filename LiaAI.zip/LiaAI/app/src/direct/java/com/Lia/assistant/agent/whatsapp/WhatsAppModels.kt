package com.Lia.assistant.agent.whatsapp

import org.json.JSONObject

enum class WhatsAppAction(val id: String) {
    /** From notifications only. Never opens the app. */
    READ_UNREAD("read_unread"),
    SEND_MESSAGE("send_message"),
    READ_CHAT("read_chat"),
    SEARCH_CHAT("search_chat"),
    MUTE_CHAT("mute_chat"),
    UNMUTE_CHAT("unmute_chat"),
    MARK_READ("mark_read");

    companion object {
        fun parse(value: String?): WhatsAppAction? = entries.firstOrNull { it.id == value?.trim()?.lowercase() }
    }
}

enum class MuteDuration(val id: String, val label: String) {
    HOURS_8("8_hours", "8 hours"),
    WEEK_1("1_week", "1 week"),
    ALWAYS("always", "Always");

    companion object {
        fun parse(value: String?): MuteDuration? = entries.firstOrNull { it.id == value?.trim()?.lowercase() }
    }
}

sealed interface WhatsAppParse {
    data class Valid(val request: WhatsAppRequest) : WhatsAppParse
    data class Invalid(val code: String, val message: String) : WhatsAppParse
}

/** A validated WhatsApp task. Built only through [parse], so nothing starts for bad arguments. */
data class WhatsAppRequest(
    val action: WhatsAppAction,
    /** Digits only, with country code, no plus sign. */
    val phone: String?,
    val contact: String?,
    val message: String?,
    val query: String?,
    val duration: MuteDuration,
) {
    companion object {
        const val MAX_MESSAGE = 4096

        private fun str(args: JSONObject, key: String): String = if (args.isNull(key)) "" else args.optString(key).trim()

        /** Digits of a phone number if it has 8 to 15 of them (formatting characters are ignored), else null. */
        fun normalizePhone(raw: String): String? {
            if (raw.any { !(it.isDigit() || it in " +-().") }) return null
            val digits = raw.filter { it.isDigit() }
            return digits.takeIf { it.length in 8..15 }
        }

        fun parse(args: JSONObject): WhatsAppParse {
            val action = WhatsAppAction.parse(str(args, "action"))
                ?: return invalid("invalid_action", "action must be read_unread, send_message, read_chat, search_chat, mute_chat, unmute_chat or mark_read")

            val phoneText = str(args, "phone")
            val phone = if (phoneText.isEmpty()) null else normalizePhone(phoneText)
                ?: return invalid("invalid_phone", "phone must be a full number with country code, for example +919876543210")
            val contact = str(args, "contact").ifEmpty { null }
            val message = str(args, "message").ifEmpty { null }
            val query = str(args, "query").ifEmpty { null }

            val durationText = str(args, "duration")
            val duration = if (durationText.isEmpty()) MuteDuration.ALWAYS else MuteDuration.parse(durationText)
                ?: return invalid("invalid_duration", "duration must be 8_hours, 1_week or always")

            when (action) {
                WhatsAppAction.READ_UNREAD -> Unit
                WhatsAppAction.SEND_MESSAGE -> {
                    if (phone == null) return invalid("phone_required", "send_message needs phone (with country code); to message someone by name use the message_contact tool")
                    if (message == null) return invalid("message_required", "send_message needs the text in message")
                    if (message.length > MAX_MESSAGE) return invalid("message_too_long", "a message is at most $MAX_MESSAGE characters")
                }
                WhatsAppAction.SEARCH_CHAT ->
                    if (query == null) return invalid("query_required", "search_chat needs query")
                WhatsAppAction.READ_CHAT, WhatsAppAction.MUTE_CHAT, WhatsAppAction.UNMUTE_CHAT, WhatsAppAction.MARK_READ ->
                    if (phone == null && contact == null) return invalid("contact_required", "${action.id} needs contact (a name) or phone")
            }
            return WhatsAppParse.Valid(WhatsAppRequest(action, phone, contact, message, query, duration))
        }

        private fun invalid(code: String, message: String) = WhatsAppParse.Invalid(code, message)
    }
}
