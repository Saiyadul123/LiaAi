package com.Lia.assistant

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.KeyboardReturn
import androidx.compose.material.icons.rounded.Visibility
import com.Lia.assistant.ui.screens.quickactions.QuickActionSpec

/** Same object exists in src/play with safe stub values. */
object FlavorRoutes {
    const val screenControlAvailable = true
    const val flavorLabel = "Direct build - screen control available"

    /** Tiles for tools only this flavor has (all go through the accessibility service). */
    fun extraQuickActions(): List<QuickActionSpec> = listOf(
        QuickActionSpec("read_screen", "Read the screen", "See what is on screen right now", Icons.Rounded.Visibility, "read_screen"),
        QuickActionSpec("go_home", "Go home", "Return to the home screen", Icons.Rounded.Home, "go_home"),
        QuickActionSpec("go_back", "Go back", "Press the Back button", Icons.Rounded.KeyboardReturn, "go_back"),
    )
}
