package com.Lia.assistant

/** Same object exists in src/play with safe stub values. */
object FlavorRoutes {
    const val screenControlAvailable = true
    const val flavorLabel = "Direct build - screen control available"
}
