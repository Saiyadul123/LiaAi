Fonts used by the Lia AI design system (all under the SIL Open Font License 1.1)

- Instrument Serif (regular + italic): bundled in res/font/instrument_serif_*.ttf
- Manrope (variable, weights 400-800): licence shipped here; add the font file as
  res/font/manrope_variable.ttf and it is picked up automatically (until then the system
  sans-serif is used). Download: https://fonts.google.com/specimen/Manrope
