package com.Lia.assistant.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import kotlin.math.pow

/**
 * Colour tokens. Identity: "a pearl of light in the night". ONE warm marigold accent marks everything
 * actionable; [lotus] and [lagoon] are reserved for the orb. Screens must only use these tokens.
 */
@Immutable
data class NovaColorScheme(
    val background: Color,
    val backgroundGradientTop: Color,
    val surface: Color,
    val surfaceGlass: Color,
    val surfaceBorder: Color,
    val surfaceRaised: Color,
    val accent: Color,
    val accentSecondary: Color,
    val accentGlow: Color,
    /** The accent as TEXT on surfaces: equals [accent] in Dark, a darker amber in Light for AA contrast. */
    val accentText: Color,
    val onAccent: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val success: Color,
    val warning: Color,
    val error: Color,
    val userBubble: Color,
    val assistantBubble: Color,
    val depthShadow: Color,
    val rimLight: Color,
    val lagoon: Color,
    val lotus: Color,
) {
    companion object {
        private val Lotus = Color(0xFFFF6FAE)
        private val Lagoon = Color(0xFF3FE0D0)

        val Dark = NovaColorScheme(
            background = Color(0xFF06050E),
            backgroundGradientTop = Color(0xFF15113A),
            surface = Color(0xFF17143A),
            surfaceGlass = Color(0xB317143A),
            surfaceBorder = Color(0x24FFFFFF),
            surfaceRaised = Color(0xFF221E4D),
            accent = Color(0xFFFFB547),
            accentSecondary = Color(0xFFFF8A3D),
            accentGlow = Color(0x66FFB547),
            accentText = Color(0xFFFFB547),
            onAccent = Color(0xFF1B1200),
            textPrimary = Color(0xFFEEE9FF),
            textSecondary = Color(0xFFA7A0CC),
            textTertiary = Color(0xFF8F89B8),
            success = Color(0xFF5BE3A0),
            warning = Color(0xFFFFC857),
            error = Color(0xFFFF6B7A),
            userBubble = Color(0xFF3B3487),
            assistantBubble = Color(0xFF1D1946),
            depthShadow = Color(0xFF3B2AA8),
            rimLight = Color(0x33FFFFFF),
            lagoon = Lagoon,
            lotus = Lotus,
        )

        val Light = NovaColorScheme(
            background = Color(0xFFF3F0FB),
            backgroundGradientTop = Color(0xFFE3DCFA),
            surface = Color(0xFFFFFFFF),
            surfaceGlass = Color(0xCCFFFFFF),
            surfaceBorder = Color(0x2615112E),
            surfaceRaised = Color(0xFFF8F6FE),
            accent = Color(0xFFB86A00),
            accentSecondary = Color(0xFFDB6B14),
            accentGlow = Color(0x40B86A00),
            accentText = Color(0xFF8F5000),
            onAccent = Color(0xFF1A0F00),
            textPrimary = Color(0xFF15112E),
            textSecondary = Color(0xFF4F4878),
            textTertiary = Color(0xFF655F8A),
            success = Color(0xFF0B7A4B),
            warning = Color(0xFF8A5A00),
            error = Color(0xFFB3261E),
            userBubble = Color(0xFFDCD3FF),
            assistantBubble = Color(0xFFFFFFFF),
            depthShadow = Color(0xFF4B3A99),
            rimLight = Color(0xCCFFFFFF),
            lagoon = Lagoon,
            lotus = Lotus,
        )
    }
}

val LocalNovaColors = staticCompositionLocalOf { NovaColorScheme.Dark }

// ---- WCAG contrast helpers (used by tests and available for tooling) -----------------------------

internal fun relativeLuminance(color: Color): Double {
    fun channel(v: Float): Double {
        val d = v.toDouble()
        return if (d <= 0.03928) d / 12.92 else ((d + 0.055) / 1.055).pow(2.4)
    }
    return 0.2126 * channel(color.red) + 0.7152 * channel(color.green) + 0.0722 * channel(color.blue)
}

/** WCAG contrast ratio (1..21). A translucent [foreground] is composited over [background] first. */
internal fun contrastRatio(foreground: Color, background: Color): Double {
    val fg = relativeLuminance(foreground.compositeOver(background))
    val bg = relativeLuminance(background)
    val lighter = maxOf(fg, bg)
    val darker = minOf(fg, bg)
    return (lighter + 0.05) / (darker + 0.05)
}
