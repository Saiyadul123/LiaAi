package com.Lia.assistant.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.theme.NovaSizes
import com.Lia.assistant.ui.theme.NovaTheme

/**
 * Text field with an optional label, leading icon, trailing slot and supporting text. The outline is
 * textTertiary (3:1+ against the surface), accent when focused and error-coloured when [isError].
 * Set [bordered] to false to embed it in another container (for example a chat input bar).
 */
@Composable
fun NovaTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    placeholder: String? = null,
    leadingIcon: ImageVector? = null,
    trailing: (@Composable () -> Unit)? = null,
    supportingText: String? = null,
    isError: Boolean = false,
    enabled: Boolean = true,
    singleLine: Boolean = false,
    minLines: Int = 1,
    maxLines: Int = if (singleLine) 1 else 4,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    bordered: Boolean = true,
) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val shape = NovaTheme.shapes.small
    var focused by remember { mutableStateOf(false) }
    val borderColor = when {
        isError -> colors.error
        focused -> colors.accent
        else -> colors.textTertiary
    }

    Column(modifier) {
        if (label != null) {
            Text(
                text = label,
                style = type.label,
                color = if (isError) colors.error else colors.textSecondary,
                modifier = Modifier.padding(bottom = 6.dp),
            )
        }
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = NovaSizes.MinTouch)
                .onFocusChanged { focused = it.isFocused }
                .semantics { if (label != null) this.contentDescription = label },
            enabled = enabled,
            textStyle = type.body.copy(color = colors.textPrimary),
            keyboardOptions = keyboardOptions,
            keyboardActions = keyboardActions,
            singleLine = singleLine,
            maxLines = maxLines,
            minLines = minLines,
            visualTransformation = visualTransformation,
            cursorBrush = SolidColor(colors.accent),
            decorationBox = { inner ->
                val frame = if (bordered) {
                    Modifier
                        .clip(shape)
                        .background(colors.surfaceRaised)
                        .border(if (focused) 2.dp else 1.dp, borderColor, shape)
                } else {
                    Modifier
                }
                Row(
                    modifier = Modifier.fillMaxWidth().then(frame).padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (leadingIcon != null) {
                        Icon(leadingIcon, contentDescription = null, modifier = Modifier.size(20.dp), tint = colors.textSecondary)
                        Spacer(Modifier.width(10.dp))
                    }
                    Box(Modifier.weight(1f)) {
                        if (value.isEmpty() && placeholder != null) {
                            Text(placeholder, style = type.body, color = colors.textTertiary)
                        }
                        inner()
                    }
                    trailing?.invoke()
                }
            },
        )
        if (supportingText != null) {
            Text(
                text = supportingText,
                style = type.caption,
                color = if (isError) colors.error else colors.textSecondary,
                modifier = Modifier.padding(start = 4.dp, top = 4.dp),
            )
        }
    }
}
