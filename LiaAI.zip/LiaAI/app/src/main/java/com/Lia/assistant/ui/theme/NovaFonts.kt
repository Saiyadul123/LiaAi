package com.Lia.assistant.ui.theme

import android.annotation.SuppressLint
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight

/**
 * Brand fonts. They are resolved by resource name so the project builds with or without the files:
 *  - Instrument Serif: res/font/instrument_serif_regular.ttf + instrument_serif_italic.ttf
 *  - Manrope (variable): res/font/manrope_variable.ttf
 * A missing file falls back to the system serif / sans-serif.
 */
@Immutable
class NovaFonts(val serif: FontFamily, val sans: FontFamily) {

    companion object {
        val Fallback = NovaFonts(FontFamily.Serif, FontFamily.SansSerif)

        private val MANROPE_WEIGHTS = listOf(400, 500, 600, 700, 800)

        /** [resolve] maps a font resource name to its id, or 0 when the font is not bundled. */
        internal fun from(resolve: (String) -> Int): NovaFonts {
            val regular = resolve("instrument_serif_regular")
            val italic = resolve("instrument_serif_italic")
            val serifFonts = buildList {
                if (regular != 0) add(Font(regular, FontWeight.Normal, FontStyle.Normal))
                if (italic != 0) add(Font(italic, FontWeight.Normal, FontStyle.Italic))
            }
            val manrope = resolve("manrope_variable")
            return NovaFonts(
                serif = if (serifFonts.isEmpty()) FontFamily.Serif else FontFamily(serifFonts),
                sans = if (manrope == 0) {
                    FontFamily.SansSerif
                } else {
                    FontFamily(
                        MANROPE_WEIGHTS.map { w ->
                            Font(
                                resId = manrope,
                                weight = FontWeight(w),
                                variationSettings = FontVariation.Settings(FontVariation.weight(w)),
                            )
                        }
                    )
                },
            )
        }
    }
}

@SuppressLint("DiscouragedApi")
@Composable
fun rememberNovaFonts(): NovaFonts {
    val context = LocalContext.current
    return remember(context) {
        NovaFonts.from { name -> context.resources.getIdentifier(name, "font", context.packageName) }
    }
}
