package com.Lia.assistant.voice

import android.content.Context
import android.content.Intent
import com.Lia.assistant.MainActivity
import com.Lia.assistant.forge.ForgeController
import org.json.JSONObject

/**
 * Entry point for the "Forge" (build_website). It records the request in [ForgeController] and tries to
 * bring the app forward; if Android refuses the background launch the request simply waits until the
 * app is opened. Returns immediately.
 */
object LiaForge {
    fun start(context: Context, args: JSONObject) {
        val brief = args.optString("description").ifBlank { args.optString("brief") }.ifBlank { null }
        ForgeController.requestOpen(brief)
        val intent = Intent(context, MainActivity::class.java)
        intent.putExtra(ForgeController.EXTRA_OPEN_FORGE, true)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        try {
            context.startActivity(intent)
        } catch (_: RuntimeException) {
            // background launch not allowed: the pending request is picked up when the app opens
        }
    }
}
