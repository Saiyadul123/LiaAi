package com.Lia.assistant.voice

import android.util.Log
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** One turn of a typed chat. */
data class ChatTurn(val isUser: Boolean, val text: String)

sealed interface ChatReplyResult {
    data class Success(val text: String) : ChatReplyResult
    data class Error(val message: String) : ChatReplyResult
}

/**
 * Text (non-live) Gemini calls over REST. The model id is discovered from the account's model list,
 * never hardcoded. The API key travels in the x-goog-api-key header, and logs only ever contain the
 * HTTP status and Gemini's own error reason (never the key or what the user typed).
 */
object GeminiTextClient {
    private const val TAG = "GeminiTextClient"
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    private const val KEY_HEADER = "x-goog-api-key"
    private val JSON = "application/json; charset=utf-8".toMediaType()

    internal const val MSG_NO_KEY = "Add your Gemini API key in Settings to use chat."
    internal const val MSG_NO_HISTORY = "There is nothing to send yet."
    internal const val MSG_UNREACHABLE = "Couldn't reach Gemini. Check your connection and try again."
    internal const val MSG_EMPTY = "Gemini sent back an empty reply. Please try again."
    internal const val MSG_BLOCKED = "Gemini couldn't answer that one. Try rephrasing your message."
    internal const val MSG_NO_MODEL = "No Gemini model is available for this API key."

    private val BLOCKED_FINISH = setOf("SAFETY", "RECITATION", "BLOCKLIST", "PROHIBITED_CONTENT", "SPII", "IMAGE_SAFETY")

    /** Shared with the Website Forge. Derive variants with newBuilder() if you need other timeouts. */
    internal val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .callTimeout(90, TimeUnit.SECONDS)
            .build()
    }

    @Volatile
    private var cachedModel: String? = null

    private sealed interface Resolution {
        class Model(val name: String) : Resolution
        class Failure(val message: String) : Resolution
    }

    // ---- Model discovery --------------------------------------------------------------------

    /** Model resource name ("models/..."), cached for the process; null if it can't be resolved. */
    internal suspend fun resolveModel(apiKey: String): String? =
        (resolve(apiKey) as? Resolution.Model)?.name

    private suspend fun resolve(apiKey: String): Resolution {
        cachedModel?.let { return Resolution.Model(it) }
        return try {
            val request = Request.Builder()
                .url("$BASE/models?pageSize=1000")
                .header(KEY_HEADER, apiKey)
                .get()
                .build()
            client.newCall(request).await().use { response ->
                val body = withContext(Dispatchers.IO) { response.body.string() }
                if (!response.isSuccessful) return Resolution.Failure(httpFailure(response.code, body))
                val model = pickModel(body) ?: return Resolution.Failure(MSG_NO_MODEL)
                cachedModel = model
                Resolution.Model(model)
            }
        } catch (_: IOException) {
            Resolution.Failure(MSG_UNREACHABLE)
        }
    }

    /**
     * First model that supports generateContent and whose name contains "flash" but not "live",
     * "image" or "tts"; otherwise the first generateContent model.
     */
    internal fun pickModel(modelsJson: String): String? {
        val models = try {
            JSONObject(modelsJson).optJSONArray("models")
        } catch (_: JSONException) {
            null
        } ?: return null

        val usable = ArrayList<String>()
        for (i in 0 until models.length()) {
            val model = models.optJSONObject(i) ?: continue
            val name = model.optString("name")
            if (name.isNotEmpty() && model.optJSONArray("supportedGenerationMethods").contains("generateContent")) {
                usable += name
            }
        }
        val preferred = usable.firstOrNull { name ->
            val n = name.lowercase()
            "flash" in n && listOf("live", "image", "tts").none { it in n }
        }
        return preferred ?: usable.firstOrNull()
    }

    private fun JSONArray?.contains(value: String): Boolean {
        if (this == null) return false
        for (i in 0 until length()) if (optString(i) == value) return true
        return false
    }

    // ---- Reply ------------------------------------------------------------------------------

    suspend fun reply(apiKey: String, systemInstruction: String, history: List<ChatTurn>): ChatReplyResult {
        if (apiKey.isBlank()) return ChatReplyResult.Error(MSG_NO_KEY)
        if (history.isEmpty()) return ChatReplyResult.Error(MSG_NO_HISTORY)

        val model = when (val r = resolve(apiKey)) {
            is Resolution.Model -> r.name
            is Resolution.Failure -> return ChatReplyResult.Error(r.message)
        }
        return try {
            val request = Request.Builder()
                .url("$BASE/$model:generateContent")
                .header(KEY_HEADER, apiKey)
                .post(buildRequestBody(systemInstruction, history).toRequestBody(JSON))
                .build()
            client.newCall(request).await().use { response ->
                val body = withContext(Dispatchers.IO) { response.body.string() }
                if (response.isSuccessful) {
                    parseReply(body)
                } else {
                    if (response.code == 404) cachedModel = null // model retired: look it up again next time
                    ChatReplyResult.Error(httpFailure(response.code, body))
                }
            }
        } catch (_: IOException) {
            ChatReplyResult.Error(MSG_UNREACHABLE)
        }
    }

    internal fun buildRequestBody(systemInstruction: String, history: List<ChatTurn>): String {
        val contents = JSONArray()
        mergeConsecutive(history).forEach { turn ->
            contents.put(
                JSONObject()
                    .put("role", if (turn.isUser) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", turn.text)))
            )
        }
        val root = JSONObject().put("contents", contents)
        if (systemInstruction.isNotBlank()) {
            root.put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
            )
        }
        return root.toString()
    }

    /** Joins neighbouring turns by the same side (for example after a failed reply was dropped). */
    internal fun mergeConsecutive(history: List<ChatTurn>): List<ChatTurn> {
        val out = ArrayList<ChatTurn>()
        for (turn in history) {
            if (turn.text.isBlank()) continue
            val last = out.lastOrNull()
            if (last != null && last.isUser == turn.isUser) {
                out[out.lastIndex] = ChatTurn(last.isUser, last.text + "\n" + turn.text)
            } else {
                out += turn
            }
        }
        return out
    }

    internal fun parseReply(json: String): ChatReplyResult {
        val root = try {
            JSONObject(json)
        } catch (_: JSONException) {
            return ChatReplyResult.Error(MSG_EMPTY)
        }
        val blockReason = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
        if (blockReason.isNotEmpty()) return ChatReplyResult.Error(MSG_BLOCKED)

        val candidate = root.optJSONArray("candidates")?.optJSONObject(0)
            ?: return ChatReplyResult.Error(MSG_EMPTY)

        val parts = candidate.optJSONObject("content")?.optJSONArray("parts")
        val text = buildString {
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.optJSONObject(i) ?: continue
                    if (part.optBoolean("thought")) continue
                    append(part.optString("text"))
                }
            }
        }.trim()
        if (text.isNotEmpty()) return ChatReplyResult.Success(text)

        return if (candidate.optString("finishReason") in BLOCKED_FINISH) {
            ChatReplyResult.Error(MSG_BLOCKED)
        } else {
            ChatReplyResult.Error(MSG_EMPTY)
        }
    }

    // ---- Errors -----------------------------------------------------------------------------

    /** Gemini's own error message from an error body, or null. */
    internal fun extractReason(body: String): String? = try {
        JSONObject(body).optJSONObject("error")?.optString("message")?.trim()?.take(200)?.takeIf { it.isNotEmpty() }
    } catch (_: JSONException) {
        null
    }

    internal fun describeHttpError(status: Int, reason: String?): String = when {
        status == 429 -> "Gemini is busy or over its quota right now (HTTP 429). Try again in a moment."
        status == 401 || reason?.contains("API key", ignoreCase = true) == true ->
            "Gemini rejected your API key (HTTP $status). Check it in Settings."
        status >= 500 -> "Gemini is having trouble right now (HTTP $status). Try again shortly."
        else -> "Gemini returned an error (HTTP $status${reason?.let { ": $it" }.orEmpty()})."
    }

    /** Logs status + Gemini's reason only, and returns the message to show the user. */
    private fun httpFailure(status: Int, body: String): String {
        val reason = extractReason(body)
        Log.w(TAG, "HTTP $status${reason?.let { ": $it" }.orEmpty()}")
        return describeHttpError(status, reason)
    }

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
        cont.invokeOnCancellation { cancel() }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(e)
            }

            override fun onResponse(call: Call, response: Response) {
                cont.resume(response) { response.close() }
            }
        })
    }

    internal fun resetModelCacheForTest() {
        cachedModel = null
    }
}
