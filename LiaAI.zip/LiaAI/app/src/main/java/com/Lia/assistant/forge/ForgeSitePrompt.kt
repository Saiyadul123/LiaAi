package com.Lia.assistant.forge

/** Instructions for the model that writes the websites the Forge builds for users. */
object ForgeSitePrompt {
    val THREE_D: String = """
        Every website you generate uses 3D, not flat layouts.
        - Hero: a Three.js scene (a themed object or a particle field) that reacts to the pointer and to scroll.
        - Final call to action: a second Three.js scene, or a scroll-driven 3D transform.
        - Everywhere else use CSS 3D: perspective tilt cards, translateZ depth layers, flip cards, rotating cubes.
        - Photos in at most two sections, each with a dark gradient overlay so the text stays readable.
        - Content is always visible without waiting for animation: motion only enhances it.
    """.trimIndent()
}
