package com.Lia.assistant.forge

import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/** What people are told when a build goes wrong. Raw Gemini messages are never shown. */
object ForgeErrors {
    const val STOPPED_EARLY = "Gemini stopped before finishing"

    fun isOverloaded(e: SseError): Boolean =
        e.code == 503 || e.status.equals("UNAVAILABLE", ignoreCase = true) || e.message.contains("overloaded", ignoreCase = true)

    fun friendly(e: SseError): String = when {
        isOverloaded(e) -> "Gemini is busy right now. Please try again in a moment."
        e.code == 429 || e.status.equals("RESOURCE_EXHAUSTED", ignoreCase = true) ->
            "Gemini says you have used up your quota or are going too fast. Wait a little and try again."
        e.message.contains("api key", ignoreCase = true) || e.code == 401 || e.code == 403 ||
            e.status.equals("UNAUTHENTICATED", ignoreCase = true) || e.status.equals("PERMISSION_DENIED", ignoreCase = true) ->
            "Gemini did not accept your API key. Check it in Settings."
        e.code == 404 -> "The Gemini model for this feature is not available for your key."
        e.code == 400 -> "Gemini could not handle that request. Try describing the website a different way."
        e.code in 500..599 -> "Gemini had a problem on its side. Please try again."
        else -> "Gemini could not build the website. Please try again."
    }

    fun forIo(t: Throwable): String = when (t) {
        is SocketTimeoutException -> "Gemini took too long to answer. Please try again."
        is UnknownHostException, is ConnectException -> "There is no internet connection."
        is IOException -> "The connection to Gemini was interrupted. Please try again."
        else -> "Gemini could not build the website. Please try again."
    }
}
