package com.Lia.assistant.ui.screens.permissions

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme

/** Green: allowed. Amber: not allowed yet, can be asked. Red: blocked, only Android settings can fix it. */
enum class PermissionLight { GRANTED, CAN_ASK, BLOCKED }

/**
 * Red only when the user was already asked and Android will not show the dialog again
 * (no rationale to show). Before the first ask, or when a rationale is due, it stays amber.
 */
internal fun permissionLight(granted: Boolean, askedBefore: Boolean, showRationale: Boolean): PermissionLight = when {
    granted -> PermissionLight.GRANTED
    !askedBefore -> PermissionLight.CAN_ASK
    showRationale -> PermissionLight.CAN_ASK
    else -> PermissionLight.BLOCKED
}

internal fun permissionActionLabel(light: PermissionLight): String = when (light) {
    PermissionLight.GRANTED -> "Manage"
    PermissionLight.CAN_ASK -> "Allow"
    PermissionLight.BLOCKED -> "Open settings"
}

internal fun permissionStateText(light: PermissionLight): String = when (light) {
    PermissionLight.GRANTED -> "Allowed"
    PermissionLight.CAN_ASK -> "Not allowed yet"
    PermissionLight.BLOCKED -> "Blocked, open settings to change"
}

/** A status light that pulses once whenever its state changes. */
@Composable
private fun StatusLight(light: PermissionLight) {
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val target = when (light) {
        PermissionLight.GRANTED -> colors.success
        PermissionLight.CAN_ASK -> colors.warning
        PermissionLight.BLOCKED -> colors.error
    }
    val color by animateColorAsState(target, tween(if (reduced) 0 else NovaMotion.MEDIUM), label = "lightColor")
    val pulse = remember { Animatable(0f) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(light) {
        if (first) {
            first = false
        } else if (!reduced) {
            pulse.snapTo(0f)
            pulse.animateTo(1f, tween(600))
        }
    }
    Canvas(Modifier.size(24.dp)) {
        val r = 6.dp.toPx()
        if (pulse.value > 0f && pulse.value < 1f) {
            drawCircle(color.copy(alpha = (1f - pulse.value) * 0.6f), radius = r + pulse.value * 9.dp.toPx(), center = center)
        }
        drawCircle(color.copy(alpha = 0.30f), radius = r * 1.7f, center = center) // soft glow
        drawCircle(color, radius = r, center = center)
    }
}

/** One permission: status light, name, what it is for, and the action that fits its state. */
@Composable
fun PermissionRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    light: PermissionLight,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val haptics = LocalHapticFeedback.current
    val action = permissionActionLabel(light)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .clickable(onClickLabel = action, role = Role.Button) {
                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .semantics(mergeDescendants = true) { stateDescription = permissionStateText(light) }
            .padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.md),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StatusLight(light)
        Spacer(Modifier.width(NovaSpacing.md))
        Icon(icon, contentDescription = null, tint = colors.textSecondary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(NovaSpacing.md))
        Column(Modifier.weight(1f)) {
            Text(title, style = type.body, color = colors.textPrimary)
            Text(subtitle, style = type.caption, color = colors.textSecondary)
        }
        Spacer(Modifier.width(NovaSpacing.sm))
        Text(action, style = type.label, color = colors.accentText)
    }
}
