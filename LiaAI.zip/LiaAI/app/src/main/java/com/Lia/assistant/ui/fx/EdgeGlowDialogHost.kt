package com.Lia.assistant.ui.fx

import android.graphics.Color as AndroidColor
import android.graphics.drawable.ColorDrawable
import android.view.ViewGroup
import android.view.WindowManager
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import com.Lia.assistant.ui.components.ListeningEdgeGlow
import com.Lia.assistant.voice.VoiceSessionManager

/**
 * Hosts [ListeningEdgeGlow] in a full-screen, transparent, non-touchable Dialog window so it sits
 * above every screen (and every other dialog opened earlier). Present only while a voice session is
 * active, and not when the direct flavor's overlay window is already showing the same glow.
 */
@Composable
fun EdgeGlowDialogHost() {
    val active by VoiceSessionManager.isActive.collectAsState()
    val state by VoiceSessionManager.state.collectAsState()
    val amplitude by VoiceSessionManager.amplitude.collectAsState()
    val overlayShowing by OverlayEdgeGlowController.showing.collectAsState()
    if (!active || overlayShowing) return

    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false,
        ),
    ) {
        val window = (LocalView.current.parent as? DialogWindowProvider)?.window
        SideEffect {
            window?.apply {
                setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                setBackgroundDrawable(ColorDrawable(AndroidColor.TRANSPARENT))
                clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                addFlags(
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                )
            }
        }
        ListeningEdgeGlow(state = state, amplitude = amplitude, modifier = Modifier.fillMaxSize())
    }
}
