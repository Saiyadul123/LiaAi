package com.Lia.assistant.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.runtime.Immutable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Instrument Serif for display / headline / "voice" lines, Manrope for title / body / label / caption.
 * Styles carry no colour: components pick it from [NovaColorScheme].
 */
@Immutable
data class NovaTypography(
    val display: TextStyle,
    val headline: TextStyle,
    /** Italic serif for the assistant's spoken lines and quotes. */
    val voice: TextStyle,
    val title: TextStyle,
    val body: TextStyle,
    val label: TextStyle,
    val caption: TextStyle,
) {
    /** Maps the tokens onto Material3 so stock components pick up the brand fonts. */
    fun toMaterial(): Typography = Typography(
        displayLarge = display,
        displayMedium = display.copy(fontSize = 34.sp, lineHeight = 42.sp),
        displaySmall = headline,
        headlineLarge = headline,
        headlineMedium = headline.copy(fontSize = 24.sp, lineHeight = 32.sp),
        headlineSmall = headline.copy(fontSize = 22.sp, lineHeight = 28.sp),
        titleLarge = title.copy(fontSize = 20.sp, lineHeight = 28.sp),
        titleMedium = title,
        titleSmall = title.copy(fontSize = 15.sp, lineHeight = 20.sp),
        bodyLarge = body,
        bodyMedium = body,
        bodySmall = caption,
        labelLarge = label.copy(fontSize = 14.sp, lineHeight = 20.sp),
        labelMedium = label,
        labelSmall = caption,
    )

    companion object {
        fun create(fonts: NovaFonts): NovaTypography = NovaTypography(
            display = TextStyle(
                fontFamily = fonts.serif, fontWeight = FontWeight.Normal,
                fontSize = 40.sp, lineHeight = 48.sp, letterSpacing = (-0.5).sp,
            ),
            headline = TextStyle(
                fontFamily = fonts.serif, fontWeight = FontWeight.Normal,
                fontSize = 28.sp, lineHeight = 36.sp,
            ),
            voice = TextStyle(
                fontFamily = fonts.serif, fontWeight = FontWeight.Normal, fontStyle = FontStyle.Italic,
                fontSize = 22.sp, lineHeight = 30.sp,
            ),
            title = TextStyle(
                fontFamily = fonts.sans, fontWeight = FontWeight.SemiBold,
                fontSize = 17.sp, lineHeight = 24.sp,
            ),
            body = TextStyle(
                fontFamily = fonts.sans, fontWeight = FontWeight.Normal,
                fontSize = 15.sp, lineHeight = 22.sp,
            ),
            label = TextStyle(
                fontFamily = fonts.sans, fontWeight = FontWeight.Medium,
                fontSize = 13.sp, lineHeight = 18.sp,
            ),
            caption = TextStyle(
                fontFamily = fonts.sans, fontWeight = FontWeight.Normal,
                fontSize = 12.sp, lineHeight = 16.sp,
            ),
        )
    }
}
