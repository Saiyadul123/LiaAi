package com.Lia.assistant.voice

/**
 * Builds a Gemini function declaration. Every parameter is sent as type STRING inside an OBJECT
 * schema (see GeminiLiveProtocol). [params] maps parameter name -> description (insertion order
 * is kept); [required] must be a subset of the parameter names.
 */
fun functionDecl(
    name: String,
    description: String,
    params: Map<String, String> = emptyMap(),
    required: List<String> = emptyList(),
): ToolDeclaration {
    val unknown = required.filter { it !in params }
    require(unknown.isEmpty()) { "required parameters not declared: $unknown" }
    return ToolDeclaration(
        name = name,
        description = description,
        params = params.map { (paramName, paramDescription) ->
            ToolParam(paramName, paramDescription, required = paramName in required)
        },
    )
}
