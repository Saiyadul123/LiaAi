package com.Lia.assistant.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * UI state holder, remembered once at the navigation root.
 *
 * Fields start with defaults; call [load] once (e.g. from a LaunchedEffect, or keep the splash
 * screen up until [loaded] is true) so the disk read happens off the main thread.
 * Every applyX() updates the Compose state immediately and persists the change.
 * Named applyX (not setX) to avoid JVM setter clashes with the mutableStateOf properties.
 */
class NovaAppState(
    context: Context,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO),
) {
    private val appContext: Context = context.applicationContext

    var loaded by mutableStateOf(false)
        private set

    var themeMode by mutableStateOf(ThemeMode.DEFAULT)
        private set
    var reducedMotion by mutableStateOf(false)
        private set
    var orbStyle by mutableStateOf(DEFAULT_ORB_STYLE)
        private set
    var personality by mutableStateOf(Personality.DEFAULT)
        private set
    var assistantName by mutableStateOf(AssistantBrand.NAME)
        private set
    var userName by mutableStateOf("")
        private set
    var language by mutableStateOf(LanguagePreference.DEFAULT)
        private set
    var voiceName by mutableStateOf(SettingsFallback.DEFAULT_VOICE_NAME)
        private set
    var speechSpeed by mutableStateOf(DEFAULT_SPEECH_SPEED)
        private set
    var voiceVolume by mutableStateOf(DEFAULT_VOICE_VOLUME)
        private set
    var hasOnboarded by mutableStateOf(false)
        private set
    var voiceInputEnabled by mutableStateOf(true)
        private set
    var saveHistory by mutableStateOf(true)
        private set

    /** In-memory for now; chat-history persistence is a later step. */
    val conversations = mutableStateListOf<Conversation>()

    private class Snapshot(
        val themeMode: ThemeMode,
        val reducedMotion: Boolean,
        val orbStyle: String,
        val personality: Personality,
        val assistantName: String,
        val userName: String,
        val language: LanguagePreference,
        val voiceName: String,
        val speechSpeed: Float,
        val voiceVolume: Float,
        val hasOnboarded: Boolean,
        val voiceInputEnabled: Boolean,
        val saveHistory: Boolean,
    )

    /** Reads NovaPreferences on the IO dispatcher, then publishes to Compose state. */
    suspend fun load() {
        val s = withContext(Dispatchers.IO) {
            val k = NovaPreferences.Keys
            fun str(key: String) = NovaPreferences.getString(appContext, key)
            Snapshot(
                themeMode = ThemeMode.fromName(str(k.THEME_MODE)),
                reducedMotion = NovaPreferences.getBoolean(appContext, k.REDUCED_MOTION, false),
                orbStyle = str(k.ORB_STYLE).ifBlank { DEFAULT_ORB_STYLE },
                personality = SettingsFallback.personality(str(k.PERSONALITY), null),
                assistantName = SettingsFallback.assistantName(str(k.ASSISTANT_NAME), null),
                userName = str(k.USER_NAME),
                language = SettingsFallback.language(str(k.LANGUAGE), null),
                voiceName = SettingsFallback.voiceName(str(k.VOICE_NAME), null),
                speechSpeed = NovaPreferences.getFloat(appContext, k.SPEECH_SPEED, DEFAULT_SPEECH_SPEED)
                    .coerceIn(SPEED_RANGE),
                voiceVolume = NovaPreferences.getFloat(appContext, k.VOICE_VOLUME, DEFAULT_VOICE_VOLUME)
                    .coerceIn(VOLUME_RANGE),
                hasOnboarded = NovaPreferences.getBoolean(appContext, k.HAS_ONBOARDED, false),
                voiceInputEnabled = NovaPreferences.getBoolean(appContext, k.VOICE_INPUT_ENABLED, true),
                saveHistory = NovaPreferences.getBoolean(appContext, k.SAVE_HISTORY, true),
            )
        }
        themeMode = s.themeMode
        reducedMotion = s.reducedMotion
        orbStyle = s.orbStyle
        personality = s.personality
        assistantName = s.assistantName
        userName = s.userName
        language = s.language
        voiceName = s.voiceName
        speechSpeed = s.speechSpeed
        voiceVolume = s.voiceVolume
        hasOnboarded = s.hasOnboarded
        voiceInputEnabled = s.voiceInputEnabled
        saveHistory = s.saveHistory
        loaded = true
    }

    // ---- applyX -----------------------------------------------------------------------------

    fun applyThemeMode(value: ThemeMode) {
        themeMode = value
        NovaPreferences.putString(appContext, NovaPreferences.Keys.THEME_MODE, value.name)
    }

    fun applyReducedMotion(value: Boolean) {
        reducedMotion = value
        NovaPreferences.putBoolean(appContext, NovaPreferences.Keys.REDUCED_MOTION, value)
    }

    fun applyOrbStyle(value: String) {
        orbStyle = value
        NovaPreferences.putString(appContext, NovaPreferences.Keys.ORB_STYLE, value)
    }

    fun applyPersonality(value: Personality) {
        personality = value
        NovaPreferences.putString(appContext, NovaPreferences.Keys.PERSONALITY, value.name)
        scope.launch(Dispatchers.IO) { PersonalityRepository.setPersonality(appContext, value) }
    }

    fun applyAssistantName(value: String) {
        val name = value.trim().ifEmpty { AssistantBrand.NAME }
        assistantName = name
        NovaPreferences.putString(appContext, NovaPreferences.Keys.ASSISTANT_NAME, name)
        scope.launch(Dispatchers.IO) { PersonalityRepository.setAssistantName(appContext, name) }
    }

    fun applyUserName(value: String) {
        val name = value.trim()
        userName = name
        NovaPreferences.putString(appContext, NovaPreferences.Keys.USER_NAME, name)
    }

    fun applyLanguage(value: LanguagePreference) {
        language = value
        NovaPreferences.putString(appContext, NovaPreferences.Keys.LANGUAGE, value.name)
        scope.launch(Dispatchers.IO) { PersonalityRepository.setLanguage(appContext, value) }
    }

    fun applyVoiceName(value: String) {
        val name = value.trim().ifEmpty { SettingsFallback.DEFAULT_VOICE_NAME }
        voiceName = name
        NovaPreferences.putString(appContext, NovaPreferences.Keys.VOICE_NAME, name)
        // Keep the DataStore copy in sync, otherwise it would shadow this value on the next read.
        scope.launch(Dispatchers.IO) { PersonalityRepository.setVoiceName(appContext, name) }
    }

    fun applySpeechSpeed(value: Float) {
        val v = value.coerceIn(SPEED_RANGE)
        speechSpeed = v
        NovaPreferences.putFloat(appContext, NovaPreferences.Keys.SPEECH_SPEED, v)
    }

    fun applyVoiceVolume(value: Float) {
        val v = value.coerceIn(VOLUME_RANGE)
        voiceVolume = v
        NovaPreferences.putFloat(appContext, NovaPreferences.Keys.VOICE_VOLUME, v)
    }

    fun applyHasOnboarded(value: Boolean) {
        hasOnboarded = value
        NovaPreferences.putBoolean(appContext, NovaPreferences.Keys.HAS_ONBOARDED, value)
    }

    fun applyVoiceInputEnabled(value: Boolean) {
        voiceInputEnabled = value
        NovaPreferences.putBoolean(appContext, NovaPreferences.Keys.VOICE_INPUT_ENABLED, value)
    }

    fun applySaveHistory(value: Boolean) {
        saveHistory = value
        NovaPreferences.putBoolean(appContext, NovaPreferences.Keys.SAVE_HISTORY, value)
    }

    companion object {
        const val DEFAULT_ORB_STYLE = "classic"
        const val DEFAULT_SPEECH_SPEED = 1.0f
        const val DEFAULT_VOICE_VOLUME = 1.0f
        val SPEED_RANGE = 0.5f..2.0f
        val VOLUME_RANGE = 0f..1f
    }
}
