package com.Lia.assistant

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.forge.ForgeController
import com.Lia.assistant.ui.fx.EdgeGlowDialogHost
import com.Lia.assistant.ui.navigation.NovaApp
import com.Lia.assistant.ui.screens.splash.LiaSplash3D
import com.Lia.assistant.ui.screens.splash.SplashSession
import com.Lia.assistant.ui.theme.NovaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen() // the system splash only covers cold start up to the first frame
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIntent(intent)

        val appState = NovaAppState(applicationContext)

        setContent {
            LaunchedEffect(Unit) { appState.load() }
            NovaTheme(mode = appState.themeMode, reducedMotion = appState.reducedMotion) {
                // Once per process: rotation or coming back from the background never replays it.
                var showSplash by remember { mutableStateOf(!SplashSession.played) }
                Box(Modifier.fillMaxSize()) {
                    NovaApp(appState)
                    if (showSplash) {
                        LiaSplash3D(
                            ready = appState.loaded,
                            onFinished = { showSplash = false },
                            assistantName = appState.assistantName,
                        )
                    }
                }
                // The edge glow lives in a full-screen Dialog window, above every screen.
                EdgeGlowDialogHost()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** A launch carrying EXTRA_OPEN_FORGE asks the app to open the Website Forge. */
    private fun handleIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(ForgeController.EXTRA_OPEN_FORGE, false) == true) {
            ForgeController.requestOpen()
            intent.removeExtra(ForgeController.EXTRA_OPEN_FORGE)
        }
    }
}
