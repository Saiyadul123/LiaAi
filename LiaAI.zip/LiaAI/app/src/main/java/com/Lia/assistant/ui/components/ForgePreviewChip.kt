package com.Lia.assistant.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.Lia.assistant.ui.theme.NovaSizes
import com.Lia.assistant.ui.theme.NovaTheme

/** A tiny turning "reactor" (rings around a glowing core): the preview of the Forge scene. Still with reduced motion. */
@Composable
fun MiniReactor(modifier: Modifier = Modifier) {
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val turn = rememberInfiniteTransition(label = "miniReactor").animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing)),
        label = "miniReactorTurn",
    )
    Canvas(modifier) {
        val r = size.minDimension / 2f
        val center = Offset(size.width / 2f, size.height / 2f)
        val a = if (reduced) 30f else turn.value
        drawCircle(colors.accent.copy(alpha = 0.25f), radius = r * 0.95f, center = center, style = Stroke(r * 0.08f))
        drawArc(
            color = colors.accent, startAngle = a, sweepAngle = 110f, useCenter = false,
            topLeft = Offset(center.x - r * 0.8f, center.y - r * 0.8f), size = Size(r * 1.6f, r * 1.6f),
            style = Stroke(r * 0.12f, cap = StrokeCap.Round),
        )
        drawArc(
            color = colors.textSecondary, startAngle = 180f - a * 1.6f, sweepAngle = 80f, useCenter = false,
            topLeft = Offset(center.x - r * 0.55f, center.y - r * 0.55f), size = Size(r * 1.1f, r * 1.1f),
            style = Stroke(r * 0.1f, cap = StrokeCap.Round),
        )
        drawCircle(
            brush = Brush.radialGradient(listOf(colors.accentSecondary, Color.Transparent), center, r * 0.4f),
            radius = r * 0.4f, center = center,
        )
    }
}

/** A chip with a mini Forge preview that opens the Website Forge. */
@Composable
fun ForgePreviewChip(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    label: String = "Open the Forge",
) {
    val colors = NovaTheme.colors
    val haptics = LocalHapticFeedback.current
    val pill = NovaTheme.shapes.pill
    Row(
        modifier = modifier
            .heightIn(min = NovaSizes.MinTouch)
            .clip(pill)
            .background(colors.surfaceRaised)
            .border(1.dp, colors.accent, pill)
            .clickable(onClickLabel = label, role = Role.Button) {
                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .padding(start = 8.dp, end = 16.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        MiniReactor(Modifier.size(32.dp))
        Spacer(Modifier.width(10.dp))
        Text(
            text = label,
            style = NovaTheme.typography.title.copy(fontSize = 14.sp, lineHeight = 20.sp),
            color = colors.accentText,
        )
    }
}
