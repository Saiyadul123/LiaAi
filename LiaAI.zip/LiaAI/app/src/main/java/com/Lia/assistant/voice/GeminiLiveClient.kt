package com.Lia.assistant.voice

import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONObject

/**
 * WebSocket client for the Gemini Live API.
 *
 * Listener callbacks arrive on OkHttp's background threads and must not throw. Neither the API
 * key nor raw server messages are ever logged or put into error messages.
 *
 * After a remote close or a failure the listener gets onError (if abnormal) and then onClosed.
 * A local [disconnect] is silent: the caller already knows.
 */
class GeminiLiveClient(
    private val apiKey: String,
    private val listener: Listener,
    private val httpClient: OkHttpClient = defaultHttpClient(),
) {

    interface Listener {
        fun onSetupComplete() {}
        /** 24 kHz, 16-bit little-endian mono PCM. */
        fun onAudioChunk(bytes: ByteArray) {}
        fun onInputTranscript(text: String) {}
        fun onOutputTranscript(text: String) {}
        fun onToolCall(id: String, name: String, args: JSONObject) {}
        fun onTurnComplete() {}
        fun onInterrupted() {}
        fun onError(message: String) {}
        fun onClosed() {}
    }

    private val dedup = ToolCallDeduplicator()
    private val socket = AtomicReference<WebSocket?>(null)
    private val generation = AtomicInteger(0)

    @Volatile
    private var ready = false

    /** True once the server has acknowledged the setup message. */
    val isReady: Boolean get() = ready

    /** Opens a session. Any existing session is closed first. */
    @Synchronized
    fun connect(systemInstruction: String, voiceName: String = DEFAULT_VOICE) {
        if (apiKey.isBlank()) {
            listener.onError("No API key set. Add your Gemini API key in Settings.")
            return
        }
        disconnect()
        val gen = generation.get()
        val setup = GeminiLiveProtocol.setupMessage(
            MODEL, voiceName, systemInstruction, LiaToolCatalog.declarations()
        )
        val request = Request.Builder().url(buildUrl(apiKey)).build()
        socket.set(httpClient.newWebSocket(request, Connection(gen, setup)))
    }

    /** Streams 16 kHz PCM16 mono microphone audio. Returns false if the session is not ready. */
    fun sendAudio(pcmBytes: ByteArray): Boolean {
        if (!ready || pcmBytes.isEmpty()) return false
        return socket.get()?.send(GeminiLiveProtocol.audioMessage(pcmBytes)) ?: false
    }

    /** [resultJson] should be a JSON object; other text is wrapped as {"result": ...}. */
    fun sendToolResponse(id: String, name: String, resultJson: String): Boolean {
        if (!ready) return false
        return socket.get()?.send(GeminiLiveProtocol.toolResponseMessage(id, name, resultJson)) ?: false
    }

    /** Closes the session with code 1000. Safe to call repeatedly. */
    @Synchronized
    fun disconnect() {
        generation.incrementAndGet() // events from the old socket are now ignored
        ready = false
        dedup.clear()
        socket.getAndSet(null)?.close(NORMAL_CLOSURE, "client closing")
    }

    private inner class Connection(
        private val gen: Int,
        private val setupJson: String,
    ) : WebSocketListener() {

        private fun stale() = gen != generation.get()

        /** Marks this connection finished; returns false if it was already superseded. */
        private fun finish(): Boolean {
            synchronized(this@GeminiLiveClient) {
                if (stale()) return false
                generation.incrementAndGet()
                ready = false
                socket.set(null)
                dedup.clear()
                return true
            }
        }

        override fun onOpen(webSocket: WebSocket, response: Response) {
            if (stale()) return
            if (!webSocket.send(setupJson)) listener.onError("Could not send the session setup.")
        }

        override fun onMessage(webSocket: WebSocket, text: String) = handle(text)

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handle(bytes.utf8())

        private fun handle(raw: String) {
            if (stale()) return
            GeminiLiveProtocol.parse(raw, relay, dedup)
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            webSocket.close(NORMAL_CLOSURE, null)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            if (!finish()) return
            if (code != NORMAL_CLOSURE) {
                val detail = reason.take(200).ifBlank { "no reason given" }
                listener.onError(GeminiLiveProtocol.redact("Connection closed ($code): $detail", apiKey))
            }
            listener.onClosed()
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            if (!finish()) return
            val code = response?.code
            val message = when (code) {
                400, 401, 403 -> "Gemini rejected the API key or request (HTTP $code). Check your key in Settings."
                null -> GeminiLiveProtocol.redact(t.message?.take(200) ?: "Connection failed", apiKey)
                else -> "Connection failed (HTTP $code)."
            }
            listener.onError(message)
            listener.onClosed()
        }
    }

    /** Marks the session ready on setupComplete, then forwards every event to [listener]. */
    private val relay = object : Listener by listener {
        override fun onSetupComplete() {
            ready = true
            listener.onSetupComplete()
        }
    }

    companion object {
        /** The ONE place the Live model name lives. Verify against the Live API docs before release. */
        const val MODEL = "models/gemini-3.1-flash-live-preview"

        const val WS_URL =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta." +
                "GenerativeService.BidiGenerateContent?key=<API_KEY>"

        const val DEFAULT_VOICE = "Aoede"
        private const val NORMAL_CLOSURE = 1000

        internal fun buildUrl(apiKey: String): String =
            WS_URL.replace("<API_KEY>", URLEncoder.encode(apiKey, "UTF-8"))

        fun defaultHttpClient(): OkHttpClient = OkHttpClient.Builder()
            .readTimeout(0, TimeUnit.MILLISECONDS)   // long-lived socket: no read timeout
            .connectTimeout(20, TimeUnit.SECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .build()
    }
}
