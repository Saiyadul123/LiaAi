package com.Lia.assistant.ui.theme

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * The shared device tilt (-1..1 on both axes). NovaApp provides ONE low-pass filtered sensor listener;
 * every layer reads it here instead of registering its own. Zero without a provider or with reduced motion.
 */
val LocalTilt = staticCompositionLocalOf<() -> Offset> { { Offset.Zero } }

/**
 * How far a depth layer shifts with tilt, in dp: 2 dp for the night sky (layer 0) up to 12 dp for the
 * floating controls (layer 4). Deeper layers move less.
 * Layers: 0 sky, 1 ambient light, 2 surfaces, 3 hero object, 4 floating controls.
 */
fun parallaxShiftDp(layer: Int): Float = 2f + 10f * (layer.coerceIn(0, 4) / 4f)

/** Shifts this layer with the device tilt. Does nothing with reduced motion. */
fun Modifier.tiltParallax(layer: Int): Modifier = composed {
    val tilt = LocalTilt.current
    if (NovaTheme.reducedMotion) {
        this
    } else {
        val shift = parallaxShiftDp(layer)
        this.graphicsLayer {
            val t = tilt()
            translationX = t.x * shift.dp.toPx()
            translationY = t.y * shift.dp.toPx()
        }
    }
}

/**
 * Parallax for pager content: the page itself moves one full width per page, so adding
 * pageOffset * width * (1 - factor) makes its content travel at [factor] (0.6 = 60 %) of that speed.
 * [pageOffset] is (currentPage - page) + currentPageOffsetFraction.
 */
fun parallaxShift(pageOffset: Float, widthPx: Float, factor: Float = 0.6f): Float =
    pageOffset * widthPx * (1f - factor)

// ---- entrance ---------------------------------------------------------------------------------

/** One orchestrated entrance per screen. */
const val ENTRANCE_MS = 600

/** Where [progress] (0..1) sits inside the slice [start]..[end], clamped to 0..1. */
fun entranceFraction(progress: Float, start: Float, end: Float): Float {
    if (end <= start) return if (progress >= end) 1f else 0f
    return ((progress - start) / (end - start)).coerceIn(0f, 1f)
}

/** The screen's entrance progress, 0 to 1 over [ENTRANCE_MS] (already 1 with reduced motion). */
@Composable
fun rememberStageEntrance(): State<Float> {
    val reduced = NovaTheme.reducedMotion
    val progress = remember { Animatable(if (reduced) 1f else 0f) }
    LaunchedEffect(reduced) {
        if (reduced) progress.snapTo(1f) else progress.animateTo(1f, tween(ENTRANCE_MS, easing = LinearEasing))
    }
    return progress.asState()
}

/**
 * Fades and lifts an element into place during its slice of the screen entrance (from [start] for
 * [span] of the sequence). Back layers get an earlier [start] than front ones.
 */
fun Modifier.stageEntrance(progress: State<Float>, start: Float, span: Float = 0.5f, rise: Dp = 16.dp): Modifier =
    graphicsLayer {
        val f = entranceFraction(progress.value, start, start + span)
        alpha = f
        translationY = (1f - f) * rise.toPx()
    }

// ---- card tilt maths --------------------------------------------------------------------------

object CardTilt {
    /** Home "Try saying" cards: rotationY of +-6 degrees by horizontal position (fraction from viewport centre). */
    fun rowRotationY(fraction: Float): Float = (-fraction * 12f).coerceIn(-6f, 6f)

    /** History rows: how far an item has scrolled off the top (0 = fully visible, 1 = gone). */
    fun offTopFraction(offset: Int, size: Int): Float =
        if (size <= 0) 0f else (-offset.toFloat() / size).coerceIn(0f, 1f)

    fun offTopRotationX(fraction: Float): Float = fraction * 35f
    fun offTopScale(fraction: Float): Float = 1f - 0.25f * fraction
    fun offTopAlpha(fraction: Float): Float = 1f - 0.7f * fraction

    data class Coverflow(val rotationY: Float, val scale: Float, val alpha: Float)

    /** Orb Style carousel: the centred item (fraction 0) is largest and flat; neighbours turn up to 35 degrees. */
    fun coverflow(fraction: Float): Coverflow {
        val f = fraction.coerceIn(-1f, 1f)
        val closeness = 1f - kotlin.math.abs(f)
        return Coverflow(rotationY = -f * 35f, scale = 1f + 0.3f * closeness, alpha = 0.55f + 0.45f * closeness)
    }
}
