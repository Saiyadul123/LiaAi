package com.Lia.assistant.ui.screens.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaOrbStyle
import com.Lia.assistant.ui.components.NovaTextField
import com.Lia.assistant.ui.components.NovaVoiceVisualizer
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.voice.NovaOrbState
import kotlinx.coroutines.launch

private const val PAGE_COUNT = 4

/** Four pages: meet the assistant, talk or type, you stay in control, and a short setup. */
@Composable
fun OnboardingScreen(appState: NovaAppState, onFinished: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val scope = rememberCoroutineScope()
    val pagerState = rememberPagerState(pageCount = { PAGE_COUNT })

    var userName by rememberSaveable { mutableStateOf(appState.userName) }
    var apiKey by rememberSaveable { mutableStateOf("") }
    val page = pagerState.currentPage
    val isLast = page == PAGE_COUNT - 1

    fun goTo(target: Int) {
        scope.launch { if (reduced) pagerState.scrollToPage(target) else pagerState.animateScrollToPage(target) }
    }

    fun finish() {
        appState.applyUserName(userName)
        if (apiKey.isNotBlank()) ApiKeyStore.saveKey(context, apiKey)
        appState.applyHasOnboarded(true)
        onFinished()
    }

    Column(modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        HorizontalPager(state = pagerState, modifier = Modifier.weight(1f).fillMaxWidth()) { index ->
            OnboardingPage(
                page = index,
                name = appState.assistantName,
                orbStyle = NovaOrbStyle.fromId(appState.orbStyle),
                userName = userName,
                onUserName = { userName = it },
                apiKey = apiKey,
                onApiKey = { apiKey = it },
            )
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (!isLast) {
                NovaButton("Skip", { goTo(PAGE_COUNT - 1) }, style = NovaButtonStyle.TEXT)
            } else {
                Spacer(Modifier.width(48.dp))
            }
            Row(
                Modifier.weight(1f).semantics { contentDescription = "Page ${page + 1} of $PAGE_COUNT" },
                horizontalArrangement = Arrangement.Center,
            ) {
                repeat(PAGE_COUNT) { i ->
                    Box(
                        Modifier
                            .padding(horizontal = 4.dp)
                            .size(if (i == page) 10.dp else 8.dp)
                            .background(if (i == page) colors.accent else colors.textTertiary, CircleShape)
                    )
                }
            }
            if (isLast) {
                NovaButton("Get started", { finish() })
            } else {
                NovaButton("Next", { goTo(page + 1) })
            }
        }
    }
}

@Composable
private fun OnboardingPage(
    page: Int,
    name: String,
    orbStyle: NovaOrbStyle,
    userName: String,
    onUserName: (String) -> Unit,
    apiKey: String,
    onApiKey: (String) -> Unit,
) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val (title, body) = when (page) {
        0 -> "Meet $name" to "Your intelligent AI companion: talk to it, type to it, and let it do things on your phone."
        1 -> "Talk or type" to "Voice mode is a live conversation. Chat is for when you'd rather type. $name understands English, Hindi and Hinglish."
        2 -> "You stay in control" to "$name asks for a permission only when it needs one. Voice and chat use Google's Gemini with your own key, and saved chats stay on this phone."
        else -> "Let's set you up" to "Tell $name your name, and paste a Gemini API key to switch it on. You can also do this later in Settings."
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = NovaSpacing.xl, vertical = NovaSpacing.lg),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        NovaVoiceVisualizer(
            state = if (page == 1) NovaOrbState.LISTENING else NovaOrbState.IDLE,
            modifier = Modifier.size(if (page == 0) 220.dp else 140.dp),
            style = orbStyle,
            name = name,
        )
        Spacer(Modifier.height(NovaSpacing.xl))
        Text(title, style = type.display, color = colors.textPrimary, textAlign = TextAlign.Center)
        Spacer(Modifier.height(NovaSpacing.md))
        Text(body, style = type.body, color = colors.textSecondary, textAlign = TextAlign.Center)

        if (page == PAGE_COUNT - 1) {
            Spacer(Modifier.height(NovaSpacing.xl))
            NovaTextField(
                value = userName, onValueChange = onUserName, modifier = Modifier.fillMaxWidth(),
                label = "Your name", placeholder = "What should $name call you?", singleLine = true,
            )
            Spacer(Modifier.height(NovaSpacing.md))
            NovaTextField(
                value = apiKey, onValueChange = onApiKey, modifier = Modifier.fillMaxWidth(),
                label = "Gemini API key (optional now)", placeholder = "Paste your key", singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                supportingText = "Kept on this phone. You can create a free key in Google AI Studio.",
            )
        }
    }
}
