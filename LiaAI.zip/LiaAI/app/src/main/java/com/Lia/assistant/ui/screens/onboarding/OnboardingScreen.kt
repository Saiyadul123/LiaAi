package com.Lia.assistant.ui.screens.onboarding

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaOrbStyle
import com.Lia.assistant.ui.components.NovaTextField
import com.Lia.assistant.ui.components.NovaVoiceVisualizer
import com.Lia.assistant.ui.fx.AmbientGlow
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.parallaxShift
import com.Lia.assistant.voice.NovaOrbState
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private const val PAGE_COUNT = 4

/** The four poses of the orb, one per page. */
internal enum class OrbPose { CENTER, ORBITING, SPLIT, SHIELDED }

internal fun poseFor(page: Int): OrbPose = when (page) {
    0 -> OrbPose.CENTER
    1 -> OrbPose.ORBITING
    2 -> OrbPose.SPLIT
    else -> OrbPose.SHIELDED
}

/** Four pages: meet the assistant, talk or type, you stay in control, and a short setup. */
@Composable
fun OnboardingScreen(appState: NovaAppState, onFinished: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val scope = rememberCoroutineScope()
    val pagerState = rememberPagerState(pageCount = { PAGE_COUNT })

    var userName by rememberSaveable { mutableStateOf(appState.userName) }
    var apiKey by rememberSaveable { mutableStateOf("") }
    val page = pagerState.currentPage
    val isLast = page == PAGE_COUNT - 1

    fun goTo(target: Int) {
        scope.launch { if (reduced) pagerState.scrollToPage(target) else pagerState.animateScrollToPage(target) }
    }

    fun finish() {
        appState.applyUserName(userName)
        if (apiKey.isNotBlank()) ApiKeyStore.saveKey(context, apiKey)
        appState.applyHasOnboarded(true)
        onFinished()
    }

    Box(modifier.fillMaxSize()) {
        AmbientGlow(state = NovaOrbState.IDLE, modifier = Modifier.fillMaxSize())

        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            HorizontalPager(state = pagerState, modifier = Modifier.weight(1f).fillMaxWidth()) { index ->
                OnboardingPage(
                    page = index,
                    pagerState = pagerState,
                    name = appState.assistantName,
                    orbStyle = NovaOrbStyle.fromId(appState.orbStyle),
                    userName = userName,
                    onUserName = { userName = it },
                    apiKey = apiKey,
                    onApiKey = { apiKey = it },
                )
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.md),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (!isLast) {
                    NovaButton("Skip", { goTo(PAGE_COUNT - 1) }, style = NovaButtonStyle.TEXT)
                } else {
                    Spacer(Modifier.width(48.dp))
                }
                Row(
                    Modifier.weight(1f).semantics { contentDescription = "Page ${page + 1} of $PAGE_COUNT" },
                    horizontalArrangement = Arrangement.Center,
                ) {
                    repeat(PAGE_COUNT) { i ->
                        Box(
                            Modifier
                                .padding(horizontal = 4.dp)
                                .size(if (i == page) 10.dp else 8.dp)
                                .background(if (i == page) colors.accent else colors.textTertiary, CircleShape)
                        )
                    }
                }
                if (isLast) {
                    NovaButton("Get started", { finish() })
                } else {
                    NovaButton("Next", { goTo(page + 1) })
                }
            }
        }
    }
}

@Composable
private fun OnboardingPage(
    page: Int,
    pagerState: PagerState,
    name: String,
    orbStyle: NovaOrbStyle,
    userName: String,
    onUserName: (String) -> Unit,
    apiKey: String,
    onApiKey: (String) -> Unit,
) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val reduced = NovaTheme.reducedMotion
    val (title, body) = when (page) {
        0 -> "Meet $name" to "Your intelligent AI companion: talk to it, type to it, and let it do things on your phone."
        1 -> "Talk or type" to "Voice mode is a live conversation. Chat is for when you'd rather type. $name understands English, Hindi and Hinglish."
        2 -> "You stay in control" to "$name asks for a permission only when it needs one. Voice and chat use Google's Gemini with your own key, and saved chats stay on this phone."
        else -> "Let's set you up" to "Tell $name your name, and paste a Gemini API key to switch it on. You can also do this later in Settings."
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                // the content travels at 0.6x the pager's scroll speed
                if (!reduced) {
                    val pageOffset = (pagerState.currentPage - page) + pagerState.currentPageOffsetFraction
                    translationX = parallaxShift(pageOffset, size.width)
                }
            }
            .verticalScroll(rememberScrollState())
            .padding(horizontal = NovaSpacing.xl, vertical = NovaSpacing.lg),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        PosedOrb(
            pose = poseFor(page),
            active = pagerState.currentPage == page,
            size = if (page == 0) 220.dp else 150.dp,
            style = orbStyle,
            name = name,
        )
        Spacer(Modifier.height(NovaSpacing.xl))
        Text(title, style = type.display, color = colors.textPrimary, textAlign = TextAlign.Center)
        Spacer(Modifier.height(NovaSpacing.md))
        Text(body, style = type.body, color = colors.textSecondary, textAlign = TextAlign.Center)

        if (page == PAGE_COUNT - 1) {
            Spacer(Modifier.height(NovaSpacing.xl))
            NovaTextField(
                value = userName, onValueChange = onUserName, modifier = Modifier.fillMaxWidth(),
                label = "Your name", placeholder = "What should $name call you?", singleLine = true,
            )
            Spacer(Modifier.height(NovaSpacing.md))
            NovaTextField(
                value = apiKey, onValueChange = onApiKey, modifier = Modifier.fillMaxWidth(),
                label = "Gemini API key (optional now)", placeholder = "Paste your key", singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                supportingText = "Kept on this phone. You can create a free key in Google AI Studio.",
            )
        }
    }
}

private val TWO_PI = (2.0 * PI).toFloat()

/** A half of the orb: the left or right 50 % of its box. */
private fun halfShape(left: Boolean) = GenericShape { size, _ ->
    addRect(
        if (left) Rect(0f, 0f, size.width / 2f, size.height)
        else Rect(size.width / 2f, 0f, size.width, size.height)
    )
}

/** The orb in this page's pose: large centre, orbiting, split into two halves, or shielded by a ring. */
@Composable
private fun PosedOrb(pose: OrbPose, active: Boolean, size: Dp, style: NovaOrbStyle, name: String) {
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val turn = rememberInfiniteTransition(label = "pose").animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "poseTurn",
    )

    when (pose) {
        OrbPose.CENTER -> NovaVoiceVisualizer(state = NovaOrbState.IDLE, modifier = Modifier.size(size), style = style, name = name)

        OrbPose.ORBITING -> Box(Modifier.size(size * 1.25f), contentAlignment = Alignment.Center) {
            NovaVoiceVisualizer(state = NovaOrbState.LISTENING, modifier = Modifier.size(size * 0.8f), style = style, name = name)
            Canvas(Modifier.fillMaxSize()) {
                val r = this.size.minDimension / 2f
                val c = Offset(this.size.width / 2f, this.size.height / 2f)
                val base = if (reduced) 0.1f else turn.value
                for (i in 0..2) {
                    val a = TWO_PI * (base + i / 3f)
                    drawCircle(
                        color = colors.accent,
                        radius = r * 0.06f,
                        center = Offset(c.x + cos(a) * r * 0.92f, c.y + sin(a) * r * 0.92f),
                    )
                }
            }
        }

        OrbPose.SPLIT -> {
            val gap by animateDpAsState(
                targetValue = if (reduced) 8.dp else if (active) 14.dp else 0.dp,
                animationSpec = tween(if (reduced) 0 else 600),
                label = "splitGap",
            )
            Box(Modifier.size(size), contentAlignment = Alignment.Center) {
                Box(Modifier.size(size).offset(x = -gap).clip(halfShape(left = true))) {
                    NovaVoiceVisualizer(state = NovaOrbState.IDLE, modifier = Modifier.fillMaxSize(), style = style, name = name)
                }
                Box(Modifier.size(size).offset(x = gap).clip(halfShape(left = false))) {
                    NovaVoiceVisualizer(state = NovaOrbState.IDLE, modifier = Modifier.fillMaxSize(), style = style, name = name)
                }
            }
        }

        OrbPose.SHIELDED -> Box(Modifier.size(size * 1.25f), contentAlignment = Alignment.Center) {
            NovaVoiceVisualizer(state = NovaOrbState.IDLE, modifier = Modifier.size(size * 0.8f), style = style, name = name)
            Canvas(Modifier.fillMaxSize()) {
                val r = this.size.minDimension / 2f
                val c = Offset(this.size.width / 2f, this.size.height / 2f)
                val start = if (reduced) 20f else turn.value * 360f
                drawCircle(colors.accent.copy(alpha = 0.25f), radius = r * 0.94f, center = c, style = Stroke(r * 0.03f))
                for (i in 0..2) {
                    drawArc(
                        color = colors.accent, startAngle = start + i * 120f, sweepAngle = 70f, useCenter = false,
                        topLeft = Offset(c.x - r * 0.94f, c.y - r * 0.94f), size = Size(r * 1.88f, r * 1.88f),
                        style = Stroke(r * 0.05f, cap = StrokeCap.Round),
                    )
                }
            }
        }
    }
}
