package com.Lia.assistant.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Single source for the "nova_prefs" SharedPreferences file (shared by ApiKeyStore and NovaPreferences). */
internal object NovaPrefsFile {
    const val NAME = "nova_prefs"

    /** Unit tests inject an in-memory implementation here. */
    @Volatile
    internal var testOverride: SharedPreferences? = null

    fun get(context: Context): SharedPreferences =
        testOverride ?: context.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)
}

/**
 * Typed access to "nova_prefs". Writes use apply() (asynchronous, never blocks the caller).
 * The first read of the file loads it from disk, so call [warmUp] off the main thread early.
 */
object NovaPreferences {

    object Keys {
        const val THEME_MODE = "theme_mode"
        const val REDUCED_MOTION = "reduced_motion"
        const val ORB_STYLE = "orb_style"
        const val PERSONALITY = "personality"
        const val USER_NAME = "user_name"
        const val VOICE_INPUT_ENABLED = "voice_input_enabled"
        const val WAKE_WORD_ENABLED = "wake_word_enabled"
        const val LANGUAGE = "language"
        const val HAS_ONBOARDED = "has_onboarded"
        const val VOICE_NAME = "voice_name"
        const val RESPONSE_STYLE = "response_style"
        const val SPEECH_SPEED = "speech_speed"
        const val VOICE_VOLUME = "voice_volume"
        const val ASSISTANT_NAME = "assistant_name"
    }

    /** Forces the prefs file to load from disk on the IO dispatcher. */
    suspend fun warmUp(context: Context) {
        withContext(Dispatchers.IO) { NovaPrefsFile.get(context).all }
    }

    fun getString(context: Context, key: String, default: String = ""): String =
        NovaPrefsFile.get(context).getString(key, default) ?: default

    fun putString(context: Context, key: String, value: String) {
        NovaPrefsFile.get(context).edit().putString(key, value).apply()
    }

    fun getBoolean(context: Context, key: String, default: Boolean = false): Boolean =
        NovaPrefsFile.get(context).getBoolean(key, default)

    fun putBoolean(context: Context, key: String, value: Boolean) {
        NovaPrefsFile.get(context).edit().putBoolean(key, value).apply()
    }

    fun getFloat(context: Context, key: String, default: Float = 0f): Float =
        NovaPrefsFile.get(context).getFloat(key, default)

    fun putFloat(context: Context, key: String, value: Float) {
        NovaPrefsFile.get(context).edit().putFloat(key, value).apply()
    }
}
