package com.Lia.assistant.ui.screens.settings

import android.content.pm.ApplicationInfo
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.Lia.assistant.FlavorRoutes
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.data.ThemeMode
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaChoiceDialog
import com.Lia.assistant.ui.components.NovaDialog
import com.Lia.assistant.ui.components.NovaOrbStyle
import com.Lia.assistant.ui.components.NovaSegmentedPicker
import com.Lia.assistant.ui.components.NovaSettingsRow
import com.Lia.assistant.ui.components.NovaSliderRow
import com.Lia.assistant.ui.components.NovaTextField
import com.Lia.assistant.ui.navigation.NovaRoutes
import com.Lia.assistant.ui.screens.common.NovaListScreen
import com.Lia.assistant.ui.screens.common.RowDivider
import com.Lia.assistant.ui.screens.common.settingsSection
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.voice.VoiceNames
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

private enum class SettingsDialog { NAME, LANGUAGE, VOICE, API_KEY }

private fun fmt(value: Float) = String.format(Locale.US, "%.2fx", value)
private fun pct(value: Float) = "${(value * 100).toInt()}%"

/** Settings in six groups: Assistant, Voice, Appearance, Capabilities, Account, About. */
@Composable
fun SettingsScreen(appState: NovaAppState, onNavigate: (String) -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val name = appState.assistantName

    var dialog by remember { mutableStateOf<SettingsDialog?>(null) }
    var keyVersion by remember { mutableIntStateOf(0) }
    val hasKey by produceState(false, keyVersion) { value = withContext(Dispatchers.IO) { ApiKeyStore.hasKey(context) } }
    val debuggable = remember { (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0 }
    val orbStyle = NovaOrbStyle.fromId(appState.orbStyle)

    NovaListScreen(title = "Settings", subtitle = "Make $name yours", modifier = modifier) {
        settingsSection("Assistant") {
            NovaSettingsRow("Name", icon = Icons.Rounded.Badge, subtitle = "What you call your assistant", value = name, onClick = { dialog = SettingsDialog.NAME })
            RowDivider()
            NovaSettingsRow("Personality", icon = Icons.Rounded.Psychology, subtitle = "How $name talks to you", value = appState.personality.displayName, onClick = { onNavigate(NovaRoutes.PERSONALITY) })
            RowDivider()
            NovaSettingsRow("Language", icon = Icons.Rounded.Language, subtitle = appState.language.description, value = appState.language.displayName, onClick = { dialog = SettingsDialog.LANGUAGE })
            RowDivider()
            NovaSettingsRow("Voice", icon = Icons.Rounded.RecordVoiceOver, subtitle = "The voice $name speaks with", value = VoiceNames.toGemini(appState.voiceName), onClick = { dialog = SettingsDialog.VOICE })
        }

        settingsSection("Voice") {
            NovaSettingsRow(
                "Voice input", icon = Icons.Rounded.Mic, subtitle = "Let $name listen in voice mode",
                switch = appState.voiceInputEnabled, onSwitchChange = appState::applyVoiceInputEnabled,
            )
            RowDivider()
            NovaSliderRow("Reading speed", appState.speechSpeed, appState::applySpeechSpeed, fmt(appState.speechSpeed), valueRange = 0.5f..2f, steps = 5)
            RowDivider()
            NovaSliderRow("Voice volume", appState.voiceVolume, appState::applyVoiceVolume, pct(appState.voiceVolume))
        }

        settingsSection("Appearance") {
            Column(Modifier.padding(NovaSpacing.lg)) {
                Text("Theme", style = type.body, color = colors.textPrimary)
                Spacer(Modifier.height(NovaSpacing.sm))
                NovaSegmentedPicker(
                    options = listOf("System", "Light", "Dark"),
                    selectedIndex = ThemeMode.entries.indexOf(appState.themeMode).coerceAtLeast(0),
                    onSelect = { appState.applyThemeMode(ThemeMode.entries[it]) },
                    contentDescription = "Theme",
                )
            }
            RowDivider()
            NovaSettingsRow("Orb style", icon = Icons.Rounded.Palette, subtitle = "How $name looks", value = orbStyle.name.lowercase().replaceFirstChar { it.uppercase() }, onClick = { onNavigate(NovaRoutes.ORB_STYLE) })
            RowDivider()
            NovaSettingsRow(
                "Reduce motion", icon = Icons.Rounded.Animation, subtitle = "Calmer, still visuals",
                switch = appState.reducedMotion, onSwitchChange = appState::applyReducedMotion,
            )
        }

        settingsSection("Capabilities") {
            NovaSettingsRow("Quick actions", icon = Icons.Rounded.Bolt, subtitle = "Open apps, call and message in one tap", onClick = { onNavigate(NovaRoutes.QUICK_ACTIONS) })
            RowDivider()
            NovaSettingsRow("Permissions", icon = Icons.Rounded.Security, subtitle = "What $name is allowed to use", onClick = { onNavigate(NovaRoutes.PERMISSIONS) })
            if (FlavorRoutes.screenControlAvailable) {
                RowDivider()
                NovaSettingsRow("Screen control", icon = Icons.Rounded.AccessibilityNew, subtitle = "Let $name read and tap your screen", onClick = { onNavigate(NovaRoutes.ACCESSIBILITY_DISCLOSURE) })
            }
        }

        settingsSection("Account") {
            NovaSettingsRow("Gemini API key", icon = Icons.Rounded.Key, subtitle = "Your own key, stored on this phone", value = if (hasKey) "Set" else "Not set", onClick = { dialog = SettingsDialog.API_KEY })
            RowDivider()
            NovaSettingsRow("Profile", icon = Icons.Rounded.Person, subtitle = "Your name and $name's name", onClick = { onNavigate(NovaRoutes.PROFILE) })
        }

        settingsSection("About") {
            NovaSettingsRow("Privacy", icon = Icons.Rounded.PrivacyTip, subtitle = "What stays on your phone", onClick = { onNavigate(NovaRoutes.PRIVACY) })
            RowDivider()
            NovaSettingsRow("About $name", icon = Icons.Rounded.Info, onClick = { onNavigate(NovaRoutes.ABOUT) })
            if (debuggable) {
                RowDivider()
                NovaSettingsRow("Debug", icon = Icons.Rounded.BugReport, subtitle = "Live session details", onClick = { onNavigate(NovaRoutes.DEBUG) })
            }
        }
    }

    when (dialog) {
        SettingsDialog.NAME -> {
            var text by remember { mutableStateOf(appState.assistantName) }
            NovaDialog(
                title = "Assistant name",
                onDismiss = { dialog = null },
                confirmText = "Save",
                onConfirm = { appState.applyAssistantName(text); dialog = null },
            ) {
                NovaTextField(text, { text = it }, Modifier.fillMaxWidth(), label = "Name", singleLine = true,
                    supportingText = "Used everywhere, including when it speaks")
            }
        }
        SettingsDialog.LANGUAGE -> NovaChoiceDialog(
            title = "Language",
            options = LanguagePreference.entries,
            selected = appState.language,
            optionLabel = { it.displayName },
            optionDescription = { it.description },
            onSelect = { appState.applyLanguage(it); dialog = null },
            onDismiss = { dialog = null },
        )
        SettingsDialog.VOICE -> NovaChoiceDialog(
            title = "Voice",
            options = VoiceNames.GEMINI_VOICES,
            selected = VoiceNames.toGemini(appState.voiceName),
            optionLabel = { it },
            onSelect = { appState.applyVoiceName(it); dialog = null },
            onDismiss = { dialog = null },
        )
        SettingsDialog.API_KEY -> {
            var key by remember { mutableStateOf("") }
            NovaDialog(
                title = "Gemini API key",
                onDismiss = { dialog = null },
                confirmText = "Save",
                onConfirm = {
                    if (key.isNotBlank()) {
                        ApiKeyStore.saveKey(context, key)
                        keyVersion++
                    }
                    dialog = null
                },
            ) {
                NovaTextField(
                    value = key, onValueChange = { key = it }, modifier = Modifier.fillMaxWidth(),
                    label = "API key", placeholder = if (hasKey) "Enter a new key to replace it" else "Paste your key",
                    singleLine = true, visualTransformation = PasswordVisualTransformation(),
                    supportingText = "Kept on this phone. $name never shows or logs it.",
                )
                if (hasKey) {
                    Spacer(Modifier.height(NovaSpacing.sm))
                    NovaButton("Remove saved key", {
                        ApiKeyStore.saveKey(context, "")
                        keyVersion++
                        dialog = null
                    }, style = NovaButtonStyle.TEXT)
                }
            }
        }
        null -> Unit
    }
}
