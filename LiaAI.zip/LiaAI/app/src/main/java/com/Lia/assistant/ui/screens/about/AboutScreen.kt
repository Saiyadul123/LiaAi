package com.Lia.assistant.ui.screens.about

import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.Lia.assistant.FlavorRoutes
import com.Lia.assistant.R
import com.Lia.assistant.data.AssistantBrand
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaDialog
import com.Lia.assistant.ui.components.NovaSettingsRow
import com.Lia.assistant.ui.screens.common.NovaListScreen
import com.Lia.assistant.ui.screens.common.RowDivider
import com.Lia.assistant.ui.screens.common.settingsSection
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun AboutScreen(appState: NovaAppState, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val name = appState.assistantName

    val version by produceState("…") {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val pm = context.packageManager
                val info = if (Build.VERSION.SDK_INT >= 33) {
                    pm.getPackageInfo(context.packageName, PackageManager.PackageInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION") pm.getPackageInfo(context.packageName, 0)
                }
                info.versionName
            }.getOrNull() ?: "unknown"
        }
    }
    var showLicences by remember { mutableStateOf(false) }
    val licences by produceState<String?>(null, showLicences) {
        if (showLicences) {
            value = withContext(Dispatchers.IO) {
                listOf("InstrumentSerif-OFL.txt" to "Instrument Serif", "Manrope-OFL.txt" to "Manrope")
                    .joinToString("\n\n") { (file, title) ->
                        val text = runCatching {
                            context.assets.open("licenses/$file").bufferedReader().use { it.readText() }
                        }.getOrDefault("(licence text unavailable)")
                        "$title\n\n$text"
                    }
            }
        }
    }

    NovaListScreen(title = "About $name", onBack = onBack, modifier = modifier) {
        item {
            Column(
                Modifier.fillMaxWidth().padding(NovaSpacing.xl),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Image(painterResource(R.drawable.lia_logo), contentDescription = "$name logo", modifier = Modifier.size(120.dp))
                Spacer(Modifier.height(NovaSpacing.md))
                Text(name, style = type.display, color = colors.textPrimary, textAlign = TextAlign.Center)
                Text(AssistantBrand.TAGLINE, style = type.voice, color = colors.textSecondary, textAlign = TextAlign.Center)
            }
        }
        settingsSection("This build") {
            NovaSettingsRow("Version", icon = Icons.Rounded.Info, value = version)
            RowDivider()
            NovaSettingsRow("Edition", subtitle = FlavorRoutes.flavorLabel)
            RowDivider()
            NovaSettingsRow("Powered by", subtitle = "Google Gemini, with your own API key")
        }
        settingsSection("Legal") {
            NovaSettingsRow("Open-source licences", icon = Icons.Rounded.Description, subtitle = "Fonts and libraries", onClick = { showLicences = true })
        }
    }

    if (showLicences) {
        NovaDialog(title = "Open-source licences", onDismiss = { showLicences = false }, dismissText = "Close") {
            Box(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                Text(licences ?: "Loading…", style = type.caption, color = colors.textSecondary)
            }
        }
    }
}
