package com.Lia.assistant.action

import android.Manifest
import android.content.ContentResolver
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

object ContactResolver {
    data class Candidate(val name: String, val number: String)

    sealed interface Result {
        data class Found(val name: String, val number: String) : Result
        data object NoPermission : Result
        data object NotFound : Result
    }

    private const val PHONE_CHARS = "0123456789 +-()."
    private const val MIN_DIGITS = 5
    private const val LIMIT = 5

    /** Digits, spaces and + - ( ) . only, with at least 5 digits. */
    fun looksLikePhoneNumber(query: String): Boolean {
        val q = query.trim()
        return q.isNotEmpty() && q.all { it in PHONE_CHARS } && q.count { it.isDigit() } >= MIN_DIGITS
    }

    /** Exact name > name starts with query > name contains query; ties keep the shorter name first. */
    internal fun rank(query: String, candidates: List<Candidate>): List<Candidate> {
        val q = query.trim().lowercase()
        fun tier(c: Candidate): Int {
            val n = c.name.trim().lowercase()
            return when {
                n == q -> 0
                n.startsWith(q) -> 1
                n.contains(q) -> 2
                else -> 3
            }
        }
        return candidates.sortedWith(compareBy<Candidate>({ tier(it) }, { it.name.length }))
    }

    /**
     * A phone-number-like query is returned as is (no permission needed). Otherwise READ_CONTACTS
     * is required and the contacts are searched by name. Blocking: call off the main thread.
     */
    fun lookup(context: Context, query: String): Result = lookup(
        query = query,
        hasPermission = {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
                PackageManager.PERMISSION_GRANTED
        },
        search = { queryPhones(context, it) },
    )

    internal fun lookup(
        query: String,
        hasPermission: () -> Boolean,
        search: (String) -> List<Candidate>,
    ): Result {
        val q = query.trim()
        if (q.isEmpty()) return Result.NotFound
        if (looksLikePhoneNumber(q)) return Result.Found(q, q)
        if (!hasPermission()) return Result.NoPermission
        val best = rank(q, search(q)).firstOrNull() ?: return Result.NotFound
        return Result.Found(best.name, best.number)
    }

    private fun queryPhones(context: Context, name: String): List<Candidate> {
        val escaped = name.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        val args = Bundle().apply {
            putString(
                ContentResolver.QUERY_ARG_SQL_SELECTION,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ? ESCAPE '\\'"
            )
            putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, arrayOf("%$escaped%"))
            putInt(ContentResolver.QUERY_ARG_LIMIT, LIMIT)
        }
        val out = ArrayList<Candidate>(LIMIT)
        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                ),
                args,
                null,
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0).orEmpty()
                    val num = c.getString(1).orEmpty()
                    if (n.isNotBlank() && num.isNotBlank()) out += Candidate(n, num)
                }
            }
        } catch (_: SecurityException) {
            // permission revoked mid-flight: behave as "nothing found"
        }
        return out
    }
}
