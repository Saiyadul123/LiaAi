package com.Lia.assistant.voice

import java.util.Base64
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/**
 * Pure JSON building/parsing for the Gemini Live WebSocket protocol (no networking, no Android
 * types, so it is unit-testable on the JVM). Raw server messages are never logged here.
 */
internal object GeminiLiveProtocol {

    const val AUDIO_IN_MIME = "audio/pcm;rate=16000"

    // ---- Outgoing ---------------------------------------------------------------------------

    /**
     * Setup message. Deliberately does NOT set realtimeInputConfig.automaticActivityDetection.
     * "tools" is omitted when there are no declarations (the API rejects an empty list).
     */
    fun setupMessage(
        model: String,
        voiceName: String,
        systemInstruction: String,
        tools: List<ToolDeclaration>,
    ): String {
        val setup = JSONObject()
            .put("model", model)
            .put(
                "generationConfig", JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig", JSONObject().put(
                            "voiceConfig", JSONObject().put(
                                "prebuiltVoiceConfig", JSONObject().put("voiceName", voiceName)
                            )
                        )
                    )
            )
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
            )
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())

        if (tools.isNotEmpty()) {
            val declarations = JSONArray()
            tools.forEach { declarations.put(declarationJson(it)) }
            setup.put("tools", JSONArray().put(JSONObject().put("functionDeclarations", declarations)))
        }
        return JSONObject().put("setup", setup).toString()
    }

    private fun declarationJson(t: ToolDeclaration): JSONObject {
        val json = JSONObject().put("name", t.name).put("description", t.description)
        // A tool without parameters omits "parameters" entirely (empty OBJECT schemas are rejected).
        if (t.params.isNotEmpty()) {
            val props = JSONObject()
            t.params.forEach {
                props.put(it.name, JSONObject().put("type", "STRING").put("description", it.description))
            }
            val schema = JSONObject().put("type", "OBJECT").put("properties", props)
            val required = t.params.filter { it.required }.map { it.name }
            if (required.isNotEmpty()) schema.put("required", JSONArray(required))
            json.put("parameters", schema)
        }
        return json
    }

    /** Base64 without line wrapping (java.util.Base64 basic encoder == Android's NO_WRAP). */
    fun audioMessage(pcm: ByteArray): String {
        val data = Base64.getEncoder().encodeToString(pcm)
        return """{"realtimeInput":{"audio":{"mimeType":"$AUDIO_IN_MIME","data":"$data"}}}"""
    }

    /** [resultJson] should be a JSON object; anything else is wrapped as {"result": "<text>"}. */
    fun toolResponseMessage(id: String, name: String, resultJson: String): String {
        val response = try {
            JSONObject(resultJson)
        } catch (_: JSONException) {
            JSONObject().put("result", resultJson)
        }
        val fr = JSONObject().put("id", id).put("name", name).put("response", response)
        return JSONObject()
            .put("toolResponse", JSONObject().put("functionResponses", JSONArray().put(fr)))
            .toString()
    }

    // ---- Incoming ---------------------------------------------------------------------------

    /**
     * Parses one server message and dispatches to [listener]. Unknown or ignorable messages
     * (sessionResumptionUpdate, goAway, ...) and malformed JSON are dropped silently.
     */
    fun parse(raw: String, listener: GeminiLiveClient.Listener, dedup: ToolCallDeduplicator) {
        val root = try {
            JSONObject(raw)
        } catch (_: JSONException) {
            return
        }

        if (root.has("setupComplete")) listener.onSetupComplete()

        root.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
            for (i in 0 until calls.length()) {
                val call = calls.optJSONObject(i) ?: continue
                val name = call.optString("name")
                if (name.isEmpty()) continue
                val id = call.optString("id")
                if (!dedup.markIfNew(id)) continue
                listener.onToolCall(id, name, call.optJSONObject("args") ?: JSONObject())
            }
        }

        val content = root.optJSONObject("serverContent") ?: return

        if (content.optBoolean("interrupted")) listener.onInterrupted()

        content.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
            for (i in 0 until parts.length()) {
                val inline = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                if (!inline.optString("mimeType").startsWith("audio/pcm")) continue
                val data = inline.optString("data")
                if (data.isEmpty()) continue
                val bytes = try {
                    Base64.getDecoder().decode(data)
                } catch (_: IllegalArgumentException) {
                    continue
                }
                if (bytes.isNotEmpty()) listener.onAudioChunk(bytes) // 24 kHz PCM16 mono
            }
        }

        content.optJSONObject("inputTranscription")?.optString("text")
            ?.takeIf { it.isNotEmpty() }?.let(listener::onInputTranscript)
        content.optJSONObject("outputTranscription")?.optString("text")
            ?.takeIf { it.isNotEmpty() }?.let(listener::onOutputTranscript)

        if (content.optBoolean("turnComplete")) listener.onTurnComplete()
    }

    // ---- Safety -----------------------------------------------------------------------------

    /** Removes the API key (and any "key=..." query fragment) from text that may reach the UI. */
    fun redact(text: String, apiKey: String): String {
        var out = text
        if (apiKey.isNotBlank()) out = out.replace(apiKey, "***")
        return out.replace(Regex("key=[^&\\s\"']+"), "key=***")
    }
}
