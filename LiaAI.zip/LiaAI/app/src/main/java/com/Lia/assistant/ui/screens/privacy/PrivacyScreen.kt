package com.Lia.assistant.ui.screens.privacy

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.ChatHistoryStore
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaDialog
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaSettingsRow
import com.Lia.assistant.ui.screens.common.NovaListScreen
import com.Lia.assistant.ui.screens.common.RowDivider
import com.Lia.assistant.ui.screens.common.settingsSection
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class PrivacyConfirm { HISTORY, KEY }

@Composable
fun PrivacyScreen(appState: NovaAppState, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val name = appState.assistantName

    var confirm by remember { mutableStateOf<PrivacyConfirm?>(null) }
    var keyVersion by remember { mutableIntStateOf(0) }
    val hasKey by produceState(false, keyVersion) { value = withContext(Dispatchers.IO) { ApiKeyStore.hasKey(context) } }

    NovaListScreen(title = "Privacy", subtitle = "What stays on your phone", onBack = onBack, modifier = modifier) {
        item {
            NovaGlassCard(Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg)) {
                val points = listOf(
                    "Voice mode sends your microphone audio to Google's Gemini service while a session is running, using your own API key.",
                    "Typed chats are sent to Gemini to get a reply.",
                    "Saved chats stay on this phone, in $name's private storage. You can turn saving off or delete them below.",
                    "Your API key is kept on this phone. $name never shows it or writes it to logs.",
                    "To call or message, $name only looks up the contact you ask for.",
                    "$name has no ads and no analytics.",
                )
                points.forEachIndexed { i, text ->
                    if (i > 0) Spacer(Modifier.height(NovaSpacing.md))
                    Text(text, style = type.body, color = if (i == 0) colors.textPrimary else colors.textSecondary)
                }
            }
        }
        settingsSection("Your data") {
            NovaSettingsRow(
                "Save chat history", icon = Icons.Rounded.History, subtitle = "Keep typed chats in History",
                switch = appState.saveHistory, onSwitchChange = appState::applySaveHistory,
            )
            RowDivider()
            NovaSettingsRow("Delete all history", icon = Icons.Rounded.DeleteOutline, subtitle = "Removes every saved chat", onClick = { confirm = PrivacyConfirm.HISTORY })
            RowDivider()
            NovaSettingsRow(
                "Remove my API key", icon = Icons.Rounded.Key,
                subtitle = "You can add it again any time", value = if (hasKey) "Set" else "Not set",
                onClick = { if (hasKey) confirm = PrivacyConfirm.KEY },
            )
        }
    }

    when (confirm) {
        PrivacyConfirm.HISTORY -> NovaDialog(
            title = "Delete all history?",
            onDismiss = { confirm = null },
            confirmText = "Delete",
            onConfirm = {
                confirm = null
                scope.launch { ChatHistoryStore.clear(context) }
            },
        ) { Text("Every saved chat is removed from this phone. It can't be undone.", style = type.body, color = colors.textSecondary) }

        PrivacyConfirm.KEY -> NovaDialog(
            title = "Remove your API key?",
            onDismiss = { confirm = null },
            confirmText = "Remove",
            onConfirm = {
                confirm = null
                ApiKeyStore.saveKey(context, "")
                keyVersion++
            },
        ) { Text("Voice mode and chat stop working until you add a key again.", style = type.body, color = colors.textSecondary) }

        null -> Unit
    }
}
