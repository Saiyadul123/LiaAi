package com.Lia.assistant.voice

/**
 * Detects "build me a website ..." requests in typed chat so they can go to the Website Forge
 * instead of Gemini. Questions about how to build a website are deliberately not matched.
 */
object ForgeIntent {
    data class Request(val brief: String)

    private const val MAX_BRIEF = 1_000

    private val BUILD_REQUEST = Regex(
        """\b(?:build|make|create|design|generate|develop|code|whip up)\b([^.,;!?\n]{0,40}?)""" +
            """\b(?:websites?|web ?sites?|web ?pages?|landing ?pages?|home ?pages?|portfolio sites?)\b""",
        RegexOption.IGNORE_CASE
    )
    private val QUESTION_START = Regex(
        """^\s*(?:how|what|why|which|when|where|who|is|are|does|do|did|explain|tell me)\b""",
        RegexOption.IGNORE_CASE
    )
    private val HOW_TO = Regex(
        """\b(?:how (?:to|do|can|would|should)|explain|tutorial|steps to)\b""",
        RegexOption.IGNORE_CASE
    )
    private val MIDDLE_BLOCKERS = Regex("""\b(?:and|then|or|but|visit|visited|read|see|saw)\b""", RegexOption.IGNORE_CASE)

    /** The Forge request if [text] asks for a website to be built, else null. */
    fun extract(text: String): Request? {
        val t = text.trim()
        if (t.length < 8) return null
        if (QUESTION_START.containsMatchIn(t) || HOW_TO.containsMatchIn(t)) return null
        val match = BUILD_REQUEST.find(t) ?: return null
        if (MIDDLE_BLOCKERS.containsMatchIn(match.groupValues[1])) return null
        return Request(t.take(MAX_BRIEF))
    }
}
