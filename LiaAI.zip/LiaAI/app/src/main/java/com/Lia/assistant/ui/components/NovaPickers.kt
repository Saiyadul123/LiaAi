package com.Lia.assistant.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.paneTitle
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaSizes
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.depthSurface

/** Modal dialog in the app's own style. Buttons appear when [confirmText] / [dismissText] are given. */
@Composable
fun NovaDialog(
    title: String,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    confirmText: String? = null,
    onConfirm: (() -> Unit)? = null,
    dismissText: String? = "Cancel",
    content: @Composable ColumnScope.() -> Unit,
) {
    val colors = NovaTheme.colors
    val shape = NovaTheme.shapes.large
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = modifier
                .depthSurface(shape, elevation = 16.dp)
                .clip(shape)
                .background(colors.surfaceRaised)
                .border(1.dp, colors.surfaceBorder, shape)
                .padding(NovaSpacing.xl)
                .semantics { paneTitle = title },
        ) {
            Text(
                text = title,
                style = NovaTheme.typography.headline.copy(fontSize = 24.sp, lineHeight = 30.sp),
                color = colors.textPrimary,
                modifier = Modifier.semantics { heading() },
            )
            Spacer(Modifier.height(NovaSpacing.md))
            content()
            if (dismissText != null || (confirmText != null && onConfirm != null)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = NovaSpacing.lg),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (dismissText != null) NovaButton(dismissText, onDismiss, style = NovaButtonStyle.TEXT)
                    if (confirmText != null && onConfirm != null) {
                        Spacer(Modifier.width(NovaSpacing.sm))
                        NovaButton(confirmText, onConfirm)
                    }
                }
            }
        }
    }
}

/** Radio-list picker (personality, language, voice ...). [onSelect] fires on tap; the caller decides when to dismiss. */
@Composable
fun <T> NovaChoiceDialog(
    title: String,
    options: List<T>,
    selected: T,
    optionLabel: (T) -> String,
    onSelect: (T) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    optionDescription: (T) -> String? = { null },
    dismissText: String = "Close",
) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    NovaDialog(title = title, onDismiss = onDismiss, modifier = modifier, dismissText = dismissText) {
        Column(
            Modifier
                .heightIn(max = 400.dp)
                .verticalScroll(rememberScrollState())
                .selectableGroup(),
        ) {
            options.forEach { option ->
                val isSelected = option == selected
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 56.dp)
                        .clip(NovaTheme.shapes.small)
                        .selectable(selected = isSelected, role = Role.RadioButton, onClick = { onSelect(option) })
                        .padding(horizontal = NovaSpacing.xs),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = null,
                        colors = RadioButtonDefaults.colors(
                            selectedColor = colors.accent,
                            unselectedColor = colors.textTertiary,
                        ),
                    )
                    Spacer(Modifier.width(NovaSpacing.md))
                    Column(Modifier.padding(vertical = NovaSpacing.sm)) {
                        Text(
                            optionLabel(option),
                            style = type.body.copy(fontWeight = FontWeight.Medium),
                            color = colors.textPrimary,
                        )
                        optionDescription(option)?.let { Text(it, style = type.caption, color = colors.textSecondary) }
                    }
                }
            }
        }
    }
}

/** Pill-shaped single choice among a few short options (for example Dark / Light / System). */
@Composable
fun NovaSegmentedPicker(
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    contentDescription: String? = null,
) {
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val pill = NovaTheme.shapes.pill
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(pill)
            .background(colors.surfaceRaised)
            .border(1.dp, colors.surfaceBorder, pill)
            .padding(4.dp)
            .selectableGroup()
            .semantics { if (contentDescription != null) this.contentDescription = contentDescription },
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        options.forEachIndexed { index, label ->
            val selected = index == selectedIndex
            val fill by animateColorAsState(
                targetValue = if (selected) colors.accent else Color.Transparent,
                animationSpec = tween(if (reduced) 0 else NovaMotion.FAST),
                label = "segment",
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = NovaSizes.MinTouch)
                    .clip(pill)
                    .background(fill)
                    .selectable(selected = selected, role = Role.RadioButton, onClick = { onSelect(index) }),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = label,
                    style = NovaTheme.typography.title.copy(fontSize = 15.sp, lineHeight = 20.sp),
                    color = if (selected) colors.onAccent else colors.textSecondary,
                )
            }
        }
    }
}

/** Title + value label above a slider (speech speed, volume ...). */
@Composable
fun NovaSliderRow(
    title: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    valueLabel: String,
    modifier: Modifier = Modifier,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f,
    steps: Int = 0,
) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    Column(modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = type.body.copy(fontWeight = FontWeight.Medium), color = colors.textPrimary, modifier = Modifier.weight(1f))
            Text(valueLabel, style = type.body, color = colors.textSecondary)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = steps,
            modifier = Modifier
                .heightIn(min = NovaSizes.MinTouch)
                .semantics {
                    contentDescription = title
                    stateDescription = valueLabel
                },
            colors = SliderDefaults.colors(
                thumbColor = colors.accent,
                activeTrackColor = colors.accent,
                inactiveTrackColor = colors.textTertiary.copy(alpha = 0.4f),
                activeTickColor = colors.onAccent,
                inactiveTickColor = colors.textTertiary,
            ),
        )
    }
}
