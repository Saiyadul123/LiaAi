package com.Lia.assistant.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.theme.NovaTheme
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

internal const val RING_BARS = 48
internal const val RING_MIN = 0.08f
private val TWO_PI = (2.0 * PI).toFloat()

/**
 * Length of each bar as a fraction (0.08..1) of the maximum. Silence leaves a thin even ring; louder
 * voice makes the bars taller, with a travelling wave ([phase] 0..1) so they do not all move together.
 */
internal fun ringBarLengths(count: Int, amplitude: Float, phase: Float): FloatArray {
    val amp = amplitude.coerceIn(0f, 1f)
    return FloatArray(count) { i ->
        val wave = 0.5f + 0.5f * sin((i / count.toFloat() * 6f + phase) * TWO_PI)
        (RING_MIN + amp * (0.35f + 0.57f * wave)).coerceIn(RING_MIN, 1f)
    }
}

/**
 * A thin ring of 48 bars around the orb, scaled by [amplitude]. Show it on the speaking state only.
 * With reduced motion the wave stops travelling (the bars still follow the voice).
 */
@Composable
fun VoiceRing(amplitude: Float, modifier: Modifier = Modifier) {
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val travel = rememberInfiniteTransition(label = "voiceRing").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)),
        label = "voiceRingPhase",
    )
    Canvas(modifier) {
        val r = size.minDimension / 2f
        val center = Offset(size.width / 2f, size.height / 2f)
        val inner = r * 0.80f
        val maxLength = r * 0.20f
        val lengths = ringBarLengths(RING_BARS, amplitude, if (reduced) 0f else travel.value)
        val stroke = 3.dp.toPx()
        for (i in 0 until RING_BARS) {
            val angle = TWO_PI * i / RING_BARS - TWO_PI / 4f
            val dx = cos(angle)
            val dy = sin(angle)
            val length = lengths[i] * maxLength
            drawLine(
                color = colors.accent.copy(alpha = 0.45f + 0.5f * lengths[i]),
                start = Offset(center.x + dx * inner, center.y + dy * inner),
                end = Offset(center.x + dx * (inner + length), center.y + dy * (inner + length)),
                strokeWidth = stroke,
                cap = StrokeCap.Round,
            )
        }
    }
}
