package com.Lia.assistant.forge

data class ForgeStat(val label: String, val value: String)

/**
 * What the Forge screen shows while a site is being built: which of the six stages is running, how far
 * along it is, and four small stats. Nothing produces real progress yet, so the default is "idle".
 */
data class ForgeProgress(
    val stage: Int = -1,
    val percent: Int = 0,
    val stats: List<ForgeStat> = EMPTY_STATS,
) {
    val isRunning: Boolean get() = stage in STAGES.indices
    val stageName: String get() = if (isRunning) STAGES[stage] else "Waiting"
    /** How many of the six track segments are lit. */
    val litSegments: Int get() = if (isRunning) stage + 1 else 0
    val percentText: String get() = if (isRunning) "${percent.coerceIn(0, 100)}%" else "–"

    companion object {
        val STAGES = listOf("Plan", "Design", "3D scene", "Content", "Assemble", "Polish")
        val EMPTY_STATS = listOf(
            ForgeStat("Files", "–"), ForgeStat("Sections", "–"), ForgeStat("3D scenes", "–"), ForgeStat("Elapsed", "–"),
        )
        val Idle = ForgeProgress()
    }
}
