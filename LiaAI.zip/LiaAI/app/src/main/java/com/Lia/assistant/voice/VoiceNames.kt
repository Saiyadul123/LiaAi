package com.Lia.assistant.voice

/** Maps whatever voice name the UI stores to a valid Gemini prebuilt voice. */
object VoiceNames {
    const val DEFAULT = "Aoede"

    val GEMINI_VOICES: List<String> = listOf(
        "Zephyr", "Puck", "Charon", "Kore", "Fenrir", "Leda", "Orus", "Aoede", "Callirrhoe",
        "Autonoe", "Enceladus", "Iapetus", "Umbriel", "Algieba", "Despina", "Erinome", "Algenib",
        "Rasalgethi", "Laomedeia", "Achernar", "Alnilam", "Schedar", "Gacrux", "Pulcherrima",
        "Achird", "Zubenelgenubi", "Vindemiatrix", "Sadachbia", "Sadaltager", "Sulafat"
    )

    private val byLowercase = GEMINI_VOICES.associateBy { it.lowercase() }

    /** Accepts "Kore", "kore" or decorated names like "Kore (Firm)"; anything unknown becomes [DEFAULT]. */
    fun toGemini(uiName: String?): String {
        val head = uiName.orEmpty().trim().substringBefore('(').trim().substringBefore(' ').lowercase()
        return byLowercase[head] ?: DEFAULT
    }
}
