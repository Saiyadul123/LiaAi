package com.Lia.assistant.action

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import kotlin.math.abs

object AppLauncher {
    data class Match(val label: String, val packageName: String)

    private val WORD_SPLIT = Regex("[^\\p{L}\\p{N}]+")

    /**
     * Finds an app by spoken/typed name. An exact (case-insensitive) label wins. Otherwise a
     * candidate label (at least 3 characters) must start with the query, be a prefix of the query,
     * or have every query word as the prefix of one of its words. There is NO substring matching
     * ("tube" never finds "YouTube"). Among candidates the label whose length is closest to the
     * query wins (ties: shorter, then alphabetical).
     */
    fun findApp(apps: Map<String, String>, query: String): Match? {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return null
        apps[q]?.let { return Match(q, it) }
        if (q.length < 2) return null // a single letter is not a meaningful fuzzy query

        val queryWords = words(q)
        val best = apps.keys
            .filter { it.length >= 3 && isCandidate(it, q, queryWords) }
            .minWithOrNull(compareBy<String>({ abs(it.length - q.length) }, { it.length }, { it }))
            ?: return null
        return Match(best, apps.getValue(best))
    }

    suspend fun findApp(context: Context, query: String): Match? =
        findApp(InstalledAppLabelCache.get(context), query)

    private fun isCandidate(key: String, q: String, queryWords: List<String>): Boolean {
        if (key.startsWith(q) || q.startsWith(key)) return true
        if (queryWords.isEmpty()) return false
        val keyWords = words(key)
        return queryWords.all { qw -> keyWords.any { it.startsWith(qw) } }
    }

    private fun words(text: String): List<String> = text.split(WORD_SPLIT).filter { it.isNotEmpty() }

    /** Starts the app's launcher activity. Returns false if it cannot be launched. */
    fun launch(context: Context, packageName: String): Boolean {
        val pm = context.packageManager ?: return false
        val intent = pm.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (_: ActivityNotFoundException) {
            false
        } catch (_: SecurityException) {
            false
        }
    }
}
