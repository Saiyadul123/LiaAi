package com.Lia.assistant.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaSizes
import com.Lia.assistant.ui.theme.NovaTheme

enum class NovaButtonStyle { PRIMARY, SECONDARY, TEXT }

private const val PRESSED_SCALE = 0.96f
private const val DISABLED_ALPHA = 0.4f

/** The marigold accent button. Presses to 0.96 scale (not with reduced motion); at least 48 dp tall. */
@Composable
fun NovaButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: NovaButtonStyle = NovaButtonStyle.PRIMARY,
    enabled: Boolean = true,
    leadingIcon: ImageVector? = null,
    contentDescription: String? = null,
) {
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && !reduced) PRESSED_SCALE else 1f,
        animationSpec = tween(NovaMotion.FAST),
        label = "buttonPress",
    )
    val shape = NovaTheme.shapes.pill
    val labelColor = if (style == NovaButtonStyle.PRIMARY) colors.onAccent else colors.accentText

    val glow = if (style == NovaButtonStyle.PRIMARY && enabled) {
        Modifier.shadow(8.dp, shape, clip = false, ambientColor = colors.accentGlow, spotColor = colors.accentGlow)
    } else {
        Modifier
    }
    val fill = when (style) {
        NovaButtonStyle.PRIMARY ->
            Modifier.background(Brush.horizontalGradient(listOf(colors.accent, colors.accentSecondary)), shape)
        NovaButtonStyle.SECONDARY ->
            Modifier.background(colors.surfaceRaised, shape).border(1.dp, colors.accent, shape)
        NovaButtonStyle.TEXT -> Modifier
    }

    Row(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = if (enabled) 1f else DISABLED_ALPHA
            }
            .then(glow)
            .heightIn(min = NovaSizes.MinTouch)
            .widthIn(min = NovaSizes.MinTouch)
            .clip(shape)
            .then(fill)
            .clickable(
                interactionSource = interaction,
                indication = ripple(color = labelColor),
                enabled = enabled,
                role = Role.Button,
                onClick = onClick,
            )
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .semantics { if (contentDescription != null) this.contentDescription = contentDescription },
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leadingIcon != null) {
            Icon(leadingIcon, contentDescription = null, modifier = Modifier.size(20.dp), tint = labelColor)
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = NovaTheme.typography.title.copy(fontSize = 15.sp, lineHeight = 20.sp),
            color = labelColor,
            maxLines = 1,
        )
    }
}
