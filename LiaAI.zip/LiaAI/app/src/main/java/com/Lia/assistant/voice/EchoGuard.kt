package com.Lia.assistant.voice

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Keeps the microphone muted while the assistant is speaking (plus a short tail) so the model
 * does not hear its own voice.
 *
 * Call [notifyPlaybackStarted] / [notifyPlaybackStopped] in matched pairs per playback stream or
 * burst, and skip sending mic audio while [isMicMuted] is true. A 60 s watchdog force-unmutes if a
 * "stopped" call is ever lost. Thread-safe; no logging.
 */
object EchoGuard {
    const val ECHO_TAIL_MS = 450L
    const val WATCHDOG_MS = 60_000L

    private val lock = Any()
    private var scope: CoroutineScope = defaultScope()

    private var active = 0
    @Volatile private var muted = false

    private var tailJob: Job? = null
    private var watchdogJob: Job? = null

    // Generation counters make late-running (already cancelled) jobs harmless.
    private var tailGen = 0
    private var watchdogGen = 0

    fun isMicMuted(): Boolean = muted

    /** Playback began: count it, mute now, cancel any pending unmute, (re)arm the watchdog. */
    fun notifyPlaybackStarted() {
        synchronized(lock) {
            active++
            muted = true
            tailGen++
            tailJob?.cancel()
            tailJob = null

            val gen = ++watchdogGen
            watchdogJob?.cancel()
            watchdogJob = scope.launch {
                delay(WATCHDOG_MS)
                forceUnmute(gen)
            }
        }
    }

    /** Playback ended: when the last active playback stops, unmute after [ECHO_TAIL_MS]. */
    fun notifyPlaybackStopped() {
        synchronized(lock) {
            if (active == 0) return // unmatched stop: never go negative
            active--
            if (active > 0) return

            val gen = ++tailGen
            tailJob?.cancel()
            tailJob = scope.launch {
                delay(ECHO_TAIL_MS)
                synchronized(lock) {
                    if (gen == tailGen && active == 0) {
                        muted = false
                        tailJob = null
                        watchdogGen++
                        watchdogJob?.cancel()
                        watchdogJob = null
                    }
                }
            }
        }
    }

    /** Immediately clears all state (call when a voice session starts or stops). */
    fun reset() {
        synchronized(lock) {
            tailGen++
            watchdogGen++
            tailJob?.cancel()
            watchdogJob?.cancel()
            tailJob = null
            watchdogJob = null
            active = 0
            muted = false
        }
    }

    private fun forceUnmute(gen: Int) {
        synchronized(lock) {
            if (gen != watchdogGen) return
            tailGen++
            tailJob?.cancel()
            tailJob = null
            watchdogJob = null
            active = 0
            muted = false
        }
    }

    // ---- test hooks --------------------------------------------------------------------------

    internal fun activeCount(): Int = synchronized(lock) { active }

    /** Swaps the scope used for timers (tests pass a TestScope); null restores the default. */
    internal fun setScopeForTest(testScope: CoroutineScope?) {
        synchronized(lock) {
            reset()
            scope = testScope ?: defaultScope()
        }
    }

    private fun defaultScope() = CoroutineScope(SupervisorJob() + Dispatchers.Default)
}
