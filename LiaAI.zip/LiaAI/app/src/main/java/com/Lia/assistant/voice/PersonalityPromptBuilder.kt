package com.Lia.assistant.voice

import com.Lia.assistant.data.AssistantBrand
import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.Personality

/** Assembles the system instruction sent to the model. */
object PersonalityPromptBuilder {

    fun build(
        personality: Personality,
        language: LanguagePreference,
        detectedLanguage: DetectedLanguage,
        recap: String?,
        assistantName: String,
    ): String {
        val name = assistantName.trim().ifEmpty { AssistantBrand.NAME }
        return buildList {
            add(base(name))
            add(LiaCapabilityPrompts.toolInstruction(name))
            add(personality.systemInstruction)
            add(languagePolicy(language, detectedLanguage))
            add(SAFETY)
            if (!recap.isNullOrBlank()) add(continuation(recap))
        }.joinToString("\n\n")
    }

    private fun base(name: String) =
        "You are $name, a persistent personal voice assistant living on the user's phone. " +
            "Keep replies short and conversational, like spoken conversation."

    private fun languagePolicy(language: LanguagePreference, detected: DetectedLanguage): String =
        when (language) {
            LanguagePreference.AUTO -> {
                val hint = when (detected) {
                    DetectedLanguage.HINDI -> " The user's latest turn looks like Hindi."
                    DetectedLanguage.HINGLISH -> " The user's latest turn looks like Hinglish (Hindi in Roman script mixed with English)."
                    DetectedLanguage.ENGLISH -> " The user's latest turn looks like English."
                    DetectedLanguage.UNKNOWN -> ""
                }
                "Language: Match the language the user speaks, turn by turn. Never translate what the " +
                    "user said, and do not comment on their language choice.$hint"
            }
            LanguagePreference.HINDI ->
                "Language: Always reply in Hindi (Devanagari script), even if the user speaks another language."
            LanguagePreference.HINGLISH ->
                "Language: Always reply in Hinglish: Hindi written in Roman script mixed with English, " +
                    "the way people talk casually. Do not switch to pure English or pure Hindi."
            LanguagePreference.ENGLISH ->
                "Language: Always reply in English, even if the user speaks another language."
        }

    private const val SAFETY =
        "Safety: Never claim to be human. Never produce sexually explicit content. If the user asks " +
            "you to stop or change a topic, stop immediately. Vary your phrasing and openers so you " +
            "do not repeat yourself across turns."

    private fun continuation(recap: String) =
        "This is a continuing conversation — do not greet again. Recap:\n${recap.trim()}"
}
