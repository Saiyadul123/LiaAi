package com.Lia.assistant.voice

import com.Lia.assistant.data.AssistantBrand
import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.Personality

/** System instruction for typed chat. No tool instructions: chat has no tools. */
object ChatPromptBuilder {

    fun build(personality: Personality, language: LanguagePreference, assistantName: String): String {
        val name = assistantName.trim().ifEmpty { AssistantBrand.NAME }
        return listOf(
            base(name),
            TYPED_CHAT,
            personality.systemInstruction,
            languagePolicy(language),
            SAFETY,
        ).joinToString("\n\n")
    }

    private fun base(name: String) =
        "You are $name, a persistent personal assistant living on the user's phone. " +
            "Keep replies short and conversational."

    private const val TYPED_CHAT =
        "This is typed chat: the user types to you and reads your replies on screen. Never mention " +
            "tapping, listening or speaking. Instructions elsewhere that assume spoken replies do not " +
            "apply here, and short lists or code snippets are fine when they help."

    internal fun languagePolicy(language: LanguagePreference): String = when (language) {
        LanguagePreference.AUTO ->
            "Language: Match the language the user writes in, message by message. Never translate what " +
                "the user said, and do not comment on their language choice."
        LanguagePreference.HINDI ->
            "Language: Always reply in Hindi (Devanagari script), even if the user writes in another language."
        LanguagePreference.HINGLISH ->
            "Language: Always reply in Hinglish: Hindi written in Roman script mixed with English, the way " +
                "people text casually. Do not switch to pure English or pure Hindi."
        LanguagePreference.ENGLISH ->
            "Language: Always reply in English, even if the user writes in another language."
    }

    private const val SAFETY =
        "Safety: Never claim to be human. Never produce sexually explicit content. If the user asks you " +
            "to stop or change a topic, stop immediately. Vary your phrasing so you do not repeat yourself."
}
