package com.Lia.assistant.ui.screens.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.Lia.assistant.FlavorRoutes
import com.Lia.assistant.R
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaOrbStyle
import com.Lia.assistant.ui.components.NovaSectionHeader
import com.Lia.assistant.ui.components.NovaSettingsRow
import com.Lia.assistant.ui.components.NovaVoiceVisualizer
import com.Lia.assistant.ui.fx.AmbientGlow
import com.Lia.assistant.ui.theme.CardTilt
import com.Lia.assistant.ui.theme.NovaSizes
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.bottomBarContentPadding
import com.Lia.assistant.ui.theme.depthSurface
import com.Lia.assistant.ui.theme.rememberStageEntrance
import com.Lia.assistant.ui.theme.stageEntrance
import com.Lia.assistant.ui.theme.tiltParallax
import com.Lia.assistant.voice.NovaOrbState
import com.Lia.assistant.voice.VoiceSessionManager
import java.util.Calendar

/**
 * Home as a 3D stage: a state-tinted glow field behind, the orb at about 55 % of the width as the hero
 * (tap = Voice), floating pill buttons, and a row of "Try saying" cards that turn slightly as they scroll
 * past. One entrance sequence plays, the greeting first.
 */
@Composable
fun HomeScreen(
    appState: NovaAppState,
    onTalk: () -> Unit,
    onType: () -> Unit,
    onProfile: () -> Unit,
    onQuickActions: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val name = appState.assistantName
    val haptics = LocalHapticFeedback.current

    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greeting = Greeting.line(hour, appState.userName)
    val active by VoiceSessionManager.isActive.collectAsState()
    val sessionState by VoiceSessionManager.state.collectAsState()
    val amplitude by VoiceSessionManager.amplitude.collectAsState()
    val orbState = if (active) sessionState else NovaOrbState.IDLE

    val entrance = rememberStageEntrance()
    val orbSize = LocalConfiguration.current.screenWidthDp.dp * 0.55f
    val rowState = rememberLazyListState()

    val ideas = buildList {
        add("Call Mom" to "Places the call, or opens the dialer")
        add("YouTube kholo" to "Launches any app on your phone")
        add("Message Asha: I'm running late" to "Opens the message ready to send")
        if (FlavorRoutes.screenControlAvailable) add("What's on my screen?" to "$name reads it and can tap for you")
        add("Tell me something interesting" to "Or just chat about anything")
    }

    Box(modifier.fillMaxSize()) {
        AmbientGlow(state = orbState, modifier = Modifier.fillMaxSize()) // layer 1

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = bottomBarContentPadding(NovaSpacing.xl),
            verticalArrangement = Arrangement.spacedBy(NovaSpacing.md),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item {
                HomeHeader(
                    name = name,
                    initial = appState.userName,
                    onProfile = onProfile,
                    modifier = Modifier.stageEntrance(entrance, start = 0.30f).tiltParallax(4),
                )
            }

            // the greeting fades in first
            item {
                Text(
                    text = greeting,
                    style = type.voice.copy(fontSize = 28.sp, lineHeight = 36.sp),
                    color = colors.textPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = NovaSpacing.xl).stageEntrance(entrance, start = 0f, span = 0.35f),
                )
            }

            // layer 3: the hero orb
            item {
                Box(
                    modifier = Modifier
                        .size(orbSize)
                        .stageEntrance(entrance, start = 0.10f)
                        .tiltParallax(3)
                        .clip(CircleShape)
                        .clickable(onClickLabel = "Talk to $name", role = Role.Button) {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onTalk()
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    NovaVoiceVisualizer(
                        state = orbState,
                        modifier = Modifier.fillMaxSize(),
                        amplitude = amplitude,
                        style = NovaOrbStyle.fromId(appState.orbStyle),
                        name = name,
                    )
                }
            }

            item {
                Text(
                    text = "Tap me to talk",
                    style = type.voice,
                    color = colors.textSecondary,
                    modifier = Modifier.stageEntrance(entrance, start = 0.28f, span = 0.4f),
                )
            }

            // layer 4: floating pill buttons
            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = NovaSpacing.lg)
                        .stageEntrance(entrance, start = 0.38f)
                        .tiltParallax(4),
                    horizontalArrangement = Arrangement.spacedBy(NovaSpacing.md),
                ) {
                    NovaButton("Talk", onTalk, Modifier.weight(1f), leadingIcon = Icons.Rounded.Mic)
                    NovaButton("Type", onType, Modifier.weight(1f), style = NovaButtonStyle.GLASS, leadingIcon = Icons.Rounded.Keyboard)
                }
            }

            item {
                Column(Modifier.fillMaxWidth().stageEntrance(entrance, start = 0.48f)) {
                    NovaSectionHeader("Try saying")
                    Spacer(Modifier.height(NovaSpacing.sm))
                    LazyRow(
                        state = rowState,
                        contentPadding = PaddingValues(horizontal = NovaSpacing.lg),
                        horizontalArrangement = Arrangement.spacedBy(NovaSpacing.md),
                    ) {
                        itemsIndexed(ideas, key = { _, idea -> idea.first }) { index, idea ->
                            val (phrase, hint) = idea
                            NovaGlassCard(
                                modifier = Modifier
                                    .width(240.dp)
                                    .graphicsLayer {
                                        // turn a little (+-6 degrees) with the card's position in the row
                                        val info = rowState.layoutInfo
                                        val item = info.visibleItemsInfo.firstOrNull { it.index == index }
                                        val width = info.viewportSize.width
                                        val fraction = if (item == null || width == 0) 0f
                                        else ((item.offset + item.size / 2f) - width / 2f) / width
                                        rotationY = CardTilt.rowRotationY(fraction)
                                        cameraDistance = 12f * density
                                    },
                                onClick = onTalk,
                                onClickLabel = "Talk to $name",
                            ) {
                                Text("“$phrase”", style = type.voice, color = colors.textPrimary)
                                Spacer(Modifier.height(NovaSpacing.xs))
                                Text(hint, style = type.caption, color = colors.textSecondary)
                            }
                        }
                    }
                }
            }

            item {
                NovaGlassCard(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg).stageEntrance(entrance, start = 0.5f),
                    contentPadding = PaddingValues(0.dp),
                ) {
                    NovaSettingsRow(
                        title = "Quick actions",
                        icon = Icons.Rounded.Bolt,
                        subtitle = "Open an app, call or message in one tap",
                        onClick = onQuickActions,
                    )
                }
            }
        }
    }
}

/** A floating glass circle (layer 4). */
@Composable
private fun GlassCircle(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, label: String? = null, content: @Composable () -> Unit) {
    val colors = NovaTheme.colors
    val haptics = LocalHapticFeedback.current
    var circle = modifier
        .size(NovaSizes.MinTouch)
        .depthSurface(CircleShape, elevation = 6.dp)
        .clip(CircleShape)
        .background(colors.surfaceGlass)
        .border(1.dp, colors.surfaceBorder, CircleShape)
    if (onClick != null) {
        circle = circle.clickable(onClickLabel = label, role = Role.Button) {
            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        }
    }
    Box(circle.semantics { if (label != null) contentDescription = label }, contentAlignment = Alignment.Center) { content() }
}

@Composable
private fun HomeHeader(name: String, initial: String, onProfile: () -> Unit, modifier: Modifier = Modifier) {
    val colors = NovaTheme.colors
    Row(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GlassCircle {
            Image(painterResource(R.drawable.lia_logo), contentDescription = null, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.width(NovaSpacing.md))
        Text(name, style = NovaTheme.typography.title, color = colors.textPrimary, modifier = Modifier.weight(1f))
        GlassCircle(onClick = onProfile, label = "Profile") {
            Text(
                initial.trim().take(1).uppercase().ifEmpty { "•" },
                style = NovaTheme.typography.title,
                color = colors.textPrimary,
            )
        }
    }
}
