package com.Lia.assistant.ui.screens.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.Lia.assistant.FlavorRoutes
import com.Lia.assistant.R
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaOrbStyle
import com.Lia.assistant.ui.components.NovaSectionHeader
import com.Lia.assistant.ui.components.NovaSettingsRow
import com.Lia.assistant.ui.components.NovaVoiceVisualizer
import com.Lia.assistant.ui.theme.NovaSizes
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.bottomBarContentPadding
import com.Lia.assistant.voice.NovaOrbState
import com.Lia.assistant.voice.VoiceSessionManager
import java.util.Calendar

/** The landing screen: a time-of-day greeting in the serif voice, the live orb, Talk / Type, and ideas. */
@Composable
fun HomeScreen(
    appState: NovaAppState,
    onTalk: () -> Unit,
    onType: () -> Unit,
    onProfile: () -> Unit,
    onQuickActions: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val name = appState.assistantName

    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greeting = Greeting.text(hour)
    val active by VoiceSessionManager.isActive.collectAsState()
    val sessionState by VoiceSessionManager.state.collectAsState()
    val amplitude by VoiceSessionManager.amplitude.collectAsState()
    val orbState = if (active) sessionState else NovaOrbState.IDLE

    val ideas = buildList {
        add("Call Mom" to "Places the call, or opens the dialer")
        add("Open YouTube" to "Launches any app on your phone")
        add("Message Asha: I'm running late" to "Opens the message ready to send")
        if (FlavorRoutes.screenControlAvailable) add("What's on my screen?" to "$name reads it and can tap for you")
        add("Tell me something interesting" to "Or just chat about anything")
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = bottomBarContentPadding(NovaSpacing.xl),
        verticalArrangement = Arrangement.spacedBy(NovaSpacing.md),
    ) {
        item { HomeHeader(name = name, initial = appState.userName, onProfile = onProfile) }

        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.xl), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(greeting, style = type.voice, color = colors.textSecondary, textAlign = TextAlign.Center)
                Text(
                    appState.userName.ifBlank { "there" },
                    style = type.display,
                    color = colors.textPrimary,
                    textAlign = TextAlign.Center,
                )
            }
        }

        item {
            Box(Modifier.fillMaxWidth().padding(vertical = NovaSpacing.md), contentAlignment = Alignment.Center) {
                NovaVoiceVisualizer(
                    state = orbState,
                    modifier = Modifier.size(220.dp),
                    amplitude = amplitude,
                    style = NovaOrbStyle.fromId(appState.orbStyle),
                    name = name,
                )
            }
        }

        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg),
                horizontalArrangement = Arrangement.spacedBy(NovaSpacing.md),
            ) {
                NovaButton("Talk to $name", onTalk, Modifier.weight(1f), leadingIcon = Icons.Rounded.Mic)
                NovaButton("Type", onType, Modifier.weight(1f), style = NovaButtonStyle.SECONDARY, leadingIcon = Icons.Rounded.Keyboard)
            }
        }

        item { NovaSectionHeader("Try saying") }
        ideas.forEach { (phrase, hint) ->
            item {
                NovaGlassCard(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg),
                    onClick = onTalk,
                    onClickLabel = "Talk to $name",
                ) {
                    Text("“$phrase”", style = type.voice, color = colors.textPrimary)
                    Spacer(Modifier.height(NovaSpacing.xs))
                    Text(hint, style = type.caption, color = colors.textSecondary)
                }
            }
        }

        item {
            NovaGlassCard(
                modifier = Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg),
                contentPadding = PaddingValues(0.dp),
            ) {
                NovaSettingsRow(
                    title = "Quick actions",
                    icon = Icons.Rounded.Bolt,
                    subtitle = "Open an app, call or message in one tap",
                    onClick = onQuickActions,
                )
            }
        }
    }
}

@Composable
private fun HomeHeader(name: String, initial: String, onProfile: () -> Unit) {
    val colors = NovaTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            painter = painterResource(R.drawable.lia_logo),
            contentDescription = null,
            modifier = Modifier.size(44.dp),
        )
        Spacer(Modifier.width(NovaSpacing.md))
        Text(name, style = NovaTheme.typography.title, color = colors.textPrimary, modifier = Modifier.weight(1f))
        Box(
            modifier = Modifier
                .size(NovaSizes.MinTouch)
                .clip(CircleShape)
                .background(colors.surfaceGlass)
                .border(1.dp, colors.surfaceBorder, CircleShape)
                .clickable(onClickLabel = "Open profile", role = Role.Button, onClick = onProfile)
                .semantics { contentDescription = "Profile" },
            contentAlignment = Alignment.Center,
        ) {
            Text(
                initial.trim().take(1).uppercase().ifEmpty { "•" },
                style = NovaTheme.typography.title,
                color = colors.textPrimary,
            )
        }
    }
}
