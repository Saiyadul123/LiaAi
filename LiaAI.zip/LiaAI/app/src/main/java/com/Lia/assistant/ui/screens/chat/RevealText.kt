package com.Lia.assistant.ui.screens.chat

/** Word-by-word reveal helpers. Spacing and line breaks of the original text are preserved. */
object RevealText {
    private val WORD = Regex("\\S+")

    fun wordCount(text: String): Int = WORD.findAll(text).count()

    /** The text up to and including the first [words] words. */
    fun prefix(text: String, words: Int): String {
        if (words <= 0) return ""
        val matches = WORD.findAll(text).toList()
        if (words >= matches.size) return text
        return text.substring(0, matches[words - 1].range.last + 1)
    }
}
