package com.Lia.assistant.ui.screens.forge

import android.annotation.SuppressLint
import android.view.MotionEvent
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaSizes
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.depthSurface
import kotlinx.coroutines.delay

private const val TOOLBAR_HIDE_MS = 3000L

/**
 * Shows a generated page full-screen. A glass toolbar floats at the top, hides itself after a few seconds
 * and returns on a touch; a small menu handle at the bottom right is always visible.
 *
 * The WebView is a plain AndroidView: it must never sit inside graphicsLayer or AnimatedVisibility (it
 * renders black there), so only its siblings animate. JavaScript is on (the pages use Three.js), file and
 * content access are off, and mixed content is blocked. Nothing routes here yet: it waits for the builder.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ForgeResultViewer(
    html: String,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    title: String = "Your website",
) {
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    var toolbarVisible by remember { mutableStateOf(true) }
    LaunchedEffect(toolbarVisible) {
        if (toolbarVisible) {
            delay(TOOLBAR_HIDE_MS)
            toolbarVisible = false
        }
    }

    Box(modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    webViewClient = WebViewClient()
                    setOnTouchListener { _, event ->
                        if (event.action == MotionEvent.ACTION_UP) toolbarVisible = true
                        false // the page still gets the touch
                    }
                    loadDataWithBaseURL("https://forge.invalid/", html, "text/html", "UTF-8", null)
                }
            },
            onRelease = { it.destroy() },
        )

        AnimatedVisibility(
            visible = toolbarVisible,
            enter = fadeIn(tween(if (reduced) 0 else NovaMotion.MEDIUM)),
            exit = fadeOut(tween(if (reduced) 0 else NovaMotion.MEDIUM)),
            modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = NovaSpacing.sm),
        ) {
            Row(
                modifier = Modifier
                    .depthSurface(NovaTheme.shapes.pill, elevation = 10.dp)
                    .clip(NovaTheme.shapes.pill)
                    .background(colors.surfaceGlass)
                    .border(1.dp, colors.surfaceBorder, NovaTheme.shapes.pill)
                    .padding(start = NovaSpacing.lg, end = NovaSpacing.xs),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(title, style = NovaTheme.typography.title, color = colors.textPrimary)
                Spacer(Modifier.width(NovaSpacing.sm))
                IconButton(onClick = onClose) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close", tint = colors.textPrimary)
                }
            }
        }

        // always visible: brings the toolbar back
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(NovaSpacing.lg)
                .size(NovaSizes.MinTouch)
                .depthSurface(CircleShape, elevation = 8.dp)
                .clip(CircleShape)
                .background(colors.surfaceGlass)
                .border(1.dp, colors.surfaceBorder, CircleShape)
                .clickable(onClickLabel = "Show menu", role = Role.Button) { toolbarVisible = true },
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.MoreHoriz, contentDescription = "Menu", tint = colors.textPrimary)
        }
    }
}
