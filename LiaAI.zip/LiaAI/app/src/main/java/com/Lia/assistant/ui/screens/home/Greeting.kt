package com.Lia.assistant.ui.screens.home

enum class DayPart { MORNING, AFTERNOON, EVENING, NIGHT }

object Greeting {
    fun partOf(hour: Int): DayPart = when (hour.mod(24)) {
        in 5..11 -> DayPart.MORNING
        in 12..16 -> DayPart.AFTERNOON
        in 17..21 -> DayPart.EVENING
        else -> DayPart.NIGHT
    }

    fun text(hour: Int): String = when (partOf(hour)) {
        DayPart.MORNING -> "Good morning"
        DayPart.AFTERNOON -> "Good afternoon"
        DayPart.EVENING -> "Good evening"
        DayPart.NIGHT -> "Still up?"
    }

    /** "Good morning, Asha", or just "Good morning" without a name. Late at night: "Still up, Asha?". */
    fun line(hour: Int, name: String): String {
        val who = name.trim()
        return when {
            partOf(hour) == DayPart.NIGHT -> if (who.isEmpty()) "Still up?" else "Still up, $who?"
            who.isEmpty() -> text(hour)
            else -> "${text(hour)}, $who"
        }
    }
}
