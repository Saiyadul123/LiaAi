package com.Lia.assistant.ui.screens.home

enum class DayPart { MORNING, AFTERNOON, EVENING, NIGHT }

object Greeting {
    fun partOf(hour: Int): DayPart = when (hour.mod(24)) {
        in 5..11 -> DayPart.MORNING
        in 12..16 -> DayPart.AFTERNOON
        in 17..21 -> DayPart.EVENING
        else -> DayPart.NIGHT
    }

    fun text(hour: Int): String = when (partOf(hour)) {
        DayPart.MORNING -> "Good morning"
        DayPart.AFTERNOON -> "Good afternoon"
        DayPart.EVENING -> "Good evening"
        DayPart.NIGHT -> "Still up?"
    }
}
