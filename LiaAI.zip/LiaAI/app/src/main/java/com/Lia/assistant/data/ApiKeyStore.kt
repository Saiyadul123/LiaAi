package com.Lia.assistant.data

import android.content.Context

/**
 * Holds the user-supplied Gemini API key (entered in Settings).
 * The key is never hardcoded and must never be logged or included in error messages.
 */
object ApiKeyStore {
    private const val KEY_GEMINI = "gemini_api_key"

    /** Returns the saved key, or an empty string when none is set. */
    fun getKey(context: Context): String =
        NovaPrefsFile.get(context).getString(KEY_GEMINI, "").orEmpty()

    /** Saves the trimmed key. A blank key clears the stored value. */
    fun saveKey(context: Context, key: String) {
        val trimmed = key.trim()
        val editor = NovaPrefsFile.get(context).edit()
        if (trimmed.isEmpty()) editor.remove(KEY_GEMINI) else editor.putString(KEY_GEMINI, trimmed)
        editor.apply()
    }

    fun hasKey(context: Context): Boolean = getKey(context).isNotBlank()
}
