package com.Lia.assistant.ui.screens.quickactions

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.Lia.assistant.action.ActionExecutor
import com.Lia.assistant.ui.components.NovaDialog
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaSegmentedPicker
import com.Lia.assistant.ui.components.NovaTextField
import com.Lia.assistant.ui.components.NovaTopBar
import com.Lia.assistant.ui.theme.LocalBottomBarInset
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Tiles that run real tools directly: no voice session needed. Only tools this build has are shown. */
@Composable
fun QuickActionsScreen(onBack: () -> Unit, modifier: Modifier = Modifier) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val specs = remember { QuickActions.all() }
    var selected by remember { mutableStateOf<QuickActionSpec?>(null) }

    Column(modifier.fillMaxSize()) {
        NovaTopBar(title = "Quick actions", subtitle = "One tap, no talking needed", onBack = onBack)
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(
                start = NovaSpacing.lg, end = NovaSpacing.lg, top = NovaSpacing.sm,
                bottom = LocalBottomBarInset.current + NovaSpacing.xl,
            ),
            horizontalArrangement = Arrangement.spacedBy(NovaSpacing.md),
            verticalArrangement = Arrangement.spacedBy(NovaSpacing.md),
        ) {
            items(specs, key = { it.id }) { spec ->
                NovaGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { selected = spec },
                    onClickLabel = spec.title,
                ) {
                    Icon(spec.icon, contentDescription = null, tint = colors.accentText, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.height(NovaSpacing.sm))
                    Text(spec.title, style = type.title, color = colors.textPrimary)
                    Text(spec.subtitle, style = type.caption, color = colors.textSecondary)
                }
            }
        }
    }

    selected?.let { QuickActionDialog(it, onDismiss = { selected = null }) }
}

@Composable
private fun QuickActionDialog(spec: QuickActionSpec, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val values = remember { mutableStateMapOf<String, String>() }
    var running by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }

    fun execute() {
        if (running) return
        val missing = QuickActions.firstMissing(spec, values)
        if (missing != null) {
            result = "Please fill in: ${missing.label}"
            return
        }
        running = true
        result = null
        val app = context.applicationContext
        val args = QuickActions.argsFor(spec, values)
        scope.launch {
            // Tools talk to the system (contacts, accessibility): never on the main thread.
            val json = withContext(Dispatchers.IO) { ActionExecutor.execute(app, spec.tool, args) }
            result = QuickActionResults.describe(json)
            running = false
        }
    }

    NovaDialog(
        title = spec.title,
        onDismiss = onDismiss,
        confirmText = if (running) "Working…" else "Run",
        onConfirm = ::execute,
        dismissText = "Close",
    ) {
        spec.params.forEach { p ->
            val options = p.options
            if (options != null) {
                Text(p.label, style = type.label, color = colors.textSecondary, modifier = Modifier.padding(bottom = 6.dp))
                val current = values[p.key] ?: options.first()
                NovaSegmentedPicker(
                    options = options.map { o -> o.replaceFirstChar { it.uppercase() } },
                    selectedIndex = options.indexOf(current).coerceAtLeast(0),
                    onSelect = { values[p.key] = options[it] },
                    contentDescription = p.label,
                )
            } else {
                NovaTextField(
                    value = values[p.key].orEmpty(),
                    onValueChange = { values[p.key] = it },
                    label = p.label,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.height(NovaSpacing.md))
        }
        result?.let {
            Box(Modifier.heightIn(max = 200.dp).verticalScroll(rememberScrollState())) {
                Text(it, style = type.body, color = colors.textPrimary)
            }
        }
    }
}
