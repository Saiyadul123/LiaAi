package com.Lia.assistant.ui.screens.history

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.ChatHistoryStore
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.data.StoredConversation
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaDialog
import com.Lia.assistant.ui.components.NovaEmptyState
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaTextField
import com.Lia.assistant.ui.components.NovaTopBar
import com.Lia.assistant.ui.components.NovaVoiceVisualizer
import com.Lia.assistant.ui.screens.common.rememberLifecycleTick
import com.Lia.assistant.ui.theme.CardTilt
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.bottomBarContentPadding
import com.Lia.assistant.voice.NovaOrbState
import kotlinx.coroutines.launch

/** "3 h ago" style labels for the list. */
internal fun relativeTime(nowMillis: Long, thenMillis: Long): String {
    val minutes = ((nowMillis - thenMillis) / 60_000L).coerceAtLeast(0L)
    return when {
        minutes < 1 -> "Just now"
        minutes < 60 -> "$minutes min ago"
        minutes < 24 * 60 -> "${minutes / 60} h ago"
        minutes < 2 * 24 * 60 -> "Yesterday"
        minutes < 30 * 24 * 60 -> "${minutes / (24 * 60)} days ago"
        else -> "A while ago"
    }
}

/** Chats whose title or any message contains [query] (ignoring case); everything for a blank query. */
internal fun filterConversations(list: List<StoredConversation>, query: String): List<StoredConversation> {
    val q = query.trim()
    if (q.isEmpty()) return list
    return list.filter { c ->
        c.title.contains(q, ignoreCase = true) || c.turns.any { it.text.contains(q, ignoreCase = true) }
    }
}

/**
 * Saved typed chats (kept on this device): a floating glass search bar, and thin glass rows that tilt back
 * and compress as they scroll off the top. Tap one to continue it.
 */
@Composable
fun HistoryScreen(
    appState: NovaAppState,
    onOpen: (String) -> Unit,
    onStartChat: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val name = appState.assistantName

    val tick = rememberLifecycleTick()
    var reload by remember { mutableIntStateOf(0) }
    val conversations by produceState<List<StoredConversation>?>(null, tick, reload) { value = ChatHistoryStore.list(context) }
    var confirmClear by remember { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    val now = remember(conversations) { System.currentTimeMillis() }
    val listState = rememberLazyListState()
    val all = conversations
    val shown = remember(all, query) { all?.let { filterConversations(it, query) } }

    Column(modifier.fillMaxSize()) {
        NovaTopBar(
            title = "History",
            subtitle = "Your chats with $name",
            actions = {
                if (!all.isNullOrEmpty()) NovaButton("Clear all", { confirmClear = true }, style = NovaButtonStyle.TEXT)
            },
        )

        if (!all.isNullOrEmpty()) {
            NovaGlassCard(
                modifier = Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm),
                shape = NovaTheme.shapes.pill,
                contentPadding = PaddingValues(horizontal = NovaSpacing.md, vertical = 2.dp),
                elevation = 10.dp,
            ) {
                NovaTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = "Search chats",
                    leadingIcon = Icons.Rounded.Search,
                    singleLine = true,
                    bordered = false,
                    trailing = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Clear search", tint = colors.textSecondary)
                            }
                        }
                    },
                )
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = bottomBarContentPadding(NovaSpacing.xl),
            verticalArrangement = Arrangement.spacedBy(NovaSpacing.sm),
        ) {
            if (!appState.saveHistory) {
                item {
                    NovaGlassCard(Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg)) {
                        Text("Saving is off. New chats won't appear here (change it in Privacy).", style = type.body, color = colors.textSecondary)
                    }
                }
            }
            if (all != null && all.isEmpty()) {
                item {
                    NovaEmptyState(
                        title = "No conversations yet",
                        message = "Your chats with $name will show up here.",
                        modifier = Modifier.fillMaxWidth(),
                        actionText = "Start chatting",
                        onAction = onStartChat,
                        hero = {
                            // a dim, resting orb
                            NovaVoiceVisualizer(
                                state = NovaOrbState.IDLE,
                                modifier = Modifier.size(120.dp).graphicsLayer { alpha = 0.5f },
                                name = name,
                            )
                        },
                    )
                }
            } else if (shown != null && shown.isEmpty()) {
                item {
                    Text(
                        "Nothing matches “${query.trim()}”.",
                        style = type.body, color = colors.textSecondary,
                        modifier = Modifier.padding(horizontal = NovaSpacing.xl, vertical = NovaSpacing.lg),
                    )
                }
            }
            if (shown != null) {
                items(shown, key = { it.id }) { conversation ->
                    NovaGlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = NovaSpacing.lg)
                            .graphicsLayer {
                                // thin rows tilt back and compress as they scroll off the top
                                val info = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == conversation.id }
                                val gone = if (info == null) 0f else CardTilt.offTopFraction(info.offset, info.size)
                                transformOrigin = TransformOrigin(0.5f, 1f)
                                rotationX = CardTilt.offTopRotationX(gone)
                                scaleX = CardTilt.offTopScale(gone)
                                scaleY = CardTilt.offTopScale(gone)
                                alpha = CardTilt.offTopAlpha(gone)
                                cameraDistance = 12f * density
                            },
                        onClick = { onOpen(conversation.id) },
                        onClickLabel = "Open conversation",
                        contentPadding = PaddingValues(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm),
                        elevation = 4.dp,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(conversation.title, style = type.title, color = colors.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    "${conversation.turns.size} messages · ${relativeTime(now, conversation.updatedAtMillis)}",
                                    style = type.caption, color = colors.textSecondary,
                                )
                            }
                            IconButton(onClick = {
                                scope.launch {
                                    ChatHistoryStore.delete(context, conversation.id)
                                    reload++
                                }
                            }) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete conversation: ${conversation.title}", tint = colors.textSecondary)
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmClear) {
        NovaDialog(
            title = "Clear all history?",
            onDismiss = { confirmClear = false },
            confirmText = "Clear all",
            onConfirm = {
                confirmClear = false
                scope.launch {
                    ChatHistoryStore.clear(context)
                    reload++
                }
            },
        ) {
            Text("This deletes every saved chat from this phone. It can't be undone.", style = type.body, color = colors.textSecondary)
        }
    }
}
