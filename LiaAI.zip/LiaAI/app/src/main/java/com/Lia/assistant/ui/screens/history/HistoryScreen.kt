package com.Lia.assistant.ui.screens.history

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import com.Lia.assistant.data.ChatHistoryStore
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.data.StoredConversation
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaDialog
import com.Lia.assistant.ui.components.NovaEmptyState
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.screens.common.NovaListScreen
import com.Lia.assistant.ui.screens.common.rememberLifecycleTick
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import kotlinx.coroutines.launch

/** "3 h ago" style labels for the list. */
internal fun relativeTime(nowMillis: Long, thenMillis: Long): String {
    val minutes = ((nowMillis - thenMillis) / 60_000L).coerceAtLeast(0L)
    return when {
        minutes < 1 -> "Just now"
        minutes < 60 -> "$minutes min ago"
        minutes < 24 * 60 -> "${minutes / 60} h ago"
        minutes < 2 * 24 * 60 -> "Yesterday"
        minutes < 30 * 24 * 60 -> "${minutes / (24 * 60)} days ago"
        else -> "A while ago"
    }
}

/** Saved typed chats (kept on this device). Tap one to continue it. */
@Composable
fun HistoryScreen(
    appState: NovaAppState,
    onOpen: (String) -> Unit,
    onStartChat: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val name = appState.assistantName

    val tick = rememberLifecycleTick()
    var reload by remember { mutableIntStateOf(0) }
    val conversations by produceState<List<StoredConversation>?>(null, tick, reload) { value = ChatHistoryStore.list(context) }
    var confirmClear by remember { mutableStateOf(false) }
    val now = remember(conversations) { System.currentTimeMillis() }

    NovaListScreen(
        title = "History",
        subtitle = "Your chats with $name",
        modifier = modifier,
        actions = {
            if (!conversations.isNullOrEmpty()) NovaButton("Clear all", { confirmClear = true }, style = NovaButtonStyle.TEXT)
        },
    ) {
        if (!appState.saveHistory) {
            item {
                NovaGlassCard(Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg)) {
                    Text("Saving is off. New chats won't appear here (change it in Privacy).", style = type.body, color = colors.textSecondary)
                }
            }
        }
        val list = conversations
        if (list != null && list.isEmpty()) {
            item {
                NovaEmptyState(
                    title = "No chats yet",
                    message = "Your conversations with $name will show up here.",
                    modifier = Modifier.fillMaxWidth(),
                    actionText = "Start chatting",
                    onAction = onStartChat,
                )
            }
        }
        if (list != null) {
            items(list, key = { it.id }) { conversation ->
                NovaGlassCard(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg),
                    onClick = { onOpen(conversation.id) },
                    onClickLabel = "Open conversation",
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(conversation.title, style = type.title, color = colors.textPrimary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${conversation.turns.size} messages · ${relativeTime(now, conversation.updatedAtMillis)}",
                                style = type.caption, color = colors.textSecondary,
                            )
                        }
                        IconButton(onClick = {
                            scope.launch {
                                ChatHistoryStore.delete(context, conversation.id)
                                reload++
                            }
                        }) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete conversation: ${conversation.title}", tint = colors.textSecondary)
                        }
                    }
                }
            }
        }
    }

    if (confirmClear) {
        NovaDialog(
            title = "Clear all history?",
            onDismiss = { confirmClear = false },
            confirmText = "Clear all",
            onConfirm = {
                confirmClear = false
                scope.launch {
                    ChatHistoryStore.clear(context)
                    reload++
                }
            },
        ) {
            Text("This deletes every saved chat from this phone. It can't be undone.", style = type.body, color = colors.textSecondary)
        }
    }
}
