package com.Lia.assistant.ui.screens.forge

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.Lia.assistant.forge.ForgeProgress
import com.Lia.assistant.ui.theme.LocalTilt
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.parallaxShiftDp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val TWO_PI = (2.0 * PI).toFloat()

/**
 * The "Forge Reactor": a glowing core inside three counter-rotating rings, sparks in orbit, and one
 * marker per build stage that lights up as the build advances. The scene is the star of the Forge
 * screen: no text, logs or terminal. Idle it simmers; running it burns brighter with progress. It
 * drifts a little with device tilt, and is still with reduced motion.
 */
@Composable
fun ForgeReactorScene(progress: ForgeProgress, modifier: Modifier = Modifier) {
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val tilt = LocalTilt.current
    val spin = rememberInfiniteTransition(label = "reactor").animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "reactorSpin",
    )
    val energy = if (progress.isRunning) 0.55f + 0.45f * (progress.percent.coerceIn(0, 100) / 100f) else 0.3f
    val lit = progress.litSegments

    Canvas(modifier) {
        val t = if (reduced) Offset.Zero else tilt()
        val shift = parallaxShiftDp(3).dp.toPx()
        val phase = if (reduced) 0.1f else spin.value
        val center = Offset(size.width / 2f + t.x * shift, size.height * 0.40f + t.y * shift)
        val r = size.minDimension * 0.30f

        // heat haze behind everything
        drawCircle(
            brush = Brush.radialGradient(listOf(colors.accent.copy(alpha = 0.32f * energy), Color.Transparent), center, r * 2.6f),
            radius = r * 2.6f, center = center,
        )

        // three counter-rotating rings
        val ringColors = listOf(colors.accent, colors.textSecondary, colors.accentSecondary)
        for (i in 0..2) {
            val ringR = r * (0.62f + 0.24f * i)
            val direction = if (i % 2 == 0) 1f else -1f
            val start = phase * 360f * direction * (1f + i * 0.6f)
            val topLeft = Offset(center.x - ringR, center.y - ringR)
            val box = Size(ringR * 2f, ringR * 2f)
            drawArc(
                color = ringColors[i].copy(alpha = 0.9f), startAngle = start, sweepAngle = 190f - i * 30f, useCenter = false,
                topLeft = topLeft, size = box, style = Stroke(r * 0.055f, cap = StrokeCap.Round),
            )
            drawArc(
                color = ringColors[i].copy(alpha = 0.35f), startAngle = start + 200f, sweepAngle = 70f, useCenter = false,
                topLeft = topLeft, size = box, style = Stroke(r * 0.035f, cap = StrokeCap.Round),
            )
        }

        // one marker per build stage, lit as the build advances
        for (i in 0 until 6) {
            val a = TWO_PI * (i / 6f) - TWO_PI / 4f
            val on = i < lit
            drawCircle(
                color = if (on) colors.accent else colors.textTertiary.copy(alpha = 0.4f),
                radius = r * (if (on) 0.06f else 0.04f),
                center = Offset(center.x + cos(a) * r * 1.38f, center.y + sin(a) * r * 1.38f),
            )
        }

        // sparks in orbit
        for (k in 0 until 12) {
            val a = TWO_PI * (phase * (2f + k * 0.15f) + k / 12f)
            val orbit = r * (0.75f + 0.55f * ((k * 7) % 12) / 12f)
            drawCircle(
                color = colors.accentSecondary.copy(alpha = 0.35f + 0.5f * energy),
                radius = r * 0.022f * (1f + (k % 3) * 0.4f),
                center = Offset(center.x + cos(a) * orbit, center.y + sin(a) * orbit),
            )
        }

        // the core
        val pulse = if (reduced) 0.5f else 0.5f + 0.5f * sin(phase * TWO_PI * 8f)
        val coreR = r * 0.42f * (1f + 0.08f * pulse * energy)
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.95f), colors.accent, colors.accentSecondary.copy(alpha = 0f)),
                center, coreR * 1.4f,
            ),
            radius = coreR * 1.4f, center = center,
        )
    }
}
