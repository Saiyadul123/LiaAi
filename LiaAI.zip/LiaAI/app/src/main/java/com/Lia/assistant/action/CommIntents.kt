package com.Lia.assistant.action

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.telephony.PhoneNumberUtils
import android.telephony.TelephonyManager
import java.net.URLEncoder
import java.util.Locale

/**
 * Builders for call/SMS/WhatsApp intents. Nothing here sends a message: composers are only
 * opened (never SmsManager, never SEND_SMS). Intents are built statement by statement so JVM
 * unit tests with stubbed Android classes keep working.
 */
object CommIntents {
    enum class MessageApp { SMS, WHATSAPP }

    val WHATSAPP_PACKAGES = listOf("com.whatsapp", "com.whatsapp.w4b")

    fun parseMessageApp(raw: String?): MessageApp {
        val v = raw.orEmpty().trim().lowercase()
        return if (v.contains("whatsapp") || v == "wa") MessageApp.WHATSAPP else MessageApp.SMS
    }

    fun callAction(direct: Boolean): String = if (direct) Intent.ACTION_CALL else Intent.ACTION_DIAL

    fun digitsOnly(number: String): String = number.filter { it.isDigit() }

    /** https://wa.me/<digits>?text=<percent-encoded>. */
    fun whatsAppUrl(number: String, text: String): String {
        val encoded = URLEncoder.encode(text, "UTF-8").replace("+", "%20")
        return "https://wa.me/${digitsOnly(number)}?text=$encoded"
    }

    fun callIntent(number: String, direct: Boolean): Intent {
        val intent = Intent(callAction(direct), Uri.fromParts("tel", number, null))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return intent
    }

    fun smsIntent(number: String, body: String): Intent {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)))
        intent.putExtra("sms_body", body)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return intent
    }

    fun whatsAppIntent(context: Context, number: String, text: String, packageName: String): Intent {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(whatsAppUrl(whatsAppNumber(context, number), text)))
        intent.setPackage(packageName)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return intent
    }

    /** wa.me needs an international number: add the country code when the number has none. */
    internal fun whatsAppNumber(context: Context, number: String): String {
        if (number.trim().startsWith("+")) return number
        return try {
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            val iso = (tm?.networkCountryIso?.takeIf { it.isNotBlank() }
                ?: tm?.simCountryIso?.takeIf { it.isNotBlank() }
                ?: Locale.getDefault().country).uppercase()
            PhoneNumberUtils.formatNumberToE164(number, iso) ?: number
        } catch (_: RuntimeException) {
            number
        }
    }

    fun isInstalled(context: Context, packageName: String): Boolean = try {
        val pm = context.packageManager
        if (Build.VERSION.SDK_INT >= 33) {
            pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION") pm.getPackageInfo(packageName, 0)
        }
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    } catch (_: RuntimeException) {
        false
    }

    /** Starts [intent]; false if no activity handles it or the OS refuses. */
    fun start(context: Context, intent: Intent): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (_: ActivityNotFoundException) {
            false
        } catch (_: SecurityException) {
            false
        }
    }
}
