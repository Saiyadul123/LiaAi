package com.Lia.assistant.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme

/** Small caps-style heading for a group of rows, with an optional text action on the right. */
@Composable
fun NovaSectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    actionText: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(start = NovaSpacing.lg, end = NovaSpacing.sm, top = NovaSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = title.uppercase(),
            style = NovaTheme.typography.label.copy(letterSpacing = 0.8.sp),
            color = NovaTheme.colors.textSecondary,
            modifier = Modifier.weight(1f).semantics { heading() },
        )
        if (actionText != null && onAction != null) {
            NovaButton(actionText, onAction, style = NovaButtonStyle.TEXT)
        }
    }
}
