package com.Lia.assistant.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import com.Lia.assistant.ui.fx.NovaGlowColors
import com.Lia.assistant.ui.theme.NovaColorScheme
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.voice.NovaOrbState
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Personality looks for the Canvas orb. */
enum class NovaOrbStyle {
    NOVA, AURORA, PLASMA, GLASS, ENERGY, MINIMAL, ARCHER;

    companion object {
        /** Parses a stored id ("nova", "ARCHER", ...); anything unknown is [NOVA]. */
        fun fromId(id: String?): NovaOrbStyle =
            entries.firstOrNull { it.name.equals(id?.trim(), ignoreCase = true) } ?: NOVA
    }
}

internal const val ORB_BREATH_MS = 4200
internal const val ORB_BREATH_AMOUNT = 0.035f
internal const val ARCHER_PARTICLES = 400
private val TWO_PI = (2.0 * PI).toFloat()

/** Rotation period: 9 s normally, 2.6 s while thinking, 1.1 s while connecting. */
internal fun orbRotationMillis(state: NovaOrbState): Int = when (state) {
    NovaOrbState.THINKING -> 2600
    NovaOrbState.CONNECTING -> 1100
    else -> 9000
}

/** Breathing: a sine of +-3.5 % around 1 (phase 0..1 is one 4.2 s cycle). */
internal fun breathScale(phase: Float): Float = 1f + ORB_BREATH_AMOUNT * sin(phase * TWO_PI)

/** Orbiting particles: ENERGY 8, PLASMA 6, GLASS 3, otherwise 5; none for MINIMAL or ERROR. */
internal fun orbParticleCount(style: NovaOrbStyle, state: NovaOrbState): Int = when {
    state == NovaOrbState.ERROR || style == NovaOrbStyle.MINIMAL -> 0
    style == NovaOrbStyle.ENERGY -> 8
    style == NovaOrbStyle.PLASMA -> 6
    style == NovaOrbStyle.GLASS -> 3
    else -> 5
}

internal fun orbStatusDescription(name: String, state: NovaOrbState): String =
    "$name status: ${state.name.lowercase()}"

@Immutable
internal data class OrbStyleColors(val inner: Color, val outer: Color, val glow: Color, val particle: Color)

internal fun orbStyleColors(style: NovaOrbStyle, state: NovaOrbState, c: NovaColorScheme): OrbStyleColors {
    if (state == NovaOrbState.ERROR) return OrbStyleColors(c.error, c.error.copy(alpha = 0.7f), c.error, c.error)
    return when (style) {
        NovaOrbStyle.NOVA -> OrbStyleColors(c.lotus, c.lagoon, c.lotus, c.lagoon)
        NovaOrbStyle.AURORA -> OrbStyleColors(c.lagoon, NovaGlowColors.Violet, c.lagoon, c.lotus)
        NovaOrbStyle.PLASMA -> OrbStyleColors(c.lotus, c.accentSecondary, c.lotus, c.accent)
        NovaOrbStyle.GLASS -> OrbStyleColors(Color.White.copy(alpha = 0.35f), c.lagoon.copy(alpha = 0.55f), c.lagoon, Color.White)
        NovaOrbStyle.ENERGY -> OrbStyleColors(c.accent, c.accentSecondary, c.accent, c.accent)
        NovaOrbStyle.MINIMAL -> OrbStyleColors(c.lotus, c.lotus, c.lotus, c.lotus)
        NovaOrbStyle.ARCHER -> OrbStyleColors(c.accent, c.lagoon, c.accentSecondary, c.accent)
    }
}

/** A point on a unit sphere plus a fixed pseudo-random [jitter] in -1..1. */
internal data class SpherePoint(val x: Float, val y: Float, val z: Float, val jitter: Float)

/** Points spread evenly over a sphere along a golden spiral (Fibonacci sphere). */
internal fun goldenSpherePoints(count: Int): List<SpherePoint> {
    if (count <= 0) return emptyList()
    val goldenAngle = (PI * (3.0 - sqrt(5.0))).toFloat()
    return List(count) { i ->
        val y = 1f - 2f * (i + 0.5f) / count
        val ring = sqrt((1f - y * y).coerceAtLeast(0f))
        val theta = goldenAngle * i
        val h = ((i * 2654435761L) and 0xFFFFL).toFloat() / 65535f
        SpherePoint(cos(theta) * ring, y, sin(theta) * ring, h * 2f - 1f)
    }
}

/**
 * The Canvas orb: used below Android 13 and as the fallback for [com.Lia.assistant.ui.fx.LiaOrb3D].
 * Layers: outer glow, ripples (listening), sweeping arc (connecting), orbiting particles, core,
 * glass highlight, error pulse, and for ARCHER ~400 particles on a rotating sphere. Frozen with
 * reduced motion.
 */
@Composable
fun NovaOrb(
    state: NovaOrbState,
    modifier: Modifier = Modifier,
    style: NovaOrbStyle = NovaOrbStyle.NOVA,
    amplitude: Float = 0f,
    name: String = "Assistant",
) {
    val scheme = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val palette = orbStyleColors(style, state, scheme)
    val particles = orbParticleCount(style, state)
    val archerPoints = remember { goldenSpherePoints(ARCHER_PARTICLES) }

    val transition = rememberInfiniteTransition(label = "novaOrb")
    val breath = transition.animateFloat(
        0f, 1f, infiniteRepeatable(tween(ORB_BREATH_MS, easing = LinearEasing)), label = "breath"
    )
    val rotation = transition.animateFloat(
        0f, 360f, infiniteRepeatable(tween(orbRotationMillis(state), easing = LinearEasing)), label = "rotation"
    )
    val rings = transition.animateFloat(
        0f, 1f, infiniteRepeatable(tween(2000, easing = LinearEasing)), label = "rings"
    )
    val description = orbStatusDescription(name, state)

    Canvas(modifier.semantics { contentDescription = description }) {
        val r = size.minDimension / 2f
        val center = Offset(size.width / 2f, size.height / 2f)
        val rot = if (reduced) 0f else rotation.value
        val breathPhase = if (reduced) 0f else breath.value
        val scale = if (reduced) 1f else breathScale(breathPhase)
        val amp = amplitude.coerceIn(0f, 1f)
        val coreR = r * 0.52f * scale * (1f + amp * 0.25f)
        val intensity = when (state) {
            NovaOrbState.SPEAKING -> 0.55f + 0.35f * amp
            NovaOrbState.LISTENING -> 0.45f
            NovaOrbState.THINKING, NovaOrbState.CONNECTING -> 0.40f
            NovaOrbState.IDLE -> 0.35f
            NovaOrbState.ERROR -> 0.30f
        }

        // 1. radial outer glow
        drawCircle(
            brush = Brush.radialGradient(listOf(palette.glow.copy(alpha = intensity), Color.Transparent), center, r),
            radius = r,
            center = center,
        )

        // 2. two expanding, fading rings while listening
        if (state == NovaOrbState.LISTENING) {
            for (i in 0..1) {
                val p = if (reduced) 0.3f + 0.4f * i else (rings.value + i * 0.5f) % 1f
                drawCircle(
                    color = palette.glow.copy(alpha = (1f - p) * 0.45f),
                    radius = coreR + (r - coreR) * p,
                    center = center,
                    style = Stroke(r * 0.02f),
                )
            }
        }

        // 3. rotating 100-degree arc while connecting
        if (state == NovaOrbState.CONNECTING) {
            drawArc(
                color = scheme.accent,
                startAngle = rot,
                sweepAngle = 100f,
                useCenter = false,
                topLeft = Offset(center.x - r * 0.85f, center.y - r * 0.85f),
                size = Size(r * 1.7f, r * 1.7f),
                style = Stroke(r * 0.05f, cap = StrokeCap.Round),
            )
        }

        // 4. orbiting particles
        for (i in 0 until particles) {
            val a = Math.toRadians((rot + i * 360f / particles).toDouble())
            val orbit = r * 0.86f
            drawCircle(
                color = palette.particle.copy(alpha = 0.85f),
                radius = r * 0.045f,
                center = Offset(center.x + (cos(a) * orbit).toFloat(), center.y + (sin(a) * orbit).toFloat()),
            )
        }

        // 5. core (ARCHER is made of particles instead)
        if (style != NovaOrbStyle.ARCHER) {
            val brush = if (style == NovaOrbStyle.MINIMAL) {
                Brush.radialGradient(listOf(palette.inner, palette.inner), center, coreR)
            } else {
                Brush.radialGradient(
                    colors = listOf(palette.inner, palette.outer.copy(alpha = 0.85f)),
                    center = Offset(center.x - coreR * 0.25f, center.y - coreR * 0.30f),
                    radius = coreR * 1.4f,
                )
            }
            drawCircle(brush = brush, radius = coreR, center = center)
        }

        // 6. glass: a white highlight arc
        if (style == NovaOrbStyle.GLASS) {
            drawArc(
                color = Color.White.copy(alpha = 0.7f),
                startAngle = 200f,
                sweepAngle = 70f,
                useCenter = false,
                topLeft = Offset(center.x - coreR * 0.8f, center.y - coreR * 0.8f),
                size = Size(coreR * 1.6f, coreR * 1.6f),
                style = Stroke(r * 0.03f, cap = StrokeCap.Round),
            )
        }

        // 7. error: a slow pulse ring
        if (state == NovaOrbState.ERROR) {
            val pulse = 0.5f + 0.5f * sin(breathPhase * TWO_PI)
            drawCircle(
                color = scheme.error.copy(alpha = 0.5f),
                radius = coreR * (1.15f + 0.2f * pulse),
                center = center,
                style = Stroke(r * 0.025f),
            )
        }

        // 8. ARCHER: ~400 particles on a golden-spiral sphere with depth-scaled alpha and size
        if (style == NovaOrbStyle.ARCHER) {
            val spin = Math.toRadians(rot.toDouble()).toFloat()
            val tilt = 0.35f
            val sphereR = r * 0.62f * scale
            val cosS = cos(spin)
            val sinS = sin(spin)
            val cosT = cos(tilt)
            val sinT = sin(tilt)
            archerPoints.forEach { pt ->
                val x1 = pt.x * cosS + pt.z * sinS
                val z1 = -pt.x * sinS + pt.z * cosS
                val y2 = pt.y * cosT - z1 * sinT
                val z2 = pt.y * sinT + z1 * cosT
                val depth = (z2 + 1f) / 2f
                val jitter = 1f + amp * 0.18f * pt.jitter
                drawCircle(
                    color = lerp(palette.outer, palette.inner, depth).copy(alpha = 0.15f + 0.85f * depth),
                    radius = r * 0.012f * (0.6f + 0.9f * depth) * (1f + amp * 0.5f),
                    center = Offset(center.x + x1 * sphereR * jitter, center.y - y2 * sphereR * jitter),
                )
            }
        }
    }
}
