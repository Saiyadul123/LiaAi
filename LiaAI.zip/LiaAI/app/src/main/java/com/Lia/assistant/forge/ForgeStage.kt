package com.Lia.assistant.forge

/**
 * The six stages shown while a site is written. NOTE: the stage table this was meant to follow was not
 * available when this was written, so the evidence rules in [ForgeStageDetector] are an assumption
 * kept in one place so they are easy to swap.
 */
enum class ForgeStage(val label: String) {
    PLANNING("Planning"),
    STRUCTURE("Structure"),
    STYLING("Styling"),
    VISUALS("Visuals"),
    MOTION("Motion"),
    FINISHING("Finishing");

    /** How many of the six track segments are lit. */
    val segments: Int get() = ordinal + 1
}

/**
 * Works out the stage from the page as written so far. Only the body counts: the head of a page already
 * lists the Tailwind, GSAP and Three.js scripts, which says nothing about how far the page has got.
 * Evidence only ever grows as text arrives, so the stage never goes backwards.
 */
object ForgeStageDetector {
    private val LANDMARK = Regex("<(?:section|header|nav|main|footer)\\b")
    private val CLASS_ATTR = Regex("\\bclass\\s*=")
    private val VISUAL_MARKERS = listOf("<canvas", "<svg", "<img", "picsum.photos", "pravatar.cc", "webgl", "three.module", "new three.")
    private val MOTION_MARKERS = listOf("gsap.", "scrolltrigger", "requestanimationframe", "@keyframes", "intersectionobserver")
    private const val STYLED_CLASS_COUNT = 25

    fun detect(partialHtml: String): ForgeStage {
        val body = bodyOf(partialHtml) ?: return ForgeStage.PLANNING
        val lower = body.lowercase()
        if (lower.contains("</body")) return ForgeStage.FINISHING
        if (MOTION_MARKERS.any { lower.contains(it) }) return ForgeStage.MOTION
        if (VISUAL_MARKERS.any { lower.contains(it) }) return ForgeStage.VISUALS
        val styled = lower.contains("<style") || CLASS_ATTR.findAll(lower).count() >= STYLED_CLASS_COUNT
        if (styled && LANDMARK.containsMatchIn(lower)) return ForgeStage.STYLING
        if (LANDMARK.containsMatchIn(lower)) return ForgeStage.STRUCTURE
        return ForgeStage.PLANNING
    }

    /** Everything after the complete opening <body> tag, or null while there is none. */
    internal fun bodyOf(html: String): String? {
        val start = html.indexOf("<body", ignoreCase = true)
        if (start < 0) return null
        val end = html.indexOf('>', start)
        return if (end < 0) null else html.substring(end + 1)
    }
}

/** The named parts of a page as it is written, for "Laying out Pricing" log lines. */
object ForgeSections {
    private const val MAX = 12
    private const val WINDOW = 700

    private val LANDMARK = Regex("<(header|nav|section|footer)\\b([^>]*)>", RegexOption.IGNORE_CASE)
    private val ID = Regex("""\bid\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    private val ARIA = Regex("""\baria-label\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    private val HEADING = Regex("<h[1-3]\\b[^>]*>(.*?)</h[1-3]>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val TAG = Regex("<[^>]*>")

    /**
     * Section names in page order. A section is listed once its name is known (an id, an aria-label or a
     * finished heading), so a name does not change while its heading is still arriving. Header, nav and
     * footer are listed at once under their plain names unless they carry an id or aria-label.
     */
    fun detect(partialHtml: String): List<String> {
        val body = ForgeStageDetector.bodyOf(partialHtml) ?: return emptyList()
        val marks = LANDMARK.findAll(body).toList()
        val names = mutableListOf<String>()
        var sectionNo = 0
        for ((i, m) in marks.withIndex()) {
            val tag = m.groupValues[1].lowercase()
            val isSection = tag == "section"
            if (isSection) sectionNo++
            val attrs = m.groupValues[2]
            val windowStart = m.range.last + 1
            val nextStart = marks.getOrNull(i + 1)?.range?.first ?: body.length
            val windowEnd = minOf(nextStart, windowStart + WINDOW, body.length)
            val window = body.substring(windowStart, windowEnd)
            val fromId = ID.find(attrs)?.groupValues?.get(1)?.let(::humanize)
            val fromAria = ARIA.find(attrs)?.groupValues?.get(1)?.trim()?.take(32)
            // only sections are named from their heading; header, nav and footer keep their plain names
            val fromHeading = if (isSection) {
                HEADING.find(window)?.groupValues?.get(1)?.let(::cleanText)?.takeIf { it.isNotEmpty() }?.take(32)
            } else null
            val fallback = when (tag) {
                "header" -> "Header"
                "nav" -> "Navigation"
                "footer" -> "Footer"
                else -> "Section $sectionNo"
            }
            val named = fromId ?: fromAria ?: fromHeading
            val windowFull = windowEnd < body.length
            if (named == null && isSection && !windowFull) break // still arriving: do not list it under a temporary name
            names += named ?: fallback
            if (names.size == MAX) break
        }
        return dedupe(names)
    }

    private fun humanize(id: String): String =
        id.trim().split('-', '_', ' ').filter { it.isNotEmpty() }.joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }.take(32)

    private fun cleanText(html: String): String = TAG.replace(html, " ").replace(Regex("\\s+"), " ").trim()

    private fun dedupe(names: List<String>): List<String> {
        val seen = HashMap<String, Int>()
        return names.map { n ->
            val count = (seen[n] ?: 0) + 1
            seen[n] = count
            if (count == 1) n else "$n $count"
        }
    }
}
