package com.Lia.assistant.voice

import android.content.Context
import android.os.Process
import com.Lia.assistant.action.ActionExecutor
import com.Lia.assistant.action.InstalledAppLabelCache
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.Personality
import com.Lia.assistant.data.PersonalityRepository
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject

/**
 * The live voice session, independent of any screen (a foreground service keeps the process alive).
 *
 * Threading: Gemini callbacks arrive on OkHttp threads, mic callbacks on the mic thread. Server
 * audio is queued to a dedicated playback thread, so a blocking AudioTrack write can never delay
 * reading an "interrupted" message. Every callback is tagged with a session epoch and dropped if
 * the epoch changed (reconnect or stop). The audio path never logs.
 */
object VoiceSessionManager {

    private const val RECONNECT_DELAY_MS = 1_200L
    private const val MAX_RECONNECTS = 5
    private const val PLAYBACK_SILENCE_MS = 300L
    private const val STABLE_CONNECTION_MS = 10_000L
    private const val FORGE_TOOL = "build_website"
    const val RECONNECT_FAILED_MESSAGE = "Connection lost - tap Stop and reopen Voice Mode"

    // ---- Public state -----------------------------------------------------------------------

    private val _state = MutableStateFlow(NovaOrbState.IDLE)
    val state: StateFlow<NovaOrbState> = _state.asStateFlow()

    private val _amplitude = MutableStateFlow(0f)
    val amplitude: StateFlow<Float> = _amplitude.asStateFlow()

    private val _muted = MutableStateFlow(false)
    val muted: StateFlow<Boolean> = _muted.asStateFlow()

    private val _statusText = MutableStateFlow("Idle")
    val statusText: StateFlow<String> = _statusText.asStateFlow()

    private val _isActive = MutableStateFlow(false)
    val isActive: StateFlow<Boolean> = _isActive.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private val _currentPersonality = MutableStateFlow(Personality.DEFAULT)
    val currentPersonality: StateFlow<Personality> = _currentPersonality.asStateFlow()

    private val _currentLanguage = MutableStateFlow(LanguagePreference.DEFAULT)
    val currentLanguage: StateFlow<LanguagePreference> = _currentLanguage.asStateFlow()

    private val _detectedLanguage = MutableStateFlow(DetectedLanguage.UNKNOWN)
    val detectedLanguage: StateFlow<DetectedLanguage> = _detectedLanguage.asStateFlow()

    private val _vadActive = MutableStateFlow(false)
    val vadActive: StateFlow<Boolean> = _vadActive.asStateFlow()

    val latency = VoiceLatencyTracker()
    internal val memory = ConversationMemory()

    // ---- Internals --------------------------------------------------------------------------

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val playbackDispatcher = Executors.newSingleThreadExecutor { r ->
        Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            r.run()
        }, "lia-playback").apply { isDaemon = true }
    }.asCoroutineDispatcher()

    private val sessionMutex = Mutex()
    private val lifecycleLock = Any()
    private val reconnectLock = Any()
    private val micLock = Any()
    private val transcriptLock = Any()

    private val epoch = AtomicInteger(0)
    private val playbackGen = AtomicInteger(0)
    private val playbackActive = AtomicBoolean(false)
    private val silenceJob = AtomicReference<Job?>(null)

    @Volatile private var appContext: Context? = null
    @Volatile private var client: GeminiLiveClient? = null
    @Volatile private var audio: LiveAudioIO? = null
    @Volatile private var playbackChannel: Channel<PlaybackItem>? = null
    private var playbackJob: Job? = null
    private var connectJob: Job? = null
    private var reconnectJob: Job? = null
    private var reconnectScheduled = false
    private var reconnectAttempts = 0
    private var micStarted = false
    @Volatile private var lastSetupAt = 0L

    private val vad = AmplitudeVad()
    private val userBuf = StringBuilder()
    private val modelBuf = StringBuilder()

    private sealed interface PlaybackItem {
        val gen: Int
        class Audio(override val gen: Int, val bytes: ByteArray) : PlaybackItem
        class TurnEnd(override val gen: Int) : PlaybackItem
    }

    private fun nowMs() = System.nanoTime() / 1_000_000L

    // ---- Lifecycle --------------------------------------------------------------------------

    @Volatile private var outputVolume = 1f

    /** Playback volume (0..1) of the voice session; applies live. */
    fun setOutputVolume(value: Float) {
        outputVolume = value.coerceIn(0f, 1f)
        audio?.setVolume(outputVolume)
    }

    fun start(context: Context) {
        val app = context.applicationContext
        synchronized(lifecycleLock) {
            if (_isActive.value) return
            appContext = app
            _isActive.value = true

            // reset state
            _lastError.value = null
            _muted.value = false
            _amplitude.value = 0f
            _vadActive.value = false
            _detectedLanguage.value = DetectedLanguage.UNKNOWN
            setState(NovaOrbState.CONNECTING, "Connecting…", force = true)
            memory.clear()
            synchronized(transcriptLock) { userBuf.setLength(0); modelBuf.setLength(0) }
            reconnectAttempts = 0
            lastSetupAt = 0L
            latency.reset()
            vad.reset()
            EchoGuard.reset()
            playbackActive.set(false)
            synchronized(micLock) { micStarted = false }
            synchronized(reconnectLock) { reconnectScheduled = false }

            audio = LiveAudioIO({ onMicChunk(it) }, { onMicAmplitude(it) })
            audio?.setVolume(outputVolume)

            val channel = Channel<PlaybackItem>(Channel.UNLIMITED)
            playbackChannel = channel
            playbackJob = scope.launch(playbackDispatcher) { runPlayback(channel) }

            connectJob = scope.launch {
                sessionMutex.withLock { connectSession(isResuming = false) }
            }
        }
        InstalledAppLabelCache.prewarm(app)
    }

    fun stop() {
        _isActive.value = false
        epoch.incrementAndGet()
        playbackGen.incrementAndGet()
        synchronized(reconnectLock) {
            reconnectScheduled = false
            reconnectJob?.cancel()
            reconnectJob = null
        }
        connectJob?.cancel()
        connectJob = null
        silenceJob.getAndSet(null)?.cancel()
        playbackChannel?.close()
        playbackChannel = null
        playbackJob?.cancel()
        playbackJob = null
        client?.disconnect()
        client = null
        audio?.release()
        audio = null
        synchronized(micLock) { micStarted = false }
        playbackActive.set(false)
        EchoGuard.reset()
        memory.clear()
        synchronized(transcriptLock) { userBuf.setLength(0); modelBuf.setLength(0) }
        vad.reset()
        _amplitude.value = 0f
        _vadActive.value = false
        _muted.value = false
        setState(NovaOrbState.IDLE, "Idle", force = true)
    }

    fun toggleMute() {
        val m = !_muted.value
        _muted.value = m
        if (m) {
            vad.reset()
            _vadActive.value = false
            _amplitude.value = 0f
        }
        if (_state.value == NovaOrbState.LISTENING) setListening()
    }

    /** Live cannot change the system instruction mid-session, so reconnect with a recap. */
    fun refreshInstructions(context: Context) {
        if (!_isActive.value) return
        synchronized(reconnectLock) {
            reconnectScheduled = false
            reconnectJob?.cancel()
            reconnectJob = null
        }
        scope.launch {
            sessionMutex.withLock { if (_isActive.value) connectSession(isResuming = true) }
        }
    }

    /** Called by the foreground service when RECORD_AUDIO is missing. */
    internal fun reportPermissionDenied() {
        abortWithError("Microphone permission is required for voice mode.")
    }

    // ---- Connecting -------------------------------------------------------------------------

    private suspend fun connectSession(isResuming: Boolean) {
        val app = appContext ?: return
        if (!_isActive.value) return

        val myEpoch = epoch.incrementAndGet()
        playbackGen.incrementAndGet()
        val previous = client
        client = null
        previous?.disconnect()
        audio?.flushPlayback()
        endPlaybackTurn()
        flushTranscripts() // so the recap includes the latest words

        if (_state.value != NovaOrbState.CONNECTING) {
            setState(NovaOrbState.CONNECTING, if (isResuming) "Reconnecting…" else "Connecting…", force = true)
        }
        latency.markConnectStart()

        val personality = PersonalityRepository.getPersonality(app)
        val language = PersonalityRepository.getLanguage(app)
        val assistantName = PersonalityRepository.getAssistantName(app)
        val voice = VoiceNames.toGemini(PersonalityRepository.getVoiceName(app))
        _currentPersonality.value = personality
        _currentLanguage.value = language

        val key = ApiKeyStore.getKey(app)
        if (key.isBlank()) {
            abortWithError("Add your Gemini API key in Settings.")
            return
        }

        val prompt = PersonalityPromptBuilder.build(
            personality = personality,
            language = language,
            detectedLanguage = _detectedLanguage.value,
            recap = if (isResuming) memory.recap() else null,
            assistantName = assistantName,
        )

        if (epoch.get() != myEpoch || !_isActive.value) return
        val listener = SessionListener(myEpoch, app)
        val newClient = GeminiLiveClient(key, listener)
        listener.owner = newClient
        client = newClient
        newClient.connect(prompt, voice)
        if (epoch.get() != myEpoch || !_isActive.value) newClient.disconnect() // stop() raced us
    }

    private fun scheduleReconnect() {
        if (!_isActive.value) return
        synchronized(reconnectLock) {
            if (reconnectScheduled) return // single-flight
            if (lastSetupAt > 0 && nowMs() - lastSetupAt >= STABLE_CONNECTION_MS) reconnectAttempts = 0
            if (reconnectAttempts >= MAX_RECONNECTS) {
                failReconnecting()
                return
            }
            reconnectAttempts++
            latency.noteReconnect()
            reconnectScheduled = true
            setState(NovaOrbState.CONNECTING, "Reconnecting… ($reconnectAttempts/$MAX_RECONNECTS)", force = true)
            reconnectJob = scope.launch {
                delay(RECONNECT_DELAY_MS)
                synchronized(reconnectLock) { reconnectScheduled = false }
                sessionMutex.withLock { if (_isActive.value) connectSession(isResuming = true) }
            }
        }
    }

    private fun failReconnecting() {
        epoch.incrementAndGet() // ignore anything the dead client still emits
        playbackGen.incrementAndGet()
        client?.disconnect()
        client = null
        endPlaybackTurn()
        synchronized(micLock) {
            audio?.stopMic() // never keep recording while disconnected
            micStarted = false
        }
        _lastError.value = RECONNECT_FAILED_MESSAGE
        _amplitude.value = 0f
        _vadActive.value = false
        setState(NovaOrbState.ERROR, RECONNECT_FAILED_MESSAGE, force = true)
    }

    private fun abortWithError(message: String) {
        stop()
        _lastError.value = message
        setState(NovaOrbState.ERROR, message, force = true)
    }

    private fun isPermanentError(message: String) =
        message.startsWith("No API key") || message.startsWith("Gemini rejected")

    // ---- Gemini listener --------------------------------------------------------------------

    private class SessionListener(
        private val myEpoch: Int,
        private val app: Context,
    ) : GeminiLiveClient.Listener {

        lateinit var owner: GeminiLiveClient
        private val failureHandled = AtomicBoolean(false)

        private fun stale() = epoch.get() != myEpoch || !_isActive.value

        override fun onSetupComplete() {
            if (stale()) return
            lastSetupAt = nowMs()
            latency.markSetupComplete()
            setListening()
            startMicOnce()
        }

        override fun onAudioChunk(bytes: ByteArray) {
            if (stale()) return
            playbackChannel?.trySend(PlaybackItem.Audio(playbackGen.get(), bytes))
        }

        override fun onInputTranscript(text: String) {
            if (stale()) return
            appendUserTranscript(text)
        }

        override fun onOutputTranscript(text: String) {
            if (stale()) return
            appendModelTranscript(text)
        }

        override fun onTurnComplete() {
            if (stale()) return
            flushTranscripts()
            // Queued behind any audio still waiting to play, so the mic stays muted until it is done.
            playbackChannel?.trySend(PlaybackItem.TurnEnd(playbackGen.get()))
        }

        override fun onInterrupted() {
            if (stale()) return
            playbackGen.incrementAndGet() // everything queued so far is now void
            val channel = playbackChannel
            if (channel != null) while (channel.tryReceive().isSuccess) { /* drain */ }
            audio?.flushPlayback()
            endPlaybackTurn()
            flushTranscripts()
            latency.beginTurn()
            if (_state.value == NovaOrbState.SPEAKING) setListening()
        }

        override fun onToolCall(id: String, name: String, args: JSONObject) {
            if (stale()) return
            if (name == FORGE_TOOL) {
                runCatching { LiaForge.start(app, args) }
                owner.sendToolResponse(id, name, """{"result":"forge_started"}""")
                return
            }
            setState(NovaOrbState.THINKING, "Working on it…")
            scope.launch {
                val result = try {
                    ActionExecutor.execute(app, name, args)
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    JSONObject().put("error", "tool_failed")
                }
                if (!stale()) {
                    owner.sendToolResponse(id, name, result.toString())
                    if (_state.value == NovaOrbState.THINKING) setListening()
                }
            }
        }

        override fun onError(message: String) {
            if (stale() || !failureHandled.compareAndSet(false, true)) return
            _lastError.value = message
            if (isPermanentError(message)) abortWithError(message) else scheduleReconnect()
        }

        override fun onClosed() {
            if (stale() || !failureHandled.compareAndSet(false, true)) return
            scheduleReconnect()
        }
    }

    // ---- Mic --------------------------------------------------------------------------------

    private fun startMicOnce() {
        val started = synchronized(micLock) {
            if (micStarted) return
            val a = audio ?: return
            micStarted = a.startMic()
            micStarted
        }
        if (!started) abortWithError("Microphone is unavailable. Check the permission and try again.")
    }

    private fun onMicChunk(bytes: ByteArray) {
        if (_muted.value || EchoGuard.isMicMuted()) return
        client?.sendAudio(bytes)
    }

    private fun onMicAmplitude(rms: Float) {
        if (_muted.value || EchoGuard.isMicMuted()) {
            if (_state.value == NovaOrbState.LISTENING) _amplitude.value = 0f
            if (vad.active) {
                vad.reset()
                _vadActive.value = false
            }
            return
        }
        if (_state.value == NovaOrbState.LISTENING) _amplitude.value = rms
        val was = vad.active
        val now = vad.update(rms)
        if (now != was) {
            _vadActive.value = now
            if (now) {
                if (!latency.hasMark(VoiceLatencyTracker.Mark.FIRST_AUDIO)) latency.beginTurn()
            } else {
                latency.mark(VoiceLatencyTracker.Mark.USER_SPEECH_END)
            }
        }
    }

    // ---- Playback ---------------------------------------------------------------------------

    private suspend fun runPlayback(channel: Channel<PlaybackItem>) {
        for (item in channel) {
            if (item.gen != playbackGen.get() || !_isActive.value) continue
            when (item) {
                is PlaybackItem.Audio -> {
                    if (playbackActive.compareAndSet(false, true)) {
                        EchoGuard.notifyPlaybackStarted()
                        latency.mark(VoiceLatencyTracker.Mark.FIRST_AUDIO)
                        setState(NovaOrbState.SPEAKING, "Speaking")
                    }
                    val level = audio?.playChunk(item.bytes) ?: 0f
                    if (item.gen == playbackGen.get()) {
                        _amplitude.value = level
                        armSilenceWatchdog(item.gen)
                    }
                }
                is PlaybackItem.TurnEnd -> completeTurn()
            }
        }
    }

    /** Ends the turn if no further chunk is played within [PLAYBACK_SILENCE_MS]. */
    private fun armSilenceWatchdog(gen: Int) {
        val job = scope.launch {
            delay(PLAYBACK_SILENCE_MS)
            if (gen == playbackGen.get() && _isActive.value) completeTurn()
        }
        silenceJob.getAndSet(job)?.cancel()
    }

    /** Idempotent: releases the EchoGuard hold (once per started playback). */
    private fun endPlaybackTurn(): Boolean {
        silenceJob.getAndSet(null)?.cancel()
        if (playbackActive.compareAndSet(true, false)) {
            EchoGuard.notifyPlaybackStopped()
            return true
        }
        return false
    }

    private fun completeTurn() {
        endPlaybackTurn()
        latency.mark(VoiceLatencyTracker.Mark.TURN_COMPLETE)
        latency.beginTurn()
        if (_state.value == NovaOrbState.SPEAKING) setListening()
    }

    // ---- Transcripts ------------------------------------------------------------------------

    private fun appendUserTranscript(text: String) {
        val detected: DetectedLanguage
        synchronized(transcriptLock) {
            if (modelBuf.isNotEmpty()) flushLocked()
            userBuf.append(text)
            detected = LanguageDetector.detect(userBuf.toString())
        }
        if (detected != DetectedLanguage.UNKNOWN) _detectedLanguage.value = detected
    }

    private fun appendModelTranscript(text: String) {
        synchronized(transcriptLock) {
            if (userBuf.isNotEmpty()) flushLocked()
            modelBuf.append(text)
        }
    }

    private fun flushTranscripts() = synchronized(transcriptLock) { flushLocked() }

    private fun flushLocked() {
        if (userBuf.isNotEmpty()) memory.add(ConversationMemory.Role.USER, userBuf.toString())
        if (modelBuf.isNotEmpty()) memory.add(ConversationMemory.Role.ASSISTANT, modelBuf.toString())
        userBuf.setLength(0)
        modelBuf.setLength(0)
    }

    // ---- State helpers ----------------------------------------------------------------------

    private fun setState(newState: NovaOrbState, text: String, force: Boolean = false) {
        if (!force && _state.value == NovaOrbState.ERROR) return
        _state.value = newState
        _statusText.value = text
    }

    private fun setListening() {
        setState(NovaOrbState.LISTENING, if (_muted.value) "Muted" else "Listening")
        _amplitude.value = 0f
    }
}
