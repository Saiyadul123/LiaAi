package com.Lia.assistant.voice

import android.content.Context

/**
 * STUB: the live voice session is implemented in a later step. PersonalityRepository calls
 * [refreshInstructions] after every settings change so a running session can re-read the
 * personality, language, assistant name and voice from PersonalityRepository.
 */
object VoiceSessionManager {
    fun refreshInstructions(context: Context) {
        // No live session yet.
    }
}
