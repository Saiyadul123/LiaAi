package com.Lia.assistant.voice

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.Lia.assistant.MainActivity
import com.Lia.assistant.R
import com.Lia.assistant.data.NovaPreferences
import com.Lia.assistant.data.SettingsFallback
import com.Lia.assistant.ui.fx.OverlayEdgeGlowController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Keeps the process alive (microphone foreground service) while a voice session runs. */
class VoiceForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var watchJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            VoiceSessionManager.stop()
            OverlayEdgeGlowController.stop()
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val name = assistantName()
        createChannel(name)
        try {
            val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
            ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(name), type)
        } catch (_: RuntimeException) {
            // Missing mic permission (SecurityException) or a background start that is not allowed.
            VoiceSessionManager.reportPermissionDenied()
            stopSelf()
            return START_NOT_STICKY
        }

        VoiceSessionManager.start(applicationContext)

        OverlayEdgeGlowController.start(applicationContext)

        watchJob?.cancel()
        watchJob = scope.launch {
            VoiceSessionManager.isActive.first { !it } // the session ended on its own (e.g. fatal error)
            OverlayEdgeGlowController.stop()
            ServiceCompat.stopForeground(this@VoiceForegroundService, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        VoiceSessionManager.stop()
        OverlayEdgeGlowController.stop()
        super.onDestroy()
    }

    private fun assistantName(): String = SettingsFallback.assistantName(
        NovaPreferences.getString(this, NovaPreferences.Keys.ASSISTANT_NAME), null
    )

    private fun createChannel(name: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "$name voice session", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(name: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, VoiceForegroundService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_lia)
            .setContentTitle("$name is listening")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, "Stop", stop)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.Lia.assistant.voice.action.STOP"
        private const val CHANNEL_ID = "lia_voice_session"
        private const val NOTIFICATION_ID = 4101

        /** Starts voice mode. Returns false if RECORD_AUDIO is missing or the OS refused the start. */
        fun start(context: Context): Boolean {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) return false
            return try {
                ContextCompat.startForegroundService(context, Intent(context, VoiceForegroundService::class.java))
                true
            } catch (_: RuntimeException) {
                false
            }
        }

        fun stop(context: Context) {
            VoiceSessionManager.stop()
            OverlayEdgeGlowController.stop()
            context.stopService(Intent(context, VoiceForegroundService::class.java))
        }
    }
}
