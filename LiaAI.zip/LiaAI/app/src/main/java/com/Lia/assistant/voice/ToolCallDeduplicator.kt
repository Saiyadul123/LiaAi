package com.Lia.assistant.voice

/**
 * Remembers recently seen tool-call ids so a call delivered twice is only executed once.
 * Bounded: when more than [maxSize] ids are held, the oldest is forgotten. Thread-safe.
 */
class ToolCallDeduplicator(private val maxSize: Int = DEFAULT_MAX_SIZE) {

    init {
        require(maxSize > 0) { "maxSize must be positive" }
    }

    private val seen = LinkedHashSet<String>()

    /**
     * Returns true if [id] has not been seen (and records it), false if it is a duplicate.
     * A blank id cannot be tracked, so it is always treated as new and never stored.
     */
    @Synchronized
    fun markIfNew(id: String): Boolean {
        if (id.isBlank()) return true
        if (!seen.add(id)) return false
        if (seen.size > maxSize) {
            val oldest = seen.iterator()
            oldest.next()
            oldest.remove()
        }
        return true
    }

    @Synchronized
    fun size(): Int = seen.size

    @Synchronized
    fun clear() = seen.clear()

    companion object {
        const val DEFAULT_MAX_SIZE = 256
    }
}
