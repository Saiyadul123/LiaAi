package com.Lia.assistant.data

import android.content.Context
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

data class StoredTurn(val isUser: Boolean, val text: String)

data class StoredConversation(
    val id: String,
    val title: String,
    val updatedAtMillis: Long,
    val turns: List<StoredTurn>,
)

/**
 * Typed-chat history, kept on the device only (a JSON file in the app's private storage).
 * All access is off the main thread and serialised by a lock; writes go through a temp file.
 */
object ChatHistoryStore {
    const val MAX_CONVERSATIONS = 50
    private const val FILE = "chat_history.json"
    private const val TITLE_LENGTH = 48
    private val lock = Any()

    suspend fun list(context: Context): List<StoredConversation> =
        withContext(Dispatchers.IO) { synchronized(lock) { readAll(context) } }

    suspend fun get(context: Context, id: String): StoredConversation? =
        withContext(Dispatchers.IO) { synchronized(lock) { readAll(context).firstOrNull { it.id == id } } }

    suspend fun save(context: Context, conversation: StoredConversation) {
        withContext(Dispatchers.IO) {
            synchronized(lock) { writeAll(context, upsert(readAll(context), conversation, MAX_CONVERSATIONS)) }
        }
    }

    suspend fun delete(context: Context, id: String) {
        withContext(Dispatchers.IO) {
            synchronized(lock) { writeAll(context, readAll(context).filter { it.id != id }) }
        }
    }

    suspend fun clear(context: Context) {
        withContext(Dispatchers.IO) { synchronized(lock) { File(context.filesDir, FILE).delete() } }
    }

    private fun readAll(context: Context): List<StoredConversation> {
        val file = File(context.filesDir, FILE)
        if (!file.exists()) return emptyList()
        return fromJson(file.readText()).sortedByDescending { it.updatedAtMillis }
    }

    private fun writeAll(context: Context, list: List<StoredConversation>) {
        val file = File(context.filesDir, FILE)
        val tmp = File(context.filesDir, "$FILE.tmp")
        tmp.writeText(toJson(list))
        if (!tmp.renameTo(file)) {
            file.delete()
            tmp.renameTo(file)
        }
    }

    // ---- pure helpers (unit-tested) ----------------------------------------------------------

    internal fun toJson(list: List<StoredConversation>): String {
        val array = JSONArray()
        list.forEach { c ->
            val turns = JSONArray()
            c.turns.forEach { turns.put(JSONObject().put("u", it.isUser).put("t", it.text)) }
            array.put(
                JSONObject().put("id", c.id).put("title", c.title).put("updatedAt", c.updatedAtMillis).put("turns", turns)
            )
        }
        return JSONObject().put("version", 1).put("conversations", array).toString()
    }

    internal fun fromJson(json: String): List<StoredConversation> = try {
        val array = JSONObject(json).optJSONArray("conversations") ?: JSONArray()
        (0 until array.length()).mapNotNull { i ->
            val o = array.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString("id")
            if (id.isEmpty()) return@mapNotNull null
            val turnsJson = o.optJSONArray("turns") ?: JSONArray()
            val turns = (0 until turnsJson.length()).mapNotNull { j ->
                val t = turnsJson.optJSONObject(j) ?: return@mapNotNull null
                StoredTurn(t.optBoolean("u"), t.optString("t"))
            }
            StoredConversation(id, o.optString("title"), o.optLong("updatedAt"), turns)
        }
    } catch (_: JSONException) {
        emptyList()
    }

    /** Puts [conversation] first, replacing any older copy, newest first, at most [max] kept. */
    internal fun upsert(list: List<StoredConversation>, conversation: StoredConversation, max: Int): List<StoredConversation> =
        (listOf(conversation) + list.filter { it.id != conversation.id })
            .sortedByDescending { it.updatedAtMillis }
            .take(max)

    /** First user message, whitespace collapsed and shortened. */
    internal fun titleFor(turns: List<StoredTurn>): String {
        val first = turns.firstOrNull { it.isUser }?.text.orEmpty().replace(Regex("\\s+"), " ").trim()
        if (first.isEmpty()) return "New conversation"
        return if (first.length > TITLE_LENGTH) first.take(TITLE_LENGTH - 1).trimEnd() + "…" else first
    }
}
