package com.Lia.assistant.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaSizes
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.depthSurface

/**
 * A translucent "glass" card over the night sky (layer 2). Pass [onClick] to make it tappable: it then
 * has a 48 dp minimum height, button semantics, a light haptic tick, and a depth push on press
 * (scale 0.96 while the shadow shrinks). [elevation] sets how high it floats: deeper cards use less.
 */
@Composable
fun NovaGlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = NovaTheme.shapes.medium,
    onClick: (() -> Unit)? = null,
    onClickLabel: String? = null,
    contentPadding: PaddingValues = PaddingValues(NovaSpacing.lg),
    elevation: Dp = 8.dp,
    content: @Composable ColumnScope.() -> Unit,
) {
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val haptics = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val push = pressed && onClick != null
    val scale by animateFloatAsState(
        targetValue = if (push && !reduced) 0.96f else 1f,
        animationSpec = tween(NovaMotion.FAST),
        label = "cardPush",
    )
    val lift by animateDpAsState(
        targetValue = if (push) elevation * 0.4f else elevation,
        animationSpec = tween(if (reduced) 0 else NovaMotion.FAST),
        label = "cardLift",
    )

    var card = modifier
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .depthSurface(shape, elevation = lift)
        .clip(shape)
        .background(colors.surfaceGlass)
        .border(1.dp, colors.surfaceBorder, shape)
    if (onClick != null) {
        card = card
            .heightIn(min = NovaSizes.MinTouch)
            .clickable(
                interactionSource = interaction,
                indication = ripple(),
                onClickLabel = onClickLabel,
                role = Role.Button,
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                },
            )
    }
    Column(modifier = card.padding(contentPadding), content = content)
}
