package com.Lia.assistant.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.theme.NovaSizes
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.depthSurface

/**
 * A translucent "glass" card over the night sky. Pass [onClick] to make it tappable (it then has a
 * 48 dp minimum height and button semantics).
 */
@Composable
fun NovaGlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = NovaTheme.shapes.medium,
    onClick: (() -> Unit)? = null,
    onClickLabel: String? = null,
    contentPadding: PaddingValues = PaddingValues(NovaSpacing.lg),
    content: @Composable ColumnScope.() -> Unit,
) {
    val colors = NovaTheme.colors
    var card = modifier
        .depthSurface(shape, elevation = 8.dp)
        .clip(shape)
        .background(colors.surfaceGlass)
        .border(1.dp, colors.surfaceBorder, shape)
    if (onClick != null) {
        card = card
            .heightIn(min = NovaSizes.MinTouch)
            .clickable(onClickLabel = onClickLabel, role = Role.Button, onClick = onClick)
    }
    Column(modifier = card.padding(contentPadding), content = content)
}
