package com.Lia.assistant.action

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Tool handlers shared by both flavors. Every handler returns a JSONObject:
 * {"result": "<outcome>", ...} for normal outcomes (including "not found" style ones) and
 * {"error": "<message>"} for bad input or unknown tools. Messages are only ever opened in a
 * composer here, the user taps Send.
 */
object PhoneActions {

    fun result(value: String, vararg extras: Pair<String, String>): JSONObject {
        val out = JSONObject().put("result", value)
        extras.forEach { out.put(it.first, it.second) }
        return out
    }

    fun error(message: String): JSONObject = JSONObject().put("error", message)

    fun unknownTool(name: String): JSONObject = error("Unknown tool: $name")

    private fun missing(param: String) = error("Missing parameter: $param")

    // ---- open_app ---------------------------------------------------------------------------

    suspend fun openApp(context: Context, args: JSONObject): JSONObject {
        val query = args.optString("app_name").trim()
        if (query.isEmpty()) return missing("app_name")
        val match = AppLauncher.findApp(context, query) ?: return result("app_not_found")
        return if (AppLauncher.launch(context, match.packageName)) {
            result("opened", "app" to match.label)
        } else {
            result("could_not_open", "app" to match.label)
        }
    }

    // ---- call_contact -----------------------------------------------------------------------

    suspend fun callContact(context: Context, args: JSONObject): JSONObject {
        val query = args.optString("contact").trim()
        if (query.isEmpty()) return missing("contact")
        return when (val found = lookup(context, query)) {
            ContactResolver.Result.NoPermission -> result("no_contacts_permission")
            ContactResolver.Result.NotFound -> result("contact_not_found")
            is ContactResolver.Result.Found -> dial(context, found)
        }
    }

    private fun dial(context: Context, found: ContactResolver.Result.Found): JSONObject {
        val canCall = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) ==
            PackageManager.PERMISSION_GRANTED
        if (canCall && CommIntents.start(context, CommIntents.callIntent(found.number, direct = true))) {
            return result("calling", "contact" to found.name)
        }
        return if (CommIntents.start(context, CommIntents.callIntent(found.number, direct = false))) {
            result(if (canCall) "dialer_opened" else "dialer_opened_no_permission", "contact" to found.name)
        } else {
            error("No dialer app is available")
        }
    }

    // ---- message_contact --------------------------------------------------------------------

    sealed interface Composer {
        data class Opened(val app: CommIntents.MessageApp, val contactName: String) : Composer
        data class Failed(val json: JSONObject) : Composer
    }

    /** Opens the SMS or WhatsApp composer with the text filled in. Never sends anything. */
    suspend fun openComposer(
        context: Context,
        args: JSONObject,
        isPackageInstalled: (String) -> Boolean = { CommIntents.isInstalled(context, it) },
    ): Composer {
        val query = args.optString("contact").trim()
        val message = args.optString("message")
        if (query.isEmpty()) return Composer.Failed(missing("contact"))
        if (message.isBlank()) return Composer.Failed(missing("message"))

        val found = when (val r = lookup(context, query)) {
            ContactResolver.Result.NoPermission -> return Composer.Failed(result("no_contacts_permission"))
            ContactResolver.Result.NotFound -> return Composer.Failed(result("contact_not_found"))
            is ContactResolver.Result.Found -> r
        }

        val app = CommIntents.parseMessageApp(args.optString("app"))
        return when (app) {
            CommIntents.MessageApp.SMS ->
                if (CommIntents.start(context, CommIntents.smsIntent(found.number, message))) {
                    Composer.Opened(app, found.name)
                } else {
                    Composer.Failed(result("no_messaging_app"))
                }

            CommIntents.MessageApp.WHATSAPP -> {
                val pkg = CommIntents.WHATSAPP_PACKAGES.firstOrNull(isPackageInstalled)
                    ?: return Composer.Failed(result("whatsapp_not_installed"))
                if (CommIntents.start(context, CommIntents.whatsAppIntent(context, found.number, message, pkg))) {
                    Composer.Opened(app, found.name)
                } else {
                    Composer.Failed(result("no_messaging_app"))
                }
            }
        }
    }

    fun composerOpenedJson(opened: Composer.Opened, outcome: String = "composer_opened"): JSONObject =
        result(outcome, "contact" to opened.contactName, "app" to opened.app.name.lowercase())

    private suspend fun lookup(context: Context, query: String): ContactResolver.Result =
        withContext(Dispatchers.IO) { ContactResolver.lookup(context, query) }
}
