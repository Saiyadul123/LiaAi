package com.Lia.assistant.ui.navigation

import java.net.URLEncoder

object NovaRoutes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val CHAT = "chat"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val VOICE = "voice"
    const val QUICK_ACTIONS = "quick_actions"
    const val PROFILE = "profile"
    const val PERSONALITY = "personality"
    const val ORB_STYLE = "orb_style"
    const val PRIVACY = "privacy"
    const val PERMISSIONS = "permissions"
    const val ABOUT = "about"
    const val DEBUG = "debug"
    const val FORGE = "forge"
    const val ACCESSIBILITY_DISCLOSURE = "accessibility_disclosure"

    const val ARG_CONVERSATION = "conversation"
    const val ARG_PROMPT = "prompt"
    /** Chat takes an optional saved conversation to reopen and an optional first message. */
    const val CHAT_PATTERN = "$CHAT?$ARG_CONVERSATION={$ARG_CONVERSATION}&$ARG_PROMPT={$ARG_PROMPT}"

    /** Routes that show the floating bottom navigation. */
    val bottomBarRoutes = setOf(HOME, CHAT, HISTORY, SETTINGS)

    fun baseRoute(route: String?): String? = route?.substringBefore('?')?.substringBefore('/')

    fun showsBottomBar(route: String?): Boolean {
        val base = baseRoute(route) ?: return false
        return base in bottomBarRoutes
    }

    fun startRoute(hasOnboarded: Boolean): String = if (hasOnboarded) HOME else ONBOARDING

    fun chat(conversationId: String? = null, prompt: String? = null): String {
        val parts = buildList {
            if (conversationId != null) add("$ARG_CONVERSATION=${URLEncoder.encode(conversationId, "UTF-8")}")
            if (prompt != null) add("$ARG_PROMPT=${URLEncoder.encode(prompt, "UTF-8")}")
        }
        return if (parts.isEmpty()) CHAT else "$CHAT?${parts.joinToString("&")}"
    }
}
