package com.Lia.assistant.data

/** Minimal in-memory conversation summary (persistence for chat history is a later step). */
data class Conversation(
    val id: String,
    val title: String,
    val updatedAtMillis: Long,
)
