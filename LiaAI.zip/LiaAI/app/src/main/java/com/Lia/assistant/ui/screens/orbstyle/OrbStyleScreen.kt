package com.Lia.assistant.ui.screens.orbstyle

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaOrbStyle
import com.Lia.assistant.ui.components.NovaVoiceVisualizer
import com.Lia.assistant.ui.screens.common.NovaListScreen
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.voice.NovaOrbState

internal fun orbStyleTitle(style: NovaOrbStyle): String = style.name.lowercase().replaceFirstChar { it.uppercase() }

internal fun orbStyleBlurb(style: NovaOrbStyle): String = when (style) {
    NovaOrbStyle.NOVA -> "The lit 3D pearl (a soft orb on older phones)"
    NovaOrbStyle.AURORA -> "Teal and violet light"
    NovaOrbStyle.PLASMA -> "A hot pink and amber swirl"
    NovaOrbStyle.GLASS -> "Clear glass with a bright highlight"
    NovaOrbStyle.ENERGY -> "Bright amber with fast sparks"
    NovaOrbStyle.MINIMAL -> "One calm circle"
    NovaOrbStyle.ARCHER -> "A sphere made of hundreds of points"
}

/** Choose the orb's look. Every option is shown live. */
@Composable
fun OrbStyleScreen(appState: NovaAppState, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val current = NovaOrbStyle.fromId(appState.orbStyle)

    NovaListScreen(
        title = "Orb style",
        subtitle = "How ${appState.assistantName} looks",
        onBack = onBack,
        modifier = modifier,
    ) {
        NovaOrbStyle.entries.forEach { style ->
            item(key = style.name) {
                val isSelected = style == current
                NovaGlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = NovaSpacing.lg)
                        .semantics { selected = isSelected }
                        .then(if (isSelected) Modifier.border(2.dp, colors.accent, NovaTheme.shapes.medium) else Modifier),
                    onClick = { appState.applyOrbStyle(style.name) },
                    onClickLabel = "Choose ${orbStyleTitle(style)}",
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        NovaVoiceVisualizer(
                            state = NovaOrbState.IDLE,
                            modifier = Modifier.size(72.dp),
                            style = style,
                            name = appState.assistantName,
                        )
                        Spacer(Modifier.width(NovaSpacing.lg))
                        Column(Modifier.weight(1f)) {
                            Text(orbStyleTitle(style), style = type.title, color = colors.textPrimary)
                            Text(orbStyleBlurb(style), style = type.body, color = colors.textSecondary)
                        }
                        if (isSelected) Icon(Icons.Rounded.CheckCircle, contentDescription = "Selected", tint = colors.accentText)
                    }
                }
            }
        }
    }
}
