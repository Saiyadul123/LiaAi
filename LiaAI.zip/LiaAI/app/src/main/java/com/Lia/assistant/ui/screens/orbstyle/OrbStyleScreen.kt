package com.Lia.assistant.ui.screens.orbstyle

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaChip
import com.Lia.assistant.ui.components.NovaOrbStyle
import com.Lia.assistant.ui.components.NovaTopBar
import com.Lia.assistant.ui.components.NovaVoiceVisualizer
import com.Lia.assistant.ui.theme.CardTilt
import com.Lia.assistant.ui.theme.LocalBottomBarInset
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.voice.NovaOrbState
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

internal fun orbStyleTitle(style: NovaOrbStyle): String = style.name.lowercase().replaceFirstChar { it.uppercase() }

internal fun orbStyleBlurb(style: NovaOrbStyle): String = when (style) {
    NovaOrbStyle.NOVA -> "The lit 3D pearl (a soft orb on older phones)"
    NovaOrbStyle.AURORA -> "Teal and violet light"
    NovaOrbStyle.PLASMA -> "A hot pink and amber swirl"
    NovaOrbStyle.GLASS -> "Clear glass with a bright highlight"
    NovaOrbStyle.ENERGY -> "Bright amber with fast sparks"
    NovaOrbStyle.MINIMAL -> "One calm circle"
    NovaOrbStyle.ARCHER -> "A sphere made of hundreds of points"
}

private val ITEM_SIZE = 132.dp
private val PREVIEW_STATES = listOf(
    NovaOrbState.IDLE to "Idle",
    NovaOrbState.LISTENING to "Listening",
    NovaOrbState.SPEAKING to "Speaking",
)

/** The carousel item whose centre is closest to the middle of the viewport. */
private fun centeredIndex(state: LazyListState): Int? {
    val info = state.layoutInfo
    val center = (info.viewportStartOffset + info.viewportEndOffset) / 2f
    return info.visibleItemsInfo.minByOrNull { abs((it.offset + it.size / 2f) - center) }?.index
}

/**
 * A large live preview with Idle / Listening / Speaking chips, and a snapping coverflow of the seven
 * styles: the centred one is largest and flat, its neighbours turn toward it. The style that settles in
 * the middle is the one in use.
 */
@Composable
fun OrbStyleScreen(appState: NovaAppState, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val reduced = NovaTheme.reducedMotion
    val name = appState.assistantName
    val scope = rememberCoroutineScope()
    val styles = NovaOrbStyle.entries
    val current = NovaOrbStyle.fromId(appState.orbStyle)

    var previewState by remember { mutableStateOf(NovaOrbState.IDLE) }
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = styles.indexOf(current).coerceAtLeast(0))

    // Pretend voice for the Speaking preview.
    val wave = rememberInfiniteTransition(label = "previewVoice").animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "previewWave",
    )
    val amplitude = when {
        previewState != NovaOrbState.SPEAKING -> 0.1f
        reduced -> 0.35f
        else -> 0.35f + 0.3f * sin(wave.value * 2f * PI.toFloat())
    }

    // The style that settles in the middle becomes the chosen one.
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress }.filter { !it }.collect {
            val index = centeredIndex(listState)
            if (index != null && styles[index] != NovaOrbStyle.fromId(appState.orbStyle)) {
                appState.applyOrbStyle(styles[index].name)
            }
        }
    }

    Column(modifier.fillMaxSize()) {
        NovaTopBar(title = "Orb style", subtitle = "How $name looks", onBack = onBack)

        Box(Modifier.fillMaxWidth().padding(vertical = NovaSpacing.md), contentAlignment = Alignment.Center) {
            NovaVoiceVisualizer(
                state = previewState,
                modifier = Modifier.size(200.dp),
                amplitude = amplitude,
                style = current,
                name = name,
            )
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg),
            horizontalArrangement = Arrangement.spacedBy(NovaSpacing.sm, Alignment.CenterHorizontally),
        ) {
            PREVIEW_STATES.forEach { (state, label) ->
                NovaChip(label = label, selected = previewState == state, onClick = { previewState = state })
            }
        }

        Spacer(Modifier.height(NovaSpacing.lg))

        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val sidePad = ((maxWidth - ITEM_SIZE) / 2).coerceAtLeast(0.dp)
            LazyRow(
                state = listState,
                flingBehavior = rememberSnapFlingBehavior(listState),
                contentPadding = PaddingValues(horizontal = sidePad),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                itemsIndexed(styles, key = { _, style -> style.name }) { index, style ->
                    Box(
                        modifier = Modifier
                            .size(ITEM_SIZE)
                            .graphicsLayer {
                                val info = listState.layoutInfo
                                val item = info.visibleItemsInfo.firstOrNull { it.index == index }
                                val center = (info.viewportStartOffset + info.viewportEndOffset) / 2f
                                val fraction = if (item == null) 1f else ((item.offset + item.size / 2f) - center) / item.size
                                val flow = CardTilt.coverflow(fraction)
                                rotationY = flow.rotationY
                                scaleX = flow.scale
                                scaleY = flow.scale
                                alpha = flow.alpha
                                cameraDistance = 14f * density
                            }
                            .clickable(onClickLabel = "Choose ${orbStyleTitle(style)}", role = Role.Button) {
                                scope.launch {
                                    if (reduced) listState.scrollToItem(index) else listState.animateScrollToItem(index)
                                }
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        NovaVoiceVisualizer(
                            state = NovaOrbState.IDLE,
                            modifier = Modifier.size(96.dp),
                            style = style,
                            name = name,
                        )
                    }
                }
            }
        }

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = NovaSpacing.xl)
                .padding(top = NovaSpacing.lg, bottom = LocalBottomBarInset.current + NovaSpacing.xl),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(orbStyleTitle(current), style = type.headline, color = colors.textPrimary, textAlign = TextAlign.Center)
            Text(orbStyleBlurb(current), style = type.body, color = colors.textSecondary, textAlign = TextAlign.Center)
        }
    }
}
