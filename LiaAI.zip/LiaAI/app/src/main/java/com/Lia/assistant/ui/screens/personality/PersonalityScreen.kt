package com.Lia.assistant.ui.screens.personality

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.data.Personality
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaTopBar
import com.Lia.assistant.ui.theme.LocalBottomBarInset
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme

/**
 * A grid of the ten personalities. The chosen card lifts toward you (scale 1.04, a stronger shadow and a
 * marigold rim) while the others dim. A running voice session picks the change up with a quiet reconnect.
 */
@Composable
fun PersonalityScreen(appState: NovaAppState, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography

    Column(modifier.fillMaxSize()) {
        NovaTopBar(title = "Personality", subtitle = "How ${appState.assistantName} talks to you", onBack = onBack)
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(
                start = NovaSpacing.lg, end = NovaSpacing.lg, top = NovaSpacing.sm,
                bottom = LocalBottomBarInset.current + NovaSpacing.xl,
            ),
            horizontalArrangement = Arrangement.spacedBy(NovaSpacing.md),
            verticalArrangement = Arrangement.spacedBy(NovaSpacing.md),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    "Changes take effect immediately",
                    style = type.voice.copy(fontSize = 18.sp, lineHeight = 24.sp),
                    color = colors.textSecondary,
                    modifier = Modifier.padding(bottom = NovaSpacing.xs),
                )
            }
            items(Personality.entries, key = { it.name }) { p ->
                PersonalityCard(p, selected = p == appState.personality, onClick = { appState.applyPersonality(p) })
            }
        }
    }
}

@Composable
private fun PersonalityCard(p: Personality, selected: Boolean, onClick: () -> Unit) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val reduced = NovaTheme.reducedMotion
    val spec = tween<Float>(if (reduced) 0 else NovaMotion.MEDIUM)
    val lift by animateFloatAsState(if (selected) 1.04f else 1f, spec, label = "personalityLift")
    val dim by animateFloatAsState(if (selected) 1f else 0.65f, spec, label = "personalityDim")

    NovaGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = lift; scaleY = lift; alpha = dim }
            .semantics { this.selected = selected }
            .then(if (selected) Modifier.border(2.dp, colors.accent, NovaTheme.shapes.medium) else Modifier),
        onClick = onClick,
        onClickLabel = "Choose ${p.displayName}",
        elevation = if (selected) 18.dp else 6.dp,
    ) {
        Icon(
            p.icon,
            contentDescription = null,
            tint = if (selected) colors.accentText else colors.textSecondary,
            modifier = Modifier.size(28.dp),
        )
        Spacer(Modifier.height(NovaSpacing.sm))
        Text(p.displayName, style = type.title, color = colors.textPrimary, maxLines = 1)
        Text(p.description, style = type.caption, color = colors.textSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}
