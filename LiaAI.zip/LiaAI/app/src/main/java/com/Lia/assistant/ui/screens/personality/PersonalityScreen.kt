package com.Lia.assistant.ui.screens.personality

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.data.Personality
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.screens.common.NovaListScreen
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme

/** Pick how the assistant talks. The change reaches a running voice session through a quiet reconnect. */
@Composable
fun PersonalityScreen(appState: NovaAppState, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    NovaListScreen(
        title = "Personality",
        subtitle = "How ${appState.assistantName} talks to you",
        onBack = onBack,
        modifier = modifier,
    ) {
        Personality.entries.forEach { p ->
            item(key = p.name) {
                val isSelected = p == appState.personality
                NovaGlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = NovaSpacing.lg)
                        .semantics { selected = isSelected }
                        .then(if (isSelected) Modifier.border(2.dp, colors.accent, NovaTheme.shapes.medium) else Modifier),
                    onClick = { appState.applyPersonality(p) },
                    onClickLabel = "Choose ${p.displayName}",
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(p.icon, contentDescription = null, tint = if (isSelected) colors.accentText else colors.textSecondary, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(NovaSpacing.lg))
                        Column(Modifier.weight(1f)) {
                            Text(p.displayName, style = type.title, color = colors.textPrimary)
                            Text(p.description, style = type.body, color = colors.textSecondary)
                        }
                        if (isSelected) {
                            Icon(Icons.Rounded.CheckCircle, contentDescription = "Selected", tint = colors.accentText)
                        }
                    }
                }
            }
        }
    }
}
