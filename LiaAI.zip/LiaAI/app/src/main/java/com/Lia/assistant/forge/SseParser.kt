package com.Lia.assistant.forge

import org.json.JSONException
import org.json.JSONObject

/** An error object from a Gemini response. [message] is for logs only: show people [ForgeErrors.friendly]. */
data class SseError(val code: Int, val status: String, val message: String)

/** Reads Gemini's streamGenerateContent?alt=sse output, one line or one JSON event at a time. */
object SseParser {
    const val DONE = "[DONE]"

    /** The payload of a "data:" line, or null for anything else (blank lines, comments, event:, id:). */
    fun dataPayload(line: String): String? {
        if (!line.startsWith("data:")) return null
        return line.substring(5).trim().ifEmpty { null }
    }

    fun isDone(payload: String): Boolean = payload == DONE

    /** All the text in the first candidate, in order. Thinking parts are left out. Never throws. */
    fun extractText(json: String): String {
        val parts = parse(json)?.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts") ?: return ""
        val out = StringBuilder()
        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            if (part.optBoolean("thought", false)) continue
            if (part.has("text") && !part.isNull("text")) out.append(part.getString("text"))
        }
        return out.toString()
    }

    /** The error in an event, or null when it is not an error. */
    fun extractError(json: String): SseError? {
        val error = parse(json)?.optJSONObject("error") ?: return null
        return SseError(
            code = error.optInt("code", 0),
            status = if (error.isNull("status")) "" else error.optString("status", ""),
            message = if (error.isNull("message")) "" else error.optString("message", ""),
        )
    }

    /** "STOP", "MAX_TOKENS", "RECITATION", ... once the model has finished, else null. */
    fun extractFinishReason(json: String): String? {
        val candidate = parse(json)?.optJSONArray("candidates")?.optJSONObject(0) ?: return null
        if (!candidate.has("finishReason") || candidate.isNull("finishReason")) return null
        return candidate.getString("finishReason").ifEmpty { null }
    }

    private fun parse(json: String): JSONObject? = try {
        JSONObject(json)
    } catch (_: JSONException) {
        null
    }
}
