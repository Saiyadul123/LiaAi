package com.Lia.assistant.ui.screens.quickactions

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.ui.graphics.vector.ImageVector
import com.Lia.assistant.FlavorRoutes
import org.json.JSONObject

/** One input a quick action needs. [options] (stored values) turns it into a small picker. */
data class QuickParam(
    val key: String,
    val label: String,
    val required: Boolean = true,
    val options: List<String>? = null,
)

/** A tile that runs one real tool. Only tools that exist in this build are listed. */
data class QuickActionSpec(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val tool: String,
    val params: List<QuickParam> = emptyList(),
)

object QuickActions {
    fun common(): List<QuickActionSpec> = listOf(
        QuickActionSpec(
            "open_app", "Open an app", "Launch any app on your phone", Icons.Rounded.Apps, "open_app",
            listOf(QuickParam("app_name", "App name")),
        ),
        QuickActionSpec(
            "call", "Call someone", "A saved contact or a number", Icons.Rounded.Call, "call_contact",
            listOf(QuickParam("contact", "Contact name or number")),
        ),
        QuickActionSpec(
            "message", "Send a message", "SMS or WhatsApp", Icons.Rounded.Sms, "message_contact",
            listOf(
                QuickParam("contact", "Contact name or number"),
                QuickParam("message", "Message"),
                QuickParam("app", "Send with", options = listOf("sms", "whatsapp")),
            ),
        ),
    )

    /** Common tiles plus whatever this flavor adds (screen control in the direct build). */
    fun all(): List<QuickActionSpec> = common() + FlavorRoutes.extraQuickActions()

    /** The first required parameter that has no value yet, or null if the action can run. */
    fun firstMissing(spec: QuickActionSpec, values: Map<String, String>): QuickParam? =
        spec.params.firstOrNull { it.required && values[it.key].isNullOrBlank() }

    fun argsFor(spec: QuickActionSpec, values: Map<String, String>): JSONObject {
        val args = JSONObject()
        spec.params.forEach { p ->
            val v = values[p.key]?.trim().orEmpty().ifEmpty { p.options?.firstOrNull().orEmpty() }
            if (v.isNotEmpty()) args.put(p.key, v)
        }
        return args
    }
}

/** Turns a tool's JSON result into a sentence for the user. */
object QuickActionResults {
    fun describe(json: JSONObject): String {
        json.optString("error").takeIf { it.isNotEmpty() }?.let { return it }
        return when (val r = json.optString("result")) {
            "opened" -> "Opened ${json.optString("app").ifEmpty { "the app" }}."
            "calling" -> "Calling ${json.optString("contact").ifEmpty { "now" }}."
            "dialer_opened", "dialer_opened_no_permission" -> "The dialer is open: tap Call."
            "composer_opened" -> "The message is ready: tap Send."
            "sent" -> "Message sent."
            "composer_opened_send_not_found" -> "The message is ready, but I couldn't find Send: tap it yourself."
            "app_not_found" -> "I couldn't find that app."
            "could_not_open" -> "That app wouldn't open."
            "contact_not_found" -> "I couldn't find that contact."
            "no_contacts_permission" -> "Allow contacts access in Permissions first."
            "whatsapp_not_installed" -> "WhatsApp isn't installed."
            "no_messaging_app" -> "No messaging app is available."
            "accessibility_not_enabled" -> "Turn on screen control first."
            "tapped", "typed", "scrolled", "done" -> "Done."
            "element_not_found" -> "I couldn't find that on the screen."
            "ok" -> json.optString("screen").ifEmpty { "Done." }
            "empty" -> "The screen has nothing to read."
            "" -> "No result."
            else -> r.replace('_', ' ').replaceFirstChar { it.uppercase() } + "."
        }
    }
}
