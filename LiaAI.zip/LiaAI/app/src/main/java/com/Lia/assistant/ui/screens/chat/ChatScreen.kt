package com.Lia.assistant.ui.screens.chat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.Lia.assistant.data.AssistantBrand
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaEmptyState
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaMessageBubble
import com.Lia.assistant.ui.components.NovaOrbStyle
import com.Lia.assistant.ui.components.NovaTextField
import com.Lia.assistant.ui.components.NovaTopBar
import com.Lia.assistant.ui.components.NovaTypingBubble
import com.Lia.assistant.ui.components.NovaVoiceVisualizer
import com.Lia.assistant.ui.theme.LocalBottomBarInset
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.voice.NovaOrbState

/**
 * Typed chat. Replies are revealed word by word; Forge requests go to the Website Forge. [onBack] is
 * null on the bottom-bar tab (no back arrow). [conversationId] reopens a saved chat from History and
 * [initialPrompt] sends a first message once. The night sky and bottom bar come from the app shell.
 */
@Composable
fun ChatScreen(
    appState: NovaAppState,
    modifier: Modifier = Modifier,
    onBack: (() -> Unit)? = null,
    conversationId: String? = null,
    initialPrompt: String? = null,
    viewModel: ChatViewModel = viewModel(),
) {
    val context = LocalContext.current
    val colors = NovaTheme.colors

    // One TextToSpeech engine for this screen, released when it leaves the composition.
    val tts = remember { TtsController(context) }
    DisposableEffect(tts) { onDispose { tts.shutdown() } }

    val settings = ChatSettings(appState.personality, appState.language, appState.assistantName, appState.saveHistory)
    val entries = viewModel.messages.toList()
    val typing = viewModel.isTyping
    var input by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(conversationId) { if (conversationId != null) viewModel.loadConversation(conversationId) }
    var promptHandled by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(initialPrompt) {
        if (!promptHandled && !initialPrompt.isNullOrBlank()) {
            promptHandled = true
            viewModel.send(initialPrompt, settings)
        }
    }

    val orbState = when {
        typing -> NovaOrbState.THINKING
        tts.speaking -> NovaOrbState.SPEAKING
        else -> NovaOrbState.IDLE
    }

    fun submit() {
        if (input.isBlank() || typing) return
        tts.stop()
        viewModel.send(input, settings)
        input = ""
    }

    val listState = rememberLazyListState()
    // The list is reversed (newest at index 0, anchored at the bottom): jump there on new content.
    LaunchedEffect(entries.lastOrNull()?.id, typing) { listState.animateScrollToItem(0) }

    // Keep the input above the floating bottom bar, or above the keyboard when it is open.
    val density = LocalDensity.current
    val imeOpen = WindowInsets.ime.getBottom(density) > 0
    val barInset = LocalBottomBarInset.current
    val inputInset: Modifier = when {
        imeOpen -> Modifier
        barInset > 0.dp -> Modifier.padding(bottom = barInset)
        else -> Modifier.navigationBarsPadding()
    }

    Column(modifier = modifier.fillMaxSize().imePadding()) {
        NovaTopBar(
            title = settings.assistantName,
            subtitle = if (typing) "Typing..." else "Here to help",
            onBack = onBack,
            leading = {
                NovaVoiceVisualizer(
                    state = orbState,
                    modifier = Modifier.size(40.dp),
                    style = NovaOrbStyle.fromId(appState.orbStyle),
                    name = settings.assistantName,
                )
            },
        )

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (entries.isEmpty() && !typing) {
                NovaEmptyState(
                    title = "Say hi to ${settings.assistantName}",
                    message = AssistantBrand.TAGLINE,
                    modifier = Modifier.align(Alignment.Center),
                )
            }
            val lastIsAssistant = entries.lastOrNull()?.isUser == false
            LazyColumn(
                state = listState,
                reverseLayout = true,
                contentPadding = PaddingValues(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm),
                verticalArrangement = Arrangement.spacedBy(NovaSpacing.sm),
                modifier = Modifier.fillMaxSize(),
            ) {
                if (typing) item(key = "typing") { NovaTypingBubble() }
                items(items = entries.asReversed(), key = { it.id }) { entry ->
                    val isThisSpeaking = tts.speaking && tts.speakingId == entry.id
                    NovaMessageBubble(
                        message = entry.toUi(),
                        isSpeaking = isThisSpeaking,
                        onCopy = if (!entry.isUser && entry.kind != ChatEntry.Kind.ERROR) {
                            { copyToClipboard(context, entry.text) }
                        } else null,
                        onSpeak = if (!entry.isUser && entry.kind == ChatEntry.Kind.NORMAL) {
                            {
                                if (isThisSpeaking) {
                                    tts.stop()
                                } else if (!tts.speak(entry.id, entry.text, appState.language, appState.speechSpeed)) {
                                    Toast.makeText(context, "Speech isn't ready yet", Toast.LENGTH_SHORT).show()
                                }
                            }
                        } else null,
                        onRetry = if (lastIsAssistant && !typing && entry.id == entries.last().id &&
                            entry.kind != ChatEntry.Kind.FORGE
                        ) {
                            {
                                tts.stop()
                                viewModel.retry(settings)
                            }
                        } else null,
                        onClick = if (entry.isRevealing) {
                            { viewModel.skipReveal(entry.id) }
                        } else null,
                    )
                }
            }
        }

        ChatInputBar(
            value = input,
            onValueChange = { input = it },
            sendEnabled = input.isNotBlank() && !typing,
            onSend = ::submit,
            placeholder = "Message ${settings.assistantName}",
            sendTint = if (input.isNotBlank() && !typing) colors.accentText else colors.textTertiary,
            insetModifier = inputInset,
        )
    }
}

/** A floating glass pill; Send on the keyboard sends the message too. */
@Composable
private fun ChatInputBar(
    value: String,
    onValueChange: (String) -> Unit,
    sendEnabled: Boolean,
    onSend: () -> Unit,
    placeholder: String,
    sendTint: androidx.compose.ui.graphics.Color,
    insetModifier: Modifier,
) {
    NovaGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .then(insetModifier)
            .padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm),
        shape = NovaTheme.shapes.pill,
        contentPadding = PaddingValues(start = NovaSpacing.sm, end = 4.dp, top = 4.dp, bottom = 4.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NovaTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.weight(1f),
                placeholder = placeholder,
                bordered = false,
                maxLines = 4,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    imeAction = ImeAction.Send,
                ),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
            )
            IconButton(onClick = onSend, enabled = sendEnabled) {
                Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = "Send message", tint = sendTint)
            }
        }
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
    clipboard.setPrimaryClip(ClipData.newPlainText("Chat reply", text))
    // Android 13+ shows its own confirmation.
    if (Build.VERSION.SDK_INT < 33) Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
}
