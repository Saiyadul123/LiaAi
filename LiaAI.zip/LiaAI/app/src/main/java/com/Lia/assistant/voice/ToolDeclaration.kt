package com.Lia.assistant.voice

/** A single STRING parameter of a tool. */
data class ToolParam(
    val name: String,
    val description: String,
    val required: Boolean = true,
)

/** A function the model may call. All parameters are sent as type STRING. */
data class ToolDeclaration(
    val name: String,
    val description: String,
    val params: List<ToolParam> = emptyList(),
)
