package com.Lia.assistant.ui.screens.debug

import android.os.Build
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.Lia.assistant.FlavorRoutes
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.screens.common.NovaListScreen
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.voice.EchoGuard
import com.Lia.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Live voice-session details for troubleshooting. Never shows the API key, only whether one is set. */
@Composable
fun DebugScreen(appState: NovaAppState, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val manager = VoiceSessionManager
    val active by manager.isActive.collectAsState()
    val state by manager.state.collectAsState()
    val status by manager.statusText.collectAsState()
    val muted by manager.muted.collectAsState()
    val vad by manager.vadActive.collectAsState()
    val detected by manager.detectedLanguage.collectAsState()
    val personality by manager.currentPersonality.collectAsState()
    val language by manager.currentLanguage.collectAsState()
    val lastError by manager.lastError.collectAsState()
    val connectMs by manager.latency.connectLatencyMs.collectAsState()
    val turn by manager.latency.lastTurn.collectAsState()
    val reconnects by manager.latency.reconnectCount.collectAsState()
    val hasKey by produceState(false) { value = withContext(Dispatchers.IO) { ApiKeyStore.hasKey(context) } }

    NovaListScreen(title = "Debug", subtitle = appState.assistantName, onBack = onBack, modifier = modifier) {
        item {
            NovaGlassCard(Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg)) {
                Line("Session active", active.toString())
                Line("State", state.name)
                Line("Status", status)
                Line("Muted (user)", muted.toString())
                Line("Mic muted (echo guard)", EchoGuard.isMicMuted().toString())
                Line("Voice activity", vad.toString())
                Line("Detected language", detected.name)
                Line("Personality", personality.displayName)
                Line("Language setting", language.displayName)
                Line("Last error", lastError ?: "none")
            }
        }
        item {
            NovaGlassCard(Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg)) {
                Line("Connect time", connectMs?.let { "$it ms" } ?: "n/a")
                Line("Time to first audio", turn?.timeToFirstAudioMs?.let { "$it ms" } ?: "n/a")
                Line("Audio length", turn?.audioDurationMs?.let { "$it ms" } ?: "n/a")
                Line("Turn total", turn?.totalMs?.let { "$it ms" } ?: "n/a")
                Line("Reconnects", reconnects.toString())
            }
        }
        item {
            NovaGlassCard(Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg)) {
                Line("API key set", hasKey.toString())
                Line("Android", "API ${Build.VERSION.SDK_INT}")
                Line("Edition", FlavorRoutes.flavorLabel)
                Line("Orb style", appState.orbStyle)
                Line("Reduced motion", appState.reducedMotion.toString())
            }
        }
    }
}

@Composable
private fun Line(label: String, value: String) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, style = type.caption, color = colors.textSecondary, modifier = Modifier.weight(1f))
        Text(value, style = type.label, color = colors.textPrimary, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
    }
}
