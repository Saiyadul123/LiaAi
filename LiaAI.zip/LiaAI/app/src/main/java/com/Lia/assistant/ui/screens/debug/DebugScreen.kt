package com.Lia.assistant.ui.screens.debug

import android.os.Build
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.Lia.assistant.FlavorRoutes
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.screens.common.NovaListScreen
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.voice.EchoGuard
import com.Lia.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * "Voice Pipeline Debugger": the live state of the voice session, for troubleshooting.
 * Never shows the API key (only whether one is set), and never shows what was said.
 */
@Composable
fun DebugScreen(appState: NovaAppState, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val manager = VoiceSessionManager
    val active by manager.isActive.collectAsState()
    val orb by manager.state.collectAsState()
    val status by manager.statusText.collectAsState()
    val muted by manager.muted.collectAsState()
    val vad by manager.vadActive.collectAsState()
    val detected by manager.detectedLanguage.collectAsState()
    val personality by manager.currentPersonality.collectAsState()
    val language by manager.currentLanguage.collectAsState()
    val lastError by manager.lastError.collectAsState()
    val connectMs by manager.latency.connectLatencyMs.collectAsState()
    val reconnects by manager.latency.reconnectCount.collectAsState()
    val history by manager.latency.history.collectAsState()
    val hasKey by produceState(false) { value = withContext(Dispatchers.IO) { ApiKeyStore.hasKey(context) } }

    val connection = DebugModel.connectionState(active, orb, reconnects, connectMs, lastError)
    val mic = DebugModel.micState(active, muted, EchoGuard.isMicMuted())
    val rows = DebugModel.rows(history)
    val summary = DebugModel.summary(history)

    NovaListScreen(title = "Voice Pipeline Debugger", subtitle = appState.assistantName, onBack = onBack, modifier = modifier) {
        item {
            Section("Connection") {
                Line("State", connection.label)
                Line("Status", status)
                Line("Connect time", DebugModel.formatMs(connectMs))
                Line("Reconnects", reconnects.toString())
                Line("Last error", lastError ?: "none")
            }
        }
        item {
            Section("Pipeline") {
                Line("Personality", personality.displayName)
                Line("Language setting", language.displayName)
                Line("Detected language", detected.name.lowercase().replaceFirstChar { it.uppercase() })
                Line("Voice activity (VAD)", if (vad) "Speech detected" else "Quiet")
                Line("Microphone", mic.label)
            }
        }
        item {
            Section("Turn latency") {
                Line("Turns this session", summary.turns.toString())
                Line("Average to first audio", DebugModel.formatMs(summary.averageFirstAudioMs))
                Line("Slowest to first audio", DebugModel.formatMs(summary.worstFirstAudioMs))
                if (rows.isEmpty()) {
                    Line("Per turn", "no turns yet")
                } else {
                    Header()
                    rows.forEach { Row4("#${it.number}", it.firstAudio, it.audio, it.total) }
                }
            }
        }
        item {
            Section("App") {
                Line("API key set", hasKey.toString())
                Line("Android", "API ${Build.VERSION.SDK_INT}")
                Line("Edition", FlavorRoutes.flavorLabel)
                Line("Orb style", appState.orbStyle)
                Line("Reduced motion", appState.reducedMotion.toString())
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val type = NovaTheme.typography
    val colors = NovaTheme.colors
    NovaGlassCard(Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg)) {
        Text(title, style = type.title, color = colors.textPrimary)
        Spacer(Modifier.height(NovaSpacing.sm))
        content()
    }
}

@Composable
private fun Line(label: String, value: String) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, style = type.caption, color = colors.textSecondary, modifier = Modifier.weight(1f))
        Text(value, style = type.label, color = colors.textPrimary, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun Header() = Row4("Turn", "First audio", "Audio", "Total", secondary = true)

@Composable
private fun Row4(a: String, b: String, c: String, d: String, secondary: Boolean = false) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val color = if (secondary) colors.textSecondary else colors.textPrimary
    val style = if (secondary) type.caption else type.label
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(a, style = style, color = color, modifier = Modifier.weight(0.7f))
        Text(b, style = style, color = color, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
        Text(c, style = style, color = color, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
        Text(d, style = style, color = color, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
    }
}
