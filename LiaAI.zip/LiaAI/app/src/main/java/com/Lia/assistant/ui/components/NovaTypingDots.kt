package com.Lia.assistant.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.theme.NovaTheme
import kotlin.math.abs
import kotlin.math.sin

/** Three softly pulsing dots ("the assistant is typing"). Static when motion is reduced. */
@Composable
fun NovaTypingDots(
    modifier: Modifier = Modifier,
    description: String = "Assistant is typing",
    color: Color = NovaTheme.colors.textSecondary,
) {
    val reduced = NovaTheme.reducedMotion
    val t = rememberInfiniteTransition(label = "dots").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
        label = "dotsPhase",
    )
    Row(
        modifier = modifier.semantics { contentDescription = description },
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(3) { index ->
            Box(
                Modifier
                    .size(8.dp)
                    .graphicsLayer {
                        val wave = if (reduced) 0.6f else 0.35f + 0.65f * abs(sin(((t.value + index * 0.2f) % 1f) * Math.PI.toFloat()))
                        alpha = wave
                        val s = if (reduced) 1f else 0.8f + 0.2f * wave
                        scaleX = s
                        scaleY = s
                    }
                    .background(color, CircleShape)
            )
        }
    }
}

/** [NovaTypingDots] inside an assistant-style bubble, for chat lists. */
@Composable
fun NovaTypingBubble(modifier: Modifier = Modifier) {
    val colors = NovaTheme.colors
    val shape = NovaTheme.shapes.bubbleAssistant
    Box(
        modifier = modifier
            .clip(shape)
            .background(colors.assistantBubble)
            .border(1.dp, colors.surfaceBorder, shape)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        NovaTypingDots()
    }
}
