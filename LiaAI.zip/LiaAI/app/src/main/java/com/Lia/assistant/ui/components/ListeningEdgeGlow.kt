package com.Lia.assistant.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.fx.NovaGlowColors
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.voice.NovaOrbState
import kotlin.math.PI
import kotlin.math.sin

internal data class EdgeGlowSpec(val color: Color, val alpha: Float)

/**
 * Colour and strength of the screen-edge glow. [breath] is a 0..1 sine used for the resting pulse.
 * IDLE is invisible; violet rests, pink speaks (louder = brighter), red signals an error.
 */
internal fun edgeGlowSpec(state: NovaOrbState, amplitude: Float, breath: Float): EdgeGlowSpec {
    val amp = amplitude.coerceIn(0f, 1f)
    val b = breath.coerceIn(0f, 1f)
    return when (state) {
        NovaOrbState.IDLE -> EdgeGlowSpec(NovaGlowColors.Violet, 0f)
        NovaOrbState.LISTENING -> EdgeGlowSpec(NovaGlowColors.Violet, 0.40f + 0.18f * b)
        NovaOrbState.THINKING -> EdgeGlowSpec(NovaGlowColors.Violet, 0.50f + 0.15f * b)
        NovaOrbState.CONNECTING -> EdgeGlowSpec(NovaGlowColors.Violet, 0.30f)
        NovaOrbState.SPEAKING -> EdgeGlowSpec(NovaGlowColors.Pink, 0.45f + 0.45f * amp)
        NovaOrbState.ERROR -> EdgeGlowSpec(NovaGlowColors.Red, 0.60f)
    }
}

private val TWO_PI = (2.0 * PI).toFloat()

/**
 * A slim (~26 dp) glow around the screen edge. It only draws; it has no opinion on where it is
 * hosted (a full-screen Dialog inside the app, or an overlay window in the direct flavor).
 */
@Composable
fun ListeningEdgeGlow(
    state: NovaOrbState,
    modifier: Modifier = Modifier,
    amplitude: Float = 0f,
) {
    val reduced = NovaTheme.reducedMotion
    val phase = rememberInfiniteTransition(label = "edgeGlow").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3200, easing = LinearEasing)),
        label = "edgeGlowPhase",
    )
    val breath = if (reduced) 0.5f else 0.5f + 0.5f * sin(phase.value * TWO_PI)
    val spec = edgeGlowSpec(state, amplitude, breath)
    val color by animateColorAsState(
        targetValue = spec.color,
        animationSpec = tween(if (reduced) 0 else NovaMotion.MEDIUM),
        label = "edgeGlowColor",
    )

    Canvas(modifier.fillMaxSize()) {
        if (spec.alpha <= 0f) return@Canvas
        val band = 26.dp.toPx()
        val strong = color.copy(alpha = spec.alpha)
        val none = Color.Transparent
        val w = size.width
        val h = size.height
        // top, bottom, left, right bands fading inward
        drawRect(Brush.verticalGradient(listOf(strong, none), startY = 0f, endY = band), size = Size(w, band))
        drawRect(
            Brush.verticalGradient(listOf(none, strong), startY = h - band, endY = h),
            topLeft = Offset(0f, h - band), size = Size(w, band),
        )
        drawRect(Brush.horizontalGradient(listOf(strong, none), startX = 0f, endX = band), size = Size(band, h))
        drawRect(
            Brush.horizontalGradient(listOf(none, strong), startX = w - band, endX = w),
            topLeft = Offset(w - band, 0f), size = Size(band, h),
        )
    }
}
