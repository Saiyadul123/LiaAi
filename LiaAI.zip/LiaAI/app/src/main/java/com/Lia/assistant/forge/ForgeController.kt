package com.Lia.assistant.forge

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.getAndUpdate

/**
 * Hand-off between "something wants the Website Forge" (chat, a voice tool call, a notification) and
 * the UI. A request stays pending until the navigation host consumes it, so it also works when the app
 * was in the background or still loading.
 */
object ForgeController {
    const val EXTRA_OPEN_FORGE = "com.Lia.assistant.extra.OPEN_FORGE"

    private val _pendingOpen = MutableStateFlow(false)
    val pendingOpen: StateFlow<Boolean> = _pendingOpen.asStateFlow()

    private val _brief = MutableStateFlow<String?>(null)
    /** What the user asked to be built, if known. */
    val brief: StateFlow<String?> = _brief.asStateFlow()

    private val _progress = MutableStateFlow(ForgeProgress.Idle)
    /** Build progress for the Forge screen (reported by the builder, which is not in this build yet). */
    val progress: StateFlow<ForgeProgress> = _progress.asStateFlow()

    /** Remembers the request and asks the UI to open the Forge. */
    fun requestOpen(brief: String? = null) {
        setBrief(brief)
        _pendingOpen.value = true
    }

    /** Remembers the request without opening anything (chat shows a chip the user taps). */
    fun setBrief(brief: String?) {
        if (!brief.isNullOrBlank()) _brief.value = brief.trim()
    }

    /** Returns true exactly once per request. */
    fun consume(): Boolean = _pendingOpen.getAndUpdate { false }

    fun updateProgress(progress: ForgeProgress) {
        _progress.value = progress
    }

    /** Stops any build and forgets the request. */
    fun cancel() {
        _progress.value = ForgeProgress.Idle
        _pendingOpen.value = false
        _brief.value = null
    }

    internal fun resetForTest() = cancel()
}
