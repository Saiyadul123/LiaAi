package com.Lia.assistant.forge

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.getAndUpdate

/**
 * Hand-off between "something wants the Website Forge" (chat, a voice tool call, a notification) and
 * the UI. A request stays pending until the navigation host consumes it, so it also works when the app
 * was in the background or still loading.
 */
object ForgeController {
    const val EXTRA_OPEN_FORGE = "com.Lia.assistant.extra.OPEN_FORGE"

    private val _pendingOpen = MutableStateFlow(false)
    val pendingOpen: StateFlow<Boolean> = _pendingOpen.asStateFlow()

    private val _brief = MutableStateFlow<String?>(null)
    /** What the user asked to be built, if known. */
    val brief: StateFlow<String?> = _brief.asStateFlow()

    fun requestOpen(brief: String? = null) {
        if (!brief.isNullOrBlank()) _brief.value = brief.trim()
        _pendingOpen.value = true
    }

    /** Returns true exactly once per request. */
    fun consume(): Boolean = _pendingOpen.getAndUpdate { false }

    internal fun resetForTest() {
        _pendingOpen.value = false
        _brief.value = null
    }
}
