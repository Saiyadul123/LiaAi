package com.Lia.assistant.forge

/** Cleaning up, repairing and protecting the HTML the model writes. */
object ForgeHtml {
    const val SAFETY_NET_ID = "lia-safety-net"

    private val FENCE_OPEN = Regex("^```[a-zA-Z]*[ \\t]*\\r?\\n?")

    /** Removes a Markdown code fence (and any chatter outside it). Works on text that is still streaming. */
    fun stripFences(raw: String): String {
        var t = raw.trim()
        val fenceAt = t.indexOf("```")
        // "Here is your site:" before the fence: keep only what is inside it (but never cut real markup)
        if (fenceAt > 0 && !t.substring(0, fenceAt).contains('<')) t = t.substring(fenceAt)
        val fenced = t.startsWith("```")
        if (fenced) t = t.replaceFirst(FENCE_OPEN, "")
        t = t.trimEnd()
        if (fenced) {
            // the model fenced its answer: whatever follows the closing fence is chatter
            val close = t.lastIndexOf("```")
            if (close >= 0) t = t.substring(0, close)
        } else if (t.endsWith("```")) {
            t = t.removeSuffix("```") // only a stray closing fence at the very end; a ``` inside the page stays
        }
        return t.trim()
    }

    /** True for a complete-looking page: starts like a document and has a body. */
    fun looksLikeHtml(text: String): Boolean {
        val t = stripFences(text).trimStart().lowercase()
        return (t.startsWith("<!doctype html") || t.startsWith("<html")) && t.contains("<body")
    }

    /** Closes whatever a cut-off page left open so a browser can still show it. */
    fun repairTruncated(html: String): String {
        var t = html.trimEnd()
        val lt = t.lastIndexOf('<')
        if (lt > t.lastIndexOf('>')) t = t.substring(0, lt).trimEnd() // a tag cut in half
        val lower = t.lowercase()
        val out = StringBuilder(t)
        if (lower.lastIndexOf("<script") > lower.lastIndexOf("</script")) out.append("\n</script>")
        if (lower.lastIndexOf("<style") > lower.lastIndexOf("</style")) out.append("\n</style>")
        if (!lower.contains("</body")) out.append("\n</body>")
        if (!lower.contains("</html")) out.append("\n</html>")
        return out.toString()
    }

    /**
     * Adds a small script that fades in anything stuck at opacity 0 inside the viewport for 1.4 s, in case
     * the page's own animation never ran. Safe to call twice: the page gets the script once.
     */
    fun withSafetyNet(html: String): String {
        if (html.contains("id=\"$SAFETY_NET_ID\"")) return html
        val tag = "<script id=\"$SAFETY_NET_ID\">$SAFETY_NET_JS</script>"
        val at = html.lastIndexOf("</body>", ignoreCase = true)
        return if (at >= 0) html.substring(0, at) + tag + "\n" + html.substring(at) else html + "\n" + tag
    }

    private const val SAFETY_NET_JS = """(function(){
var seen=new WeakMap(),started=Date.now(),timer=null;
function skipped(el){
  if(el.tagName==='CANVAS'||el.closest('[aria-hidden="true"]'))return true;
  var cs=getComputedStyle(el);
  return cs.position==='fixed'||cs.pointerEvents==='none';
}
function tick(){
  if(Date.now()-started>60000){clearInterval(timer);return;}
  var els=document.body?document.body.querySelectorAll('*'):[],now=Date.now();
  for(var i=0;i<els.length&&i<2000;i++){
    var el=els[i];
    if(parseFloat(getComputedStyle(el).opacity)!==0){seen.delete(el);continue;}
    var r=el.getBoundingClientRect();
    if(r.width<2||r.height<2||r.bottom<=0||r.top>=innerHeight||r.right<=0||r.left>=innerWidth){seen.delete(el);continue;}
    if(skipped(el))continue;
    var t=seen.get(el);
    if(!t){seen.set(el,now);continue;}
    if(now-t>=1400){el.style.transition='opacity .6s ease';el.style.opacity='1';seen.delete(el);}
  }
}
timer=setInterval(tick,350);
})();"""
}
