package com.Lia.assistant.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaTextField
import com.Lia.assistant.ui.screens.common.NovaListScreen
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme

@Composable
fun ProfileScreen(appState: NovaAppState, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val colors = NovaTheme.colors
    var user by remember { mutableStateOf(appState.userName) }
    var assistant by remember { mutableStateOf(appState.assistantName) }
    val changed = user.trim() != appState.userName || assistant.trim().ifEmpty { appState.assistantName } != appState.assistantName

    NovaListScreen(title = "Profile", subtitle = "You and ${appState.assistantName}", onBack = onBack, modifier = modifier) {
        item {
            Box(Modifier.fillMaxWidth().padding(vertical = NovaSpacing.md), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(96.dp)
                        .background(colors.surfaceGlass, CircleShape)
                        .border(1.dp, colors.surfaceBorder, CircleShape)
                        .semantics { contentDescription = "Your avatar" },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        user.trim().take(1).uppercase().ifEmpty { "•" },
                        style = NovaTheme.typography.display,
                        color = colors.textPrimary,
                    )
                }
            }
        }
        item {
            NovaTextField(
                value = user, onValueChange = { user = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg),
                label = "Your name", placeholder = "What should I call you?", singleLine = true,
            )
        }
        item {
            NovaTextField(
                value = assistant, onValueChange = { assistant = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg),
                label = "Assistant name", singleLine = true,
                supportingText = "Used everywhere, including when it speaks",
            )
        }
        item {
            NovaButton(
                text = "Save",
                onClick = {
                    appState.applyUserName(user)
                    appState.applyAssistantName(assistant)
                    onBack()
                },
                enabled = changed,
                modifier = Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg),
            )
        }
    }
}
