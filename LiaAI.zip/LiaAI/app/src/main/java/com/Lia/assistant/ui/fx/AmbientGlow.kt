package com.Lia.assistant.ui.fx

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.theme.LocalTilt
import com.Lia.assistant.ui.theme.NovaColorScheme
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.parallaxShiftDp
import com.Lia.assistant.voice.NovaOrbState
import kotlin.math.PI
import kotlin.math.sin

/** Colour of the layer-1 light field for each state (lagoon listening, marigold speaking, ...). */
fun ambientGlowColor(state: NovaOrbState, scheme: NovaColorScheme): Color = when (state) {
    NovaOrbState.IDLE -> NovaGlowColors.Violet
    NovaOrbState.LISTENING -> scheme.lagoon
    NovaOrbState.THINKING -> NovaGlowColors.Violet
    NovaOrbState.SPEAKING -> scheme.accent
    NovaOrbState.CONNECTING -> scheme.accentSecondary
    NovaOrbState.ERROR -> scheme.error
}

private val TWO_PI = (2.0 * PI).toFloat()

/**
 * Layer 1 of the stage: two large, soft radial light fields tinted by the live state. The colour
 * cross-fades (never snaps), the fields breathe slowly and drift a little with tilt. Gradients only, no blur.
 */
@Composable
fun AmbientGlow(
    state: NovaOrbState,
    modifier: Modifier = Modifier,
    focusY: Float = 0.38f,
    strength: Float = 1f,
) {
    val scheme = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val tilt = LocalTilt.current
    val color by animateColorAsState(
        targetValue = ambientGlowColor(state, scheme),
        animationSpec = tween(if (reduced) 0 else NovaMotion.SLOW),
        label = "ambientColor",
    )
    val breath = rememberInfiniteTransition(label = "ambient").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing)),
        label = "ambientBreath",
    )

    Canvas(modifier) {
        val t = if (reduced) Offset.Zero else tilt()
        val shift = parallaxShiftDp(1).dp.toPx()
        val pulse = if (reduced) 0.5f else 0.5f + 0.5f * sin(breath.value * TWO_PI)
        val alpha = (0.22f + 0.08f * pulse) * strength

        val big = size.maxDimension * 0.6f
        val c1 = Offset(size.width * 0.5f + t.x * shift, size.height * focusY + t.y * shift)
        drawCircle(
            brush = Brush.radialGradient(listOf(color.copy(alpha = alpha), Color.Transparent), c1, big),
            radius = big, center = c1,
        )
        val small = size.maxDimension * 0.45f
        val c2 = Offset(size.width * 0.85f - t.x * shift, size.height * 0.92f - t.y * shift)
        drawCircle(
            brush = Brush.radialGradient(listOf(color.copy(alpha = alpha * 0.6f), Color.Transparent), c2, small),
            radius = small, center = c2,
        )
    }
}
