package com.Lia.assistant.ui.screens.chat

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.voice.DetectedLanguage
import com.Lia.assistant.voice.LanguageDetector
import java.util.Locale

/** Locale used to read [text] aloud. */
fun speechLocale(language: LanguagePreference, text: String): Locale = when (language) {
    LanguagePreference.HINDI -> Locale.forLanguageTag("hi-IN")
    LanguagePreference.HINGLISH -> Locale.forLanguageTag("en-IN")
    LanguagePreference.ENGLISH -> Locale.US
    LanguagePreference.AUTO -> when (LanguageDetector.detect(text)) {
        DetectedLanguage.HINDI -> Locale.forLanguageTag("hi-IN")
        DetectedLanguage.HINGLISH -> Locale.forLanguageTag("en-IN")
        else -> Locale.getDefault()
    }
}

/**
 * One TextToSpeech engine for the chat screen: created once, shut down by the screen's
 * DisposableEffect. [speaking] and [speakingId] drive the UI.
 */
@Stable
class TtsController(context: Context) {
    var speaking by mutableStateOf(false)
        private set
    var speakingId by mutableLongStateOf(-1L)
        private set

    @Volatile private var ready = false
    private var engine: TextToSpeech? = null

    init {
        engine = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) = finish(utteranceId)
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = finish(utteranceId)
                    override fun onError(utteranceId: String?, errorCode: Int) = finish(utteranceId)
                    override fun onStop(utteranceId: String?, interrupted: Boolean) = finish(utteranceId)
                })
                ready = true
            }
        }
    }

    /** Returns false while the engine is still starting (or missing). */
    fun speak(messageId: Long, text: String, language: LanguagePreference, rate: Float = 1f): Boolean {
        val e = engine ?: return false
        if (!ready) return false
        val locale = speechLocale(language, text)
        if (e.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE) e.setLanguage(locale)
        e.setSpeechRate(rate.coerceIn(0.5f, 2f))
        speakingId = messageId
        speaking = true
        e.speak(text.take(TextToSpeech.getMaxSpeechInputLength()), TextToSpeech.QUEUE_FLUSH, null, idFor(messageId))
        return true
    }

    fun stop() {
        engine?.stop()
        speaking = false
        speakingId = -1L
    }

    fun shutdown() {
        stop()
        engine?.shutdown()
        engine = null
        ready = false
    }

    private fun idFor(messageId: Long) = "msg-$messageId"

    // Ignore callbacks from an utterance that a newer one has already replaced.
    private fun finish(utteranceId: String?) {
        if (utteranceId == idFor(speakingId)) {
            speaking = false
            speakingId = -1L
        }
    }
}
