package com.Lia.assistant

import android.app.Service
import android.content.Intent
import android.os.IBinder

/** Placeholder microphone foreground service (real implementation comes later). */
class VoiceService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopSelf(); return START_NOT_STICKY
    }
}
