package com.Lia.assistant.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.Lia.assistant.voice.VoiceSessionManager
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

// Top-level so there is exactly one DataStore instance for this file name.
private val Context.assistantStore: DataStore<Preferences> by preferencesDataStore(name = "assistant_settings")

/**
 * Personality / language / assistant name / voice settings.
 * Reads: DataStore, falling back to the legacy NovaPreferences value, then to a default.
 * Writes: DataStore AND NovaPreferences, then refreshes any live voice session.
 */
object PersonalityRepository {

    private val KEY_PERSONALITY = stringPreferencesKey("personality")
    private val KEY_LANGUAGE = stringPreferencesKey("language")
    private val KEY_ASSISTANT_NAME = stringPreferencesKey("assistant_name")
    private val KEY_VOICE_NAME = stringPreferencesKey("voice_name")

    // ---- Flows ------------------------------------------------------------------------------

    fun personality(context: Context): Flow<Personality> = read(context) { prefs, app ->
        SettingsFallback.personality(
            prefs[KEY_PERSONALITY],
            NovaPreferences.getString(app, NovaPreferences.Keys.PERSONALITY)
        )
    }

    fun language(context: Context): Flow<LanguagePreference> = read(context) { prefs, app ->
        SettingsFallback.language(
            prefs[KEY_LANGUAGE],
            NovaPreferences.getString(app, NovaPreferences.Keys.LANGUAGE)
        )
    }

    fun assistantName(context: Context): Flow<String> = read(context) { prefs, app ->
        SettingsFallback.assistantName(
            prefs[KEY_ASSISTANT_NAME],
            NovaPreferences.getString(app, NovaPreferences.Keys.ASSISTANT_NAME)
        )
    }

    fun voiceName(context: Context): Flow<String> = read(context) { prefs, app ->
        SettingsFallback.voiceName(
            prefs[KEY_VOICE_NAME],
            NovaPreferences.getString(app, NovaPreferences.Keys.VOICE_NAME)
        )
    }

    // ---- Suspend getters --------------------------------------------------------------------

    suspend fun getPersonality(context: Context): Personality = personality(context).first()
    suspend fun getLanguage(context: Context): LanguagePreference = language(context).first()
    suspend fun getAssistantName(context: Context): String = assistantName(context).first()
    suspend fun getVoiceName(context: Context): String = voiceName(context).first()

    // ---- Setters ----------------------------------------------------------------------------

    suspend fun setPersonality(context: Context, value: Personality) =
        write(context, KEY_PERSONALITY, NovaPreferences.Keys.PERSONALITY, value.name)

    suspend fun setLanguage(context: Context, value: LanguagePreference) =
        write(context, KEY_LANGUAGE, NovaPreferences.Keys.LANGUAGE, value.name)

    suspend fun setAssistantName(context: Context, value: String) =
        write(
            context, KEY_ASSISTANT_NAME, NovaPreferences.Keys.ASSISTANT_NAME,
            value.trim().ifEmpty { AssistantBrand.NAME }
        )

    suspend fun setVoiceName(context: Context, value: String) =
        write(
            context, KEY_VOICE_NAME, NovaPreferences.Keys.VOICE_NAME,
            value.trim().ifEmpty { SettingsFallback.DEFAULT_VOICE_NAME }
        )

    // ---- Internals --------------------------------------------------------------------------

    private fun <T> read(
        context: Context,
        transform: (Preferences, Context) -> T,
    ): Flow<T> {
        val app = context.applicationContext
        return app.assistantStore.data
            .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
            .map { prefs -> transform(prefs, app) }
            .distinctUntilChanged()
            .flowOn(Dispatchers.IO) // DataStore + SharedPreferences fallback never touch the main thread
    }

    private suspend fun write(
        context: Context,
        dataStoreKey: Preferences.Key<String>,
        prefsKey: String,
        value: String,
    ) {
        val app = context.applicationContext
        withContext(Dispatchers.IO) {
            app.assistantStore.edit { it[dataStoreKey] = value }
            NovaPreferences.putString(app, prefsKey, value)
            VoiceSessionManager.refreshInstructions(app)
        }
    }
}
