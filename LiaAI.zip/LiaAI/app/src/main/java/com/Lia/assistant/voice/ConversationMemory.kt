package com.Lia.assistant.voice

/**
 * Rolling window of the last [maxTurns] turns. Thread-safe, in memory only; call [clear] when the
 * voice session stops.
 */
class ConversationMemory(
    private val maxTurns: Int = MAX_TURNS,
    private val maxRecapChars: Int = MAX_RECAP_CHARS,
) {
    enum class Role { USER, ASSISTANT }
    data class Turn(val role: Role, val text: String)

    private val lock = Any()
    private val turns = ArrayDeque<Turn>()

    fun add(role: Role, text: String) {
        val clean = text.trim().replace(Regex("\\s+"), " ")
        if (clean.isEmpty()) return
        synchronized(lock) {
            turns.addLast(Turn(role, clean))
            while (turns.size > maxTurns) turns.removeFirst()
        }
    }

    fun snapshot(): List<Turn> = synchronized(lock) { turns.toList() }

    fun size(): Int = synchronized(lock) { turns.size }

    fun clear() = synchronized(lock) { turns.clear() }

    /**
     * "User: ..." / "You: ..." lines, capped to the last [maxRecapChars] characters.
     * Returns null when there is nothing to recap, so callers can omit the recap section.
     */
    fun recap(): String? {
        val current = snapshot()
        if (current.isEmpty()) return null
        val full = current.joinToString("\n") {
            (if (it.role == Role.USER) "User: " else "You: ") + it.text
        }
        return full.takeLast(maxRecapChars)
    }

    companion object {
        const val MAX_TURNS = 12
        const val MAX_RECAP_CHARS = 1600
    }
}
