package com.Lia.assistant.ui.screens.permissions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.ActivityCompat
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.screens.common.NovaListScreen
import com.Lia.assistant.ui.screens.common.RowDivider
import com.Lia.assistant.ui.screens.common.findActivity
import com.Lia.assistant.ui.screens.common.hasPermission
import com.Lia.assistant.ui.screens.common.rememberLifecycleTick
import com.Lia.assistant.ui.screens.common.settingsSection
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme

private data class PermissionItem(
    val permission: String,
    val title: String,
    val subtitle: (String) -> String,
    val icon: ImageVector,
    val minSdk: Int = 1,
)

private val permissionItems = listOf(
    PermissionItem(Manifest.permission.RECORD_AUDIO, "Microphone", { n -> "So $n can hear you in voice mode" }, Icons.Rounded.Mic),
    PermissionItem(Manifest.permission.READ_CONTACTS, "Contacts", { n -> "So $n can find who to call or message" }, Icons.Rounded.Contacts),
    PermissionItem(Manifest.permission.CALL_PHONE, "Phone calls", { _ -> "Calls start straight away; otherwise the dialer opens" }, Icons.Rounded.Call),
    PermissionItem(Manifest.permission.POST_NOTIFICATIONS, "Notifications", { n -> "Shows the notice while $n is listening" }, Icons.Rounded.Notifications, minSdk = 33),
)

/**
 * Live status of every permission with a green / amber / red light, re-read whenever the screen resumes.
 * Tap an amber one to be asked; tap a red or green one to open the app's system settings.
 */
@Composable
fun PermissionsScreen(
    appState: NovaAppState,
    onBack: () -> Unit,
    onOpenDisclosure: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val name = appState.assistantName
    val activity = remember(context) { context.findActivity() }

    val tick = rememberLifecycleTick()
    var nonce by remember { mutableIntStateOf(0) }
    val asked = remember { mutableStateListOf<String>() } // asked during this visit
    var pending by remember { mutableStateOf<String?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        pending?.let { asked.add(it) }
        pending = null
        nonce++
    }
    val refreshKey = tick * 31 + nonce

    NovaListScreen(title = "Permissions", subtitle = "What $name can use", onBack = onBack, modifier = modifier) {
        settingsSection("On this phone") {
            permissionItems.filter { Build.VERSION.SDK_INT >= it.minSdk }.forEachIndexed { index, item ->
                if (index > 0) RowDivider()
                val granted = remember(refreshKey) { hasPermission(context, item.permission) }
                val rationale = activity != null &&
                    ActivityCompat.shouldShowRequestPermissionRationale(activity, item.permission)
                val light = permissionLight(granted, item.permission in asked, rationale)
                PermissionRow(
                    title = item.title,
                    subtitle = item.subtitle(name),
                    icon = item.icon,
                    light = light,
                    onClick = {
                        if (light == PermissionLight.CAN_ASK) {
                            pending = item.permission
                            launcher.launch(item.permission)
                        } else {
                            openAppSettings(context)
                        }
                    },
                )
            }
            FlavorPermissionRows(refreshKey, name, onOpenDisclosure)
        }
        item {
            Column(Modifier.padding(horizontal = NovaSpacing.lg), verticalArrangement = Arrangement.spacedBy(NovaSpacing.sm)) {
                Text(
                    "Android only lets you turn a permission off in the app's system settings. A red light means a request will not show a dialog any more: open the settings.",
                    style = type.caption, color = colors.textSecondary,
                )
                NovaButton("Open app settings", { openAppSettings(context) }, style = NovaButtonStyle.GLASS)
            }
        }
    }
}

private fun openAppSettings(context: Context) {
    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}
