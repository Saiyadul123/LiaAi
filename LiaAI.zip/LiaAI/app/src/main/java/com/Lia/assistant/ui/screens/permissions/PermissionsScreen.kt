package com.Lia.assistant.ui.screens.permissions

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaSettingsRow
import com.Lia.assistant.ui.screens.common.NovaListScreen
import com.Lia.assistant.ui.screens.common.RowDivider
import com.Lia.assistant.ui.screens.common.hasPermission
import com.Lia.assistant.ui.screens.common.rememberLifecycleTick
import com.Lia.assistant.ui.screens.common.settingsSection
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme

private data class PermissionItem(
    val permission: String,
    val title: String,
    val subtitle: (String) -> String,
    val icon: ImageVector,
    val minSdk: Int = 1,
)

private val permissionItems = listOf(
    PermissionItem(Manifest.permission.RECORD_AUDIO, "Microphone", { n -> "So $n can hear you in voice mode" }, Icons.Rounded.Mic),
    PermissionItem(Manifest.permission.READ_CONTACTS, "Contacts", { n -> "So $n can find who to call or message" }, Icons.Rounded.Contacts),
    PermissionItem(Manifest.permission.CALL_PHONE, "Phone calls", { _ -> "Calls start straight away; otherwise the dialer opens" }, Icons.Rounded.Call),
    PermissionItem(Manifest.permission.POST_NOTIFICATIONS, "Notifications", { n -> "Shows the notice while $n is listening" }, Icons.Rounded.Notifications, minSdk = 33),
)

/** Live status of every permission, re-read whenever the screen resumes. Tap a missing one to ask for it. */
@Composable
fun PermissionsScreen(
    appState: NovaAppState,
    onBack: () -> Unit,
    onOpenDisclosure: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val name = appState.assistantName

    val tick = rememberLifecycleTick()
    var nonce by remember { mutableIntStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { nonce++ }
    val refreshKey = tick * 31 + nonce

    NovaListScreen(title = "Permissions", subtitle = "What $name can use", onBack = onBack, modifier = modifier) {
        settingsSection("On this phone") {
            permissionItems.filter { Build.VERSION.SDK_INT >= it.minSdk }.forEachIndexed { index, item ->
                if (index > 0) RowDivider()
                val granted = remember(refreshKey) { hasPermission(context, item.permission) }
                NovaSettingsRow(
                    title = item.title,
                    icon = item.icon,
                    subtitle = item.subtitle(name),
                    value = if (granted) "Allowed" else "Not allowed",
                    onClick = {
                        if (granted) openAppSettings(context) else launcher.launch(item.permission)
                    },
                )
            }
            FlavorPermissionRows(refreshKey, name, onOpenDisclosure)
        }
        item {
            Column(Modifier.padding(horizontal = NovaSpacing.lg), verticalArrangement = Arrangement.spacedBy(NovaSpacing.sm)) {
                Text(
                    "Android only lets you turn a permission off in the app's system settings. If a request does nothing, it was denied for good: open the settings.",
                    style = type.caption, color = colors.textSecondary,
                )
                NovaButton("Open app settings", { openAppSettings(context) }, style = NovaButtonStyle.SECONDARY)
            }
        }
    }
}

private fun openAppSettings(context: android.content.Context) {
    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}
