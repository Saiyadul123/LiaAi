package com.Lia.assistant.voice

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Per-turn latency bookkeeping. Marks must arrive in [Mark] order within a turn: a mark whose
 * position is not after the last accepted one (duplicate or out of order) is ignored. Skipping a
 * mark is allowed, the deltas that need it are then null. Thread-safe; never logs.
 */
class VoiceLatencyTracker(
    private val clock: () -> Long = { System.nanoTime() / 1_000_000L },
) {
    enum class Mark { USER_SPEECH_END, FIRST_AUDIO, TURN_COMPLETE }

    data class TurnLatency(
        /** USER_SPEECH_END -> FIRST_AUDIO. */
        val timeToFirstAudioMs: Long?,
        /** FIRST_AUDIO -> TURN_COMPLETE. */
        val audioDurationMs: Long?,
        /** USER_SPEECH_END -> TURN_COMPLETE. */
        val totalMs: Long?,
    )

    private val lock = Any()
    private val stamps = LongArray(Mark.entries.size) { NONE }
    private var lastOrdinal = -1

    private var connectStartAt = NONE
    private var setupDone = false

    private val _lastTurn = MutableStateFlow<TurnLatency?>(null)
    /** Published whenever a turn reaches TURN_COMPLETE. */
    val lastTurn: StateFlow<TurnLatency?> = _lastTurn.asStateFlow()

    private val _connectLatencyMs = MutableStateFlow<Long?>(null)
    /** Time from connect start to setupComplete for the latest connection. */
    val connectLatencyMs: StateFlow<Long?> = _connectLatencyMs.asStateFlow()

    private val _reconnectCount = MutableStateFlow(0)
    val reconnectCount: StateFlow<Int> = _reconnectCount.asStateFlow()

    /** Returns true if the mark was accepted. */
    fun mark(mark: Mark): Boolean = synchronized(lock) {
        if (mark.ordinal <= lastOrdinal) return false
        stamps[mark.ordinal] = clock()
        lastOrdinal = mark.ordinal
        if (mark == Mark.TURN_COMPLETE) _lastTurn.value = snapshotLocked()
        true
    }

    fun hasMark(mark: Mark): Boolean = synchronized(lock) { stamps[mark.ordinal] != NONE }

    fun timestamp(mark: Mark): Long? = synchronized(lock) { stamps[mark.ordinal].takeIf { it != NONE } }

    /** Deltas for the turn in progress (null where a mark is missing). */
    fun currentTurn(): TurnLatency = synchronized(lock) { snapshotLocked() }

    /** Starts a fresh turn: forgets the marks of the previous one. */
    fun beginTurn() = synchronized(lock) {
        stamps.fill(NONE)
        lastOrdinal = -1
    }

    fun markConnectStart() = synchronized(lock) {
        connectStartAt = clock()
        setupDone = false
        _connectLatencyMs.value = null
    }

    /** Accepted once per connect, and only after [markConnectStart]. */
    fun markSetupComplete(): Boolean = synchronized(lock) {
        if (connectStartAt == NONE || setupDone) return false
        _connectLatencyMs.value = clock() - connectStartAt
        setupDone = true
        true
    }

    fun noteReconnect() {
        _reconnectCount.value = _reconnectCount.value + 1
    }

    /** Clears everything, including the reconnect count (new voice session). */
    fun reset() = synchronized(lock) {
        stamps.fill(NONE)
        lastOrdinal = -1
        connectStartAt = NONE
        setupDone = false
        _lastTurn.value = null
        _connectLatencyMs.value = null
        _reconnectCount.value = 0
    }

    private fun snapshotLocked(): TurnLatency {
        fun delta(from: Mark, to: Mark): Long? {
            val a = stamps[from.ordinal]
            val b = stamps[to.ordinal]
            return if (a != NONE && b != NONE) b - a else null
        }
        return TurnLatency(
            timeToFirstAudioMs = delta(Mark.USER_SPEECH_END, Mark.FIRST_AUDIO),
            audioDurationMs = delta(Mark.FIRST_AUDIO, Mark.TURN_COMPLETE),
            totalMs = delta(Mark.USER_SPEECH_END, Mark.TURN_COMPLETE),
        )
    }

    private companion object {
        const val NONE = -1L
    }
}
