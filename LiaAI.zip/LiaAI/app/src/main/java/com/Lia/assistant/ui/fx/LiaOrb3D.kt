package com.Lia.assistant.ui.fx

import android.graphics.RuntimeShader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.withFrameNanos
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.isSpecified
import com.Lia.assistant.ui.components.NovaOrb
import com.Lia.assistant.ui.components.NovaOrbStyle
import com.Lia.assistant.ui.components.orbStatusDescription
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.rememberDeviceTilt
import com.Lia.assistant.voice.NovaOrbState
import kotlin.math.PI
import kotlin.math.sin

/**
 * Lia as a lit 3D sphere (AGSL shader, Android 13+) for the NOVA style; the other styles are the
 * Canvas orb on every device. Below API 33 (or if the shader fails to
 * compile) it draws the Canvas [NovaOrb] unchanged. [size] may be Dp.Unspecified to size via [modifier].
 * [amplitude] (0..1) displaces the silhouette and brightens the core; with reduced motion time is
 * frozen and the light ignores device tilt.
 */
@Composable
fun LiaOrb3D(
    state: NovaOrbState,
    size: Dp,
    amplitude: Float = 0f,
    modifier: Modifier = Modifier,
    style: NovaOrbStyle = NovaOrbStyle.NOVA,
    name: String = "Assistant",
) {
    val sized = if (size.isSpecified) modifier.size(size) else modifier
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && style == NovaOrbStyle.NOVA) {
        ShaderOrb(state, amplitude, sized, style, name)
    } else {
        NovaOrb(state = state, modifier = sized, style = style, amplitude = amplitude, name = name)
    }
}

private val TWO_PI = (2.0 * PI).toFloat()
private const val BREATH_SECONDS = 4.2f

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@Composable
private fun ShaderOrb(
    state: NovaOrbState,
    amplitude: Float,
    modifier: Modifier,
    style: NovaOrbStyle,
    name: String,
) {
    val reduced = NovaTheme.reducedMotion
    val shader = remember { runCatching { RuntimeShader(LiaOrbShader.SOURCE) }.getOrNull() }
    if (shader == null) { // AGSL failed to compile on this device: use the Canvas orb
        NovaOrb(state = state, modifier = modifier, style = style, amplitude = amplitude, name = name)
        return
    }

    val params = orbParams(state, NovaTheme.colors)
    val smoothAmplitude = animateFloatAsState(amplitude.coerceIn(0f, 1f), tween(90), label = "orbAmplitude")
    var time by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(reduced) {
        if (!reduced) {
            val start = withFrameNanos { it }
            while (true) {
                withFrameNanos { time = (it - start) / 1_000_000_000f }
            }
        }
    }
    val tilt = rememberDeviceTilt() // low-pass filtered accelerometer, unregistered on dispose; zero when reduced
    val description = orbStatusDescription(name, state)

    Canvas(modifier.semantics { contentDescription = description }) {
        val t = time
        val tiltNow = tilt()
        shader.setFloatUniform("resolution", size.width, size.height)
        shader.setFloatUniform("time", t)
        shader.setFloatUniform("amplitude", smoothAmplitude.value)
        shader.setFloatUniform("tilt", tiltNow.x, tiltNow.y)
        shader.setFloatUniform("spin", params.spin)
        shader.setFloatUniform("brightness", params.brightness)
        shader.setFloatUniform("swirl", params.swirl)
        shader.setFloatUniform("breath", sin(t * TWO_PI / BREATH_SECONDS) * params.breath)
        shader.setColorUniform("coreColor", params.colors.core.toArgb())
        shader.setColorUniform("rimColor", params.colors.rim.toArgb())
        shader.setColorUniform("haloColor", params.colors.halo.toArgb())
        drawRect(ShaderBrush(shader))
    }
}
