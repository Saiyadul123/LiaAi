package com.Lia.assistant.ui.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.forge.ForgeController
import com.Lia.assistant.ui.components.NovaOrbStyle
import com.Lia.assistant.ui.screens.about.AboutScreen
import com.Lia.assistant.ui.screens.chat.ChatScreen
import com.Lia.assistant.ui.screens.debug.DebugScreen
import com.Lia.assistant.ui.screens.forge.ForgeScreen
import com.Lia.assistant.ui.screens.history.HistoryScreen
import com.Lia.assistant.ui.screens.home.HomeScreen
import com.Lia.assistant.ui.screens.onboarding.OnboardingScreen
import com.Lia.assistant.ui.screens.orbstyle.OrbStyleScreen
import com.Lia.assistant.ui.screens.permissions.PermissionsScreen
import com.Lia.assistant.ui.screens.personality.PersonalityScreen
import com.Lia.assistant.ui.screens.privacy.PrivacyScreen
import com.Lia.assistant.ui.screens.profile.ProfileScreen
import com.Lia.assistant.ui.screens.quickactions.QuickActionsScreen
import com.Lia.assistant.ui.screens.settings.SettingsScreen
import com.Lia.assistant.ui.screens.voice.VoiceScreen
import com.Lia.assistant.ui.theme.LocalBottomBarInset
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.nightSky
import com.Lia.assistant.ui.theme.rememberDeviceTilt
import com.Lia.assistant.voice.VoiceSessionManager

/**
 * The app shell: the night sky, the navigation graph and the floating bottom bar (only on Home, Chat,
 * History and Settings). Content runs under the bar and learns its height from [LocalBottomBarInset].
 */
@Composable
fun NovaApp(appState: NovaAppState) {
    val navController = rememberNavController()
    val reduced = NovaTheme.reducedMotion
    val backStackEntry by navController.currentBackStackEntryAsState()
    val route = backStackEntry?.destination?.route
    val showBar = NovaRoutes.showsBottomBar(route)

    val voiceState by VoiceSessionManager.state.collectAsState()
    val voiceActive by VoiceSessionManager.isActive.collectAsState()
    val amplitude by VoiceSessionManager.amplitude.collectAsState()

    LaunchedEffect(appState.voiceVolume) { VoiceSessionManager.setOutputVolume(appState.voiceVolume) }

    // Someone asked for the Forge (chat, a voice tool, a notification): consume the request and open it.
    val pendingForge by ForgeController.pendingOpen.collectAsState()
    LaunchedEffect(pendingForge, appState.loaded) {
        if (appState.loaded && pendingForge && ForgeController.consume()) {
            navController.navigate(NovaRoutes.FORGE) { launchSingleTop = true }
        }
    }

    Box(Modifier.fillMaxSize().nightSky(tilt = rememberDeviceTilt())) {
        // Wait for the saved settings so the start screen (onboarding or home) is right the first time.
        if (appState.loaded) {
            val start = remember { NovaRoutes.startRoute(appState.hasOnboarded) }
            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                bottomBar = {
                    AnimatedVisibility(
                        visible = showBar,
                        enter = if (reduced) EnterTransition.None else slideInVertically(tween(NovaMotion.MEDIUM)) { it } + fadeIn(tween(NovaMotion.MEDIUM)),
                        exit = if (reduced) ExitTransition.None else slideOutVertically(tween(NovaMotion.MEDIUM)) { it } + fadeOut(tween(NovaMotion.MEDIUM)),
                    ) {
                        LiaBottomNavigation(
                            currentRoute = route,
                            assistantName = appState.assistantName,
                            orbStyle = NovaOrbStyle.fromId(appState.orbStyle),
                            voiceState = if (voiceActive) voiceState else com.Lia.assistant.voice.NovaOrbState.IDLE,
                            voiceAmplitude = amplitude,
                            onNavigate = { navController.navigateTab(it) },
                            onTalk = { navController.navigate(NovaRoutes.VOICE) { launchSingleTop = true } },
                        )
                    }
                },
            ) { inner ->
                CompositionLocalProvider(LocalBottomBarInset provides inner.calculateBottomPadding()) {
                    NovaNavHost(navController, appState, start, reduced)
                }
            }
        }
    }
}

@Composable
private fun NovaNavHost(navController: NavHostController, appState: NovaAppState, start: String, reduced: Boolean) {
    val go: (String) -> Unit = { navController.navigate(it) { launchSingleTop = true } }
    val back: () -> Unit = { navController.popBackStack() }
    val fadeSpec = tween<Float>(NovaMotion.MEDIUM)

    NavHost(
        navController = navController,
        startDestination = start,
        modifier = Modifier.fillMaxSize(),
        enterTransition = { if (reduced) EnterTransition.None else fadeIn(fadeSpec) },
        exitTransition = { if (reduced) ExitTransition.None else fadeOut(fadeSpec) },
        popEnterTransition = { if (reduced) EnterTransition.None else fadeIn(fadeSpec) },
        popExitTransition = { if (reduced) ExitTransition.None else fadeOut(fadeSpec) },
    ) {
        composable(NovaRoutes.SPLASH) {
            // Only reachable by a stale deep link: forward to the real start screen.
            LaunchedEffect(Unit) {
                navController.navigate(start) { popUpTo(NovaRoutes.SPLASH) { inclusive = true } }
            }
        }
        composable(NovaRoutes.ONBOARDING) {
            OnboardingScreen(appState, onFinished = {
                navController.navigate(NovaRoutes.HOME) { popUpTo(NovaRoutes.ONBOARDING) { inclusive = true } }
            })
        }
        composable(NovaRoutes.HOME) {
            HomeScreen(
                appState = appState,
                onTalk = { go(NovaRoutes.VOICE) },
                onType = { navController.navigateTab(NovaRoutes.CHAT) },
                onProfile = { go(NovaRoutes.PROFILE) },
                onQuickActions = { go(NovaRoutes.QUICK_ACTIONS) },
            )
        }
        composable(
            route = NovaRoutes.CHAT_PATTERN,
            arguments = listOf(
                navArgument(NovaRoutes.ARG_CONVERSATION) { type = NavType.StringType; nullable = true; defaultValue = null },
                navArgument(NovaRoutes.ARG_PROMPT) { type = NavType.StringType; nullable = true; defaultValue = null },
            ),
        ) { entry ->
            ChatScreen(
                appState = appState,
                conversationId = entry.arguments?.getString(NovaRoutes.ARG_CONVERSATION),
                initialPrompt = entry.arguments?.getString(NovaRoutes.ARG_PROMPT),
            )
        }
        composable(NovaRoutes.HISTORY) {
            HistoryScreen(
                appState = appState,
                onOpen = { go(NovaRoutes.chat(conversationId = it)) },
                onStartChat = { navController.navigateTab(NovaRoutes.CHAT) },
            )
        }
        composable(NovaRoutes.SETTINGS) { SettingsScreen(appState, onNavigate = go) }
        composable(NovaRoutes.VOICE) {
            VoiceScreen(
                appState = appState,
                onClose = back,
                onOpenSettings = { navController.navigateTab(NovaRoutes.SETTINGS) },
            )
        }
        composable(NovaRoutes.QUICK_ACTIONS) { QuickActionsScreen(onBack = back) }
        composable(NovaRoutes.PROFILE) { ProfileScreen(appState, onBack = back) }
        composable(NovaRoutes.PERSONALITY) { PersonalityScreen(appState, onBack = back) }
        composable(NovaRoutes.ORB_STYLE) { OrbStyleScreen(appState, onBack = back) }
        composable(NovaRoutes.PRIVACY) { PrivacyScreen(appState, onBack = back) }
        composable(NovaRoutes.PERMISSIONS) {
            PermissionsScreen(appState, onBack = back, onOpenDisclosure = { go(NovaRoutes.ACCESSIBILITY_DISCLOSURE) })
        }
        composable(NovaRoutes.ABOUT) { AboutScreen(appState, onBack = back) }
        composable(NovaRoutes.DEBUG) { DebugScreen(appState, onBack = back) }
        composable(NovaRoutes.FORGE) { ForgeScreen(appState, onBack = back) }
        // Direct flavor: the accessibility disclosure. Play registers nothing.
        registerAccessibilityDisclosureRoute(navController, appState)
    }
}

/** Bottom-bar navigation: one instance per tab, keeping each tab's state. */
private fun NavHostController.navigateTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}
