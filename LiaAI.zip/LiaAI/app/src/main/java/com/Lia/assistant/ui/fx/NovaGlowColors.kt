package com.Lia.assistant.ui.fx

import androidx.compose.ui.graphics.Color

/** Fixed glow colours shared by the orb and the screen-edge glow. */
object NovaGlowColors {
    /** Resting violet. */
    val Violet = Color(0xFF8B5CF6)
    /** Speaking pink (the lotus). */
    val Pink = Color(0xFFFF6FAE)
    /** Error red. */
    val Red = Color(0xFFFF7A85)
}
