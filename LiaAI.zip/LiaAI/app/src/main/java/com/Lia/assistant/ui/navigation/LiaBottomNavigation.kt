package com.Lia.assistant.ui.navigation

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaOrbStyle
import com.Lia.assistant.ui.components.NovaVoiceVisualizer
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaSizes
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.depthSurface
import com.Lia.assistant.voice.NovaOrbState

/**
 * The floating glass bar (layer 4): Home, Chat, History, Settings, with the Talk orb docked in the
 * middle, raised a little above the bar in its own glass socket. It brings its own navigation-bar inset.
 */
@Composable
fun LiaBottomNavigation(
    currentRoute: String?,
    assistantName: String,
    orbStyle: NovaOrbStyle,
    voiceState: NovaOrbState,
    voiceAmplitude: Float,
    onNavigate: (String) -> Unit,
    onTalk: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val base = NovaRoutes.baseRoute(currentRoute)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(start = NovaSpacing.lg, end = NovaSpacing.lg, top = 22.dp, bottom = NovaSpacing.sm),
        contentAlignment = Alignment.Center,
    ) {
        NovaGlassCard(
            modifier = Modifier.fillMaxWidth(),
            shape = NovaTheme.shapes.pill,
            contentPadding = PaddingValues(horizontal = NovaSpacing.sm, vertical = 6.dp),
            elevation = 12.dp,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                NavItem(Icons.Rounded.Home, "Home", base == NovaRoutes.HOME, { onNavigate(NovaRoutes.HOME) }, Modifier.weight(1f))
                NavItem(Icons.Rounded.ChatBubble, "Chat", base == NovaRoutes.CHAT, { onNavigate(NovaRoutes.CHAT) }, Modifier.weight(1f))
                Spacer(Modifier.weight(1f)) // the Talk orb sits here
                NavItem(Icons.Rounded.History, "History", base == NovaRoutes.HISTORY, { onNavigate(NovaRoutes.HISTORY) }, Modifier.weight(1f))
                NavItem(Icons.Rounded.Settings, "Settings", base == NovaRoutes.SETTINGS, { onNavigate(NovaRoutes.SETTINGS) }, Modifier.weight(1f))
            }
        }
        TalkOrb(
            name = assistantName,
            style = orbStyle,
            state = voiceState,
            amplitude = voiceAmplitude,
            onClick = onTalk,
            modifier = Modifier.offset(y = (-14).dp),
        )
    }
}

@Composable
private fun NavItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = NovaTheme.colors
    val haptics = LocalHapticFeedback.current
    // The accent marks the selected (actionable) destination.
    val tint = if (selected) colors.accentText else colors.textSecondary
    Column(
        modifier = modifier
            .heightIn(min = NovaSizes.MinTouch)
            .clip(NovaTheme.shapes.small)
            .selectable(
                selected = selected,
                role = Role.Tab,
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                },
            )
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
        Text(label, style = NovaTheme.typography.caption, color = tint, maxLines = 1)
    }
}

@Composable
private fun TalkOrb(
    name: String,
    style: NovaOrbStyle,
    state: NovaOrbState,
    amplitude: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val haptics = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && !reduced) 0.96f else 1f,
        animationSpec = tween(NovaMotion.FAST),
        label = "talkPress",
    )
    val label = "Talk to $name"
    Box(
        modifier = modifier
            .size(68.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .depthSurface(CircleShape, elevation = 12.dp)
            .clip(CircleShape)
            .background(colors.surfaceGlass)
            .border(1.dp, colors.surfaceBorder, CircleShape)
            .clickable(
                interactionSource = interaction,
                indication = ripple(),
                onClickLabel = label,
                role = Role.Button,
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                },
            )
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        NovaVoiceVisualizer(state = state, modifier = Modifier.size(60.dp), amplitude = amplitude, style = style, name = name)
    }
}
