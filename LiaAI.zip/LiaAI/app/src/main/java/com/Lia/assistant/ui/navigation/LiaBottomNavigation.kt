package com.Lia.assistant.ui.navigation

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaOrbStyle
import com.Lia.assistant.ui.components.NovaVoiceVisualizer
import com.Lia.assistant.ui.theme.NovaSizes
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.voice.NovaOrbState

/**
 * The floating glass bar: Home, Chat, the Talk orb in the middle (opens Voice), History, Settings.
 * It brings its own navigation-bar inset, so the host just places it at the bottom.
 */
@Composable
fun LiaBottomNavigation(
    currentRoute: String?,
    assistantName: String,
    orbStyle: NovaOrbStyle,
    voiceState: NovaOrbState,
    voiceAmplitude: Float,
    onNavigate: (String) -> Unit,
    onTalk: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val base = NovaRoutes.baseRoute(currentRoute)
    NovaGlassCard(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm),
        shape = NovaTheme.shapes.pill,
        contentPadding = PaddingValues(horizontal = NovaSpacing.sm, vertical = 6.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            NavItem(Icons.Rounded.Home, "Home", base == NovaRoutes.HOME, { onNavigate(NovaRoutes.HOME) }, Modifier.weight(1f))
            NavItem(Icons.Rounded.ChatBubble, "Chat", base == NovaRoutes.CHAT, { onNavigate(NovaRoutes.CHAT) }, Modifier.weight(1f))
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                TalkOrb(assistantName, orbStyle, voiceState, voiceAmplitude, onTalk)
            }
            NavItem(Icons.Rounded.History, "History", base == NovaRoutes.HISTORY, { onNavigate(NovaRoutes.HISTORY) }, Modifier.weight(1f))
            NavItem(Icons.Rounded.Settings, "Settings", base == NovaRoutes.SETTINGS, { onNavigate(NovaRoutes.SETTINGS) }, Modifier.weight(1f))
        }
    }
}

@Composable
private fun NavItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = NovaTheme.colors
    // The accent marks the selected (actionable) destination.
    val tint = if (selected) colors.accentText else colors.textSecondary
    Column(
        modifier = modifier
            .heightIn(min = NovaSizes.MinTouch)
            .clip(NovaTheme.shapes.small)
            .selectable(selected = selected, role = Role.Tab, onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
        Text(label, style = NovaTheme.typography.caption, color = tint, maxLines = 1)
    }
}

@Composable
private fun TalkOrb(
    name: String,
    style: NovaOrbStyle,
    state: NovaOrbState,
    amplitude: Float,
    onClick: () -> Unit,
) {
    val label = "Talk to $name"
    Box(
        modifier = Modifier
            .size(60.dp)
            .clip(CircleShape)
            .clickable(onClickLabel = label, role = Role.Button, onClick = onClick)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        NovaVoiceVisualizer(state = state, modifier = Modifier.size(60.dp), amplitude = amplitude, style = style, name = name)
    }
}
