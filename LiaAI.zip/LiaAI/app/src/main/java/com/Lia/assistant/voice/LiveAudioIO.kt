package com.Lia.assistant.voice

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AudioEffect
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Process
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Microphone capture (16 kHz PCM16 mono) and speaker playback (24 kHz PCM16 mono) for the live
 * voice session.
 *
 * - Mic callbacks run on a dedicated audio thread and must not throw or block. They are called
 *   even while [EchoGuard] has the mic muted (so the UI can keep animating); gating what is sent
 *   to the server is the caller's job.
 * - [playChunk] performs a blocking write: call it from a background thread, never the main thread.
 * - The caller must hold RECORD_AUDIO before [startMic].
 * - Nothing in the audio path logs.
 */
class LiveAudioIO(
    private val onMicChunk: (ByteArray) -> Unit,
    private val onMicAmplitude: (Float) -> Unit,
) {
    private val micLock = Any()
    private var mic: MicSession? = null

    private val trackLock = Any()
    @Volatile private var track: AudioTrack? = null
    @Volatile private var volume = 1f

    val isMicRunning: Boolean get() = synchronized(micLock) { mic != null }

    // ---- Microphone -------------------------------------------------------------------------

    /** Starts capture. Returns false if the recorder could not be created or started. */
    @SuppressLint("MissingPermission")
    fun startMic(): Boolean {
        return synchronized(micLock) {
            if (mic != null) return true

            val record = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    MIC_SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    micBufferSize(
                        AudioRecord.getMinBufferSize(
                            MIC_SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                        )
                    )
                )
            } catch (_: RuntimeException) { // includes SecurityException
                return false
            }

            if (record.state != AudioRecord.STATE_INITIALIZED) {
                record.release()
                return false
            }

            val effects = attachEffects(record.audioSessionId)
            try {
                record.startRecording()
            } catch (_: IllegalStateException) {
                effects.forEach { runCatching { it.release() } }
                record.release()
                return false
            }

            val session = MicSession(record, effects)
            mic = session
            session.start()
            true
        }
    }

    /** Stops capture. The audio thread releases the recorder and effects itself. */
    fun stopMic() {
        synchronized(micLock) {
            mic?.requestStop()
            mic = null
        }
    }

    private fun attachEffects(sessionId: Int): List<AudioEffect> {
        val effects = ArrayList<AudioEffect>(3)
        try {
            if (AcousticEchoCanceler.isAvailable()) {
                AcousticEchoCanceler.create(sessionId)?.let { it.setEnabled(true); effects += it }
            }
        } catch (_: RuntimeException) { }
        try {
            if (NoiseSuppressor.isAvailable()) {
                NoiseSuppressor.create(sessionId)?.let { it.setEnabled(true); effects += it }
            }
        } catch (_: RuntimeException) { }
        try {
            if (AutomaticGainControl.isAvailable()) {
                AutomaticGainControl.create(sessionId)?.let { it.setEnabled(true); effects += it }
            }
        } catch (_: RuntimeException) { }
        return effects
    }

    private inner class MicSession(
        private val record: AudioRecord,
        private val effects: List<AudioEffect>,
    ) : Thread("lia-mic") {

        @Volatile private var active = true

        init { isDaemon = true }

        fun requestStop() {
            active = false
            try { record.stop() } catch (_: IllegalStateException) { } // unblocks a pending read
        }

        override fun run() {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val buffer = ByteArray(MIC_CHUNK_BYTES)
            try {
                while (active) {
                    val n = record.read(buffer, 0, buffer.size)
                    if (n > 0) {
                        if (!active) break
                        val chunk = buffer.copyOf(n) // consumers may hold on to it
                        onMicChunk(chunk)
                        onMicAmplitude(rms(chunk, n))
                    } else if (n < 0) {
                        break
                    }
                }
            } finally {
                effects.forEach { runCatching { it.release() } }
                try { record.stop() } catch (_: IllegalStateException) { }
                record.release()
            }
        }
    }

    // ---- Speaker ----------------------------------------------------------------------------

    /** Plays a 24 kHz PCM16 mono chunk (blocking write) and returns that chunk's RMS level 0..1. */
    fun playChunk(bytes: ByteArray): Float {
        val len = bytes.size and 1.inv() // whole samples only
        if (len == 0) return 0f
        val level = rms(bytes, len)
        val t = ensureTrack() ?: return level
        var offset = 0
        while (offset < len) {
            val written = try {
                t.write(bytes, offset, len - offset)
            } catch (_: IllegalStateException) {
                -1
            }
            if (written <= 0) break
            offset += written
        }
        return level
    }

    /** Drops queued audio immediately (used when the user interrupts). */
    fun flushPlayback() {
        val t = track ?: return
        try {
            t.pause()
            t.flush()
            t.play()
        } catch (_: IllegalStateException) { }
    }

    fun setVolume(value: Float) {
        val v = value.coerceIn(0f, 1f)
        volume = v
        try { track?.setVolume(v) } catch (_: IllegalStateException) { }
    }

    /** Stops the mic and frees the speaker. The instance may be reused; the track is recreated lazily. */
    fun release() {
        stopMic()
        synchronized(trackLock) {
            val t = track
            track = null
            if (t != null) {
                try { t.pause(); t.flush() } catch (_: IllegalStateException) { }
                t.release()
            }
        }
    }

    private fun ensureTrack(): AudioTrack? {
        track?.let { return it }
        return synchronized(trackLock) {
            track?.let { return it }
            try {
                val minBuf = AudioTrack.getMinBufferSize(
                    SPEAKER_SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                val t = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANT)          // NOT VOICE_COMMUNICATION
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(SPEAKER_SAMPLE_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .build()
                    )
                    .setBufferSizeInBytes(speakerBufferSize(minBuf))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                t.setVolume(volume)
                t.play()
                track = t
                t
            } catch (_: RuntimeException) {
                null
            }
        }
    }

    companion object {
        const val MIC_SAMPLE_RATE = 16_000
        const val SPEAKER_SAMPLE_RATE = 24_000
        const val MIC_CHUNK_BYTES = 2048
        const val MIN_MIC_BUFFER_BYTES = 4096
        private const val SPEAKER_FALLBACK_MIN_BYTES = 4800 // 100 ms at 24 kHz mono PCM16

        /** max(minBufferSize, 4096); an error code from getMinBufferSize falls back to 4096. */
        internal fun micBufferSize(minBufferSize: Int): Int = max(minBufferSize, MIN_MIC_BUFFER_BYTES)

        /** 4x the minimum buffer (latency/underrun trade-off); error codes use a 100 ms fallback. */
        internal fun speakerBufferSize(minBufferSize: Int): Int =
            (if (minBufferSize > 0) minBufferSize else SPEAKER_FALLBACK_MIN_BYTES) * 4

        /**
         * RMS of little-endian PCM16 in 0..1: sqrt(mean(s^2)) / 32768. Only whole samples within
         * the first [length] bytes are used; no allocation.
         */
        fun rms(pcm: ByteArray, length: Int = pcm.size): Float {
            val samples = minOf(length, pcm.size) / 2
            if (samples <= 0) return 0f
            var sum = 0.0
            var i = 0
            val end = samples * 2
            while (i < end) {
                val s = (pcm[i + 1].toInt() shl 8) or (pcm[i].toInt() and 0xFF)
                sum += s.toDouble() * s
                i += 2
            }
            return (sqrt(sum / samples) / 32768.0).toFloat().coerceIn(0f, 1f)
        }
    }
}
