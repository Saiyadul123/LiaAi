package com.Lia.assistant.ui.screens.voice

/** What stands between the user and a running voice session. */
enum class VoiceGate { VOICE_DISABLED, NEEDS_MIC, NEEDS_KEY, READY }

object VoiceGates {
    /** Checked in this order, so the user fixes one thing at a time. */
    fun evaluate(voiceInputEnabled: Boolean, micGranted: Boolean, hasKey: Boolean): VoiceGate = when {
        !voiceInputEnabled -> VoiceGate.VOICE_DISABLED
        !micGranted -> VoiceGate.NEEDS_MIC
        !hasKey -> VoiceGate.NEEDS_KEY
        else -> VoiceGate.READY
    }
}

/** The serif line under the orb. */
object VoiceStatus {
    fun line(name: String, active: Boolean, state: com.Lia.assistant.voice.NovaOrbState, muted: Boolean): String {
        if (!active) return "$name is resting"
        if (muted && state == com.Lia.assistant.voice.NovaOrbState.LISTENING) return "Muted. $name can't hear you"
        return when (state) {
            com.Lia.assistant.voice.NovaOrbState.IDLE -> "$name is ready"
            com.Lia.assistant.voice.NovaOrbState.LISTENING -> "$name is listening…"
            com.Lia.assistant.voice.NovaOrbState.THINKING -> "$name is thinking…"
            com.Lia.assistant.voice.NovaOrbState.SPEAKING -> "$name is speaking…"
            com.Lia.assistant.voice.NovaOrbState.CONNECTING -> "Connecting to $name…"
            com.Lia.assistant.voice.NovaOrbState.ERROR -> "Something went wrong"
        }
    }
}
