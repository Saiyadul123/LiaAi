package com.Lia.assistant.ui.screens.voice

/** What stands between the user and a running voice session. */
enum class VoiceGate { VOICE_DISABLED, NEEDS_MIC, NEEDS_KEY, READY }

object VoiceGates {
    /** Checked in this order, so the user fixes one thing at a time. */
    fun evaluate(voiceInputEnabled: Boolean, micGranted: Boolean, hasKey: Boolean): VoiceGate = when {
        !voiceInputEnabled -> VoiceGate.VOICE_DISABLED
        !micGranted -> VoiceGate.NEEDS_MIC
        !hasKey -> VoiceGate.NEEDS_KEY
        else -> VoiceGate.READY
    }
}
