package com.Lia.assistant.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import kotlinx.coroutines.delay

/** What a bubble shows. [isStreaming] means the text is still arriving (a caret follows it). */
data class ChatMessage(
    val id: Long,
    val text: String,
    val isUser: Boolean,
    val isStreaming: Boolean = false,
    val isError: Boolean = false,
)

private const val CARET = "▌"
private const val CARET_BLINK_MS = 500L

/**
 * One chat bubble. Assistant bubbles show copy / speak / retry buttons (48 dp targets) for each
 * callback you pass, once the text has finished streaming. [onClick] is only active while streaming
 * (for "show the rest now").
 */
@Composable
fun NovaMessageBubble(
    message: ChatMessage,
    modifier: Modifier = Modifier,
    isSpeaking: Boolean = false,
    onCopy: (() -> Unit)? = null,
    onSpeak: (() -> Unit)? = null,
    onRetry: (() -> Unit)? = null,
    onClick: (() -> Unit)? = null,
) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val reduced = NovaTheme.reducedMotion
    val shapes = NovaTheme.shapes

    val shape = if (message.isUser) shapes.bubbleUser else shapes.bubbleAssistant
    val container = if (message.isUser) colors.userBubble else colors.assistantBubble
    val outline = when {
        message.isError -> colors.error
        message.isUser -> colors.userBubble
        else -> colors.surfaceBorder
    }

    // A discrete blink (not a per-frame animation); static when motion is reduced.
    var caretOn by remember { mutableStateOf(true) }
    LaunchedEffect(message.isStreaming, reduced) {
        caretOn = true
        while (message.isStreaming && !reduced) {
            delay(CARET_BLINK_MS)
            caretOn = !caretOn
        }
    }
    val shown = if (message.isStreaming && caretOn) message.text + CARET else message.text

    val speaker = when {
        message.isError -> "Error"
        message.isUser -> "You"
        else -> "Assistant"
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = if (message.isUser) Alignment.End else Alignment.Start,
    ) {
        Row(
            modifier = Modifier
                .widthIn(max = 320.dp)
                .clip(shape)
                .background(container)
                .border(if (message.isError) 1.5.dp else 1.dp, outline, shape)
                .then(
                    if (onClick != null && message.isStreaming) {
                        Modifier.clickable(onClickLabel = "Show full message", onClick = onClick)
                    } else {
                        Modifier
                    }
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .semantics(mergeDescendants = true) { contentDescription = "$speaker: ${message.text}" },
            verticalAlignment = Alignment.Top,
        ) {
            if (message.isError) {
                Icon(
                    Icons.Rounded.ErrorOutline,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                    tint = colors.error,
                )
                Spacer(Modifier.width(NovaSpacing.sm))
            }
            Text(text = shown, style = type.body, color = colors.textPrimary)
        }

        if (!message.isUser && !message.isStreaming && (onCopy != null || onSpeak != null || onRetry != null)) {
            Row(horizontalArrangement = Arrangement.spacedBy(0.dp), verticalAlignment = Alignment.CenterVertically) {
                if (onCopy != null) BubbleAction(Icons.Rounded.ContentCopy, "Copy message", onCopy)
                if (onSpeak != null) {
                    BubbleAction(
                        icon = if (isSpeaking) Icons.Rounded.Stop else Icons.AutoMirrored.Rounded.VolumeUp,
                        description = if (isSpeaking) "Stop speaking" else "Read aloud",
                        onClick = onSpeak,
                    )
                }
                if (onRetry != null) {
                    BubbleAction(Icons.Rounded.Refresh, if (message.isError) "Try again" else "Regenerate reply", onRetry)
                }
            }
        }
    }
}

@Composable
private fun BubbleAction(icon: ImageVector, description: String, onClick: () -> Unit) {
    IconButton(onClick = onClick) { // IconButton is 48 dp
        Icon(icon, contentDescription = description, modifier = Modifier.size(20.dp), tint = NovaTheme.colors.textSecondary)
    }
}
