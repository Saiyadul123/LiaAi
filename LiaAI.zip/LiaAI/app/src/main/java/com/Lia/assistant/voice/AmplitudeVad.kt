package com.Lia.assistant.voice

/** Tiny energy-based voice-activity indicator with a hold time so it does not flicker. */
internal class AmplitudeVad(
    private val threshold: Float = 0.02f,
    private val holdMs: Long = 500L,
    private val clock: () -> Long = { System.nanoTime() / 1_000_000L },
) {
    @Volatile
    var active: Boolean = false
        private set

    private var lastLoudAt = 0L

    /** Feeds one RMS reading (0..1) and returns whether speech is currently considered active. */
    @Synchronized
    fun update(rms: Float): Boolean {
        val now = clock()
        if (rms >= threshold) {
            lastLoudAt = now
            active = true
        } else if (active && now - lastLoudAt >= holdMs) {
            active = false
        }
        return active
    }

    @Synchronized
    fun reset() {
        active = false
        lastLoudAt = 0L
    }
}
