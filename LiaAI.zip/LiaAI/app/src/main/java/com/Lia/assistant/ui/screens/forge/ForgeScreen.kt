package com.Lia.assistant.ui.screens.forge

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Language
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.forge.ForgeController
import com.Lia.assistant.ui.components.NovaEmptyState
import com.Lia.assistant.ui.components.NovaTopBar

/**
 * Where "build me a website" lands. The builder itself is not part of this build yet, so this screen says
 * so plainly and keeps the user's request.
 */
@Composable
fun ForgeScreen(appState: NovaAppState, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val name = appState.assistantName
    val brief by ForgeController.brief.collectAsState()

    Column(modifier.fillMaxSize()) {
        NovaTopBar(title = "Website Forge", subtitle = name, onBack = onBack)
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            NovaEmptyState(
                title = "The Forge isn't ready yet",
                message = buildString {
                    append("$name will build websites here. That part isn't in this build yet.")
                    brief?.let { append("\n\nYour request is saved:\n“$it”") }
                },
                icon = Icons.Rounded.Language,
                actionText = "Back",
                onAction = onBack,
            )
        }
    }
}
