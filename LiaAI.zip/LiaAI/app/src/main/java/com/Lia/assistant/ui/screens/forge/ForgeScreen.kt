package com.Lia.assistant.ui.screens.forge

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.forge.ForgeController
import com.Lia.assistant.forge.ForgeProgress
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.screens.common.findActivity
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme

/**
 * The Website Forge: the reactor scene full-bleed with the system bars hidden, and only two quiet glass
 * pieces on top: the request chip and a status card (stage, big serif percent, six-segment track, four
 * stats, Cancel). No terminal, no log box. The builder itself is not in this build yet, so the card says
 * so while it is idle.
 */
@Composable
fun ForgeScreen(appState: NovaAppState, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val view = LocalView.current
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val name = appState.assistantName
    val brief by ForgeController.brief.collectAsState()
    val progress by ForgeController.progress.collectAsState()

    // Immersive while this screen is up; the bars come back when it leaves.
    DisposableEffect(Unit) {
        val window = context.findActivity()?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }

    Box(modifier.fillMaxSize()) {
        ForgeReactorScene(progress = progress, modifier = Modifier.fillMaxSize())

        // top: the request
        NovaGlassCard(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .safeDrawingPadding()
                .padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm),
            shape = NovaTheme.shapes.pill,
            contentPadding = PaddingValues(horizontal = NovaSpacing.lg, vertical = NovaSpacing.md),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Language, contentDescription = null, tint = colors.textSecondary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(NovaSpacing.md))
                Text(
                    text = brief ?: "No request yet. Ask $name by voice or chat.",
                    style = type.body,
                    color = colors.textPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }

        // bottom: the status
        NovaGlassCard(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .safeDrawingPadding()
                .fillMaxWidth()
                .padding(NovaSpacing.lg),
            elevation = 14.dp,
        ) {
            Text(progress.stageName, style = type.label, color = colors.textSecondary)
            Text(
                text = progress.percentText,
                style = type.display.copy(fontSize = 56.sp, lineHeight = 60.sp),
                color = colors.textPrimary,
            )
            Spacer(Modifier.height(NovaSpacing.sm))
            StageTrack(progress)
            Spacer(Modifier.height(NovaSpacing.lg))
            Row(Modifier.fillMaxWidth()) {
                progress.stats.take(4).forEach { stat ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(stat.value, style = type.title, color = colors.textPrimary)
                        Text(stat.label, style = type.caption, color = colors.textSecondary)
                    }
                }
            }
            if (!progress.isRunning) {
                Spacer(Modifier.height(NovaSpacing.md))
                Text(
                    "The builder isn't part of this build yet, so nothing is being made.",
                    style = type.caption, color = colors.textSecondary, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.height(NovaSpacing.sm))
            NovaButton(
                text = "Cancel",
                onClick = {
                    ForgeController.cancel()
                    onBack()
                },
                modifier = Modifier.align(Alignment.CenterHorizontally),
                style = NovaButtonStyle.TEXT,
            )
        }
    }
}

/** Six segments, one per stage; the lit ones are marigold. */
@Composable
private fun StageTrack(progress: ForgeProgress) {
    val description = if (progress.isRunning) {
        "Stage ${progress.litSegments} of ${ForgeProgress.STAGES.size}: ${progress.stageName}"
    } else {
        "No build running"
    }
    Row(
        Modifier.fillMaxWidth().semantics { contentDescription = description },
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        for (i in ForgeProgress.STAGES.indices) {
            Segment(lit = i < progress.litSegments, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun Segment(lit: Boolean, modifier: Modifier = Modifier) {
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val fill by animateColorAsState(
        targetValue = if (lit) colors.accent else colors.textTertiary.copy(alpha = 0.35f),
        animationSpec = tween(if (reduced) 0 else NovaMotion.MEDIUM),
        label = "segment",
    )
    Box(modifier.height(6.dp).background(fill, NovaTheme.shapes.pill))
}
