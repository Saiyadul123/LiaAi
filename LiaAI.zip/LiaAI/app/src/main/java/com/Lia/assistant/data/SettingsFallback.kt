package com.Lia.assistant.data

/**
 * Pure fallback rules: DataStore value -> legacy NovaPreferences value -> built-in default.
 * Kept free of Android types so they can be unit-tested on the JVM.
 */
internal object SettingsFallback {
    const val DEFAULT_VOICE_NAME = "Kore"

    fun personality(stored: String?, legacy: String?): Personality =
        Personality.fromName(stored) ?: Personality.fromName(legacy) ?: Personality.DEFAULT

    fun language(stored: String?, legacy: String?): LanguagePreference =
        LanguagePreference.fromName(stored) ?: LanguagePreference.fromName(legacy)
            ?: LanguagePreference.DEFAULT

    fun assistantName(stored: String?, legacy: String?): String =
        firstNonBlank(stored, legacy) ?: AssistantBrand.NAME

    fun voiceName(stored: String?, legacy: String?): String =
        firstNonBlank(stored, legacy) ?: DEFAULT_VOICE_NAME

    private fun firstNonBlank(vararg values: String?): String? =
        values.firstOrNull { !it.isNullOrBlank() }?.trim()
}
