package com.Lia.assistant.data

enum class LanguagePreference(val displayName: String, val description: String) {
    AUTO("Auto", "follows whatever you speak"),
    HINDI("हिन्दी", "always replies in Hindi"),
    HINGLISH("Hinglish", "Hindi and English mixed, the way you talk"),
    ENGLISH("English", "always replies in English");

    companion object {
        val DEFAULT = AUTO

        /** Parses a stored enum name; returns null for null/blank/unknown values. */
        fun fromName(name: String?): LanguagePreference? =
            entries.firstOrNull { it.name == name }
    }
}
