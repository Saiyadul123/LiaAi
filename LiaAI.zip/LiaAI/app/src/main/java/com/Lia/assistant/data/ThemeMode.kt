package com.Lia.assistant.data

enum class ThemeMode {
    SYSTEM, LIGHT, DARK;

    companion object {
        val DEFAULT = DARK
        fun fromName(name: String?): ThemeMode = entries.firstOrNull { it.name == name } ?: DEFAULT
    }
}
