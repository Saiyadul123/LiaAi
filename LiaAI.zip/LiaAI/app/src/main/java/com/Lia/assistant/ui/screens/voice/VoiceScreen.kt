package com.Lia.assistant.ui.screens.voice

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaOrbStyle
import com.Lia.assistant.ui.components.NovaTopBar
import com.Lia.assistant.ui.components.NovaVoiceVisualizer
import com.Lia.assistant.ui.screens.common.hasPermission
import com.Lia.assistant.ui.screens.common.rememberLifecycleTick
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.voice.NovaOrbState
import com.Lia.assistant.voice.VoiceForegroundService
import com.Lia.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Voice mode. Walks the user through what is missing (voice input on, microphone, API key), then starts
 * the foreground service. Closing or leaving this screen does NOT stop the session; only Stop does.
 */
@Composable
fun VoiceScreen(
    appState: NovaAppState,
    onClose: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val name = appState.assistantName

    val tick = rememberLifecycleTick()
    var permissionNonce by remember { mutableIntStateOf(0) }
    val micGranted = remember(tick, permissionNonce) { hasPermission(context, Manifest.permission.RECORD_AUDIO) }
    val hasKey by produceState(false, tick) { value = withContext(Dispatchers.IO) { ApiKeyStore.hasKey(context) } }
    val gate = VoiceGates.evaluate(appState.voiceInputEnabled, micGranted, hasKey)

    val active by VoiceSessionManager.isActive.collectAsState()
    val sessionState by VoiceSessionManager.state.collectAsState()
    val amplitude by VoiceSessionManager.amplitude.collectAsState()
    val status by VoiceSessionManager.statusText.collectAsState()
    val muted by VoiceSessionManager.muted.collectAsState()
    val lastError by VoiceSessionManager.lastError.collectAsState()

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { permissionNonce++ }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        // Notifications are nice to have (the "listening" notice); start either way.
        VoiceForegroundService.start(context)
    }

    // Start when everything is in place; the Start button bumps the nonce to start again after Stop.
    var startNonce by remember { mutableIntStateOf(1) }
    LaunchedEffect(gate, startNonce) {
        if (gate == VoiceGate.READY && startNonce > 0 && !VoiceSessionManager.isActive.value) {
            if (Build.VERSION.SDK_INT >= 33 && !hasPermission(context, Manifest.permission.POST_NOTIFICATIONS)) {
                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                VoiceForegroundService.start(context)
            }
        }
    }

    Column(modifier.fillMaxSize()) {
        NovaTopBar(title = "Voice mode", subtitle = name, onBack = onClose, backContentDescription = "Close voice mode")

        Column(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = NovaSpacing.xl),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            NovaVoiceVisualizer(
                state = if (active) sessionState else NovaOrbState.IDLE,
                modifier = Modifier.size(240.dp),
                amplitude = amplitude,
                style = NovaOrbStyle.fromId(appState.orbStyle),
                name = name,
            )
            Spacer(Modifier.height(NovaSpacing.xl))
            if (gate == VoiceGate.READY) {
                Text(
                    text = if (active) status else "Voice session stopped",
                    style = type.voice,
                    color = colors.textPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.semantics { contentDescription = "$name: ${if (active) status else "stopped"}" },
                )
                if (lastError != null) {
                    Spacer(Modifier.height(NovaSpacing.sm))
                    Text(lastError.orEmpty(), style = type.body, color = colors.error, textAlign = TextAlign.Center)
                }
            } else {
                GateCard(
                    gate = gate,
                    name = name,
                    onAllowMic = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                    onOpenSettings = onOpenSettings,
                    onEnableVoice = { appState.applyVoiceInputEnabled(true) },
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = NovaSpacing.xl, vertical = NovaSpacing.xl),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Top,
        ) {
            VoiceControl(
                icon = if (muted) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                label = if (muted) "Unmute" else "Mute",
                selected = muted,
                enabled = active,
                onClick = { VoiceSessionManager.toggleMute() },
            )
            if (active) {
                VoiceControl(Icons.Rounded.Stop, "Stop", onClick = { VoiceForegroundService.stop(context) })
            } else {
                VoiceControl(
                    icon = Icons.Rounded.PlayArrow,
                    label = "Start",
                    enabled = gate == VoiceGate.READY,
                    onClick = { startNonce++ },
                )
            }
            VoiceControl(Icons.Rounded.Close, "Close", onClick = onClose)
        }
    }
}

@Composable
private fun GateCard(
    gate: VoiceGate,
    name: String,
    onAllowMic: () -> Unit,
    onOpenSettings: () -> Unit,
    onEnableVoice: () -> Unit,
) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val (title, body, action, onAction) = when (gate) {
        VoiceGate.VOICE_DISABLED -> Quad(
            "Voice input is off", "Turn it on to talk to $name.", "Turn on", onEnableVoice,
        )
        VoiceGate.NEEDS_MIC -> Quad(
            "$name needs the microphone", "Audio is only captured while a voice session runs.", "Allow microphone", onAllowMic,
        )
        else -> Quad(
            "Add your Gemini API key", "Voice mode talks to Gemini with your own key.", "Open settings", onOpenSettings,
        )
    }
    NovaGlassCard(Modifier.fillMaxWidth()) {
        Text(title, style = type.title, color = colors.textPrimary)
        Spacer(Modifier.height(NovaSpacing.xs))
        Text(body, style = type.body, color = colors.textSecondary)
        Spacer(Modifier.height(NovaSpacing.md))
        NovaButton(action, onAction)
    }
}

private data class Quad(val title: String, val body: String, val action: String, val onAction: () -> Unit)

/** A round 64 dp control with a label underneath. */
@Composable
private fun VoiceControl(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    selected: Boolean = false,
    enabled: Boolean = true,
) {
    val colors = NovaTheme.colors
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.graphicsLayer { alpha = if (enabled) 1f else 0.4f },
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(if (selected) colors.accent else colors.surfaceGlass)
                .border(1.dp, if (selected) colors.accent else colors.surfaceBorder, CircleShape)
                .clickable(enabled = enabled, onClickLabel = label, role = Role.Button, onClick = onClick)
                .semantics { contentDescription = label },
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = if (selected) colors.onAccent else colors.textPrimary, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(NovaSpacing.xs))
        Text(label, style = NovaTheme.typography.caption, color = colors.textSecondary)
    }
}
