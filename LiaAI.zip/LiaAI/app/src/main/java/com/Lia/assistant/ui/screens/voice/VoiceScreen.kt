package com.Lia.assistant.ui.screens.voice

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaOrbStyle
import com.Lia.assistant.ui.components.NovaTopBar
import com.Lia.assistant.ui.components.NovaVoiceVisualizer
import com.Lia.assistant.ui.components.VoiceRing
import com.Lia.assistant.ui.fx.AmbientGlow
import com.Lia.assistant.ui.screens.common.hasPermission
import com.Lia.assistant.ui.screens.common.rememberLifecycleTick
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.depthSurface
import com.Lia.assistant.ui.theme.rememberStageEntrance
import com.Lia.assistant.ui.theme.stageEntrance
import com.Lia.assistant.ui.theme.tiltParallax
import com.Lia.assistant.voice.NovaOrbState
import com.Lia.assistant.voice.VoiceForegroundService
import com.Lia.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Voice mode as a full-bleed stage: the orb at 70 % of the width, a state-coloured light field, the
 * serif status line and a frosted control row. While speaking, a ring of 48 bars follows the voice.
 * Missing pieces (voice input, microphone, API key) reuse the same stage with a dim red orb and one
 * action. Closing or leaving does NOT stop the session; only Stop does.
 */
@Composable
fun VoiceScreen(
    appState: NovaAppState,
    onClose: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val name = appState.assistantName

    val tick = rememberLifecycleTick()
    var permissionNonce by remember { mutableIntStateOf(0) }
    val micGranted = remember(tick, permissionNonce) { hasPermission(context, Manifest.permission.RECORD_AUDIO) }
    val hasKey by produceState(false, tick) { value = withContext(Dispatchers.IO) { ApiKeyStore.hasKey(context) } }
    val gate = VoiceGates.evaluate(appState.voiceInputEnabled, micGranted, hasKey)

    val active by VoiceSessionManager.isActive.collectAsState()
    val sessionState by VoiceSessionManager.state.collectAsState()
    val amplitude by VoiceSessionManager.amplitude.collectAsState()
    val muted by VoiceSessionManager.muted.collectAsState()
    val lastError by VoiceSessionManager.lastError.collectAsState()

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { permissionNonce++ }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        // Notifications are nice to have (the "listening" notice); start either way.
        VoiceForegroundService.start(context)
    }

    // Start when everything is in place; the Start button bumps the nonce to start again after Stop.
    var startNonce by remember { mutableIntStateOf(1) }
    LaunchedEffect(gate, startNonce) {
        if (gate == VoiceGate.READY && startNonce > 0 && !VoiceSessionManager.isActive.value) {
            if (Build.VERSION.SDK_INT >= 33 && !hasPermission(context, Manifest.permission.POST_NOTIFICATIONS)) {
                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                VoiceForegroundService.start(context)
            }
        }
    }

    val config = LocalConfiguration.current
    val orbSize = minOf(config.screenWidthDp * 0.70f, config.screenHeightDp * 0.42f).dp
    val ready = gate == VoiceGate.READY
    val stageState = when {
        !ready -> NovaOrbState.ERROR // a dim, red-tinted orb
        active -> sessionState
        else -> NovaOrbState.IDLE
    }
    val speaking = ready && active && sessionState == NovaOrbState.SPEAKING
    val entrance = rememberStageEntrance()

    Box(modifier.fillMaxSize()) {
        AmbientGlow(state = stageState, modifier = Modifier.fillMaxSize())

        Column(Modifier.fillMaxSize()) {
            NovaTopBar(title = "Voice mode", subtitle = name, onBack = onClose, backContentDescription = "Close voice mode")

            Column(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = NovaSpacing.xl),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(
                    modifier = Modifier.size(orbSize * 1.24f).stageEntrance(entrance, start = 0.05f).tiltParallax(3),
                    contentAlignment = Alignment.Center,
                ) {
                    if (speaking) VoiceRing(amplitude = amplitude, modifier = Modifier.fillMaxSize())
                    NovaVoiceVisualizer(
                        state = stageState,
                        modifier = Modifier.size(orbSize).graphicsLayer { alpha = if (ready) 1f else 0.6f },
                        amplitude = amplitude,
                        style = NovaOrbStyle.fromId(appState.orbStyle),
                        name = name,
                    )
                }
                Spacer(Modifier.height(NovaSpacing.xl))
                Box(Modifier.stageEntrance(entrance, start = 0.25f)) {
                    if (ready) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = VoiceStatus.line(name, active, sessionState, muted),
                                style = type.voice,
                                color = colors.textPrimary,
                                textAlign = TextAlign.Center,
                            )
                            if (lastError != null) {
                                Spacer(Modifier.height(NovaSpacing.sm))
                                Text(lastError.orEmpty(), style = type.body, color = colors.error, textAlign = TextAlign.Center)
                            }
                        }
                    } else {
                        GateCard(
                            gate = gate,
                            name = name,
                            onAllowMic = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                            onOpenSettings = onOpenSettings,
                            onEnableVoice = { appState.applyVoiceInputEnabled(true) },
                        )
                    }
                }
            }

            // layer 4: the frosted control row
            NovaGlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = NovaSpacing.xl, vertical = NovaSpacing.xl)
                    .stageEntrance(entrance, start = 0.35f)
                    .tiltParallax(4),
                shape = NovaTheme.shapes.pill,
                contentPadding = PaddingValues(horizontal = NovaSpacing.xl, vertical = NovaSpacing.md),
                elevation = 12.dp,
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    VoiceControl(
                        icon = if (muted) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                        label = if (muted) "Unmute" else "Mute",
                        tone = if (muted) ControlTone.ACTIVE else ControlTone.NEUTRAL,
                        enabled = active,
                        onClick = { VoiceSessionManager.toggleMute() },
                    )
                    if (active) {
                        VoiceControl(Icons.Rounded.Stop, "Stop", ControlTone.DANGER, size = 76.dp, onClick = { VoiceForegroundService.stop(context) })
                    } else {
                        VoiceControl(
                            icon = Icons.Rounded.PlayArrow,
                            label = "Start",
                            tone = ControlTone.ACTIVE,
                            size = 76.dp,
                            enabled = ready,
                            onClick = { startNonce++ },
                        )
                    }
                    VoiceControl(Icons.Rounded.Close, "Close", ControlTone.NEUTRAL, onClick = onClose)
                }
            }
        }
    }
}

/** One clear action for whatever is missing. */
@Composable
private fun GateCard(
    gate: VoiceGate,
    name: String,
    onAllowMic: () -> Unit,
    onOpenSettings: () -> Unit,
    onEnableVoice: () -> Unit,
) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    val (title, body, action, onAction) = when (gate) {
        VoiceGate.VOICE_DISABLED -> Quad("Voice input is off", "Turn it on to talk to $name.", "Turn on", onEnableVoice)
        VoiceGate.NEEDS_MIC -> Quad("$name needs the microphone", "Audio is only captured while a voice session runs.", "Allow microphone", onAllowMic)
        else -> Quad("Add your Gemini API key", "Voice mode talks to Gemini with your own key.", "Open settings", onOpenSettings)
    }
    NovaGlassCard(Modifier.fillMaxWidth()) {
        Text(title, style = type.title, color = colors.textPrimary)
        Spacer(Modifier.height(NovaSpacing.xs))
        Text(body, style = type.body, color = colors.textSecondary)
        Spacer(Modifier.height(NovaSpacing.md))
        NovaButton(action, onAction)
    }
}

private data class Quad(val title: String, val body: String, val action: String, val onAction: () -> Unit)

private enum class ControlTone { NEUTRAL, ACTIVE, DANGER }

/** A round control with a label underneath. Stop is large and red-tinted. */
@Composable
private fun VoiceControl(
    icon: ImageVector,
    label: String,
    tone: ControlTone,
    onClick: () -> Unit,
    size: Dp = 64.dp,
    enabled: Boolean = true,
) {
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val haptics = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && !reduced) 0.96f else 1f,
        animationSpec = tween(NovaMotion.FAST),
        label = "controlPress",
    )
    val fill: Color
    val edge: Color
    val glyph: Color
    when (tone) {
        ControlTone.NEUTRAL -> { fill = colors.surfaceRaised; edge = colors.surfaceBorder; glyph = colors.textPrimary }
        ControlTone.ACTIVE -> { fill = colors.accent; edge = colors.accent; glyph = colors.onAccent }
        ControlTone.DANGER -> { fill = colors.error.copy(alpha = 0.22f); edge = colors.error; glyph = colors.error }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.graphicsLayer { alpha = if (enabled) 1f else 0.4f; scaleX = scale; scaleY = scale },
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .depthSurface(CircleShape, elevation = 6.dp)
                .clip(CircleShape)
                .background(fill)
                .border(1.dp, edge, CircleShape)
                .clickable(
                    interactionSource = interaction,
                    indication = ripple(),
                    enabled = enabled,
                    onClickLabel = label,
                    role = Role.Button,
                    onClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onClick()
                    },
                )
                .semantics { contentDescription = label },
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = glyph, modifier = Modifier.size(size * 0.44f))
        }
        Spacer(Modifier.height(NovaSpacing.xs))
        Text(label, style = NovaTheme.typography.caption, color = colors.textSecondary)
    }
}
