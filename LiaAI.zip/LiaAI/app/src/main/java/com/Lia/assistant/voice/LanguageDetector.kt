package com.Lia.assistant.voice

/** Result of [LanguageDetector.detect]. */
enum class DetectedLanguage { HINDI, HINGLISH, ENGLISH, UNKNOWN }

/**
 * Cheap, offline script/marker heuristic. NOTE: U+0900..U+097F is the Devanagari block (Hindi,
 * Marathi, ...), so it maps to HINDI. (Bengali/Bangla is U+0980..U+09FF.)
 */
object LanguageDetector {

    private val SPLIT = Regex("[^a-zA-Z']+")

    private val HINGLISH_MARKERS = setOf(
        "hai", "hain", "ho", "kya", "kyun", "kaise", "nahi", "nhi", "haan", "mujhe", "tumhe", "aap",
        "mera", "meri", "tera", "teri", "yaar", "bhai", "accha", "acha", "theek", "thik", "matlab",
        "karna", "karo", "raha", "rahi", "chahiye", "batao", "bolo", "suno", "dekho", "abhi", "phir",
        "lekin", "bahut", "bohot", "thoda", "kuch", "sab", "wala", "aur", "toh", "bhi", "aaj", "kaun",
        "kab", "kahan", "kitna", "tum", "chalo", "samajh", "hoga", "zyada", "kyunki"
    )

    fun detect(text: String): DetectedLanguage {
        if (text.isBlank()) return DetectedLanguage.UNKNOWN
        if (text.any { it.code in 0x0900..0x097F }) return DetectedLanguage.HINDI

        val words = text.lowercase().split(SPLIT).filter { it.isNotEmpty() }
        if (words.isEmpty()) return DetectedLanguage.UNKNOWN // digits/emoji only

        val hits = words.count { it in HINGLISH_MARKERS }
        return if (words.size <= 4) {
            if (hits >= 1) DetectedLanguage.HINGLISH else DetectedLanguage.ENGLISH
        } else {
            val ratio = hits.toDouble() / words.size
            if (hits >= 2 || ratio >= 0.15) DetectedLanguage.HINGLISH else DetectedLanguage.ENGLISH
        }
    }
}
