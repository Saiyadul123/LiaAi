package com.Lia.assistant.ui.screens.debug

import com.Lia.assistant.voice.NovaOrbState
import com.Lia.assistant.voice.VoiceLatencyTracker
import java.util.Locale

enum class ConnectionState(val label: String) {
    DISCONNECTED("Disconnected"),
    CONNECTING("Connecting"),
    RECONNECTING("Reconnecting"),
    CONNECTED("Connected"),
    ERROR("Error"),
}

enum class MicState(val label: String) {
    OFF("Off"),
    MUTED_BY_USER("Muted by you"),
    PAUSED_ECHO_GUARD("Paused while the assistant speaks"),
    LIVE("Listening"),
}

/** One line of the per-turn table, already formatted. */
data class TurnRow(val number: Int, val firstAudio: String, val audio: String, val total: String)

data class LatencySummary(val turns: Int, val averageFirstAudioMs: Long?, val worstFirstAudioMs: Long?)

/** What the Voice Pipeline Debugger shows, worked out from plain values so it can be tested without a device. */
object DebugModel {
    const val MAX_ROWS = 8

    fun connectionState(active: Boolean, orb: NovaOrbState, reconnects: Int, connectMs: Long?, lastError: String?): ConnectionState = when {
        !active -> if (lastError != null) ConnectionState.ERROR else ConnectionState.DISCONNECTED
        orb == NovaOrbState.ERROR -> ConnectionState.ERROR
        orb == NovaOrbState.CONNECTING ->
            if (reconnects > 0 && connectMs == null) ConnectionState.RECONNECTING else ConnectionState.CONNECTING
        else -> ConnectionState.CONNECTED
    }

    fun micState(active: Boolean, mutedByUser: Boolean, mutedByEchoGuard: Boolean): MicState = when {
        !active -> MicState.OFF
        mutedByUser -> MicState.MUTED_BY_USER
        mutedByEchoGuard -> MicState.PAUSED_ECHO_GUARD
        else -> MicState.LIVE
    }

    /** "n/a" for a missing value, "420 ms" under a second, "1.3 s" above. */
    fun formatMs(ms: Long?): String = when {
        ms == null -> "n/a"
        ms < 1_000 -> "$ms ms"
        else -> String.format(Locale.ROOT, "%.1f s", ms / 1000.0)
    }

    /** Newest turn first, at most [max] rows. */
    fun rows(history: List<VoiceLatencyTracker.TurnRecord>, max: Int = MAX_ROWS): List<TurnRow> =
        history.takeLast(max).reversed().map {
            TurnRow(it.number, formatMs(it.latency.timeToFirstAudioMs), formatMs(it.latency.audioDurationMs), formatMs(it.latency.totalMs))
        }

    fun summary(history: List<VoiceLatencyTracker.TurnRecord>): LatencySummary {
        val firstAudio = history.mapNotNull { it.latency.timeToFirstAudioMs }
        return LatencySummary(
            turns = history.size,
            averageFirstAudioMs = if (firstAudio.isEmpty()) null else Math.round(firstAudio.average()),
            worstFirstAudioMs = firstAudio.maxOrNull(),
        )
    }
}
