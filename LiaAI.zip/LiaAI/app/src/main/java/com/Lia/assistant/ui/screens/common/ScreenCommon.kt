package com.Lia.assistant.ui.screens.common

import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaSectionHeader
import com.Lia.assistant.ui.components.NovaTopBar
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.bottomBarContentPadding

/** A titled screen over the night sky: top bar plus a scrolling list that can run under the bottom bar. */
@Composable
fun NovaListScreen(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
    content: LazyListScope.() -> Unit,
) {
    Column(modifier.fillMaxSize()) {
        NovaTopBar(title = title, subtitle = subtitle, onBack = onBack, actions = actions)
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = bottomBarContentPadding(NovaSpacing.xl),
            verticalArrangement = Arrangement.spacedBy(NovaSpacing.md),
            content = content,
        )
    }
}

/** A header plus one glass card holding rows (use [RowDivider] between them). */
fun LazyListScope.settingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    item {
        Column {
            NovaSectionHeader(title)
            NovaGlassCard(
                modifier = Modifier.fillMaxWidth().padding(horizontal = NovaSpacing.lg),
                contentPadding = PaddingValues(0.dp),
                content = content,
            )
        }
    }
}

@Composable
fun RowDivider() {
    HorizontalDivider(Modifier.padding(start = NovaSpacing.lg), color = NovaTheme.colors.surfaceBorder)
}

fun hasPermission(context: Context, permission: String): Boolean =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

/** Increments every time the screen resumes, so live status (permissions, services) can be re-read. */
@Composable
fun rememberLifecycleTick(): Int {
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    return tick
}
