package com.Lia.assistant.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaSizes
import com.Lia.assistant.ui.theme.NovaTheme

/** A pill-shaped toggle chip (one of several choices). The selected chip is the marigold one. */
@Composable
fun NovaChip(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val haptics = LocalHapticFeedback.current
    val pill = NovaTheme.shapes.pill
    val fill by animateColorAsState(
        targetValue = if (selected) colors.accent else colors.surfaceGlass,
        animationSpec = tween(if (reduced) 0 else NovaMotion.FAST),
        label = "chipFill",
    )
    Box(
        modifier = modifier
            .heightIn(min = NovaSizes.MinTouch)
            .clip(pill)
            .background(fill)
            .border(1.dp, if (selected) colors.accent else colors.surfaceBorder, pill)
            .selectable(
                selected = selected,
                role = Role.RadioButton,
                onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                },
            )
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            style = NovaTheme.typography.title.copy(fontSize = 14.sp, lineHeight = 20.sp),
            color = if (selected) colors.onAccent else colors.textPrimary,
        )
    }
}
