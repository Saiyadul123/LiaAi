package com.Lia.assistant.ui.screens.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.withFrameNanos
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.AssistantBrand
import com.Lia.assistant.ui.fx.LiaOrb3D
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.nightSky
import com.Lia.assistant.voice.NovaOrbState
import kotlin.math.sin

/** Process-wide memory of whether the intro already ran. Rotation and resume never replay it. */
object SplashSession {
    @Volatile
    var played: Boolean = false

    internal fun resetForTest() {
        played = false
    }
}

/** Timing and easing of the intro, kept pure so it can be unit-tested. */
internal object SplashTiming {
    const val MIN_MS = 1800L
    const val MAX_MS = 4000L
    const val REDUCED_MIN_MS = 600L
    const val FADE_MS = 400

    fun minDuration(reduced: Boolean): Long = if (reduced) REDUCED_MIN_MS else MIN_MS

    /** Done once the app is ready and the minimum time has passed, or at the hard maximum. */
    fun shouldFinish(elapsedMs: Long, ready: Boolean, reduced: Boolean): Boolean =
        elapsedMs >= MAX_MS || (ready && elapsedMs >= minDuration(reduced))

    fun progress(elapsedMs: Long, reduced: Boolean): Float =
        (elapsedMs / minDuration(reduced).toFloat()).coerceIn(0f, 1f)

    /** The orb grows from 70 % to full size with an ease-out; with reduced motion it just sits there. */
    fun orbScale(progress: Float, reduced: Boolean): Float {
        if (reduced) return 1f
        val eased = 1f - (1f - progress.coerceIn(0f, 1f)).let { it * it * it }
        return 0.7f + 0.3f * eased
    }

    fun textAlpha(progress: Float): Float = (progress * 1.4f - 0.3f).coerceIn(0f, 1f)
}

/**
 * The 3D intro, drawn over the app while it loads. It runs once per process ([SplashSession.played]),
 * stays up until [ready] and a minimum time, fades out, then calls [onFinished] so the host can remove
 * it. Touches are swallowed while it is visible.
 */
@Composable
fun LiaSplash3D(
    ready: Boolean,
    onFinished: () -> Unit,
    modifier: Modifier = Modifier,
    assistantName: String = AssistantBrand.NAME,
) {
    val reduced = NovaTheme.reducedMotion
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    var elapsedMs by remember { mutableLongStateOf(0L) }
    val fade = remember { Animatable(1f) }
    val currentReady by rememberUpdatedState(ready)
    val currentFinished by rememberUpdatedState(onFinished)

    LaunchedEffect(Unit) {
        SplashSession.played = true
        val start = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            elapsedMs = (now - start) / 1_000_000L
            if (SplashTiming.shouldFinish(elapsedMs, currentReady, reduced)) break
        }
        fade.animateTo(0f, tween(if (reduced) 0 else SplashTiming.FADE_MS))
        currentFinished()
    }

    val progress = SplashTiming.progress(elapsedMs, reduced)
    // A little "hello" pulse once the orb has settled (none with reduced motion).
    val amplitude = if (reduced || progress < 0.5f) 0f else 0.25f + 0.2f * sin(elapsedMs / 140f)

    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer { alpha = fade.value }
            .nightSky()
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) awaitPointerEvent().changes.forEach { it.consume() }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp),
        ) {
            val orbScale = SplashTiming.orbScale(progress, reduced)
            LiaOrb3D(
                state = if (currentReady) NovaOrbState.SPEAKING else NovaOrbState.CONNECTING,
                size = 240.dp,
                amplitude = amplitude,
                modifier = Modifier.graphicsLayer {
                    scaleX = orbScale
                    scaleY = orbScale
                },
                name = assistantName,
            )
            Spacer(Modifier.height(24.dp))
            Text(
                text = assistantName,
                style = type.display,
                color = colors.textPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer { alpha = SplashTiming.textAlpha(progress) },
            )
            Text(
                text = AssistantBrand.TAGLINE,
                style = type.voice,
                color = colors.textSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer { alpha = SplashTiming.textAlpha(progress) },
            )
        }
    }
}
