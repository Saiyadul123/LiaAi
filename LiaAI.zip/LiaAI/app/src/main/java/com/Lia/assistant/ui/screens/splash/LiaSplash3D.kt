package com.Lia.assistant.ui.screens.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.withFrameNanos
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.AssistantBrand
import com.Lia.assistant.ui.fx.LiaOrb3D
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.ui.theme.StarField
import com.Lia.assistant.ui.theme.nightSky
import com.Lia.assistant.voice.NovaOrbState
import kotlin.math.sin
import kotlin.math.sqrt

/** Process-wide memory of whether the intro already ran. Rotation and resume never replay it. */
object SplashSession {
    @Volatile
    var played: Boolean = false

    internal fun resetForTest() {
        played = false
    }
}

/** Timing and easing of the intro, kept pure so it can be unit-tested. The whole intro is at most 2.2 s. */
internal object SplashTiming {
    const val MIN_MS = 1600L
    const val MAX_MS = 2200L
    const val REDUCED_MIN_MS = 600L
    const val FADE_MS = 350

    fun minDuration(reduced: Boolean): Long = if (reduced) REDUCED_MIN_MS else MIN_MS

    /** Done on a tap, once the app is ready and the minimum time has passed, or at the hard maximum. */
    fun shouldFinish(elapsedMs: Long, ready: Boolean, reduced: Boolean, skipped: Boolean = false): Boolean =
        skipped || elapsedMs >= MAX_MS || (ready && elapsedMs >= minDuration(reduced))

    fun progress(elapsedMs: Long, reduced: Boolean): Float =
        (elapsedMs / minDuration(reduced).toFloat()).coerceIn(0f, 1f)

    private fun easeOut(x: Float): Float = 1f - (1f - x.coerceIn(0f, 1f)).let { it * it * it }

    /** Stars streak outward during the first 60 % of the intro (0..1). */
    fun streakPhase(progress: Float): Float = (progress / 0.6f).coerceIn(0f, 1f)

    /** Particles gather toward the centre from 15 % to 70 % (0..1, eased). */
    fun condense(progress: Float): Float = easeOut((progress - 0.15f) / 0.55f)

    /** The orb appears from 55 % to 80 %; with reduced motion it is simply there. */
    fun orbAppear(progress: Float, reduced: Boolean): Float =
        if (reduced) 1f else ((progress - 0.55f) / 0.25f).coerceIn(0f, 1f)

    fun orbScale(progress: Float, reduced: Boolean): Float =
        if (reduced) 1f else 0.5f + 0.5f * easeOut(orbAppear(progress, false))

    fun textAlpha(progress: Float): Float = ((progress - 0.6f) / 0.3f).coerceIn(0f, 1f)
}

/**
 * The 3D intro, drawn over the app while it loads: stars streak past, particles condense into the orb at
 * the centre, the name appears in serif, then it dissolves into Home. Once per process
 * ([SplashSession.played]), at most 2.2 s, and a tap skips it. [onFinished] lets the host remove it.
 */
@Composable
fun LiaSplash3D(
    ready: Boolean,
    onFinished: () -> Unit,
    modifier: Modifier = Modifier,
    assistantName: String = AssistantBrand.NAME,
) {
    val reduced = NovaTheme.reducedMotion
    val colors = NovaTheme.colors
    val type = NovaTheme.typography
    var elapsedMs by remember { mutableLongStateOf(0L) }
    var skipped by remember { mutableStateOf(false) }
    val fade = remember { Animatable(1f) }
    val currentReady by rememberUpdatedState(ready)
    val currentSkipped by rememberUpdatedState(skipped)
    val currentFinished by rememberUpdatedState(onFinished)
    val streaks = remember { StarField.generate(90, 11L) }
    val particles = remember { StarField.generate(60, 5L) }

    LaunchedEffect(Unit) {
        SplashSession.played = true
        val start = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            elapsedMs = (now - start) / 1_000_000L
            if (SplashTiming.shouldFinish(elapsedMs, currentReady, reduced, currentSkipped)) break
        }
        fade.animateTo(0f, tween(if (reduced) 0 else SplashTiming.FADE_MS))
        currentFinished()
    }

    val progress = SplashTiming.progress(elapsedMs, reduced)
    val appear = SplashTiming.orbAppear(progress, reduced)
    val amplitude = if (reduced || progress < 0.8f) 0f else 0.25f + 0.2f * sin(elapsedMs / 140f)

    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer { alpha = fade.value }
            .nightSky()
            .pointerInput(Unit) { detectTapGestures(onTap = { skipped = true }) }
            .semantics(mergeDescendants = true) { onClick(label = "Skip intro") { skipped = true; true } },
        contentAlignment = Alignment.Center,
    ) {
        if (!reduced) {
            Canvas(Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val reach = size.maxDimension * 0.75f

                // stars streak outward from the centre
                val phase = SplashTiming.streakPhase(progress)
                if (phase < 1f) {
                    streaks.forEach { s ->
                        val dx = s.x - 0.5f
                        val dy = s.y - 0.5f
                        val len = sqrt(dx * dx + dy * dy)
                        if (len > 0.001f) {
                            val ux = dx / len
                            val uy = dy / len
                            val distance = reach * (0.15f + s.depth * 0.85f)
                            val head = distance * phase
                            val tail = distance * (phase - 0.25f).coerceAtLeast(0f)
                            drawLine(
                                color = colors.textTertiary.copy(alpha = (1f - phase) * s.alpha),
                                start = Offset(center.x + ux * tail, center.y + uy * tail),
                                end = Offset(center.x + ux * head, center.y + uy * head),
                                strokeWidth = 1.5.dp.toPx() * s.depth,
                            )
                        }
                    }
                }

                // particles gather into the orb
                val gather = SplashTiming.condense(progress)
                if (appear < 1f) {
                    particles.forEachIndexed { i, p ->
                        val from = Offset(p.x * size.width, p.y * size.height)
                        val at = Offset(from.x + (center.x - from.x) * gather, from.y + (center.y - from.y) * gather)
                        drawCircle(
                            color = (if (i % 2 == 0) colors.lotus else colors.lagoon).copy(alpha = p.alpha * (1f - appear)),
                            radius = (p.radius * 1.6f * (1.2f - 0.6f * gather)).dp.toPx(),
                            center = at,
                        )
                    }
                }
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp),
        ) {
            val orbScale = SplashTiming.orbScale(progress, reduced)
            LiaOrb3D(
                state = if (currentReady) NovaOrbState.SPEAKING else NovaOrbState.CONNECTING,
                size = 240.dp,
                amplitude = amplitude,
                modifier = Modifier.graphicsLayer {
                    scaleX = orbScale
                    scaleY = orbScale
                    alpha = appear
                },
                name = assistantName,
            )
            Spacer(Modifier.height(24.dp))
            Text(
                text = assistantName,
                style = type.display,
                color = colors.textPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer { alpha = SplashTiming.textAlpha(progress) },
            )
            Text(
                text = AssistantBrand.TAGLINE,
                style = type.voice,
                color = colors.textSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer { alpha = SplashTiming.textAlpha(progress) },
            )
        }

        Text(
            text = "Tap to skip",
            style = type.caption,
            color = colors.textTertiary,
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 24.dp),
        )
    }
}
