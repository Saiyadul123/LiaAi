package com.Lia.assistant.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.theme.NovaSizes
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.NovaTheme

/**
 * A settings line: [icon] tile, [title] and [subtitle], an optional [value], and either a switch
 * ([switch] + [onSwitchChange], the whole row toggles) or a chevron ([onClick]).
 */
@Composable
fun NovaSettingsRow(
    title: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    subtitle: String? = null,
    value: String? = null,
    switch: Boolean? = null,
    onSwitchChange: ((Boolean) -> Unit)? = null,
    onClick: (() -> Unit)? = null,
    enabled: Boolean = true,
) {
    val colors = NovaTheme.colors
    val type = NovaTheme.typography

    val interactive: Modifier = when {
        switch != null && onSwitchChange != null ->
            Modifier.toggleable(value = switch, enabled = enabled, role = Role.Switch, onValueChange = onSwitchChange)
        onClick != null -> Modifier.clickable(enabled = enabled, role = Role.Button, onClick = onClick)
        else -> Modifier
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer { alpha = if (enabled) 1f else 0.4f }
            .heightIn(min = 56.dp)
            .then(interactive)
            .padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.md),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Box(
                Modifier.size(40.dp).clip(NovaTheme.shapes.small).background(colors.surfaceRaised),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp), tint = colors.textSecondary)
            }
            Spacer(Modifier.width(NovaSpacing.lg))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(title, style = type.body.copy(fontWeight = FontWeight.Medium), color = colors.textPrimary)
            if (subtitle != null) Text(subtitle, style = type.caption, color = colors.textSecondary)
        }
        if (value != null) {
            Spacer(Modifier.width(NovaSpacing.sm))
            Text(value, style = type.body, color = colors.textSecondary)
        }
        if (switch != null) {
            Spacer(Modifier.width(NovaSpacing.md))
            Switch(
                checked = switch,
                onCheckedChange = null, // the row handles the toggle (one 48 dp+ target, one semantics node)
                enabled = enabled,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = colors.onAccent,
                    checkedTrackColor = colors.accent,
                    checkedBorderColor = colors.accent,
                    uncheckedThumbColor = colors.textSecondary,
                    uncheckedTrackColor = colors.surfaceRaised,
                    uncheckedBorderColor = colors.textTertiary,
                ),
            )
        } else if (onClick != null) {
            Icon(
                Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                contentDescription = null,
                modifier = Modifier.size(22.dp),
                tint = colors.textTertiary,
            )
        }
    }
}
