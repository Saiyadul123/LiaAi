package com.Lia.assistant.action

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Process-wide map of lowercase launcher-app label -> package name. Built once on the IO
 * dispatcher under a mutex and reused for [TTL_MS]. (On the Play flavor, package visibility comes
 * from the launcher <queries> entry in the manifest.)
 */
object InstalledAppLabelCache {
    const val TTL_MS = 15 * 60 * 1000L

    private class Snapshot(val apps: Map<String, String>, val builtAt: Long)

    private val mutex = Mutex()
    @Volatile private var snapshot: Snapshot? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Test hooks.
    internal var clock: () -> Long = { System.nanoTime() / 1_000_000L }
    internal var loader: (Context) -> Map<String, String> = { loadFromPackageManager(it) }

    /** Fire-and-forget: warms the cache in the background. */
    fun prewarm(context: Context) {
        val app = context.applicationContext ?: context
        scope.launch { get(app) }
    }

    /** Returns the cached map, rebuilding it (once, even under concurrent callers) when stale. */
    suspend fun get(context: Context): Map<String, String> {
        fresh()?.let { return it.apps }
        val app = context.applicationContext ?: context
        return mutex.withLock {
            fresh()?.let { return@withLock it.apps }
            val loaded = withContext(Dispatchers.IO) { loader(app) }
            // Never cache an empty result: it usually means the query failed.
            if (loaded.isNotEmpty()) snapshot = Snapshot(loaded, clock())
            loaded
        }
    }

    fun invalidate() {
        snapshot = null
    }

    internal fun resetForTest() {
        snapshot = null
        clock = { System.nanoTime() / 1_000_000L }
        loader = { loadFromPackageManager(it) }
    }

    private fun fresh(): Snapshot? = snapshot?.takeIf { clock() - it.builtAt < TTL_MS }

    private fun loadFromPackageManager(context: Context): Map<String, String> {
        val pm = context.packageManager ?: return emptyMap()
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = try {
            if (Build.VERSION.SDK_INT >= 33) {
                pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION") pm.queryIntentActivities(intent, 0)
            }
        } catch (_: RuntimeException) {
            emptyList()
        }
        val map = LinkedHashMap<String, String>()
        for (info in infos) {
            val label = info.loadLabel(pm)?.toString()?.trim()?.lowercase().orEmpty()
            if (label.isNotEmpty()) map.putIfAbsent(label, info.activityInfo.packageName)
        }
        return map
    }
}
