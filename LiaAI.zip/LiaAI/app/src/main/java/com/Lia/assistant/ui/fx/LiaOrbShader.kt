package com.Lia.assistant.ui.fx

/** AGSL source of the 3D orb (compiled by RuntimeShader on Android 13+). */
object LiaOrbShader {
    /** Every uniform the Kotlin side sets; kept in sync with [SOURCE] by a unit test. */
    val UNIFORMS = listOf(
        "resolution", "time", "amplitude", "tilt", "spin", "brightness", "swirl", "breath",
        "coreColor", "rimColor", "haloColor",
    )

    val SOURCE = """
        uniform float2 resolution;
        uniform float time;
        uniform float amplitude;
        uniform float2 tilt;
        uniform float spin;
        uniform float brightness;
        uniform float swirl;
        uniform float breath;
        layout(color) uniform half4 coreColor;
        layout(color) uniform half4 rimColor;
        layout(color) uniform half4 haloColor;

        float hash13(float3 p) {
            p = fract(p * 0.1031);
            p += dot(p, p.zyx + 31.32);
            return fract((p.x + p.y) * p.z);
        }

        float vnoise(float3 x) {
            float3 i = floor(x);
            float3 f = fract(x);
            f = f * f * (3.0 - 2.0 * f);
            float n000 = hash13(i);
            float n100 = hash13(i + float3(1.0, 0.0, 0.0));
            float n010 = hash13(i + float3(0.0, 1.0, 0.0));
            float n110 = hash13(i + float3(1.0, 1.0, 0.0));
            float n001 = hash13(i + float3(0.0, 0.0, 1.0));
            float n101 = hash13(i + float3(1.0, 0.0, 1.0));
            float n011 = hash13(i + float3(0.0, 1.0, 1.0));
            float n111 = hash13(i + float3(1.0, 1.0, 1.0));
            return mix(mix(mix(n000, n100, f.x), mix(n010, n110, f.x), f.y),
                       mix(mix(n001, n101, f.x), mix(n011, n111, f.x), f.y), f.z);
        }

        float fbm(float3 p) {
            float v = 0.0;
            float a = 0.5;
            for (int i = 0; i < 4; i++) {
                v += a * vnoise(p);
                p = p * 2.03 + float3(1.7, 9.2, 3.1);
                a *= 0.5;
            }
            return v;
        }

        float3 rotY(float3 p, float a) {
            float c = cos(a);
            float s = sin(a);
            return float3(c * p.x + s * p.z, p.y, -s * p.x + c * p.z);
        }

        half4 main(float2 fragCoord) {
            float minDim = min(resolution.x, resolution.y);
            float2 uv = (fragCoord - 0.5 * resolution) / (0.5 * minDim);

            // Silhouette: breathing plus voice displacement (louder = bigger and wobblier).
            float ang = atan(uv.y, uv.x);
            float r = 0.64 * (1.0 + breath + 0.12 * amplitude);
            r *= 1.0 + 0.035 * amplitude * sin(ang * 5.0 + time * 7.0);

            float d = length(uv);
            float2 p = uv / r;
            float q = dot(p, p);

            // The light follows the device tilt.
            float3 lightDir = normalize(float3(-0.45 + tilt.x * 0.9, 0.55 - tilt.y * 0.9, 0.80));

            float3 core = float3(coreColor.rgb);
            float3 rim = float3(rimColor.rgb);
            float3 halo = float3(haloColor.rgb);

            float3 sphere = float3(0.0);
            if (q < 1.0) {
                // Analytic sphere normal from the pixel position.
                float z = sqrt(1.0 - q);
                float3 n = float3(p.x, -p.y, z);
                float3 viewDir = float3(0.0, 0.0, 1.0);

                float diff = max(dot(n, lightDir), 0.0);
                float3 h = normalize(lightDir + viewDir);
                float spec = pow(max(dot(n, h), 0.0), 56.0);
                float fresnel = pow(1.0 - z, 3.0);

                // Slowly rotating, domain-warped fbm = the energy field inside the orb.
                float3 sp = rotY(n, time * 0.16 * spin) * 1.7;
                float flow = time * 0.11 * (0.6 + swirl);
                float e1 = fbm(sp + float3(0.0, flow, 0.0));
                float e = fbm(sp * 1.4 + e1 * (1.2 + 1.6 * swirl) + float3(flow, 0.0, -flow));
                e = smoothstep(0.25, 0.80, e);

                float glow = e * (0.55 + 0.9 * amplitude);
                float3 body = mix(core * 0.45, core, e);
                body = mix(body, rim, smoothstep(0.55, 1.0, e) * 0.55);

                float3 lit = body * (0.30 + 0.85 * diff) + core * glow * 0.65;
                lit += rim * fresnel * 1.25;
                lit += float3(1.0) * spec * 0.85;
                lit *= brightness * (1.0 + 0.45 * amplitude);
                sphere = clamp(lit, 0.0, 1.0);
            }

            // Anti-aliased edge and a soft halo outside the sphere.
            float px = 1.5 / (0.5 * minDim * r);
            float edge = 1.0 - smoothstep(1.0 - px, 1.0, sqrt(q));
            float haloK = exp(-max(d - r, 0.0) * 3.8) * (0.55 + 0.45 * amplitude);
            float3 haloRgb = halo * haloK * 0.7;
            float haloA = haloK * 0.7;

            float3 rgb = sphere * edge + haloRgb * (1.0 - edge);
            float a = clamp(edge + haloA * (1.0 - edge), 0.0, 1.0);
            return half4(half3(rgb), half(a));
        }
    """.trimIndent()
}
