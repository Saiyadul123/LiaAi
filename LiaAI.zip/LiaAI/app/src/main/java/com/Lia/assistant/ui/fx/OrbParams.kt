package com.Lia.assistant.ui.fx

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import com.Lia.assistant.ui.theme.NovaColorScheme
import com.Lia.assistant.voice.NovaOrbState

@Immutable
data class OrbColors(val core: Color, val rim: Color, val halo: Color)

/**
 * Everything the 3D orb shader needs besides time, tilt and amplitude.
 * [spin] scales rotation of the energy field, [swirl] how turbulent it is, [breath] is the
 * silhouette breathing amount (fraction of the radius).
 */
@Immutable
data class OrbParams(
    val colors: OrbColors,
    val spin: Float,
    val brightness: Float,
    val swirl: Float,
    val breath: Float,
)

/** The look of each state: calm lotus/violet, teal listening, fast thinking swirl, warm speaking, amber connecting, dim red error. */
fun orbParams(state: NovaOrbState, scheme: NovaColorScheme): OrbParams = when (state) {
    NovaOrbState.IDLE -> OrbParams(
        colors = OrbColors(core = NovaGlowColors.Violet, rim = scheme.lotus, halo = scheme.lotus),
        spin = 1.0f, brightness = 1.0f, swirl = 0.3f, breath = 0.012f,
    )
    NovaOrbState.LISTENING -> OrbParams(
        colors = OrbColors(core = scheme.lagoon, rim = lerp(scheme.lagoon, Color.White, 0.5f), halo = scheme.lagoon),
        spin = 1.1f, brightness = 1.05f, swirl = 0.5f, breath = 0.035f, // the breathing pulse
    )
    NovaOrbState.THINKING -> OrbParams(
        colors = OrbColors(core = NovaGlowColors.Violet, rim = scheme.lagoon, halo = NovaGlowColors.Violet),
        spin = 2.6f, brightness = 1.0f, swirl = 1.4f, breath = 0.012f,
    )
    NovaOrbState.SPEAKING -> OrbParams(
        colors = OrbColors(core = scheme.accent, rim = scheme.lotus, halo = scheme.lotus),
        spin = 1.5f, brightness = 1.1f, swirl = 0.9f, breath = 0.012f,
    )
    NovaOrbState.CONNECTING -> OrbParams(
        colors = OrbColors(core = scheme.accent, rim = scheme.accentSecondary, halo = scheme.accent),
        spin = 0.5f, brightness = 1.0f, swirl = 0.2f, breath = 0.01f,
    )
    NovaOrbState.ERROR -> OrbParams(
        colors = OrbColors(core = scheme.error, rim = scheme.error, halo = scheme.error),
        spin = 0.3f, brightness = 0.55f, swirl = 0.1f, breath = 0.005f,
    )
}
