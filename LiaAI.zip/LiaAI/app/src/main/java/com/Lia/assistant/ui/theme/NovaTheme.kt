package com.Lia.assistant.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import android.provider.Settings
import android.view.View
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.Lia.assistant.data.ThemeMode

val LocalNovaReducedMotion = staticCompositionLocalOf { false }
val LocalNovaTypography = staticCompositionLocalOf { NovaTypography.create(NovaFonts.Fallback) }
val LocalNovaShapes = staticCompositionLocalOf { NovaShapes() }

/** Access to the design tokens: `NovaTheme.colors.accent`, `NovaTheme.typography.body`, ... */
object NovaTheme {
    val colors: NovaColorScheme
        @Composable @ReadOnlyComposable get() = LocalNovaColors.current
    val typography: NovaTypography
        @Composable @ReadOnlyComposable get() = LocalNovaTypography.current
    val shapes: NovaShapes
        @Composable @ReadOnlyComposable get() = LocalNovaShapes.current
    val reducedMotion: Boolean
        @Composable @ReadOnlyComposable get() = LocalNovaReducedMotion.current
    val spacing: NovaSpacing get() = NovaSpacing
}

/**
 * The Lia AI theme. No dynamic colour: the palette is the brand. [reducedMotion] is OR-ed with the
 * system "remove animations" setting.
 */
@Composable
fun NovaTheme(
    mode: ThemeMode = ThemeMode.DARK,
    reducedMotion: Boolean = false,
    content: @Composable () -> Unit,
) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val colors = if (dark) NovaColorScheme.Dark else NovaColorScheme.Light
    val fonts = rememberNovaFonts()
    val typography = remember(fonts) { NovaTypography.create(fonts) }
    val shapes = remember { NovaShapes() }

    val context = LocalContext.current
    val systemReduced = remember(context) { animationsDisabledBySystem(context) }
    val reduced = reducedMotion || systemReduced

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect { applySystemBars(view, dark) }
    }

    MaterialTheme(
        colorScheme = colors.toMaterial(dark),
        typography = typography.toMaterial(),
        shapes = Shapes(
            extraSmall = shapes.small,
            small = shapes.small,
            medium = shapes.medium,
            large = shapes.large,
            extraLarge = shapes.large,
        ),
    ) {
        CompositionLocalProvider(
            LocalNovaColors provides colors,
            LocalNovaTypography provides typography,
            LocalNovaShapes provides shapes,
            LocalNovaReducedMotion provides reduced,
            LocalContentColor provides colors.textPrimary,
        ) {
            content()
        }
    }
}

private fun NovaColorScheme.toMaterial(dark: Boolean): ColorScheme =
    if (dark) {
        darkColorScheme(
            primary = accent, onPrimary = onAccent,
            primaryContainer = surfaceRaised, onPrimaryContainer = textPrimary,
            secondary = accentSecondary, onSecondary = onAccent,
            secondaryContainer = surfaceRaised, onSecondaryContainer = textPrimary,
            tertiary = accentSecondary, onTertiary = onAccent,
            background = background, onBackground = textPrimary,
            surface = surface, onSurface = textPrimary,
            surfaceVariant = surfaceRaised, onSurfaceVariant = textSecondary,
            surfaceTint = surface,
            inverseSurface = textPrimary, inverseOnSurface = background, inversePrimary = accent,
            error = error, onError = onAccent, errorContainer = assistantBubble, onErrorContainer = textPrimary,
            outline = textTertiary, outlineVariant = surfaceBorder, scrim = Color.Black,
            surfaceContainerLowest = background, surfaceContainerLow = surface, surfaceContainer = surface,
            surfaceContainerHigh = surfaceRaised, surfaceContainerHighest = surfaceRaised,
        )
    } else {
        lightColorScheme(
            primary = accent, onPrimary = onAccent,
            primaryContainer = surfaceRaised, onPrimaryContainer = textPrimary,
            secondary = accentSecondary, onSecondary = onAccent,
            secondaryContainer = surfaceRaised, onSecondaryContainer = textPrimary,
            tertiary = accentSecondary, onTertiary = onAccent,
            background = background, onBackground = textPrimary,
            surface = surface, onSurface = textPrimary,
            surfaceVariant = surfaceRaised, onSurfaceVariant = textSecondary,
            surfaceTint = surface,
            inverseSurface = textPrimary, inverseOnSurface = background, inversePrimary = accent,
            error = error, onError = Color.White, errorContainer = assistantBubble, onErrorContainer = textPrimary,
            outline = textTertiary, outlineVariant = surfaceBorder, scrim = Color.Black,
            surfaceContainerLowest = background, surfaceContainerLow = surface, surfaceContainer = surface,
            surfaceContainerHigh = surfaceRaised, surfaceContainerHighest = surfaceRaised,
        )
    }

private fun animationsDisabledBySystem(context: Context): Boolean = try {
    Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
} catch (_: RuntimeException) {
    false
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/**
 * Edge-to-edge: transparent bars so the night sky shows through, with status/navigation icon
 * contrast matched to the theme.
 */
@Suppress("DEPRECATION")
private fun applySystemBars(view: View, dark: Boolean) {
    val window = view.context.findActivity()?.window ?: return
    window.statusBarColor = Color.Transparent.toArgb()
    window.navigationBarColor = Color.Transparent.toArgb()
    if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
    val controller = WindowCompat.getInsetsController(window, view)
    controller.isAppearanceLightStatusBars = !dark
    controller.isAppearanceLightNavigationBars = !dark
}
