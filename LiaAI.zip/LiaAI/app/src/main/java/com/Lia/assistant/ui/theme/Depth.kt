package com.Lia.assistant.ui.theme

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

/** One star of the sky, in unit coordinates. [depth] scales the tilt parallax. */
data class Star(
    val x: Float,
    val y: Float,
    /** Radius in dp. */
    val radius: Float,
    val alpha: Float,
    val depth: Float,
    val phase: Float,
)

object StarField {
    /** A sparse, deterministic field: the same seed always gives the same sky. */
    fun generate(count: Int = 70, seed: Long = 7L): List<Star> {
        val random = Random(seed)
        return List(count.coerceAtLeast(0)) {
            Star(
                x = random.nextFloat(),
                y = random.nextFloat(),
                radius = 0.6f + random.nextFloat(),          // 0.6 .. 1.6 dp
                alpha = 0.25f + random.nextFloat() * 0.65f,  // 0.25 .. 0.9
                depth = 0.2f + random.nextFloat() * 0.8f,    // 0.2 .. 1.0
                phase = random.nextFloat(),
            )
        }
    }
}

private val TWO_PI = (2.0 * PI).toFloat()

/**
 * The night backdrop: a gradient from [NovaColorScheme.backgroundGradientTop] into the background plus a
 * sparse star field that twinkles gently (static with reduced motion). [tilt] returns the device tilt in
 * -1..1 on both axes (see [rememberDeviceTilt]) and shifts the stars for a parallax effect.
 */
fun Modifier.nightSky(tilt: (() -> Offset)? = null): Modifier = composed {
    val colors = NovaTheme.colors
    val reduced = NovaTheme.reducedMotion
    val stars = remember { StarField.generate() }
    val twinkle = rememberInfiniteTransition(label = "sky").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing)),
        label = "twinkle",
    )
    // Stars are faint on the light theme so they read as texture, not noise.
    val starStrength = if (colors.background.red > 0.5f) 0.35f else 1f

    drawBehind {
        drawRect(
            Brush.verticalGradient(
                colors = listOf(colors.backgroundGradientTop, colors.background),
                startY = 0f,
                endY = size.height * 0.75f,
            )
        )
        val t = if (reduced) 0f else twinkle.value
        val shift = tilt?.invoke() ?: Offset.Zero
        val parallax = 12.dp.toPx()
        stars.forEach { s ->
            val px = wrap(s.x * size.width + shift.x * s.depth * parallax, size.width)
            val py = wrap(s.y * size.height + shift.y * s.depth * parallax, size.height)
            val pulse = if (reduced) 1f else 0.65f + 0.35f * sin((t + s.phase) * TWO_PI)
            drawCircle(
                color = colors.textTertiary.copy(alpha = (s.alpha * pulse * starStrength).coerceIn(0f, 1f)),
                radius = s.radius.dp.toPx(),
                center = Offset(px, py),
            )
        }
    }
}

private fun wrap(value: Float, max: Float): Float = if (max <= 0f) 0f else ((value % max) + max) % max

/**
 * Raised surface: a coloured ambient shadow ([NovaColorScheme.depthShadow], API 28+) plus a thin
 * rim light along the top edge. Add the fill with `.background(...)` after this modifier.
 */
fun Modifier.depthSurface(shape: Shape, elevation: Dp = 8.dp): Modifier = composed {
    val colors = NovaTheme.colors
    this
        .shadow(elevation, shape, clip = false, ambientColor = colors.depthShadow, spotColor = colors.depthShadow)
        .drawWithContent {
            drawContent()
            val outline = shape.createOutline(size, layoutDirection, this)
            drawOutline(
                outline = outline,
                brush = Brush.verticalGradient(
                    colors = listOf(colors.rimLight, Color.Transparent),
                    endY = size.height * 0.45f,
                ),
                style = Stroke(width = 1.dp.toPx()),
            )
        }
}

/** Height of the floating bottom navigation bar, so scrolling content can run underneath it. */
val LocalBottomBarInset = compositionLocalOf { 0.dp }

/** Padding that keeps the last item clear of a floating bottom bar. */
@Composable
fun bottomBarContentPadding(extra: Dp = NovaSpacing.lg): PaddingValues =
    PaddingValues(bottom = LocalBottomBarInset.current + extra)

/**
 * Smoothed device tilt in -1..1 for [nightSky]'s parallax. Returns a lambda so only drawing (not
 * composition) reacts to sensor updates. Inactive with reduced motion or without a sensor.
 */
@Composable
fun rememberDeviceTilt(enabled: Boolean = true): () -> Offset {
    val reduced = NovaTheme.reducedMotion
    val context = LocalContext.current
    val tilt = remember { mutableStateOf(Offset.Zero) }

    DisposableEffect(enabled, reduced) {
        val manager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = manager?.getDefaultSensor(Sensor.TYPE_GRAVITY)
            ?: manager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (!enabled || reduced || manager == null || sensor == null) {
            onDispose { }
        } else {
            var sx = 0f
            var sy = 0f
            val listener = object : SensorEventListener {
                override fun onSensorChanged(event: SensorEvent) {
                    val x = (-event.values[0] / 9.81f).coerceIn(-1f, 1f)
                    val y = (event.values[1] / 9.81f).coerceIn(-1f, 1f)
                    sx += (x - sx) * 0.08f
                    sy += (y - sy) * 0.08f
                    tilt.value = Offset(sx, sy)
                }

                override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
            }
            manager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
            onDispose { manager.unregisterListener(listener) }
        }
    }
    return { tilt.value }
}
