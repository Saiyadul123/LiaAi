package com.Lia.assistant.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import com.Lia.assistant.ui.fx.LiaOrb3D
import com.Lia.assistant.voice.NovaOrbState

/**
 * The design system's "voice presence": the 3D orb on Android 13+, the Canvas [NovaOrb] below.
 * Size it with [modifier]. [style] only affects the Canvas fallback.
 */
@Composable
fun NovaVoiceVisualizer(
    state: NovaOrbState,
    modifier: Modifier = Modifier,
    amplitude: Float = 0f,
    style: NovaOrbStyle = NovaOrbStyle.NOVA,
    name: String = "Assistant",
) {
    LiaOrb3D(
        state = state,
        size = Dp.Unspecified,
        amplitude = amplitude,
        modifier = modifier,
        style = style,
        name = name,
    )
}
