package com.Lia.assistant.ui.screens.chat

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.ChatHistoryStore
import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.Personality
import com.Lia.assistant.data.StoredConversation
import com.Lia.assistant.data.StoredTurn
import com.Lia.assistant.ui.components.ChatMessage
import com.Lia.assistant.voice.ChatPromptBuilder
import com.Lia.assistant.voice.ChatReplyResult
import com.Lia.assistant.voice.ChatTurn
import com.Lia.assistant.voice.ForgeIntent
import com.Lia.assistant.voice.GeminiTextClient
import com.Lia.assistant.voice.LiaForge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import org.json.JSONObject

data class ChatSettings(
    val personality: Personality,
    val language: LanguagePreference,
    val assistantName: String,
    val saveHistory: Boolean = true,
)

data class ChatEntry(
    val id: Long,
    val isUser: Boolean,
    val text: String,
    val kind: Kind = Kind.NORMAL,
    /** Words currently shown; Int.MAX_VALUE means fully revealed. */
    val shownWords: Int = Int.MAX_VALUE,
) {
    enum class Kind { NORMAL, ERROR, FORGE }

    val wordCount: Int = RevealText.wordCount(text)
    val isRevealing: Boolean get() = !isUser && shownWords < wordCount
    val visibleText: String get() = if (shownWords >= wordCount) text else RevealText.prefix(text, shownWords)
}

/** The design-system bubble model for this entry (text shown so far, streaming while it is revealed). */
fun ChatEntry.toUi(): ChatMessage = ChatMessage(
    id = id,
    text = visibleText,
    isUser = isUser,
    isStreaming = isRevealing,
    isError = kind == ChatEntry.Kind.ERROR,
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    val messages = mutableStateListOf<ChatEntry>()

    var isTyping by mutableStateOf(false)
        private set

    private var nextId = 1L
    private var replyJob: Job? = null
    private var revealJob: Job? = null
    private var conversationId: String = UUID.randomUUID().toString()
    private var loadedConversation: String? = null
    private var historyEnabled = true

    fun send(text: String, settings: ChatSettings) {
        val clean = text.trim()
        if (clean.isEmpty() || isTyping) return
        completeReveal()
        messages += ChatEntry(newId(), isUser = true, text = clean)
        historyEnabled = settings.saveHistory
        persist()

        val forge = ForgeIntent.extract(clean)
        if (forge != null) {
            runCatching {
                LiaForge.start(getApplication<Application>(), JSONObject().put("description", forge.brief))
            }
            messages += ChatEntry(newId(), isUser = false, text = FORGE_OPENING, kind = ChatEntry.Kind.FORGE)
            return
        }
        requestReply(settings)
    }

    /** Regenerates the last assistant message (or retries after an error). */
    fun retry(settings: ChatSettings) {
        if (isTyping) return
        historyEnabled = settings.saveHistory
        completeReveal()
        val last = messages.lastOrNull()
        if (last != null && !last.isUser && last.kind != ChatEntry.Kind.FORGE) messages.removeAt(messages.lastIndex)
        if (messages.lastOrNull()?.isUser == true) requestReply(settings)
    }

    /** Tapping a bubble that is still being revealed shows the rest at once. */
    fun skipReveal(id: Long) {
        revealJob?.cancel()
        updateMessage(id) { it.copy(shownWords = Int.MAX_VALUE) }
    }

    private fun requestReply(settings: ChatSettings) {
        isTyping = true
        // Snapshot everything on the main thread before suspending.
        val history = messages.filter { it.kind != ChatEntry.Kind.ERROR }.map { ChatTurn(it.isUser, it.text) }
        val prompt = ChatPromptBuilder.build(settings.personality, settings.language, settings.assistantName)
        val app = getApplication<Application>()

        replyJob = viewModelScope.launch {
            val key = withContext(Dispatchers.IO) { ApiKeyStore.getKey(app) }
            val result = GeminiTextClient.reply(key, prompt, history)
            isTyping = false
            when (result) {
                is ChatReplyResult.Success -> addRevealed(result.text)
                is ChatReplyResult.Error ->
                    messages += ChatEntry(newId(), isUser = false, text = result.message, kind = ChatEntry.Kind.ERROR)
            }
        }
    }

    private fun addRevealed(text: String) {
        val id = newId()
        messages += ChatEntry(id, isUser = false, text = text, shownWords = 0)
        persist()
        val total = RevealText.wordCount(text)
        revealJob = viewModelScope.launch {
            for (n in 1..total) {
                delay(REVEAL_DELAY_MS)
                updateMessage(id) { it.copy(shownWords = n) }
            }
        }
    }

    private fun completeReveal() {
        revealJob?.cancel()
        val i = messages.indexOfLast { it.isRevealing }
        if (i >= 0) messages[i] = messages[i].copy(shownWords = Int.MAX_VALUE)
    }

    private fun updateMessage(id: Long, transform: (ChatEntry) -> ChatEntry) {
        val i = messages.indexOfFirst { it.id == id }
        if (i >= 0) messages[i] = transform(messages[i])
    }

    /** Reopens a saved conversation from History (once, and only into an empty chat). */
    fun loadConversation(id: String) {
        if (loadedConversation == id || messages.isNotEmpty()) return
        loadedConversation = id
        val app = getApplication<Application>()
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) { ChatHistoryStore.get(app, id) } ?: return@launch
            if (messages.isNotEmpty()) return@launch
            conversationId = saved.id
            saved.turns.forEach { messages += ChatEntry(newId(), it.isUser, it.text) }
        }
    }

    /** Saves the conversation on the device (not errors or Forge notices). Off the main thread. */
    private fun persist() {
        if (!historyEnabled) return
        val turns = messages
            .filter { it.isUser || it.kind == ChatEntry.Kind.NORMAL }
            .map { StoredTurn(it.isUser, it.text) }
        if (turns.isEmpty()) return
        val conversation = StoredConversation(conversationId, ChatHistoryStore.titleFor(turns), System.currentTimeMillis(), turns)
        val app = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) { ChatHistoryStore.save(app, conversation) }
    }

    private fun newId() = nextId++

    companion object {
        const val REVEAL_DELAY_MS = 20L
        const val FORGE_OPENING = "Opening the Forge to build that website…"
    }
}
