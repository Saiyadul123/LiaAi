package com.Lia.assistant.action

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ScreenTextTest {
    @Test fun linesAreUniqueAndFormatted() {
        val c = ScreenLineCollector()
        assertTrue(c.add("input", "Search"))
        assertTrue(c.add("button", "Send"))
        assertFalse(c.add("button", "Send"))      // duplicate
        assertTrue(c.add("text", "Send"))         // same label, different role
        assertFalse(c.add("text", "   "))         // blank
        assertFalse(c.add("text", null))
        assertEquals(listOf("[input] Search", "[button] Send", "[text] Send"), c.lines())
        assertEquals("[input] Search\n[button] Send\n[text] Send", c.toText())
    }

    @Test fun labelsAreTruncatedAndWhitespaceCollapsed() {
        val c = ScreenLineCollector(maxElements = 5, maxLabelLength = 10)
        c.add("text", "a  very\nlong label indeed")
        assertEquals(listOf("[text] a very lo…"), c.lines())
        assertEquals(10, "a very lo…".length) // label part is exactly maxLabelLength
    }

    @Test fun capsTheNumberOfElements() {
        val c = ScreenLineCollector(maxElements = 3)
        repeat(10) { c.add("text", "item $it") }
        assertEquals(3, c.lines().size)
        assertTrue(c.isFull)
        assertFalse(c.add("text", "more"))
    }

    @Test fun tapMatchingTiers() {
        assertEquals(0, TapMatching.tier("send", "Send", null))
        assertEquals(0, TapMatching.tier("send", null, " SEND "))
        assertEquals(1, TapMatching.tier("send", "Send SMS"))
        assertEquals(2, TapMatching.tier("send", "Resend code"))
        assertEquals(3, TapMatching.tier("send", "Cancel"))
    }

    @Test fun accessibilitySettingParsing() {
        val pkg = "com.Lia.assistant"
        val cls = "com.Lia.assistant.action.NovaAccessibilityService"
        assertTrue(ServiceListing.isListed("other/x.Y:$pkg/$cls", pkg, cls))
        assertTrue(ServiceListing.isListed("$pkg/.action.NovaAccessibilityService", pkg, cls))
        assertTrue(ServiceListing.isListed("COM.LIA.ASSISTANT/$cls", pkg, cls))
        assertFalse(ServiceListing.isListed("other/x.Y", pkg, cls))
        assertFalse(ServiceListing.isListed("", pkg, cls))
        assertFalse(ServiceListing.isListed(null, pkg, cls))
        assertFalse(ServiceListing.isListed("$pkg/com.Lia.assistant.action.Other", pkg, cls))
    }
}
