package com.Lia.assistant.agent.social

import com.Lia.assistant.agent.TestWorlds.observation
import com.Lia.assistant.agent.TestWorlds.uiEl
import com.Lia.assistant.agent.core.Blocker
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class BlockerDetectorTest {
    private fun detect(vararg texts: String, pkg: String = "com.instagram.android", windowClass: String = "Activity") =
        BlockerDetector.detect(observation(*texts.mapIndexed { i, t -> uiEl(i, text = t, top = 100 + i * 120) }.toTypedArray(), pkg = pkg, windowClass = windowClass))

    @Test fun loginScreens() {
        assertEquals(Blocker.LOGIN, detect("Log in", "Create new account"))
        assertEquals(Blocker.LOGIN, detect("Sign in to continue"))
        assertEquals(Blocker.LOGIN, detect("Forgot password?"))
    }

    @Test fun captcha() {
        assertEquals(Blocker.CAPTCHA, detect("Select all images with traffic lights"))
        assertEquals(Blocker.CAPTCHA, detect("I'm not a robot"))
    }

    @Test fun twoFactorCodes() {
        assertEquals(Blocker.TWO_FACTOR, detect("Enter the 6-digit code we sent you"))
        assertEquals(Blocker.TWO_FACTOR, detect("Two-factor authentication"))
        assertEquals(Blocker.TWO_FACTOR, detect("Enter your security code"))
    }

    @Test fun securityChecks() {
        assertEquals(Blocker.SECURITY_CHECK, detect("We detected unusual activity on your account"))
        assertEquals(Blocker.SECURITY_CHECK, detect("Confirm it's you"))
    }

    @Test fun systemPermissionDialogs() {
        assertEquals(Blocker.PERMISSION_PROMPT, detect("Allow Instagram to access photos?", pkg = "com.google.android.permissioncontroller"))
        assertEquals(Blocker.PERMISSION_PROMPT, detect("Allow", windowClass = "com.android.permissioncontroller.GrantPermissionsActivity"))
    }

    @Test fun ordinaryScreensAreNotBlockers() {
        assertNull(detect("New post", "Next", "Write a caption", "Share"))
        assertNull(detect("Feed", "Story", "Reels"))
        // a sentence that merely mentions logging in is not a login screen
        assertNull(detect("You can log in to another account from Settings later"))
    }

    @Test fun descriptionsAndHintsAreReadToo() {
        val o = observation(uiEl(0, hint = "Enter the code", editable = true), pkg = "com.instagram.android")
        assertEquals(Blocker.TWO_FACTOR, BlockerDetector.detect(o))
    }

    @Test fun anEmptyScreenIsNotABlocker() {
        assertNull(BlockerDetector.detect(observation()))
    }
}
