package com.Lia.assistant.agent.social

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ConsentTest {
    @Test fun clearYesInEnglishAndHinglish() {
        listOf(
            "yes", "Yes!", "yeah", "yep", "sure", "ok", "okay", "yes please", "go ahead", "do it", "confirm",
            "haan", "haan kar do", "theek hai", "bilkul", "post it", "send it", "हाँ", "ठीक है",
        ).forEach { assertTrue(it, ConsentCheck.isAffirmative(it)) }
    }

    @Test fun noMaybeAndEmptyAreNotAYes() {
        listOf("no", "nope", "nahi", "not yet", "wait", "stop", "cancel", "hmm", "what is the caption", "", "   ").forEach {
            assertFalse("'$it'", ConsentCheck.isAffirmative(it))
        }
    }

    @Test fun aNoAnywhereInTheSentenceWins() {
        assertFalse(ConsentCheck.isAffirmative("yes but wait"))
        assertFalse(ConsentCheck.isAffirmative("ok actually don't"))
        assertFalse(ConsentCheck.isAffirmative("haan nahi mat karo"))
    }

    @Test fun theGateIsClosedUntilAConfirmationWasAskedFor() {
        val gate = ConfirmationGate()
        assertEquals(ConfirmCheck.NOT_PENDING, gate.evaluate(UserSignal(5, "yes")))
    }

    @Test fun theUserMustHaveSpokenSinceTheQuestion() {
        val gate = ConfirmationGate()
        gate.request(UserSignal(3, "post it"))            // what they said BEFORE the question does not count
        assertEquals(ConfirmCheck.NO_USER_REPLY, gate.evaluate(UserSignal(3, "yes")))
        assertEquals(ConfirmCheck.NO_USER_REPLY, gate.evaluate(UserSignal(2, "yes")))
    }

    @Test fun andWhatTheySaidMustBeAYes() {
        val gate = ConfirmationGate()
        gate.request(UserSignal(3, ""))
        assertEquals(ConfirmCheck.NOT_AFFIRMATIVE, gate.evaluate(UserSignal(4, "not yet")))
        assertEquals(ConfirmCheck.NOT_AFFIRMATIVE, gate.evaluate(UserSignal(4, "what time is it")))
        assertEquals(ConfirmCheck.ALLOWED, gate.evaluate(UserSignal(4, "yes, go ahead")))
    }

    @Test fun clearingClosesTheGateAgain() {
        val gate = ConfirmationGate()
        gate.request(UserSignal(0, ""))
        gate.clear()
        assertEquals(ConfirmCheck.NOT_PENDING, gate.evaluate(UserSignal(9, "yes")))
    }

    @Test fun controlCommandsParseIgnoringCase() {
        assertEquals(ControlCommand.CONFIRM, ControlCommand.parse(" Confirm "))
        assertEquals(ControlCommand.STATUS, ControlCommand.parse("status"))
        assertEquals(null, ControlCommand.parse("publish_now"))
        assertEquals(null, ControlCommand.parse(null))
    }
}
