package com.Lia.assistant.agent.social

import com.Lia.assistant.agent.FakeScreenDriver
import com.Lia.assistant.agent.TestWorlds
import com.Lia.assistant.agent.core.Expectation
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Test

class AgentTaskRegistryTest {
    /** A one-step task. Not started it is "running" (not finished); started against the fake phone it completes. */
    private fun runner(id: String): TaskRunner {
        val plan = listOf(PlanStep("open", "open", StepKind.LAUNCH_APP, packages = listOf(TestWorlds.IG), expect = Expectation.PackageIs(TestWorlds.IG)))
        return TaskRunner(
            id, "social", TaskMode.PUBLISH, "Instagram", plan, FakeScreenDriver(TestWorlds.instagram()),
            BlockerDetector::detect, "x", TestWorlds.fastConfig(), TestWorlds.noWait,
        )
    }

    private fun finished(id: String): TaskRunner = runner(id).also { runBlocking { it.start(UserSignal(0, "")) } }

    @Test fun idsCountUpAcrossKinds() {
        val r = AgentTaskRegistry()
        assertEquals("social-1", r.nextId("social"))
        assertEquals("whatsapp-2", r.nextId("whatsapp"))
        assertEquals("social-3", r.nextId("social"))
    }

    @Test fun anEmptyRegistryHasNothing() {
        val r = AgentTaskRegistry()
        assertEquals(0, r.size())
        assertNull(r.active())
        assertNull(r.get(null))
        assertNull(r.get("social-1"))
    }

    @Test fun aTaskThatHasNotFinishedIsTheActiveOne() {
        val r = AgentTaskRegistry()
        val running = runner("t1")
        r.put(running)
        assertSame(running, r.active())
        assertSame(running, r.get(null))
        assertSame(running, r.get("  ").also { }) // a blank id means "the current one"
        assertSame(running, r.get("t1"))
    }

    @Test fun aFinishedTaskIsNotActiveButIsStillTheLatest() {
        val r = AgentTaskRegistry()
        val done = finished("t1")
        r.put(done)
        assertNull(r.active())
        assertSame(done, r.get(null))
    }

    @Test fun theRunningTaskWinsOverALaterFinishedOne() {
        val r = AgentTaskRegistry()
        val running = runner("t1")
        r.put(running)
        r.put(finished("t2"))
        assertSame(running, r.active())
        assertSame(running, r.get(null))
    }

    @Test fun anUnknownIdIsNull() {
        val r = AgentTaskRegistry()
        r.put(runner("t1"))
        assertNull(r.get("t9"))
    }

    @Test fun onlyTheLastTenFinishedTasksAreKept() {
        val r = AgentTaskRegistry()
        (1..13).forEach { r.put(finished("t$it")) }
        assertEquals(10, r.size())
        assertNull(r.get("t1"))
        assertNull(r.get("t3"))
        assertSame(r.get("t13"), r.get(null))
        assertEquals("t4", r.get("t4")!!.taskId)
    }

    @Test fun aRunningTaskIsNeverDroppedByTheClean() {
        val r = AgentTaskRegistry()
        val running = runner("keep")
        r.put(running)
        (1..13).forEach { r.put(finished("t$it")) }
        assertSame(running, r.get("keep"))
    }
}
