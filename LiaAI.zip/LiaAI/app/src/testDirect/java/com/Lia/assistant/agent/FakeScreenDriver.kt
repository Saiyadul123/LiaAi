package com.Lia.assistant.agent

import com.Lia.assistant.agent.core.Bounds
import com.Lia.assistant.agent.core.CapturedScreen
import com.Lia.assistant.agent.core.DriverResult
import com.Lia.assistant.agent.core.RawNode
import com.Lia.assistant.agent.core.ScreenDriver
import com.Lia.assistant.agent.core.ScreenObservation
import com.Lia.assistant.agent.core.ScreenObserver
import com.Lia.assistant.agent.core.ScrollDirection
import com.Lia.assistant.agent.core.UiElement

/** One thing on a fake screen. Every element needs text, a description, a hint or to be clickable. */
class FakeEl(
    val text: String = "",
    val desc: String = "",
    val hint: String = "",
    val viewId: String = "",
    val className: String = "android.widget.TextView",
    val clickable: Boolean = false,
    val editable: Boolean = false,
) {
    val label: String get() = text.ifEmpty { desc }.ifEmpty { hint }
}

class FakeScreen(val id: String, val pkg: String, val elements: List<FakeEl>, val windowClass: String = "Activity")

/**
 * A scripted phone: screens, which tap leads where, and what the app does. Elements are stacked down the
 * screen, 120 px apart starting at y = 100 (the screen is 1080 x 2400).
 */
class FakeWorld(private val screens: Map<String, FakeScreen>, start: String) {
    var current: String = start
        private set
    var stamp: Long = 1
        private set

    /** "screen|label" -> screen reached by clicking it. */
    val transitions = HashMap<String, String>()
    val effects = HashMap<String, () -> Unit>()
    /** Clicks that are delivered but change nothing. */
    val swallowed = HashSet<String>()
    val backs = HashMap<String, String>()
    val apps = HashMap<String, String>()
    val links = HashMap<String, String>()
    val shares = HashMap<String, String>()
    /** "screen|elementIndex" -> text in an editable field. */
    val typed = HashMap<String, String>()
    var focused: String? = null

    var published = false
    var draftSaved = false

    fun screen(): FakeScreen = screens.getValue(current)

    fun goTo(id: String) {
        require(id in screens) { "no screen $id" }
        current = id
        stamp++
        focused = null
    }

    fun on(screen: String, label: String, to: String? = null, effect: (() -> Unit)? = null) {
        if (to != null) transitions["$screen|$label"] = to
        if (effect != null) effects["$screen|$label"] = effect
    }
}

class FakeScreenDriver(val world: FakeWorld, val observer: ScreenObserver = ScreenObserver()) : ScreenDriver {
    val log = mutableListOf<String>()
    var captures = 0
        private set

    // knobs for scripted trouble
    var staleClicks = 0
    var interfereOnNextClick = 0
    var rejectAccessibilityClicks = false
    var rejectGestures = false
    var setTextResult = DriverResult.OK
    var ignoreSetText = false

    fun clicks(label: String): Int = log.count { it == "click:$label" || it == "gesture:$label" }
    fun launched(): Int = log.count { it.startsWith("launch:") || it.startsWith("link:") || it.startsWith("share:") }

    private fun raw(): CapturedScreen {
        val s = world.screen()
        val nodes = s.elements.mapIndexed { i, e ->
            RawNode(
                text = if (e.editable) world.typed["${s.id}|$i"].orEmpty() else e.text,
                contentDescription = e.desc, hint = e.hint, viewId = e.viewId, className = e.className,
                bounds = Bounds(40, 100 + i * 120, 1040, 200 + i * 120),
                clickable = e.clickable, editable = e.editable, scrollable = false, enabled = true,
                focused = world.focused == "${s.id}|$i", checked = null, path = listOf(i),
                clickableAncestor = false, visibleToUser = true,
            )
        }
        return CapturedScreen(s.pkg, s.windowClass, nodes, 1080, 2400, world.stamp)
    }

    override suspend fun capture(): ScreenObservation {
        captures++
        return observer.observe(raw())
    }

    private fun performClick(index: Int, how: String): DriverResult {
        val s = world.screen()
        val el = s.elements.getOrNull(index) ?: return DriverResult.NOT_FOUND
        log += "$how:${el.label}"
        if (el.editable) world.focused = "${s.id}|$index"
        val key = "${s.id}|${el.label}"
        if (key in world.swallowed) return DriverResult.OK
        world.effects[key]?.invoke()
        world.transitions[key]?.let { world.goTo(it) }
        return DriverResult.OK
    }

    override suspend fun clickElement(observation: ScreenObservation, element: UiElement): DriverResult {
        if (interfereOnNextClick > 0) {
            interfereOnNextClick--
            observer.observe(raw()) // somebody else looked at the screen: the caller's observation is now old
        }
        if (staleClicks > 0) {
            staleClicks--
            return DriverResult.STALE
        }
        if (!observer.isLatest(observation)) return DriverResult.STALE
        if (rejectAccessibilityClicks) return DriverResult.FAILED
        return performClick(element.path.first(), "click")
    }

    override suspend fun gestureTap(x: Int, y: Int): DriverResult {
        if (rejectGestures) return DriverResult.FAILED
        val index = (y - 100) / 120
        if (x !in 40..1040 || y < 100) return DriverResult.FAILED
        return performClick(index, "gesture")
    }

    override suspend fun setText(text: String): DriverResult {
        if (setTextResult != DriverResult.OK) return setTextResult
        val field = world.focused ?: return DriverResult.FAILED
        log += "type:$text"
        if (!ignoreSetText) world.typed[field] = text
        return DriverResult.OK
    }

    override suspend fun scroll(direction: ScrollDirection): DriverResult {
        log += "scroll:$direction"
        return DriverResult.OK
    }

    override suspend fun back(): DriverResult {
        log += "back"
        world.backs[world.current]?.let { world.goTo(it) }
        return DriverResult.OK
    }

    override suspend fun home(): DriverResult {
        log += "home"
        return DriverResult.OK
    }

    override suspend fun launchApp(packageName: String): DriverResult {
        val target = world.apps[packageName] ?: return DriverResult.NOT_FOUND
        log += "launch:$packageName"
        world.goTo(target)
        return DriverResult.OK
    }

    override suspend fun openLink(url: String, packageNames: List<String>): DriverResult {
        val pkg = packageNames.firstOrNull { it in world.links } ?: return DriverResult.NOT_FOUND
        log += "link:$url"
        world.goTo(world.links.getValue(pkg))
        return DriverResult.OK
    }

    override suspend fun shareMedia(packageName: String, mediaUri: String, mimeType: String?, caption: String?): DriverResult {
        val target = world.shares[packageName] ?: return DriverResult.NOT_FOUND
        log += "share:$packageName:$mediaUri"
        world.goTo(target)
        return DriverResult.OK
    }
}
