package com.Lia.assistant.agent.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ScreenObserverTest {
    private fun node(text: String = "", top: Int = 100, clickable: Boolean = false, visible: Boolean = true, height: Int = 100, left: Int = 0, right: Int = 500) =
        RawNode(
            text, "", "", "", "android.view.View", Bounds(left, top, right, top + height), clickable, false, false, true, false, null,
            listOf(0), false, visible,
        )

    private fun capture(vararg nodes: RawNode) = CapturedScreen("pkg", "Act", nodes.toList(), 1080, 2400, 7)

    @Test fun observationIdsGrowAndOnlyTheLatestIsTrusted() {
        val observer = ScreenObserver()
        val first = observer.observe(capture(node("a")))
        assertTrue(observer.isLatest(first))
        val second = observer.observe(capture(node("a")))
        assertEquals(first.observationId + 1, second.observationId)
        assertFalse(observer.isLatest(first))
        assertTrue(observer.isLatest(second))
    }

    @Test fun invisibleEmptyOffscreenAndUselessNodesAreDropped() {
        val observation = ScreenObserver().observe(
            capture(
                node("shown"),
                node("hidden", visible = false),
                node("flat", height = 0),
                node("off", top = 5000),
                node("left", left = -900, right = -10),
                node(""),                       // no label, not clickable: nothing to use it for
                node("", clickable = true),     // a bare button is kept
            )
        )
        assertEquals(listOf("shown", ""), observation.elements.map { it.text })
        assertEquals(listOf(0, 1), observation.elements.map { it.id })
    }

    @Test fun observationKeepsTheScreenFacts() {
        val observation = ScreenObserver().observe(capture(node("a")))
        assertEquals("pkg", observation.packageName)
        assertEquals("Act", observation.windowClass)
        assertEquals(1080, observation.screenWidth)
        assertEquals(7L, observation.windowStamp)
    }
}
