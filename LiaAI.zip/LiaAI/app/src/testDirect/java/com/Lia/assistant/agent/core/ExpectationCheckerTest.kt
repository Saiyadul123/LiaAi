package com.Lia.assistant.agent.core

import com.Lia.assistant.agent.TestWorlds.observation
import com.Lia.assistant.agent.TestWorlds.uiEl
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExpectationCheckerTest {
    private val send = TargetSpec(labels = listOf("Send"), requireTappable = true)
    private val before = observation(uiEl(0, text = "Send", clickable = true), pkg = "wa")
    private fun check(e: Expectation, after: ScreenObservation, b: ScreenObservation? = before) = ExpectationChecker.check(e, b, after)

    @Test fun textNormalisationIgnoresCaseSpacingAndTrailingPunctuation() {
        assertEquals("sharing to instagram", TextMatch.normalize("  Sharing   to Instagram… "))
        assertEquals("it's", TextMatch.normalize("It\u2019s."))
        assertTrue(TextMatch.contains("Sharing to Instagram…", "sharing to instagram"))
        assertFalse(TextMatch.contains("anything", ""))
        assertFalse(TextMatch.contains("", "x"))
    }

    @Test fun onlyTheFirstSixtyCharactersOfALongNeedleMatter() {
        val long = "a".repeat(60) + "THE REST DIFFERS"
        assertTrue(TextMatch.contains("a".repeat(60) + " something else", long))
    }

    @Test fun nothingToCheckAlwaysPasses() {
        assertTrue(check(Expectation.None, observation()))
    }

    @Test fun targetGoneAndPresentAreOpposites() {
        val has = observation(uiEl(0, text = "Send", clickable = true))
        val empty = observation(uiEl(0, text = "Voice message", clickable = true))
        assertTrue(check(Expectation.TargetPresent(send), has))
        assertFalse(check(Expectation.TargetGone(send), has))
        assertTrue(check(Expectation.TargetGone(send), empty))
        assertFalse(check(Expectation.TargetPresent(send), empty))
    }

    @Test fun anAmbiguousTargetCountsAsPresent() {
        val two = observation(uiEl(0, text = "Send now", clickable = true, top = 200), uiEl(1, text = "Send later", clickable = true, top = 400))
        assertTrue(check(Expectation.TargetPresent(send.copy(requireUnique = true)), two))
        assertFalse(check(Expectation.TargetGone(send.copy(requireUnique = true)), two))
    }

    @Test fun textIsFoundInTextDescriptionOrHint() {
        val o = observation(uiEl(0, text = "Hello"), uiEl(1, desc = "More options", top = 300), uiEl(2, hint = "Type a message", editable = true, top = 500))
        assertTrue(check(Expectation.TextPresent("hello"), o))
        assertTrue(check(Expectation.TextPresent("more options"), o))
        assertTrue(check(Expectation.TextPresent("type a message"), o))
        assertFalse(check(Expectation.TextPresent("goodbye"), o))
    }

    @Test fun textStillInsideAnInputDoesNotCountWhenToldToExcludeInputs() {
        val typedOnly = observation(uiEl(0, text = "Running late", editable = true, clickable = true))
        val inBubble = observation(uiEl(0, text = "Running late"), uiEl(1, text = "", hint = "Type a message", editable = true, top = 300))
        assertTrue(check(Expectation.TextPresent("Running late"), typedOnly))
        assertFalse(check(Expectation.TextPresent("Running late", excludeEditable = true), typedOnly))
        assertTrue(check(Expectation.TextPresent("Running late", excludeEditable = true), inBubble))
    }

    @Test fun thePackageMustMatchExactly() {
        assertTrue(check(Expectation.PackageIs("wa"), observation(pkg = "wa")))
        assertFalse(check(Expectation.PackageIs("wa"), observation(pkg = "wa.w4b")))
    }

    @Test fun aScreenChangeIsSeenInStampWindowPackageOrLabels() {
        val same = observation(uiEl(0, text = "Send", clickable = true), pkg = "wa")
        assertFalse(check(Expectation.ScreenChanged, same))
        assertTrue(check(Expectation.ScreenChanged, same.copy(windowStamp = 2)))
        assertTrue(check(Expectation.ScreenChanged, same.copy(windowClass = "Other")))
        assertTrue(check(Expectation.ScreenChanged, same.copy(packageName = "ig")))
        assertTrue(check(Expectation.ScreenChanged, observation(uiEl(0, text = "Different"), pkg = "wa")))
        assertTrue(check(Expectation.ScreenChanged, same, b = null)) // nothing to compare with: assume it changed
    }

    @Test fun anyOfNeedsOneAndAllOfNeedsEvery() {
        val o = observation(uiEl(0, text = "Hello"), pkg = "wa")
        val yes = Expectation.TextPresent("hello")
        val no = Expectation.TextPresent("nope")
        assertTrue(check(Expectation.AnyOf(listOf(no, yes)), o))
        assertFalse(check(Expectation.AnyOf(listOf(no, no)), o))
        assertTrue(check(Expectation.AllOf(listOf(yes, Expectation.PackageIs("wa"))), o))
        assertFalse(check(Expectation.AllOf(listOf(yes, no)), o))
        assertFalse(check(Expectation.AnyOf(emptyList()), o))
        assertTrue(check(Expectation.AllOf(emptyList()), o))
    }

    @Test fun combinationsNest() {
        val o = observation(uiEl(0, text = "Sharing to Instagram…"), pkg = "ig")
        val e = Expectation.AllOf(listOf(Expectation.PackageIs("ig"), Expectation.AnyOf(listOf(Expectation.TextPresent("sharing"), Expectation.TextPresent("posted")))))
        assertTrue(check(e, o))
    }
}
