package com.Lia.assistant.agent.whatsapp

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test

class NotificationParserTest {
    @Before @After fun clear() = WhatsAppNotificationStore.clear()

    private fun parse(title: String, text: String, summary: Boolean = false) =
        WhatsAppNotificationParser.parse(title, text, summary, 100L)

    @Test fun anOrdinaryMessageIsKept() {
        val m = parse("Priya Nair", "Are we still on for tonight?")!!
        assertEquals("Priya Nair", m.sender)
        assertEquals("Are we still on for tonight?", m.text)
        assertEquals(100L, m.postedAtMillis)
    }

    @Test fun summariesAndHousekeepingAreNotMessages() {
        assertNull(parse("WhatsApp", "5 new messages", summary = true))
        assertNull(parse("WhatsApp", "3 new messages"))
        assertNull(parse("WhatsApp", "2 messages from 2 chats"))
        assertNull(parse("WhatsApp", "Checking for new messages"))
        assertNull(parse("WhatsApp", "Backup in progress"))
        assertNull(parse("WhatsApp Web", "WhatsApp Web is currently active"))
        assertNull(parse("Priya", "Incoming voice call"))
        assertNull(parse("Priya", "Ongoing video call"))
    }

    @Test fun aMessageThatMentionsMessagesIsStillAMessage() {
        assertNotNull(parse("Asha", "I sent you 3 messages yesterday"))
    }

    @Test fun blankSendersAndTextAreDropped() {
        assertNull(parse("", "hello"))
        assertNull(parse("Priya", "   "))
    }

    @Test fun longTextIsCutAtTwoHundredCharacters() {
        assertEquals(200, parse("Priya", "x".repeat(500))!!.text.length)
    }

    @Test fun theStoreFollowsNotificationsComingAndGoing() {
        WhatsAppNotificationStore.put("a", UnreadMessage("Priya", "one", 10))
        WhatsAppNotificationStore.put("b", UnreadMessage("Asha", "two", 5))
        assertEquals(listOf("two", "one"), WhatsAppNotificationStore.snapshot().map { it.text }) // oldest first
        WhatsAppNotificationStore.put("a", UnreadMessage("Priya", "one again", 20)) // same notification updated
        assertEquals(2, WhatsAppNotificationStore.snapshot().size)
        WhatsAppNotificationStore.remove("b")
        assertEquals(listOf("one again"), WhatsAppNotificationStore.snapshot().map { it.text })
        WhatsAppNotificationStore.clear()
        assertEquals(0, WhatsAppNotificationStore.snapshot().size)
    }

    @Test fun theStoreKeepsAtMostOneHundredAndDropsTheOldest() {
        (1..105).forEach { WhatsAppNotificationStore.put("k$it", UnreadMessage("s", "m$it", it.toLong())) }
        val kept = WhatsAppNotificationStore.snapshot()
        assertEquals(100, kept.size)
        assertEquals("m6", kept.first().text)
        assertEquals("m105", kept.last().text)
    }
}
