package com.Lia.assistant.agent.core

import com.Lia.assistant.agent.TestWorlds.observation
import com.Lia.assistant.agent.TestWorlds.uiEl
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TargetResolverTest {
    private fun found(o: ScreenObservation, spec: TargetSpec) = (TargetResolver.resolve(o, spec) as Resolution.Found).element.id

    @Test fun exactBeatsPrefixBeatsContains() {
        val o = observation(
            uiEl(0, text = "Please send it now", clickable = true, top = 100),
            uiEl(1, text = "Send message", clickable = true, top = 300),
            uiEl(2, text = "Send", clickable = true, top = 500),
        )
        assertEquals(2, found(o, TargetSpec(labels = listOf("Send"))))
    }

    @Test fun anyOfSeveralWordingsMatches() {
        val o = observation(uiEl(0, text = "Reels", clickable = true))
        assertEquals(0, found(o, TargetSpec(labels = listOf("Reel", "Reels"))))
    }

    @Test fun matchesTheDescriptionAndHintToo() {
        val o = observation(uiEl(0, desc = "More options", clickable = true), uiEl(1, hint = "Type a message", editable = true, top = 300))
        assertEquals(0, found(o, TargetSpec(labels = listOf("more options"))))
        assertEquals(1, found(o, TargetSpec(labels = listOf("type a message"))))
    }

    @Test fun viewIdBeatsAnyText() {
        val o = observation(
            uiEl(0, text = "Write a caption", clickable = true, top = 100),
            uiEl(1, hint = "x", viewId = "com.app:id/caption_text_view", editable = true, top = 300),
        )
        assertEquals(1, found(o, TargetSpec(labels = listOf("Write a caption"), viewIds = listOf("caption_text_view"))))
    }

    @Test fun editableAndTappableAreRequirementsNotPreferences() {
        val o = observation(uiEl(0, text = "Share"), uiEl(1, text = "Share", clickable = true, top = 300))
        assertEquals(1, found(o, TargetSpec(labels = listOf("Share"), requireTappable = true)))
        assertTrue(TargetResolver.resolve(o, TargetSpec(labels = listOf("Share"), requireEditable = true)) is Resolution.NotFound)
    }

    @Test fun aLabelWithAClickableAncestorCountsAsTappable() {
        val o = observation(uiEl(0, text = "Next", ancestorClickable = true))
        assertEquals(0, found(o, TargetSpec(labels = listOf("Next"), requireTappable = true)))
    }

    @Test fun disabledButtonsAreNotChosenWhenTappingIsRequired() {
        val o = observation(uiEl(0, text = "Post", clickable = true, enabled = false))
        assertTrue(TargetResolver.resolve(o, TargetSpec(labels = listOf("Post"), requireTappable = true)) is Resolution.NotFound)
    }

    @Test fun excludeEditableSkipsTheSearchBoxHoldingTheName() {
        val o = observation(
            uiEl(0, text = "Priya", editable = true, clickable = true, top = 100),
            uiEl(1, text = "Priya Nair", clickable = true, top = 500),
        )
        assertEquals(1, found(o, TargetSpec(labels = listOf("Priya"), requireTappable = true, excludeEditable = true)))
    }

    @Test fun regionsLimitWhereToLook() {
        val o = observation(uiEl(0, text = "Search", clickable = true, top = 100), uiEl(1, text = "Search", clickable = true, top = 2200))
        assertEquals(0, found(o, TargetSpec(labels = listOf("Search"), region = Region.TOP_BAR)))
        assertEquals(1, found(o, TargetSpec(labels = listOf("Search"), region = Region.BOTTOM_BAR)))
        assertEquals(1, found(o, TargetSpec(labels = listOf("Search"), region = Region.BELOW_TOP_BAR)))
        assertEquals(0, found(o, TargetSpec(labels = listOf("Search"), region = Region.ABOVE_BOTTOM_BAR)))
    }

    @Test fun twoEquallyGoodMatchesAreAmbiguousOnlyWhenUniquenessIsRequired() {
        val o = observation(
            uiEl(0, text = "Asha Sharma", clickable = true, top = 500),
            uiEl(1, text = "Asha Verma", clickable = true, top = 700),
        )
        val unique = TargetResolver.resolve(o, TargetSpec(labels = listOf("Asha"), requireUnique = true))
        assertEquals(setOf(0, 1), (unique as Resolution.Ambiguous).candidates.map { it.id }.toSet())
        assertTrue(TargetResolver.resolve(o, TargetSpec(labels = listOf("Asha"))) is Resolution.Found)
    }

    @Test fun anExactMatchWinsEvenWhenUniquenessIsRequired() {
        val o = observation(uiEl(0, text = "Asha", clickable = true, top = 500), uiEl(1, text = "Asha Verma", clickable = true, top = 700))
        assertEquals(0, found(o, TargetSpec(labels = listOf("Asha"), requireUnique = true)))
    }

    @Test fun theSameThingTwiceIsNotAmbiguous() {
        val o = observation(uiEl(0, text = "Priya", clickable = true, top = 500), uiEl(1, text = "Priya", clickable = true, top = 500))
        assertTrue(TargetResolver.resolve(o, TargetSpec(labels = listOf("Priya"), requireUnique = true)) is Resolution.Found)
    }

    @Test fun otherPackageAndEmptySpecsFindNothing() {
        val o = observation(uiEl(0, text = "Send", clickable = true), pkg = "other")
        assertTrue(TargetResolver.resolve(o, TargetSpec(labels = listOf("Send"), packageName = "wanted")) is Resolution.NotFound)
        assertTrue(TargetResolver.resolve(o, TargetSpec()) is Resolution.NotFound)
    }

    @Test fun shortLabelsNeverMatchInsideOtherWords() {
        val o = observation(uiEl(0, text = "Notifications", clickable = true))
        assertTrue(TargetResolver.resolve(o, TargetSpec(labels = listOf("OK"))) is Resolution.NotFound)
    }
}
