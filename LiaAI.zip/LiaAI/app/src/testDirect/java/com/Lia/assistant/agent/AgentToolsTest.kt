package com.Lia.assistant.agent

import com.Lia.assistant.voice.ToolDeclaration
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentToolsTest {
    private val tools = AgentTools.declarations()
    private fun tool(name: String): ToolDeclaration = tools.first { it.name == name }

    @Test fun fourToolsWithTheAgreedNames() {
        assertEquals(
            listOf("execute_social_media_task", "social_media_task_control", "execute_whatsapp_task", "whatsapp_task_control"),
            tools.map { it.name },
        )
        assertEquals(AgentTools.NAMES, tools.map { it.name }.toSet())
    }

    @Test fun theSocialToolTakesTheAgreedParameters() {
        val t = tool("execute_social_media_task")
        assertEquals(listOf("platform", "action", "media_uri", "caption", "mode", "target_account"), t.params.map { it.name })
        assertEquals(listOf("platform", "action"), t.params.filter { it.required }.map { it.name })
    }

    @Test fun theWhatsAppToolTakesTheAgreedParameters() {
        val t = tool("execute_whatsapp_task")
        assertEquals(listOf("action", "phone", "contact", "message", "query", "duration"), t.params.map { it.name })
        assertEquals(listOf("action"), t.params.filter { it.required }.map { it.name })
    }

    @Test fun bothControlToolsTakeACommandAndAnOptionalTaskId() {
        listOf("social_media_task_control", "whatsapp_task_control").forEach { name ->
            val t = tool(name)
            assertEquals(listOf("command", "task_id"), t.params.map { it.name })
            assertEquals(listOf("command"), t.params.filter { it.required }.map { it.name })
        }
    }

    @Test fun theControlToolsTellTheModelToConfirmOnlyAfterAnExplicitYes() {
        listOf("social_media_task_control", "whatsapp_task_control").forEach { name ->
            assertTrue(name, tool(name).description.contains("only call confirm after the user explicitly said yes", ignoreCase = true))
        }
    }

    @Test fun theDescriptionsExplainTheSafeguards() {
        val social = tool("execute_social_media_task").description
        assertTrue(social.contains("confirmation", ignoreCase = true))
        assertTrue(social.contains("draft", ignoreCase = true))
        assertTrue(social.contains("shared to this assistant", ignoreCase = true))
        assertTrue(social.contains("cannot switch accounts", ignoreCase = true))
        val wa = tool("execute_whatsapp_task").description
        assertTrue(wa.contains("never opens the app", ignoreCase = true))
        assertTrue(wa.contains("contact_ambiguous"))
    }

    @Test fun everyParameterHasADescription() {
        tools.forEach { t -> t.params.forEach { assertTrue("${t.name}.${it.name}", it.description.isNotBlank()) } }
    }
}
