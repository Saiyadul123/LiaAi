package com.Lia.assistant.agent.whatsapp

import com.Lia.assistant.agent.FakeScreenDriver
import com.Lia.assistant.agent.FakeWorld
import com.Lia.assistant.agent.TestWorlds
import com.Lia.assistant.agent.core.Expectation
import com.Lia.assistant.agent.core.FailureReason
import com.Lia.assistant.agent.social.AgentTaskRegistry
import com.Lia.assistant.agent.social.SocialTaskService
import com.Lia.assistant.agent.social.StepKind
import com.Lia.assistant.agent.social.UserSignal
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WhatsAppAgentTest {
    private class FakeNotifications(var result: UnreadResult) : NotificationSource {
        override fun unread() = result
    }

    private class Rig(unread: UnreadResult = UnreadResult.Ok(emptyList())) {
        val world: FakeWorld = TestWorlds.whatsapp()
        val driver = FakeScreenDriver(world)
        val registry = AgentTaskRegistry()
        val agent = WhatsAppAgent(driver, FakeNotifications(unread), registry, TestWorlds.fastConfig(), TestWorlds.noWait)

        suspend fun run(vararg pairs: Pair<String, String>, turns: Int = 0, said: String = ""): JSONObject =
            agent.execute(JSONObject().also { j -> pairs.forEach { j.put(it.first, it.second) } }, UserSignal(turns, said))

        suspend fun control(command: String, turns: Int = 0, said: String = ""): JSONObject =
            agent.control(JSONObject().put("command", command), UserSignal(turns, said))
    }

    private fun texts(array: org.json.JSONArray) = (0 until array.length()).map { array.getString(it) }

    // ---- unread messages: notifications only -----------------------------------------------------

    @Test fun unreadMessagesAreGroupedBySenderWithoutOpeningTheApp() = runBlocking {
        val rig = Rig(
            UnreadResult.Ok(
                listOf(
                    UnreadMessage("Priya", "hi", 1), UnreadMessage("Asha", "lunch?", 2), UnreadMessage("Priya", "you there?", 3),
                )
            )
        )
        val r = rig.run("action" to "read_unread")
        assertEquals("ok", r.getString("result"))
        assertEquals(3, r.getInt("total"))
        val chats = r.getJSONArray("chats")
        assertEquals("Priya", chats.getJSONObject(0).getString("sender")) // the most recent chat first
        assertEquals(2, chats.getJSONObject(0).getInt("count"))
        assertEquals(listOf("hi", "you there?"), texts(chats.getJSONObject(0).getJSONArray("messages")))
        assertEquals("Asha", chats.getJSONObject(1).getString("sender"))
        assertEquals(0, rig.driver.launched())
        assertEquals(0, rig.driver.captures)
        assertEquals(0, rig.registry.size())
    }

    @Test fun withoutNotificationAccessTheAnswerSaysSoAndTheAppStaysClosed() = runBlocking {
        val rig = Rig(UnreadResult.AccessDisabled)
        val r = rig.run("action" to "read_unread")
        assertEquals("notification_access_disabled", r.getString("result"))
        assertEquals(0, rig.driver.launched() + rig.driver.captures)
    }

    @Test fun aBusyInboxIsSummarisedNotDumped() = runBlocking {
        val many = (1..40).map { UnreadMessage("Sender$it", "m", it.toLong()) } + (1..9).map { UnreadMessage("Chatty", "c$it", 100L + it) }
        val r = Rig(UnreadResult.Ok(many)).run("action" to "read_unread")
        assertEquals(15, r.getJSONArray("chats").length())
        assertEquals(5, r.getJSONArray("chats").getJSONObject(0).getJSONArray("messages").length()) // Chatty, newest 5 only
        assertEquals(49, r.getInt("total"))
    }

    // ---- sending -----------------------------------------------------------------------------------

    @Test fun aMessageIsSentOnlyAfterAYes() = runBlocking {
        val rig = Rig()
        val r = rig.run("action" to "send_message", "phone" to "+91 98765 43210", "message" to "Running late", turns = 2)
        assertEquals("awaiting_confirmation", r.getString("result"))
        val summary = r.getString("confirmation_summary")
        assertTrue(summary.contains("+919876543210") && summary.contains("Running late"))
        assertTrue(rig.driver.log.contains("link:https://wa.me/919876543210?text=Running%20late"))
        assertEquals(0, rig.driver.clicks("Send"))

        val noReply = rig.control("confirm", turns = 2, said = "yes")
        assertEquals("confirmation_not_given", noReply.getString("error"))
        assertEquals(0, rig.driver.clicks("Send"))

        val done = rig.control("confirm", turns = 3, said = "yes send it")
        assertEquals("completed", done.getString("result"))
        assertTrue(done.getBoolean("verified"))
        assertEquals(1, rig.driver.clicks("Send"))
        assertEquals("wa_sent", rig.world.current)
    }

    @Test fun rejectingASendSendsNothing() = runBlocking {
        val rig = Rig()
        rig.run("action" to "send_message", "phone" to "+919876543210", "message" to "hi")
        val r = rig.control("reject")
        assertEquals("cancelled", r.getString("result"))
        assertTrue(r.getString("message").contains("sent"))
        assertEquals(0, rig.driver.clicks("Send"))
    }

    @Test fun aSendWithoutANumberIsRefusedBeforeAnythingHappens() = runBlocking {
        val rig = Rig()
        val r = rig.run("action" to "send_message", "contact" to "Priya", "message" to "hi")
        assertEquals("phone_required", r.getString("error"))
        assertEquals(0, rig.registry.size())
        assertEquals(0, rig.driver.launched())
    }

    // ---- by name ----------------------------------------------------------------------------------

    @Test fun twoContactsWithTheSameNameStopTheTaskInsteadOfGuessing() = runBlocking {
        val rig = Rig()
        val r = rig.run("action" to "read_chat", "contact" to "Asha")
        assertEquals("failed", r.getString("result"))
        assertEquals(FailureReason.CONTACT_AMBIGUOUS.code, r.getString("reason"))
        assertEquals(0, rig.driver.clicks("Asha Sharma") + rig.driver.clicks("Asha Verma"))
        assertEquals("wa_search", rig.world.current)
    }

    @Test fun aUniqueContactIsOpenedAndTheChatIsRead() = runBlocking {
        val rig = Rig()
        val r = rig.run("action" to "read_chat", "contact" to "Priya")
        assertEquals("completed", r.getString("result"))
        assertEquals(listOf("Hello Priya", "Are we still on for tonight?"), texts(r.getJSONArray("data")))
        assertEquals(1, rig.driver.clicks("Priya Nair"))
        assertEquals(0, rig.driver.clicks("Send"))
    }

    @Test fun searchingReadsTheResultsWithoutOpeningAChat() = runBlocking {
        val rig = Rig()
        val r = rig.run("action" to "search_chat", "query" to "Asha")
        assertEquals("completed", r.getString("result"))
        assertEquals(listOf("Asha Sharma", "Asha Verma", "Priya Nair"), texts(r.getJSONArray("data")))
        assertEquals("Asha", rig.world.typed["wa_search|0"])
        assertEquals("wa_search", rig.world.current)
    }

    @Test fun mutingPicksTheDurationAndConfirmsInTheDialog() = runBlocking {
        val rig = Rig()
        val r = rig.run("action" to "mute_chat", "contact" to "Priya", "duration" to "8_hours")
        assertEquals("completed", r.getString("result"))
        assertTrue(r.getBoolean("verified"))
        assertEquals(1, rig.driver.clicks("8 hours"))
        assertEquals(0, rig.driver.clicks("Always"))
        assertEquals(1, rig.driver.clicks("OK"))
        assertEquals("wa_muted", rig.world.current)
    }

    @Test fun mutingForeverIsTheDefault() = runBlocking {
        val rig = Rig()
        rig.run("action" to "mute_chat", "contact" to "Priya")
        assertEquals(1, rig.driver.clicks("Always"))
    }

    @Test fun markingReadOpensTheChatByNumberAndGoesBack() = runBlocking {
        val rig = Rig()
        val r = rig.run("action" to "mark_read", "phone" to "+919876543210")
        assertEquals("completed", r.getString("result"))
        assertTrue(rig.driver.log.contains("link:https://wa.me/919876543210"))
        assertTrue(rig.driver.log.contains("back"))
        assertEquals(0, rig.driver.clicks("Send"))
    }

    @Test fun aWhatsAppControlCommandCannotSteerASocialTask() = runBlocking {
        val rig = Rig()
        val social = SocialTaskService(rig.driver, rig.registry, TestWorlds.media(), TestWorlds.fastConfig(), TestWorlds.noWait)
        rig.world.shares[TestWorlds.IG] = "wa_home"
        social.execute(TestWorlds.igArgs(), UserSignal(0, ""))
        val r = rig.control("cancel")
        assertEquals("unknown_task", r.getString("error"))
    }

    // ---- the plans ----------------------------------------------------------------------------------

    private fun request(vararg pairs: Pair<String, String>) =
        (WhatsAppRequest.parse(JSONObject().also { j -> pairs.forEach { j.put(it.first, it.second) } }) as WhatsAppParse.Valid).request

    @Test fun onlySendingHasAnIrreversibleStepAndItIsTheLastOne() {
        val send = WhatsAppPlanner.plan(request("action" to "send_message", "phone" to "+919876543210", "message" to "hi"))
        assertEquals(1, send.count { it.irreversible })
        val last = send.last()
        assertTrue(last.irreversible && last.finalStep && last.kind == StepKind.CLICK)
        val expect = last.expect as Expectation.AllOf
        assertTrue(expect.options.any { it is Expectation.TextPresent && it.excludeEditable })
        assertTrue(expect.options.any { it is Expectation.TargetGone })

        listOf(
            arrayOf("action" to "read_chat", "contact" to "Priya"),
            arrayOf("action" to "search_chat", "query" to "Priya"),
            arrayOf("action" to "mute_chat", "contact" to "Priya"),
            arrayOf("action" to "unmute_chat", "contact" to "Priya"),
            arrayOf("action" to "mark_read", "phone" to "+919876543210"),
        ).forEach { pairs ->
            assertTrue(pairs.first().second, WhatsAppPlanner.plan(request(*pairs)).none { it.irreversible })
        }
        assertTrue(WhatsAppPlanner.plan(request("action" to "read_unread")).isEmpty())
    }

    @Test fun byNameGoesThroughSearchAndByNumberUsesTheLink() {
        val byName = WhatsAppPlanner.plan(request("action" to "read_chat", "contact" to "Priya"))
        assertEquals(StepKind.LAUNCH_APP, byName.first().kind)
        assertEquals(FailureReason.CONTACT_AMBIGUOUS, byName.first { it.id == "pick_chat" }.ambiguousAs)
        val byNumber = WhatsAppPlanner.plan(request("action" to "read_chat", "phone" to "+919876543210"))
        assertEquals(StepKind.OPEN_LINK, byNumber.first().kind)
        assertEquals("https://wa.me/919876543210", byNumber.first().url)
    }

    @Test fun theLinkEncodesTheMessageSoTheTextArrivesIntact() {
        val send = WhatsAppPlanner.plan(request("action" to "send_message", "phone" to "+919876543210", "message" to "a&b = 50%? #1"))
        assertEquals("https://wa.me/919876543210?text=a%26b%20%3D%2050%25%3F%20%231", send.first().url)
    }

    @Test fun everyMuteAndUnmuteEndsOnAStepThatChecksItsEffect() {
        val mute = WhatsAppPlanner.plan(request("action" to "mute_chat", "contact" to "Priya")).last()
        assertTrue(mute.finalStep && mute.expect != Expectation.None)
        val unmute = WhatsAppPlanner.plan(request("action" to "unmute_chat", "contact" to "Priya")).last()
        assertTrue(unmute.finalStep && unmute.expect != Expectation.None)
    }

    @Test fun theConfirmationSummaryNamesTheNumberAndTheText() {
        val s = WhatsAppPlanner.summary(request("action" to "send_message", "phone" to "+919876543210", "message" to "Running late"))
        assertTrue(s.contains("+919876543210") && s.contains("Running late"))
    }
}
