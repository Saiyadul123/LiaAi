package com.Lia.assistant.agent.social

import com.Lia.assistant.agent.FakeScreenDriver
import com.Lia.assistant.agent.FakeWorld
import com.Lia.assistant.agent.TestWorlds
import com.Lia.assistant.agent.core.Blocker
import com.Lia.assistant.agent.core.FailureReason
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/** The whole agent against a scripted Instagram and Facebook: nothing here touches a real phone. */
class SocialTaskFlowTest {
    @Before fun clear() = SharedMedia.clear()

    private class Rig(val world: FakeWorld) {
        val driver = FakeScreenDriver(world)
        val registry = AgentTaskRegistry()
        val service = SocialTaskService(driver, registry, TestWorlds.media(), TestWorlds.fastConfig(), TestWorlds.noWait)

        suspend fun execute(args: JSONObject, turns: Int = 0, said: String = "") = service.execute(args, UserSignal(turns, said))
        suspend fun control(command: String, turns: Int = 0, said: String = "", taskId: String? = null) =
            service.control(JSONObject().put("command", command).also { j -> taskId?.let { j.put("task_id", it) } }, UserSignal(turns, said))

        val runner: TaskRunner get() = registry.get(null)!!
        val visited: List<TaskState> get() = runner.machine.history.map { it.to }
    }

    private fun ig(landing: String = "ig_chooser") = Rig(TestWorlds.instagram(landing))
    private val fbArgs get() = JSONObject().put("platform", "facebook").put("action", "text_post").put("caption", "Hi everyone")

    // ---- publishing ---------------------------------------------------------------------------

    @Test fun publishingStopsForAConfirmationBeforeTheIrreversibleTap() = runBlocking {
        val rig = ig()
        val r = rig.execute(TestWorlds.igArgs())
        assertEquals("awaiting_confirmation", r.getString("result"))
        assertEquals("waiting_for_confirmation", r.getString("state"))
        assertTrue(r.getBoolean("needs_user"))
        val summary = r.getString("confirmation_summary")
        assertTrue(summary.contains("Instagram") && summary.contains("Hello world") && summary.contains("a.jpg"))
        assertFalse(rig.world.published)
        assertEquals(0, rig.driver.clicks("Share"))
        assertEquals("Hello world", rig.world.typed["ig_caption|1"]) // everything before the publish step is done
    }

    @Test fun aConfirmWithoutAnyUserReplyIsRefused() = runBlocking {
        val rig = ig()
        rig.execute(TestWorlds.igArgs(), turns = 4)
        val r = rig.control("confirm", turns = 4, said = "post it") // the user has not spoken since the question
        assertFalse(r.getBoolean("accepted"))
        assertEquals("confirmation_not_given", r.getString("error"))
        assertFalse(rig.world.published)
        assertEquals(TaskState.WAITING_FOR_CONFIRMATION, rig.runner.machine.state)
    }

    @Test fun aReplyThatIsNotAYesIsRefused() = runBlocking {
        val rig = ig()
        rig.execute(TestWorlds.igArgs(), turns = 0)
        listOf("not yet", "no", "what is the caption again").forEach { said ->
            val r = rig.control("confirm", turns = 1, said = said)
            assertFalse(said, r.getBoolean("accepted"))
            assertEquals("confirmation_not_given", r.getString("error"))
        }
        assertFalse(rig.world.published)
    }

    @Test fun aYesFromTheUserPublishesAndTheEffectIsVerified() = runBlocking {
        val rig = ig()
        rig.execute(TestWorlds.igArgs())
        val r = rig.control("confirm", turns = 1, said = "Yes, go ahead")
        assertEquals("completed", r.getString("result"))
        assertTrue(r.getBoolean("verified"))
        assertTrue(rig.world.published)
        assertEquals(1, rig.driver.clicks("Share"))
        assertEquals(TaskState.COMPLETED, rig.runner.machine.state)
    }

    @Test fun theConfirmationCannotBeUsedTwice() = runBlocking {
        val rig = ig()
        rig.execute(TestWorlds.igArgs())
        rig.control("confirm", turns = 1, said = "yes")
        val again = rig.control("confirm", turns = 2, said = "yes")
        assertFalse(again.getBoolean("accepted"))
        assertEquals("not_waiting_for_confirmation", again.getString("error"))
        assertEquals(1, rig.driver.clicks("Share"))
    }

    @Test fun rejectingCancelsWithoutPublishing() = runBlocking {
        val rig = ig()
        rig.execute(TestWorlds.igArgs())
        val r = rig.control("reject")
        assertEquals("cancelled", r.getString("result"))
        assertFalse(rig.world.published)
        assertEquals(0, rig.driver.clicks("Share"))
    }

    @Test fun cancelStopsATaskThatIsWaitingOnAnything() = runBlocking {
        val waitingForYes = ig()
        waitingForYes.execute(TestWorlds.igArgs())
        assertEquals("cancelled", waitingForYes.control("cancel").getString("result"))

        val waitingForUser = ig("ig_login")
        assertEquals("awaiting_user", waitingForUser.execute(TestWorlds.igArgs()).getString("result"))
        assertEquals("cancelled", waitingForUser.control("cancel").getString("result"))
        assertFalse(waitingForUser.world.published)

        val finished = ig()
        finished.execute(TestWorlds.igArgs())
        finished.control("cancel")
        assertEquals("already_finished", finished.control("cancel").getString("error"))
    }

    @Test fun statusChangesNothing() = runBlocking {
        val rig = ig()
        rig.execute(TestWorlds.igArgs())
        val before = rig.driver.log.size
        val r = rig.control("status")
        assertFalse(r.has("accepted")) // an accepted command is not flagged
        assertEquals("awaiting_confirmation", r.getString("result"))
        assertEquals(before, rig.driver.log.size)
    }

    @Test fun theAccountIsOnlyShownNeverSwitched() = runBlocking {
        val rig = ig()
        val args = TestWorlds.igArgs().put("target_account", "@lia.bakes")
        val summary = rig.execute(args).getString("confirmation_summary")
        assertTrue(summary.contains("@lia.bakes"))
        assertTrue(summary.contains("cannot switch accounts"))
    }

    // ---- drafts ------------------------------------------------------------------------------

    @Test fun aDraftIsSavedAndNeverPublished() = runBlocking {
        val rig = ig()
        val r = rig.execute(TestWorlds.igArgs(mode = "draft"))
        assertEquals("draft_saved", r.getString("result"))
        assertTrue(r.getString("message").contains("Nothing was published"))
        assertTrue(rig.world.draftSaved)
        assertFalse(rig.world.published)
        assertEquals(0, rig.driver.clicks("Share"))
        assertFalse(TaskState.WAITING_FOR_CONFIRMATION in rig.visited) // a draft never asks, because it never publishes
    }

    @Test fun aDraftPlanHasNoIrreversibleStepAndAPublishPlanHasExactlyOneLast() {
        fun plan(mode: String): List<PlanStep> {
            val parsed = SocialTaskRequest.parse(TestWorlds.igArgs(mode = mode), TestWorlds.media()) as ParseResult.Valid
            return SocialPlanner.plan(parsed.request)
        }
        assertTrue(plan("draft").none { it.irreversible })
        assertEquals("save_draft", plan("draft").last().id)
        val publish = plan("publish")
        assertEquals(1, publish.count { it.irreversible })
        assertTrue(publish.last().irreversible && publish.last().finalStep)
    }

    @Test fun theRunnerRefusesToPublishInDraftModeEvenWithABadPlan() = runBlocking {
        val world = TestWorlds.instagram()
        val driver = FakeScreenDriver(world)
        val plan = listOf(
            PlanStep("open", "open", StepKind.LAUNCH_APP, packages = listOf(TestWorlds.IG), expect = com.Lia.assistant.agent.core.Expectation.PackageIs(TestWorlds.IG)),
            PlanStep("publish", "publish", StepKind.CLICK, target = SocialSelectors.instagram.publish, irreversible = true, finalStep = true),
        )
        val runner = TaskRunner("t1", "social", TaskMode.DRAFT, "Instagram", plan, driver, BlockerDetector::detect, "x", TestWorlds.fastConfig(), TestWorlds.noWait)
        val report = runner.start(UserSignal(0, ""))
        assertEquals(TaskStatus.FAILED, report.status)
        assertEquals(FailureReason.DRAFT_WOULD_PUBLISH, report.failure)
        assertEquals(0, driver.clicks("Share"))
        assertFalse(world.published)
    }

    // ---- things only the user can do ------------------------------------------------------------

    @Test fun eachBlockerPausesTheTaskAndNothingIsTapped() = runBlocking {
        mapOf(
            "ig_login" to Blocker.LOGIN,
            "ig_captcha" to Blocker.CAPTCHA,
            "ig_code" to Blocker.TWO_FACTOR,
            "ig_check" to Blocker.SECURITY_CHECK,
            "perm" to Blocker.PERMISSION_PROMPT,
        ).forEach { (screen, blocker) ->
            val rig = ig(screen)
            val r = rig.execute(TestWorlds.igArgs())
            assertEquals(screen, "awaiting_user", r.getString("result"))
            assertEquals(screen, blocker.name.lowercase(), r.getString("blocker"))
            assertTrue(r.getBoolean("needs_user"))
            assertEquals(TaskState.WAITING_FOR_USER, rig.runner.machine.state)
            assertEquals(screen, 0, rig.driver.log.count { it.startsWith("click:") || it.startsWith("gesture:") || it.startsWith("type:") })
        }
    }

    @Test fun afterTheUserLogsInTheTaskCarriesOnToTheConfirmation() = runBlocking {
        val rig = ig("ig_login")
        rig.execute(TestWorlds.igArgs())
        rig.world.goTo("ig_chooser") // the user logged in themselves
        val r = rig.control("resume")
        assertEquals("awaiting_confirmation", r.getString("result"))
        assertFalse(rig.world.published)
    }

    @Test fun ifTheBlockerIsStillThereAfterResumeTheTaskWaitsAgain() = runBlocking {
        val rig = ig("ig_login")
        rig.execute(TestWorlds.igArgs())
        val r = rig.control("resume") // the user said "continue" but did not log in
        assertEquals("awaiting_user", r.getString("result"))
        assertEquals("login", r.getString("blocker"))
    }

    @Test fun resumeOnlyWorksWhileWaitingForTheUser() = runBlocking {
        val rig = ig()
        rig.execute(TestWorlds.igArgs())
        val r = rig.control("resume")
        assertFalse(r.getBoolean("accepted"))
        assertEquals("not_waiting_for_user", r.getString("error"))
    }

    // ---- trouble --------------------------------------------------------------------------------

    @Test fun aSubmitWhoseEffectIsNeverSeenIsReportedAsUnverified() = runBlocking {
        val rig = ig()
        rig.world.swallowed += "ig_caption|Share" // the tap lands but the app shows nothing
        rig.execute(TestWorlds.igArgs())
        val r = rig.control("confirm", turns = 1, said = "yes")
        assertEquals("submitted_unverified", r.getString("result"))
        assertFalse(r.getBoolean("verified"))
        assertTrue(r.getString("message").contains("could not confirm"))
        assertEquals(1, rig.driver.clicks("Share")) // and it was not tapped again
        assertEquals(TaskState.COMPLETED, rig.runner.machine.state)
    }

    @Test fun aScreenThatChangesUnderTheAgentDoesNotBreakTheFlow() = runBlocking {
        val rig = ig()
        rig.driver.interfereOnNextClick = 1
        val r = rig.execute(TestWorlds.igArgs())
        assertEquals("awaiting_confirmation", r.getString("result"))
    }

    @Test fun anAppThatCannotBeOpenedFailsClearly() = runBlocking {
        val world = TestWorlds.instagram().also { it.shares.clear() }
        val rig = Rig(world)
        val r = rig.execute(TestWorlds.igArgs())
        assertEquals("failed", r.getString("result"))
        assertEquals("app_not_available", r.getString("reason"))
        assertEquals(0, rig.driver.launched())
    }

    // ---- requests -------------------------------------------------------------------------------

    @Test fun badArgumentsNeverCreateATask() = runBlocking {
        val rig = ig()
        val r = rig.execute(TestWorlds.igArgs().put("platform", "tiktok"))
        assertEquals("invalid_platform", r.getString("error"))
        assertEquals(0, rig.registry.size())
        assertEquals(0, rig.driver.launched())
        assertEquals("media_not_content_uri", rig.execute(TestWorlds.igArgs().put("media_uri", "/sdcard/a.jpg")).getString("error"))
        assertEquals(0, rig.registry.size())
    }

    @Test fun onlyOneTaskRunsAtATime() = runBlocking {
        val rig = ig()
        rig.execute(TestWorlds.igArgs())
        val second = rig.execute(TestWorlds.igArgs())
        assertEquals("task_in_progress", second.getString("error"))
        assertEquals(1, rig.registry.size())
    }

    @Test fun controlNeedsAKnownTaskAndACommand() = runBlocking {
        val rig = ig()
        assertEquals("unknown_task", rig.control("status").getString("error")) // nothing started yet
        rig.execute(TestWorlds.igArgs())
        assertEquals("unknown_task", rig.control("status", taskId = "social-99").getString("error"))
        assertEquals("invalid_command", rig.service.control(JSONObject().put("command", "publish_now"), UserSignal(0, "")).getString("error"))
    }

    // ---- Facebook ---------------------------------------------------------------------------------

    @Test fun aFacebookTextPostGoesThroughTheSameConfirmation() = runBlocking {
        val rig = Rig(TestWorlds.facebook())
        val r = rig.execute(fbArgs)
        assertEquals("awaiting_confirmation", r.getString("result"))
        assertFalse(rig.world.published)
        assertEquals("completed", rig.control("confirm", turns = 1, said = "haan kar do").getString("result"))
        assertTrue(rig.world.published)
    }

    @Test fun aFacebookTextDraftIsSavedNotPosted() = runBlocking {
        val rig = Rig(TestWorlds.facebook())
        val r = rig.execute(fbArgs.put("mode", "draft"))
        assertEquals("draft_saved", r.getString("result"))
        assertTrue(rig.world.draftSaved)
        assertFalse(rig.world.published)
        assertEquals(0, rig.driver.clicks("POST"))
    }
}
