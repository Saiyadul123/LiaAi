package com.Lia.assistant.agent.whatsapp

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class WhatsAppRequestTest {
    private fun args(vararg pairs: Pair<String, String>) = JSONObject().also { j -> pairs.forEach { j.put(it.first, it.second) } }
    private fun code(vararg pairs: Pair<String, String>) = (WhatsAppRequest.parse(args(*pairs)) as WhatsAppParse.Invalid).code
    private fun valid(vararg pairs: Pair<String, String>) = (WhatsAppRequest.parse(args(*pairs)) as WhatsAppParse.Valid).request

    @Test fun phoneNumbersAreReducedToDigits() {
        assertEquals("919876543210", WhatsAppRequest.normalizePhone("+91 98765-43210"))
        assertEquals("4155552671", WhatsAppRequest.normalizePhone("(415) 555-2671"))
        assertNull(WhatsAppRequest.normalizePhone("12345"))
        assertNull(WhatsAppRequest.normalizePhone("1234567890123456")) // 16 digits
        assertNull(WhatsAppRequest.normalizePhone("98765x43210"))
        assertNull(WhatsAppRequest.normalizePhone("priya"))
    }

    @Test fun readingUnreadNeedsNothing() {
        assertEquals(WhatsAppAction.READ_UNREAD, valid("action" to "read_unread").action)
        assertEquals(WhatsAppAction.READ_UNREAD, valid("action" to " READ_UNREAD ").action)
    }

    @Test fun aSendNeedsANumberAndText() {
        assertEquals("phone_required", code("action" to "send_message", "message" to "hi"))
        assertEquals("message_required", code("action" to "send_message", "phone" to "+919876543210"))
        assertEquals("message_too_long", code("action" to "send_message", "phone" to "+919876543210", "message" to "x".repeat(4097)))
        val ok = valid("action" to "send_message", "phone" to "+91 98765 43210", "message" to " Running late ")
        assertEquals("919876543210", ok.phone)
        assertEquals("Running late", ok.message)
    }

    @Test fun aBadNumberIsRefusedEvenWhenOtherThingsAreFine() {
        assertEquals("invalid_phone", code("action" to "send_message", "phone" to "12345", "message" to "hi"))
        assertEquals("invalid_phone", code("action" to "read_chat", "phone" to "abc", "contact" to "Priya"))
    }

    @Test fun chatActionsNeedAContactOrANumber() {
        listOf("read_chat", "mute_chat", "unmute_chat", "mark_read").forEach {
            assertEquals(it, "contact_required", code("action" to it))
            assertEquals("Priya", valid("action" to it, "contact" to "Priya").contact)
            assertEquals("919876543210", valid("action" to it, "phone" to "+919876543210").phone)
        }
    }

    @Test fun searchNeedsAQuery() {
        assertEquals("query_required", code("action" to "search_chat"))
        assertEquals("Asha", valid("action" to "search_chat", "query" to "Asha").query)
    }

    @Test fun muteDurationDefaultsToAlwaysAndMustBeKnown() {
        assertEquals(MuteDuration.ALWAYS, valid("action" to "mute_chat", "contact" to "Priya").duration)
        assertEquals(MuteDuration.HOURS_8, valid("action" to "mute_chat", "contact" to "Priya", "duration" to "8_hours").duration)
        assertEquals(MuteDuration.WEEK_1, valid("action" to "mute_chat", "contact" to "Priya", "duration" to "1_week").duration)
        assertEquals("invalid_duration", code("action" to "mute_chat", "contact" to "Priya", "duration" to "forever"))
    }

    @Test fun unknownActionsAreRefused() {
        assertEquals("invalid_action", code("action" to "delete_chat"))
        assertEquals("invalid_action", code())
    }
}
