package com.Lia.assistant.agent.social

import com.Lia.assistant.agent.TestWorlds
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class SocialTaskRequestTest {
    @Before @After fun clear() = SharedMedia.clear()

    private val uri = TestWorlds.MEDIA.uri
    private fun args(platform: String? = "instagram", action: String? = "create_post", media: String? = uri, caption: String? = "hi", mode: String? = null, account: String? = null) =
        JSONObject().also {
            platform?.let { v -> it.put("platform", v) }
            action?.let { v -> it.put("action", v) }
            media?.let { v -> it.put("media_uri", v) }
            caption?.let { v -> it.put("caption", v) }
            mode?.let { v -> it.put("mode", v) }
            account?.let { v -> it.put("target_account", v) }
        }

    private fun parse(a: JSONObject) = SocialTaskRequest.parse(a, TestWorlds.media())
    private fun invalidCode(a: JSONObject) = (parse(a) as ParseResult.Invalid).code
    private fun valid(a: JSONObject) = (parse(a) as ParseResult.Valid).request

    @Test fun aGoodRequestIsAccepted() {
        val r = valid(args(platform = " Instagram ", action = "CREATE_REEL", caption = " Nice ", account = "@lia"))
        assertEquals(Platform.INSTAGRAM, r.platform)
        assertEquals(SocialAction.CREATE_REEL, r.action)
        assertEquals(TaskMode.PUBLISH, r.mode) // publish is the default, and still waits for a yes
        assertEquals("Nice", r.caption)
        assertEquals(uri, r.mediaUri)
        assertEquals("image/jpeg", r.mimeType)
        assertEquals("a.jpg", r.mediaName)
        assertEquals("@lia", r.targetAccount)
    }

    @Test fun platformActionAndModeMustBeKnown() {
        assertEquals("invalid_platform", invalidCode(args(platform = "tiktok")))
        assertEquals("invalid_platform", invalidCode(args(platform = null)))
        assertEquals("invalid_action", invalidCode(args(action = "delete_account")))
        assertEquals("invalid_action", invalidCode(args(action = null)))
        assertEquals("invalid_mode", invalidCode(args(mode = "schedule")))
    }

    @Test fun nullValuesCountAsMissing() {
        val a = args().put("platform", JSONObject.NULL)
        assertEquals("invalid_platform", invalidCode(a))
    }

    @Test fun instagramHasNoTextOnlyPosts() {
        assertEquals("action_not_supported", invalidCode(args(action = "text_post", media = null)))
    }

    @Test fun storiesCannotBeDrafts() {
        assertEquals("draft_not_supported", invalidCode(args(action = "create_story", mode = "draft")))
        assertEquals(TaskMode.DRAFT, valid(args(action = "create_reel", mode = "draft")).mode)
    }

    @Test fun captionRules() {
        assertEquals("caption_too_long", invalidCode(args(caption = "x".repeat(2201))))
        valid(args(caption = "x".repeat(2200)))
        val fb = args(platform = "facebook", action = "text_post", media = null)
        assertEquals("caption_required", invalidCode(fb.put("caption", "  ")))
        assertEquals("Hello", valid(fb.put("caption", "Hello")).caption)
        valid(args(caption = null)) // a media post may have no caption
    }

    @Test fun aTextPostNeedsNoMediaAndIgnoresAnyGiven() {
        val r = valid(args(platform = "facebook", action = "text_post", media = uri, caption = "Hello"))
        assertNull(r.mediaUri)
    }

    @Test fun mediaPostsNeedSharedContentUris() {
        assertEquals("media_required", invalidCode(args(media = null)))
        assertEquals("media_required", invalidCode(args(media = "  ")))
        assertEquals("media_not_content_uri", invalidCode(args(media = "file:///sdcard/DCIM/a.jpg")))
        assertEquals("media_not_content_uri", invalidCode(args(media = "/sdcard/DCIM/a.jpg")))
        assertEquals("media_not_content_uri", invalidCode(args(media = "https://example.com/a.jpg")))
        assertEquals("media_not_shared", invalidCode(args(media = "content://com.other.app/files/1")))
    }

    @Test fun latestMeansTheMostRecentlySharedFile() {
        assertEquals(uri, valid(args(media = "latest")).mediaUri)
        val none = SocialTaskRequest.parse(args(media = "latest"), MediaResolver(lookup = { null }, latest = { null }))
        assertEquals("media_not_shared", (none as ParseResult.Invalid).code)
    }

    // ---- the registry of shared files ----------------------------------------------------------

    @Test fun onlyFilesSharedToTheAssistantAreAllowed() {
        val resolver = MediaResolver()
        assertEquals("media_not_shared", (resolver.resolve("content://x/1") as MediaResolver.Result.Rejected).code)
        SharedMedia.register("content://x/1", "video/mp4", "clip.mp4")
        val ok = resolver.resolve("content://x/1") as MediaResolver.Result.Allowed
        assertEquals("video/mp4", ok.mimeType)
        assertEquals("clip.mp4", ok.displayName)
        assertEquals("content://x/1", (resolver.resolve("LATEST") as MediaResolver.Result.Allowed).uri)
    }

    @Test fun theRegistryKeepsOnlyTheLatestTwenty() {
        (1..25).forEach { SharedMedia.register("content://x/$it", null, "f$it") }
        assertNull(SharedMedia.get("content://x/1"))
        assertTrue(SharedMedia.get("content://x/25") != null)
        assertEquals("content://x/25", SharedMedia.latest()!!.uri)
    }
}
