package com.Lia.assistant.action

import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DirectActionExecutorTest {
    private fun exec(ctx: FakeContext, name: String, vararg kv: Pair<String, String>) = runBlocking {
        ActionExecutor.execute(ctx, name, JSONObject().also { o -> kv.forEach { o.put(it.first, it.second) } })
    }

    @Test fun unknownToolReturnsError() {
        assertEquals("Unknown tool: bogus", exec(FakeContext(), "bogus").getString("error"))
    }

    @Test fun screenToolsReportAccessibilityNotEnabledWithoutAService() {
        listOf("read_screen", "tap_text", "type_text", "scroll_screen", "go_back", "go_home").forEach {
            assertEquals(it, "accessibility_not_enabled", exec(FakeContext(), it, "text" to "x").getString("result"))
        }
    }

    @Test fun messageWithoutAccessibilityJustOpensTheComposer() {
        val ctx = FakeContext()
        val r = exec(ctx, "message_contact", "contact" to "98765 43210", "message" to "hi")
        assertEquals("composer_opened", r.getString("result"))
        assertEquals(1, ctx.started.size)
    }

    @Test fun sendIsTappedOnTheFirstTryAfterOneWait() = runBlocking {
        val waits = mutableListOf<Long>()
        val taps = mutableListOf<String>()
        val sent = ActionExecutor.autoTapSend(false, { taps += it; true }, { waits += it })
        assertTrue(sent)
        assertEquals(listOf(400L), waits)
        assertEquals(listOf("Send"), taps)
    }

    @Test fun whatsAppTapsContinueToChatBeforeSend() = runBlocking {
        val taps = mutableListOf<String>()
        var sendCalls = 0
        val sent = ActionExecutor.autoTapSend(
            isWhatsApp = true,
            tap = { label -> taps += label; if (label == "Send") ++sendCalls >= 2 else true },
            wait = { },
        )
        assertTrue(sent)
        assertEquals(listOf("Continue to chat", "Send", "Continue to chat", "Send"), taps)
    }

    @Test fun givesUpAfterTwelveTries() = runBlocking {
        var waits = 0
        val sent = ActionExecutor.autoTapSend(false, { false }, { waits++ })
        assertFalse(sent)
        assertEquals(12, waits)
    }

    @Test fun smsNeverTapsContinueToChat() = runBlocking {
        val taps = mutableListOf<String>()
        ActionExecutor.autoTapSend(false, { taps += it; false }, { })
        assertFalse(taps.contains("Continue to chat"))
    }
}
