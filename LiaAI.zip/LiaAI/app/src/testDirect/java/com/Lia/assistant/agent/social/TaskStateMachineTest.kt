package com.Lia.assistant.agent.social

import com.Lia.assistant.agent.social.TaskState.CANCELLED
import com.Lia.assistant.agent.social.TaskState.COMPLETED
import com.Lia.assistant.agent.social.TaskState.EXECUTING_ACTION
import com.Lia.assistant.agent.social.TaskState.FAILED
import com.Lia.assistant.agent.social.TaskState.IDLE
import com.Lia.assistant.agent.social.TaskState.NEXT_STEP
import com.Lia.assistant.agent.social.TaskState.OBSERVING
import com.Lia.assistant.agent.social.TaskState.OPENING_APP
import com.Lia.assistant.agent.social.TaskState.REOBSERVE
import com.Lia.assistant.agent.social.TaskState.RESOLVING_TARGET
import com.Lia.assistant.agent.social.TaskState.RETRY
import com.Lia.assistant.agent.social.TaskState.VALIDATING_TARGET
import com.Lia.assistant.agent.social.TaskState.VERIFYING
import com.Lia.assistant.agent.social.TaskState.WAITING_FOR_CONFIRMATION
import com.Lia.assistant.agent.social.TaskState.WAITING_FOR_UI
import com.Lia.assistant.agent.social.TaskState.WAITING_FOR_USER
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TaskStateMachineTest {

    /** The legal moves, written out independently of the production table. FAILED/CANCELLED are added below. */
    private val forward: Map<TaskState, Set<TaskState>> = mapOf(
        IDLE to setOf(OPENING_APP),
        OPENING_APP to setOf(WAITING_FOR_UI, OBSERVING, RETRY),
        OBSERVING to setOf(RESOLVING_TARGET, EXECUTING_ACTION, NEXT_STEP, WAITING_FOR_USER, RETRY),
        RESOLVING_TARGET to setOf(VALIDATING_TARGET, NEXT_STEP, RETRY, REOBSERVE, WAITING_FOR_USER),
        VALIDATING_TARGET to setOf(EXECUTING_ACTION, WAITING_FOR_CONFIRMATION, RETRY, REOBSERVE),
        WAITING_FOR_CONFIRMATION to setOf(EXECUTING_ACTION),
        EXECUTING_ACTION to setOf(WAITING_FOR_UI, VERIFYING, RETRY, WAITING_FOR_USER),
        WAITING_FOR_UI to setOf(VERIFYING, OBSERVING, REOBSERVE, RETRY, WAITING_FOR_USER),
        VERIFYING to setOf(NEXT_STEP, RETRY, REOBSERVE, WAITING_FOR_USER),
        NEXT_STEP to setOf(OBSERVING, OPENING_APP, COMPLETED),
        RETRY to setOf(OBSERVING, REOBSERVE, OPENING_APP),
        REOBSERVE to setOf(OBSERVING, RESOLVING_TARGET, WAITING_FOR_USER),
        WAITING_FOR_USER to setOf(REOBSERVE, OBSERVING, OPENING_APP),
        COMPLETED to emptySet(),
        FAILED to emptySet(),
        CANCELLED to emptySet(),
    )

    private fun expected(from: TaskState, to: TaskState): Boolean =
        to in forward.getValue(from) || (!from.isTerminal && (to == FAILED || to == CANCELLED))

    @Test fun thereAreSixteenStates() {
        assertEquals(16, TaskState.entries.size)
        assertEquals(TaskState.entries.toSet(), forward.keys)
    }

    @Test fun everyPairOfStatesIsLegalExactlyWhenTheTableSaysSo() {
        for (from in TaskState.entries) for (to in TaskState.entries) {
            val machine = TaskStateMachine(initial = from)
            val allowed = expected(from, to)
            assertEquals("canMoveTo $from -> $to", allowed, machine.canMoveTo(to))
            val thrown = runCatching { machine.moveTo(to) }.exceptionOrNull()
            if (allowed) {
                assertEquals("$from -> $to should be legal", null, thrown)
                assertEquals(to, machine.state)
                assertEquals(1, machine.history.size)
            } else {
                assertTrue("$from -> $to should throw", thrown is IllegalTransitionException)
                assertEquals("state must not change after an illegal move", from, machine.state)
                assertTrue(machine.history.isEmpty())
            }
        }
    }

    @Test fun failedAndCancelledAreReachableFromEveryStateThatIsNotFinal() {
        TaskState.entries.filter { !it.isTerminal }.forEach { from ->
            assertTrue("$from -> FAILED", TaskStateMachine(from).canMoveTo(FAILED))
            assertTrue("$from -> CANCELLED", TaskStateMachine(from).canMoveTo(CANCELLED))
        }
    }

    @Test fun finalStatesNeverLeave() {
        listOf(COMPLETED, FAILED, CANCELLED).forEach { from ->
            assertTrue(from.isTerminal)
            TaskState.entries.forEach { to ->
                assertFalse("$from -> $to", TaskStateMachine(from).canMoveTo(to))
                val thrown = runCatching { TaskStateMachine(from).moveTo(to) }.exceptionOrNull()
                assertTrue(thrown is IllegalTransitionException)
            }
        }
        assertEquals(setOf(COMPLETED, FAILED, CANCELLED), TaskState.entries.filter { it.isTerminal }.toSet())
    }

    @Test fun movingToTheSameStateIsIllegal() {
        TaskState.entries.forEach { s -> assertFalse("$s -> $s", TaskStateMachine(s).canMoveTo(s)) }
    }

    @Test fun theConfirmationStateCanOnlyBeLeftByExecutingOrEnding() {
        assertEquals(
            setOf(EXECUTING_ACTION, FAILED, CANCELLED),
            TaskStateMachine.legalTargets(WAITING_FOR_CONFIRMATION),
        )
    }

    @Test fun aTaskCannotSkipStraightToTheIrreversibleAction() {
        assertFalse(TaskStateMachine(IDLE).canMoveTo(EXECUTING_ACTION))
        assertFalse(TaskStateMachine(VALIDATING_TARGET).canMoveTo(COMPLETED))
        assertFalse(TaskStateMachine(OBSERVING).canMoveTo(WAITING_FOR_CONFIRMATION))
    }

    @Test fun theHappyPathIsLegalFromStartToFinish() {
        val m = TaskStateMachine()
        listOf(
            OPENING_APP, WAITING_FOR_UI, VERIFYING, NEXT_STEP, OBSERVING, RESOLVING_TARGET, VALIDATING_TARGET,
            WAITING_FOR_CONFIRMATION, EXECUTING_ACTION, WAITING_FOR_UI, VERIFYING, NEXT_STEP, COMPLETED,
        ).forEach { m.moveTo(it) }
        assertEquals(COMPLETED, m.state)
        assertTrue(m.isTerminal)
    }

    @Test fun theBlockerAndRetryDetoursAreLegal() {
        val blocked = TaskStateMachine(OBSERVING)
        listOf(WAITING_FOR_USER, REOBSERVE, OBSERVING).forEach { blocked.moveTo(it) }
        val retried = TaskStateMachine(EXECUTING_ACTION)
        listOf(RETRY, REOBSERVE, OBSERVING, RESOLVING_TARGET).forEach { retried.moveTo(it) }
        assertEquals(RESOLVING_TARGET, retried.state)
    }

    @Test fun everyMoveIsKeptInOrderWithItsTimeAndNote() {
        var now = 1000L
        val m = TaskStateMachine(clock = { now.also { now += 10 } })
        m.moveTo(OPENING_APP, "start")
        m.moveTo(OBSERVING)
        m.moveTo(FAILED, "boom")
        assertEquals(listOf(IDLE, OPENING_APP, OBSERVING), m.history.map { it.from })
        assertEquals(listOf(OPENING_APP, OBSERVING, FAILED), m.history.map { it.to })
        assertEquals(listOf(1000L, 1010L, 1020L), m.history.map { it.atMillis })
        assertEquals(listOf<String?>("start", null, "boom"), m.history.map { it.note })
    }

    @Test fun anIllegalMoveSaysWhichStatesWereInvolved() {
        val e = runCatching { TaskStateMachine().moveTo(COMPLETED) }.exceptionOrNull() as IllegalTransitionException
        assertEquals(IDLE, e.from)
        assertEquals(COMPLETED, e.to)
        assertTrue(e.message!!.contains("IDLE") && e.message!!.contains("COMPLETED"))
    }
}
