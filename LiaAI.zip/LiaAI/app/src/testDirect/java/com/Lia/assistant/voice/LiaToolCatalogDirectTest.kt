package com.Lia.assistant.voice

import org.junit.Assert.assertEquals
import org.junit.Test

class LiaToolCatalogDirectTest {
    @Test fun directHasPhoneActionsAndScreenControl() {
        val names = LiaToolCatalog.declarations().map { it.name }
        assertEquals(
            listOf(
                "open_app", "call_contact", "message_contact", "read_screen", "tap_text",
                "type_text", "scroll_screen", "go_back", "go_home"
            ),
            names
        )
    }

    @Test fun messageContactRequiresContactAndMessage() {
        val m = LiaToolCatalog.declarations().first { it.name == "message_contact" }
        assertEquals(listOf("contact", "message"), m.params.filter { it.required }.map { it.name })
    }
}
