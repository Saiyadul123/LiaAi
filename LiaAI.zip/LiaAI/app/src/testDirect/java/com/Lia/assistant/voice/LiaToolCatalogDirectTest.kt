package com.Lia.assistant.voice

import org.junit.Assert.assertTrue
import org.junit.Test

class LiaToolCatalogDirectTest {
    @Test fun directIncludesScreenControl() {
        val names = LiaToolCatalog.declarations().map { it.name }
        assertTrue(names.containsAll(listOf("call_contact", "read_screen", "tap", "type_text", "open_app")))
    }
}
