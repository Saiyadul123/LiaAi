package com.Lia.assistant.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LiaToolCatalogDirectTest {
    @Test fun directHasPhoneActionsScreenControlAndTheAgents() {
        val names = LiaToolCatalog.declarations().map { it.name }
        assertEquals(
            listOf(
                "open_app", "call_contact", "message_contact", "read_screen", "tap_text",
                "type_text", "scroll_screen", "go_back", "go_home",
                "execute_social_media_task", "social_media_task_control", "execute_whatsapp_task", "whatsapp_task_control",
            ),
            names
        )
    }

    @Test fun messageContactRequiresContactAndMessage() {
        val m = LiaToolCatalog.declarations().first { it.name == "message_contact" }
        assertEquals(listOf("contact", "message"), m.params.filter { it.required }.map { it.name })
    }

    @Test fun toolNamesAreUnique() {
        val names = LiaToolCatalog.declarations().map { it.name }
        assertEquals(names.size, names.toSet().size)
    }

    @Test fun theCapabilityPromptMentionsTheAgentsAndTheConfirmationRule() {
        val prompt = LiaCapabilityPrompts.toolInstruction("Lia")
        assertTrue(prompt.contains("execute_social_media_task"))
        assertTrue(prompt.contains("execute_whatsapp_task"))
        assertTrue(prompt.contains("explicitly say yes"))
    }
}
