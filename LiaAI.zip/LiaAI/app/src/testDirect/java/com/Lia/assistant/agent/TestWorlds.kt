package com.Lia.assistant.agent

import com.Lia.assistant.agent.core.Bounds
import com.Lia.assistant.agent.core.ExecConfig
import com.Lia.assistant.agent.core.ScreenObservation
import com.Lia.assistant.agent.core.UiElement
import com.Lia.assistant.agent.social.MediaResolver
import com.Lia.assistant.agent.social.SharedMedia
import com.Lia.assistant.agent.social.TaskRunner
import org.json.JSONObject

/** Ready-made scripted apps, laid out to match the selectors the planners use. */
object TestWorlds {
    const val IG = "com.instagram.android"
    const val FB = "com.facebook.katana"
    const val WA = "com.whatsapp"

    /** No waiting in tests, and few polls. */
    fun fastConfig() = TaskRunner.RunnerConfig(
        launchWaitMs = 0, pollAttempts = 2, pollIntervalMs = 0, optionalPolls = 1, maxStepRetries = 1, retryDelayMs = 0,
        exec = ExecConfig(settleMs = 0, verifyAttempts = 2, verifyIntervalMs = 0, maxReobserve = 2),
    )

    val noWait: suspend (Long) -> Unit = { }

    val MEDIA = SharedMedia.Entry("content://com.Lia.assistant.direct.fileprovider/shared/a.jpg", "image/jpeg", "a.jpg", 0)
    fun media() = MediaResolver(lookup = { if (it == MEDIA.uri) MEDIA else null }, latest = { MEDIA })

    fun igArgs(action: String = "create_post", mode: String? = null, caption: String = "Hello world") = JSONObject()
        .put("platform", "instagram").put("action", action).put("media_uri", MEDIA.uri).put("caption", caption)
        .also { if (mode != null) it.put("mode", mode) }

    private fun el(text: String, clickable: Boolean = false) = FakeEl(text = text, clickable = clickable)

    /** Instagram: share sheet -> crop -> edit -> caption -> sharing. Back from the caption offers "Save draft". */
    fun instagram(shareLands: String = "ig_chooser"): FakeWorld {
        val screens = listOf(
            FakeScreen("ig_chooser", IG, listOf(el("Share to"), el("Feed", true), el("Story", true), el("Reels", true))),
            FakeScreen("ig_crop", IG, listOf(el("New post"), el("Next", true))),
            FakeScreen("ig_edit", IG, listOf(el("Edit"), el("Next", true))),
            FakeScreen(
                "ig_caption", IG,
                listOf(
                    el("New post"),
                    FakeEl(hint = "Write a caption…", viewId = "$IG:id/caption_text_view", className = "android.widget.EditText", clickable = true, editable = true),
                    el("Share", true),
                ),
            ),
            FakeScreen("ig_sharing", IG, listOf(el("Sharing to Instagram…"))),
            FakeScreen("ig_discard", IG, listOf(el("Save draft", true), el("Discard", true))),
            FakeScreen("ig_draft_done", IG, listOf(el("Draft saved"))),
            FakeScreen("ig_login", IG, listOf(el("Log in", true), FakeEl(hint = "Password", editable = true, clickable = true), el("Create new account", true))),
            FakeScreen("ig_captcha", IG, listOf(el("Select all images with traffic lights"))),
            FakeScreen("ig_code", IG, listOf(el("Enter the 6-digit code we sent you"))),
            FakeScreen("ig_check", IG, listOf(el("We detected unusual activity on your account"))),
            FakeScreen("perm", "com.google.android.permissioncontroller", listOf(el("Allow Instagram to access photos?"), el("Allow", true))),
        ).associateBy { it.id }
        val world = FakeWorld(screens, "ig_chooser")
        world.shares[IG] = shareLands
        world.apps[IG] = "ig_chooser"
        world.on("ig_chooser", "Feed", "ig_crop")
        world.on("ig_crop", "Next", "ig_edit")
        world.on("ig_edit", "Next", "ig_caption")
        world.on("ig_caption", "Share", "ig_sharing") { world.published = true }
        world.on("ig_discard", "Save draft", "ig_draft_done") { world.draftSaved = true }
        world.backs["ig_caption"] = "ig_discard"
        return world
    }

    /** Facebook: home -> composer -> posting. */
    fun facebook(): FakeWorld {
        val screens = listOf(
            FakeScreen("fb_home", FB, listOf(el("What's on your mind?", true))),
            FakeScreen(
                "fb_composer", FB,
                listOf(
                    FakeEl(hint = "What's on your mind?", className = "android.widget.EditText", clickable = true, editable = true),
                    el("POST", true),
                ),
            ),
            FakeScreen("fb_posting", FB, listOf(el("Posting…"))),
            FakeScreen("fb_discard", FB, listOf(el("Save as draft", true), el("Discard", true))),
            FakeScreen("fb_draft_done", FB, listOf(el("Draft saved"))),
        ).associateBy { it.id }
        val world = FakeWorld(screens, "fb_home")
        world.apps[FB] = "fb_home"
        world.on("fb_home", "What's on your mind?", "fb_composer")
        world.on("fb_composer", "POST", "fb_posting") { world.published = true }
        world.on("fb_discard", "Save as draft", "fb_draft_done") { world.draftSaved = true }
        world.backs["fb_composer"] = "fb_discard"
        return world
    }

    /**
     * WhatsApp: chat list -> search (two Ashas, one Priya) -> a chat -> its menu -> the mute dialog; and a chat
     * opened by link with a message waiting in the box. Two filler rows keep results below the top bar.
     */
    fun whatsapp(): FakeWorld {
        val screens = listOf(
            FakeScreen("wa_home", WA, listOf(FakeEl(desc = "Search", clickable = true), el("Chats"), el("Contacts"), el("Priya Nair", true))),
            FakeScreen(
                "wa_search", WA,
                listOf(
                    FakeEl(hint = "Search…", viewId = "$WA:id/search_input", className = "android.widget.EditText", clickable = true, editable = true),
                    el("Chats"), el("Contacts"),
                    el("Asha Sharma", true), el("Asha Verma", true), el("Priya Nair", true),
                ),
            ),
            FakeScreen(
                "wa_chat", WA,
                listOf(
                    FakeEl(desc = "More options", clickable = true), el("Priya Nair"), el("online"),
                    el("Hello Priya"), el("Are we still on for tonight?"),
                    FakeEl(hint = "Type a message", className = "android.widget.EditText", clickable = true, editable = true),
                ),
            ),
            FakeScreen("wa_menu", WA, listOf(el("Mute notifications", true), el("Search", true))),
            FakeScreen("wa_mute", WA, listOf(el("8 hours", true), el("1 week", true), el("Always", true), el("OK", true))),
            FakeScreen("wa_muted", WA, listOf(FakeEl(desc = "More options", clickable = true), el("Priya Nair"), el("muted"))),
            FakeScreen(
                "wa_send", WA,
                listOf(
                    FakeEl(desc = "More options", clickable = true), el("Priya Nair"), el("online"),
                    FakeEl(hint = "Type a message", className = "android.widget.EditText", clickable = true, editable = true),
                    FakeEl(desc = "Send", clickable = true),
                ),
            ),
            FakeScreen(
                "wa_sent", WA,
                listOf(
                    FakeEl(desc = "More options", clickable = true), el("Priya Nair"), el("online"),
                    el("Running late"),
                    FakeEl(desc = "Voice message", clickable = true),
                ),
            ),
        ).associateBy { it.id }
        val world = FakeWorld(screens, "wa_home")
        world.apps[WA] = "wa_home"
        world.links[WA] = "wa_send"
        world.on("wa_home", "Search", "wa_search")
        world.on("wa_search", "Priya Nair", "wa_chat")
        world.on("wa_chat", "More options", "wa_menu")
        world.on("wa_menu", "Mute notifications", "wa_mute")
        world.on("wa_mute", "OK", "wa_muted")
        world.on("wa_send", "Send", "wa_sent")
        world.backs["wa_chat"] = "wa_home"
        world.typed["wa_send|3"] = "Running late" // the link pre-fills the box
        return world
    }

    // ---- hand-made observations for resolver tests ----------------------------------------------

    fun uiEl(
        id: Int, text: String = "", desc: String = "", hint: String = "", viewId: String = "", cls: String = "",
        top: Int = 100, clickable: Boolean = false, editable: Boolean = false, enabled: Boolean = true,
        ancestorClickable: Boolean = false, width: Int = 1000,
    ) = UiElement(
        id = id, text = text, contentDescription = desc, hint = hint, viewId = viewId, className = cls,
        bounds = Bounds(40, top, 40 + width, top + 100), clickable = clickable, editable = editable, scrollable = false,
        enabled = enabled, focused = false, checked = null, path = listOf(id), clickableAncestor = ancestorClickable,
    )

    fun observation(vararg elements: UiElement, pkg: String = "pkg", windowClass: String = "Activity") = ScreenObservation(
        observationId = 1, packageName = pkg, windowClass = windowClass, elements = elements.toList(),
        screenWidth = 1080, screenHeight = 2400, windowStamp = 1,
    )
}
