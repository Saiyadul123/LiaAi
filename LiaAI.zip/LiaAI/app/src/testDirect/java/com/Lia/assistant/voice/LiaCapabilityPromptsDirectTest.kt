package com.Lia.assistant.voice

import org.junit.Assert.assertTrue
import org.junit.Test

class LiaCapabilityPromptsDirectTest {
    @Test fun directDescribesScreenControl() {
        val s = LiaCapabilityPrompts.toolInstruction("Lia")
        assertTrue(s.contains("operate the screen"))
        assertTrue(s.contains("Lia"))
    }
}
