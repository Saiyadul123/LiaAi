package com.Lia.assistant.voice

import org.junit.Assert.assertTrue
import org.junit.Test

class LiaCapabilityPromptsDirectTest {
    @Test fun directDescribesScreenControlAndAutoSend() {
        val s = LiaCapabilityPrompts.toolInstruction("Lia")
        assertTrue(s.contains("operate the screen"))
        assertTrue(s.contains("taps Send for you"))
        assertTrue(s.contains("confirm the recipient"))
        assertTrue(s.contains("As Lia"))
    }
}
