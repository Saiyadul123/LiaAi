package com.Lia.assistant.agent.core

import com.Lia.assistant.agent.FakeEl
import com.Lia.assistant.agent.FakeScreen
import com.Lia.assistant.agent.FakeScreenDriver
import com.Lia.assistant.agent.FakeWorld
import com.Lia.assistant.agent.TestWorlds
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class UiActionExecutorTest {
    private val go = TargetSpec(labels = listOf("Go"), requireTappable = true, description = "the Go button")
    private val goneAfter = Expectation.TargetGone(go)

    private fun world(): FakeWorld {
        val screens = listOf(
            FakeScreen("a", "pkg", listOf(FakeEl(text = "Go", clickable = true))),
            FakeScreen("b", "pkg", listOf(FakeEl(text = "Done"))),
        ).associateBy { it.id }
        return FakeWorld(screens, "a").also { it.on("a", "Go", "b") }
    }

    private val config = ExecConfig(settleMs = 0, verifyAttempts = 2, verifyIntervalMs = 0, maxReobserve = 2)
    private fun executor(driver: FakeScreenDriver, config: ExecConfig = this.config, blocker: (ScreenObservation) -> Blocker? = { null },
                         vision: (suspend (ScreenObservation, TargetSpec) -> TapPoint?)? = null) =
        UiActionExecutor(driver, blocker, { }, config, vision)

    @Test fun aClickThatWorksIsVerifiedAndReported() = runBlocking {
        val driver = FakeScreenDriver(world())
        val result = executor(driver).click(go, goneAfter)
        assertEquals(ActionMethod.ACCESSIBILITY_CLICK, (result as ActionResult.Success).method)
        assertEquals("b", driver.world.current)
    }

    @Test fun whenTheAccessibilityClickIsRejectedAGestureOnTheBoundsIsTried() = runBlocking {
        val driver = FakeScreenDriver(world()).also { it.rejectAccessibilityClicks = true }
        val result = executor(driver).click(go, goneAfter)
        assertEquals(ActionMethod.GESTURE_ON_ELEMENT_BOUNDS, (result as ActionResult.Success).method)
        assertEquals(1, driver.clicks("Go"))
    }

    @Test fun visionTapIsTheLastResortAndOnlyWhenAProviderIsInstalled() = runBlocking {
        val cfg = config.copy(methods = listOf(ActionMethod.ACCESSIBILITY_CLICK, ActionMethod.VISION_TAP))
        val rejecting = { FakeScreenDriver(world()).also { it.rejectAccessibilityClicks = true } }

        val withVision = executor(rejecting(), cfg, vision = { _, _ -> TapPoint(500, 150) }).click(go, goneAfter)
        assertEquals(ActionMethod.VISION_TAP, (withVision as ActionResult.Success).method)

        val without = executor(rejecting(), cfg).click(go, goneAfter)
        assertEquals(FailureReason.ACTION_REJECTED, (without as ActionResult.Failed).reason)
    }

    @Test fun ifEveryMethodFailsTheClickIsReportedAsRejected() = runBlocking {
        val driver = FakeScreenDriver(world()).also { it.rejectAccessibilityClicks = true; it.rejectGestures = true }
        val result = executor(driver).click(go, goneAfter)
        assertEquals(FailureReason.ACTION_REJECTED, (result as ActionResult.Failed).reason)
        assertEquals("a", driver.world.current)
    }

    @Test fun aDeliveredClickWithoutTheExpectedEffectIsNeverRepeated() = runBlocking {
        val world = world().also { it.swallowed += "a|Go" }
        val driver = FakeScreenDriver(world)
        val result = executor(driver).click(go, goneAfter)
        assertEquals(FailureReason.NOT_VERIFIED, (result as ActionResult.Failed).reason)
        assertEquals(1, driver.clicks("Go")) // a second tap by another method could do the thing twice
    }

    @Test fun nothingToVerifyMeansSuccessAfterTheClick() = runBlocking {
        val result = executor(FakeScreenDriver(world())).click(go, Expectation.None)
        assertTrue(result is ActionResult.Success)
    }

    @Test fun aStaleObservationIsTakenAgainNotActedOn() = runBlocking {
        val driver = FakeScreenDriver(world()).also { it.interfereOnNextClick = 1 }
        val result = executor(driver).click(go, goneAfter)
        assertTrue(result is ActionResult.Success)
        assertEquals(1, driver.clicks("Go")) // the stale attempt clicked nothing
        assertTrue(driver.captures >= 3)
    }

    @Test fun ifTheScreenKeepsChangingTheClickGivesUp() = runBlocking {
        val driver = FakeScreenDriver(world()).also { it.staleClicks = 10 }
        val result = executor(driver).click(go, goneAfter)
        assertEquals(FailureReason.STALE_OBSERVATION, (result as ActionResult.Failed).reason)
        assertEquals(0, driver.clicks("Go"))
    }

    @Test fun aBlockerStopsEverythingBeforeAnyClick() = runBlocking {
        val driver = FakeScreenDriver(world())
        val result = executor(driver, blocker = { Blocker.LOGIN }).click(go, goneAfter)
        assertEquals(ActionResult.Blocked(Blocker.LOGIN), result)
        assertEquals(0, driver.clicks("Go"))
    }

    @Test fun aBlockerThatAppearsAfterTheClickIsReported() = runBlocking {
        val driver = FakeScreenDriver(world())
        val result = executor(driver, blocker = { if (it.packageName == "pkg" && it.elements.any { e -> e.text == "Done" }) Blocker.TWO_FACTOR else null })
            .click(go, goneAfter)
        assertEquals(ActionResult.Blocked(Blocker.TWO_FACTOR), result)
    }

    @Test fun missingAndAmbiguousTargetsAreReportedWithoutGuessing() = runBlocking {
        val driver = FakeScreenDriver(world())
        val missing = executor(driver).click(TargetSpec(labels = listOf("Nope")), Expectation.None)
        assertEquals(FailureReason.TARGET_NOT_FOUND, (missing as ActionResult.Failed).reason)

        val two = FakeWorld(
            listOf(FakeScreen("t", "pkg", listOf(FakeEl(text = "Asha A", clickable = true), FakeEl(text = "Asha B", clickable = true)))).associateBy { it.id },
            "t",
        )
        val ambiguous = executor(FakeScreenDriver(two)).click(TargetSpec(labels = listOf("Asha"), requireUnique = true), Expectation.None)
        assertEquals(FailureReason.TARGET_AMBIGUOUS, (ambiguous as ActionResult.Failed).reason)
    }

    @Test fun expectationsAreCheckedAgainstFreshObservations() = runBlocking {
        val driver = FakeScreenDriver(world())
        val result = executor(driver).click(go, Expectation.AllOf(listOf(Expectation.TextPresent("done"), Expectation.ScreenChanged)))
        assertTrue(result is ActionResult.Success)
    }
}
