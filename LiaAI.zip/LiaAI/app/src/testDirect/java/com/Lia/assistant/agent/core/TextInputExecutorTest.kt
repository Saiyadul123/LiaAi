package com.Lia.assistant.agent.core

import com.Lia.assistant.agent.FakeEl
import com.Lia.assistant.agent.FakeScreen
import com.Lia.assistant.agent.FakeScreenDriver
import com.Lia.assistant.agent.FakeWorld
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TextInputExecutorTest {
    private val field = TargetSpec(labels = listOf("Caption"), description = "the caption box")
    private val config = ExecConfig(settleMs = 0, verifyAttempts = 2, verifyIntervalMs = 0, maxReobserve = 2)

    private fun world() = FakeWorld(
        listOf(
            FakeScreen("form", "pkg", listOf(FakeEl(text = "Title"), FakeEl(hint = "Caption", className = "android.widget.EditText", clickable = true, editable = true))),
        ).associateBy { it.id },
        "form",
    )

    private fun typer(driver: FakeScreenDriver, blocker: (ScreenObservation) -> Blocker? = { null }) =
        TextInputExecutor(driver, blocker, { }, config)

    @Test fun focusesTypesAndChecksTheTextIsThere() = runBlocking {
        val driver = FakeScreenDriver(world())
        val result = typer(driver).type(field, "Hello world")
        assertEquals(ActionMethod.SET_TEXT, (result as ActionResult.Success).method)
        assertEquals("Hello world", driver.world.typed["form|1"])
    }

    @Test fun anotherFieldIsNeverTypedInto() = runBlocking {
        val driver = FakeScreenDriver(world())
        val result = typer(driver).type(TargetSpec(labels = listOf("Title")), "x") // "Title" is plain text, not an input
        assertEquals(FailureReason.TARGET_NOT_FOUND, (result as ActionResult.Failed).reason)
        assertTrue(driver.log.none { it.startsWith("type:") })
    }

    @Test fun fallsBackToAGestureToFocusTheField() = runBlocking {
        val driver = FakeScreenDriver(world()).also { it.rejectAccessibilityClicks = true }
        val result = typer(driver).type(field, "Hi")
        assertTrue(result is ActionResult.Success)
        assertEquals(1, driver.clicks("Caption"))
        assertTrue(driver.log.contains("gesture:Caption"))
    }

    @Test fun textThatDidNotLandIsNotReportedAsTyped() = runBlocking {
        val driver = FakeScreenDriver(world()).also { it.ignoreSetText = true }
        val result = typer(driver).type(field, "Hello")
        assertEquals(FailureReason.NOT_VERIFIED, (result as ActionResult.Failed).reason)
    }

    @Test fun aFieldThatRefusesOrCannotBeUsedIsReported() = runBlocking {
        val refused = FakeScreenDriver(world()).also { it.setTextResult = DriverResult.FAILED }
        assertEquals(FailureReason.ACTION_REJECTED, (typer(refused).type(field, "x") as ActionResult.Failed).reason)
        val unsupported = FakeScreenDriver(world()).also { it.setTextResult = DriverResult.UNSUPPORTED }
        assertEquals(FailureReason.UNSUPPORTED, (typer(unsupported).type(field, "x") as ActionResult.Failed).reason)
    }

    @Test fun blankTextAndBlockersAreHandledBeforeTyping() = runBlocking {
        val driver = FakeScreenDriver(world())
        assertEquals(FailureReason.INVALID_INPUT, (typer(driver).type(field, "  ") as ActionResult.Failed).reason)
        assertEquals(ActionResult.Blocked(Blocker.CAPTCHA), typer(driver, { Blocker.CAPTCHA }).type(field, "x"))
        assertTrue(driver.log.none { it.startsWith("type:") })
    }

    @Test fun aStaleObservationWhileFocusingIsTakenAgain() = runBlocking {
        val driver = FakeScreenDriver(world()).also { it.interfereOnNextClick = 1 }
        assertTrue(typer(driver).type(field, "Hello") is ActionResult.Success)
    }
}
