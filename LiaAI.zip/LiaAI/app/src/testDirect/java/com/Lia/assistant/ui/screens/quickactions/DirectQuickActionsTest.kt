package com.Lia.assistant.ui.screens.quickactions

import org.junit.Assert.assertEquals
import org.junit.Test

class DirectQuickActionsTest {
    @Test fun directAddsScreenControlTiles() {
        assertEquals(
            listOf("read_screen", "go_home", "go_back"),
            QuickActions.all().map { it.tool }.drop(QuickActions.common().size)
        )
    }
}
