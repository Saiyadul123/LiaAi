package com.Lia.assistant.ui.screens.chat

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RevealTextTest {
    @Test fun wordCountIgnoresExtraWhitespace() {
        assertEquals(3, RevealText.wordCount("  Hello   big\nworld "))
        assertEquals(0, RevealText.wordCount("   "))
        assertEquals(0, RevealText.wordCount(""))
    }

    @Test fun prefixKeepsOriginalSpacing() {
        val text = "Hello  big\nworld again"
        assertEquals("", RevealText.prefix(text, 0))
        assertEquals("Hello", RevealText.prefix(text, 1))
        assertEquals("Hello  big", RevealText.prefix(text, 2))
        assertEquals("Hello  big\nworld", RevealText.prefix(text, 3))
        assertEquals(text, RevealText.prefix(text, 4))
        assertEquals(text, RevealText.prefix(text, 99))
    }

    @Test fun messageRevealStateFollowsShownWords() {
        val m = ChatEntry(1, isUser = false, text = "one two three", shownWords = 1)
        assertTrue(m.isRevealing)
        assertEquals("one", m.visibleText)
        val done = m.copy(shownWords = 3)
        assertFalse(done.isRevealing)
        assertEquals("one two three", done.visibleText)
        assertFalse(ChatEntry(2, isUser = true, text = "one two").isRevealing)
        assertEquals("one two", ChatEntry(2, isUser = true, text = "one two").visibleText)
    }

    @Test fun defaultMessageIsFullyShown() {
        val m = ChatEntry(3, isUser = false, text = "all of it")
        assertFalse(m.isRevealing)
        assertEquals("all of it", m.visibleText)
    }
}
