package com.Lia.assistant.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ForgeIntentTest {
    private fun matches(text: String) = ForgeIntent.extract(text) != null

    @Test fun buildRequestsMatch() {
        listOf(
            "build me a website for my bakery",
            "Create a landing page for my startup",
            "make a portfolio website",
            "please design a simple modern website about cats",
            "can you build a website for a gym?",
            "I want to make a website for my cafe",
            "Generate a homepage for my band",
            "build me a portfolio site",
        ).forEach { assertNotNull(it, ForgeIntent.extract(it)) }
    }

    @Test fun questionsAndOtherTopicsDoNotMatch() {
        listOf(
            "how do I build a website?",
            "how to create a website from scratch",
            "what is a website",
            "explain how to make a website",
            "do you build websites?",
            "build a house",
            "I visited a website yesterday",
            "make me a sandwich",
            "build a house and then visit a website",
            "hi",
        ).forEach { assertNull(it, ForgeIntent.extract(it)) }
    }

    @Test fun briefIsTheTrimmedOriginalText() {
        assertEquals("build me a website for my bakery", ForgeIntent.extract("  build me a website for my bakery  ")!!.brief)
    }

    @Test fun veryLongBriefsAreCapped() {
        assertEquals(1_000, ForgeIntent.extract("build a website " + "x".repeat(5_000))!!.brief.length)
    }
}
