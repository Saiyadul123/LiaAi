package com.Lia.assistant.voice

import com.Lia.assistant.voice.ChatReplyResult.Error
import com.Lia.assistant.voice.ChatReplyResult.Success
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GeminiTextClientTest {
    private fun models(vararg entries: Pair<String, List<String>>): String {
        val arr = org.json.JSONArray()
        entries.forEach { (name, methods) ->
            arr.put(JSONObject().put("name", name).put("supportedGenerationMethods", org.json.JSONArray(methods)))
        }
        return JSONObject().put("models", arr).toString()
    }

    private val gc = listOf("generateContent", "countTokens")

    // ---- model choice -----------------------------------------------------------------------

    @Test fun picksFirstFlashThatIsNotLiveImageOrTts() {
        val json = models(
            "models/embedding-001" to listOf("embedContent"),
            "models/gemini-pro-x" to gc,
            "models/gemini-flash-live-x" to gc,
            "models/gemini-flash-image-x" to gc,
            "models/gemini-flash-tts-x" to gc,
            "models/gemini-flash-native-audio" to listOf("bidiGenerateContent"),
            "models/gemini-flash-a" to gc,
            "models/gemini-flash-b" to gc,
        )
        assertEquals("models/gemini-flash-a", GeminiTextClient.pickModel(json))
    }

    @Test fun fallsBackToFirstGenerateContentModel() {
        val json = models(
            "models/embedding-001" to listOf("embedContent"),
            "models/gemini-pro-x" to gc,
            "models/gemini-flash-live-x" to gc,
        )
        assertEquals("models/gemini-pro-x", GeminiTextClient.pickModel(json))
    }

    @Test fun noUsableModelOrBadJsonIsNull() {
        assertNull(GeminiTextClient.pickModel(models("models/e" to listOf("embedContent"))))
        assertNull(GeminiTextClient.pickModel("{}"))
        assertNull(GeminiTextClient.pickModel("not json"))
    }

    @Test fun flashMatchIsCaseInsensitive() {
        assertEquals("models/Gemini-FLASH-1", GeminiTextClient.pickModel(models("models/x" to gc, "models/Gemini-FLASH-1" to gc)))
    }

    // ---- request ----------------------------------------------------------------------------

    @Test fun requestShape() {
        val body = JSONObject(
            GeminiTextClient.buildRequestBody("Be brief.", listOf(ChatTurn(true, "hi"), ChatTurn(false, "hello"), ChatTurn(true, "bye")))
        )
        assertEquals(
            "Be brief.",
            body.getJSONObject("systemInstruction").getJSONArray("parts").getJSONObject(0).getString("text")
        )
        val contents = body.getJSONArray("contents")
        assertEquals(listOf("user", "model", "user"), (0 until 3).map { contents.getJSONObject(it).getString("role") })
        assertEquals("hello", contents.getJSONObject(1).getJSONArray("parts").getJSONObject(0).getString("text"))
    }

    @Test fun blankSystemInstructionIsOmitted() {
        assertFalse(JSONObject(GeminiTextClient.buildRequestBody("  ", listOf(ChatTurn(true, "hi")))).has("systemInstruction"))
    }

    @Test fun consecutiveSameSideTurnsAreMergedAndBlanksDropped() {
        val merged = GeminiTextClient.mergeConsecutive(
            listOf(ChatTurn(true, "a"), ChatTurn(true, "b"), ChatTurn(false, "  "), ChatTurn(false, "c"), ChatTurn(true, "d"))
        )
        assertEquals(listOf(ChatTurn(true, "a\nb"), ChatTurn(false, "c"), ChatTurn(true, "d")), merged)
    }

    // ---- reply parsing ----------------------------------------------------------------------

    private fun candidate(vararg partTexts: String, extra: JSONObject.() -> Unit = {}): String {
        val parts = org.json.JSONArray()
        partTexts.forEach { parts.put(JSONObject().put("text", it)) }
        val c = JSONObject().put("content", JSONObject().put("parts", parts).put("role", "model"))
        c.extra()
        return JSONObject().put("candidates", org.json.JSONArray().put(c)).toString()
    }

    @Test fun successfulReplyIsTrimmedText() {
        assertEquals(Success("Hello!"), GeminiTextClient.parseReply(candidate("  Hello!\n")))
    }

    @Test fun multiplePartsAreJoinedAndThoughtsSkipped() {
        val json = JSONObject().put(
            "candidates", org.json.JSONArray().put(
                JSONObject().put(
                    "content", JSONObject().put(
                        "parts", org.json.JSONArray()
                            .put(JSONObject().put("text", "secret reasoning").put("thought", true))
                            .put(JSONObject().put("text", "Part one. "))
                            .put(JSONObject().put("text", "Part two."))
                    )
                )
            )
        ).toString()
        assertEquals(Success("Part one. Part two."), GeminiTextClient.parseReply(json))
    }

    @Test fun blockedPromptIsReportedAsBlocked() {
        val json = JSONObject().put("promptFeedback", JSONObject().put("blockReason", "SAFETY")).toString()
        assertEquals(Error(GeminiTextClient.MSG_BLOCKED), GeminiTextClient.parseReply(json))
    }

    @Test fun safetyFinishWithoutTextIsBlockedOtherwiseEmpty() {
        assertEquals(
            Error(GeminiTextClient.MSG_BLOCKED),
            GeminiTextClient.parseReply(candidate { put("finishReason", "SAFETY") })
        )
        assertEquals(Error(GeminiTextClient.MSG_EMPTY), GeminiTextClient.parseReply(candidate("   ")))
        assertEquals(Error(GeminiTextClient.MSG_EMPTY), GeminiTextClient.parseReply("""{"candidates":[]}"""))
        assertEquals(Error(GeminiTextClient.MSG_EMPTY), GeminiTextClient.parseReply("garbage"))
    }

    // ---- errors -----------------------------------------------------------------------------

    @Test fun reasonIsExtractedFromGeminiErrorBody() {
        val body = """{"error":{"code":400,"message":"API key not valid. Please pass a valid API key.","status":"INVALID_ARGUMENT"}}"""
        assertEquals("API key not valid. Please pass a valid API key.", GeminiTextClient.extractReason(body))
        assertNull(GeminiTextClient.extractReason("<html>nope</html>"))
        assertNull(GeminiTextClient.extractReason("""{"error":{}}"""))
    }

    @Test fun httpErrorMessages() {
        assertTrue(GeminiTextClient.describeHttpError(400, "API key not valid").contains("API key"))
        assertTrue(GeminiTextClient.describeHttpError(401, null).contains("API key"))
        assertTrue(GeminiTextClient.describeHttpError(429, "quota").contains("429"))
        assertTrue(GeminiTextClient.describeHttpError(503, null).contains("503"))
        val other = GeminiTextClient.describeHttpError(403, "User location is not supported")
        assertTrue(other.contains("403") && other.contains("User location is not supported"))
        assertFalse(other.contains("API key"))
    }

    // ---- no-network guards ------------------------------------------------------------------

    @Test fun blankKeyAndEmptyHistoryFailWithoutAnyRequest() = runBlocking {
        assertEquals(Error(GeminiTextClient.MSG_NO_KEY), GeminiTextClient.reply("  ", "sys", listOf(ChatTurn(true, "hi"))))
        assertEquals(Error(GeminiTextClient.MSG_NO_HISTORY), GeminiTextClient.reply("key", "sys", emptyList()))
    }
}
