package com.Lia.assistant.voice

import com.Lia.assistant.voice.ConversationMemory.Role
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ConversationMemoryTest {
    @Test fun emptyHasNoRecap() {
        assertNull(ConversationMemory().recap())
    }

    @Test fun recapFormatsRoles() {
        val m = ConversationMemory()
        m.add(Role.USER, "hi")
        m.add(Role.ASSISTANT, "hello there")
        assertEquals("User: hi\nYou: hello there", m.recap())
    }

    @Test fun keepsOnlyLastTwelveTurns() {
        val m = ConversationMemory()
        repeat(20) { m.add(Role.USER, "msg$it") }
        val turns = m.snapshot()
        assertEquals(12, turns.size)
        assertEquals("msg8", turns.first().text)
        assertEquals("msg19", turns.last().text)
    }

    @Test fun recapIsCappedToLast1600Chars() {
        val m = ConversationMemory()
        repeat(12) { m.add(Role.USER, "x".repeat(400) + it) }
        val recap = m.recap()!!
        assertEquals(1600, recap.length)
        assertTrue(recap.endsWith("11"))
    }

    @Test fun blankIgnoredAndClearWorks() {
        val m = ConversationMemory()
        m.add(Role.USER, "   ")
        assertEquals(0, m.size())
        m.add(Role.USER, "a")
        m.clear()
        assertNull(m.recap())
    }
}
