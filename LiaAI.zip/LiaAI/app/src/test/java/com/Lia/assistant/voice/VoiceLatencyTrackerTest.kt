package com.Lia.assistant.voice

import com.Lia.assistant.voice.VoiceLatencyTracker.Mark
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceLatencyTrackerTest {
    private var now = 0L
    private val tracker = VoiceLatencyTracker { now }

    @Test fun inOrderMarksGiveCorrectDeltas() {
        now = 100; assertTrue(tracker.mark(Mark.USER_SPEECH_END))
        now = 350; assertTrue(tracker.mark(Mark.FIRST_AUDIO))
        now = 900; assertTrue(tracker.mark(Mark.TURN_COMPLETE))
        val turn = tracker.lastTurn.value!!
        assertEquals(250L, turn.timeToFirstAudioMs)
        assertEquals(550L, turn.audioDurationMs)
        assertEquals(800L, turn.totalMs)
    }

    @Test fun currentTurnShowsPartialDeltas() {
        now = 10; tracker.mark(Mark.USER_SPEECH_END)
        now = 60; tracker.mark(Mark.FIRST_AUDIO)
        val cur = tracker.currentTurn()
        assertEquals(50L, cur.timeToFirstAudioMs)
        assertNull(cur.audioDurationMs)
        assertNull(cur.totalMs)
        assertNull(tracker.lastTurn.value) // not published until TURN_COMPLETE
    }

    @Test fun outOfOrderMarksAreIgnored() {
        now = 100; assertTrue(tracker.mark(Mark.FIRST_AUDIO))
        now = 200; assertFalse(tracker.mark(Mark.USER_SPEECH_END))   // earlier stage arriving late
        assertFalse(tracker.hasMark(Mark.USER_SPEECH_END))
        assertEquals(100L, tracker.timestamp(Mark.FIRST_AUDIO))
        now = 300; assertTrue(tracker.mark(Mark.TURN_COMPLETE))
        assertNull(tracker.lastTurn.value!!.timeToFirstAudioMs)      // speech end never accepted
        assertEquals(200L, tracker.lastTurn.value!!.audioDurationMs)
    }

    @Test fun duplicateMarksAreIgnoredAndKeepFirstTimestamp() {
        now = 100; assertTrue(tracker.mark(Mark.USER_SPEECH_END))
        now = 500; assertFalse(tracker.mark(Mark.USER_SPEECH_END))
        assertEquals(100L, tracker.timestamp(Mark.USER_SPEECH_END))
        now = 600; assertTrue(tracker.mark(Mark.FIRST_AUDIO))
        now = 700; assertFalse(tracker.mark(Mark.FIRST_AUDIO))
        assertEquals(600L, tracker.timestamp(Mark.FIRST_AUDIO))
    }

    @Test fun skippedMarkLeavesDependentDeltasNull() {
        now = 100; tracker.mark(Mark.USER_SPEECH_END)
        now = 400; assertTrue(tracker.mark(Mark.TURN_COMPLETE)) // no audio in this turn
        val turn = tracker.lastTurn.value!!
        assertNull(turn.timeToFirstAudioMs)
        assertNull(turn.audioDurationMs)
        assertEquals(300L, turn.totalMs)
    }

    @Test fun beginTurnStartsFresh() {
        now = 100; tracker.mark(Mark.USER_SPEECH_END)
        now = 200; tracker.mark(Mark.TURN_COMPLETE)
        tracker.beginTurn()
        assertFalse(tracker.hasMark(Mark.USER_SPEECH_END))
        now = 1_000; assertTrue(tracker.mark(Mark.USER_SPEECH_END))
        now = 1_250; assertTrue(tracker.mark(Mark.FIRST_AUDIO))
        assertEquals(250L, tracker.currentTurn().timeToFirstAudioMs)
        assertEquals(100L, tracker.lastTurn.value!!.totalMs) // previous turn's result is kept
    }

    @Test fun connectLatencyNeedsStartFirstAndCountsOnce() {
        now = 50; assertFalse(tracker.markSetupComplete())          // setup before start: ignored
        assertNull(tracker.connectLatencyMs.value)
        now = 100; tracker.markConnectStart()
        now = 460; assertTrue(tracker.markSetupComplete())
        assertEquals(360L, tracker.connectLatencyMs.value)
        now = 900; assertFalse(tracker.markSetupComplete())         // duplicate
        assertEquals(360L, tracker.connectLatencyMs.value)
        now = 1_000; tracker.markConnectStart()                     // reconnect clears the old value
        assertNull(tracker.connectLatencyMs.value)
    }

    @Test fun reconnectCountAndReset() {
        assertEquals(0, tracker.reconnectCount.value)
        tracker.noteReconnect(); tracker.noteReconnect()
        assertEquals(2, tracker.reconnectCount.value)
        now = 5; tracker.mark(Mark.USER_SPEECH_END)
        tracker.reset()
        assertEquals(0, tracker.reconnectCount.value)
        assertFalse(tracker.hasMark(Mark.USER_SPEECH_END))
        assertNull(tracker.lastTurn.value)
    }
}
