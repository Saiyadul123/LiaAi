package com.Lia.assistant.forge

import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ForgeErrorsTest {
    private fun err(code: Int, status: String = "", message: String = "") = SseError(code, status, message)

    @Test fun overloadedIsRecognisedByCodeStatusOrWording() {
        assertTrue(ForgeErrors.isOverloaded(err(503)))
        assertTrue(ForgeErrors.isOverloaded(err(0, "UNAVAILABLE")))
        assertTrue(ForgeErrors.isOverloaded(err(0, "", "The model is overloaded. Please try again later.")))
        assertFalse(ForgeErrors.isOverloaded(err(429, "RESOURCE_EXHAUSTED")))
        assertFalse(ForgeErrors.isOverloaded(err(400)))
    }

    @Test fun overloadedGetsAFriendlyMessage() {
        assertEquals("Gemini is busy right now. Please try again in a moment.", ForgeErrors.friendly(err(503, "UNAVAILABLE", "The model is overloaded.")))
    }

    @Test fun quotaKeyAndRequestProblemsAreExplained() {
        assertTrue(ForgeErrors.friendly(err(429, "RESOURCE_EXHAUSTED")).contains("quota"))
        assertTrue(ForgeErrors.friendly(err(403, "PERMISSION_DENIED")).contains("API key"))
        assertTrue(ForgeErrors.friendly(err(400, "INVALID_ARGUMENT", "API key not valid. Please pass a valid API key.")).contains("API key"))
        assertTrue(ForgeErrors.friendly(err(404)).contains("model"))
        assertTrue(ForgeErrors.friendly(err(400, "INVALID_ARGUMENT", "bad field")).contains("describing"))
        assertTrue(ForgeErrors.friendly(err(500, "INTERNAL")).contains("its side"))
    }

    @Test fun anUnknownErrorStillGetsAKindMessage() {
        assertEquals("Gemini could not build the website. Please try again.", ForgeErrors.friendly(err(0)))
    }

    @Test fun rawErrorTextIsNeverShown() {
        val secret = "request abc123 for key FAKE_KEY_FOR_TEST failed"
        listOf(err(503, "UNAVAILABLE", secret), err(429, "", secret), err(403, "", secret), err(400, "", secret), err(0, "", secret)).forEach {
            val shown = ForgeErrors.friendly(it)
            assertFalse(shown, shown.contains("FAKE_KEY") || shown.contains("abc123"))
        }
    }

    @Test fun networkProblemsAreExplained() {
        assertTrue(ForgeErrors.forIo(SocketTimeoutException()).contains("too long"))
        assertTrue(ForgeErrors.forIo(UnknownHostException("generativelanguage.googleapis.com")).contains("no internet"))
        assertTrue(ForgeErrors.forIo(ConnectException()).contains("no internet"))
        assertTrue(ForgeErrors.forIo(IOException("reset")).contains("interrupted"))
        assertEquals("Gemini could not build the website. Please try again.", ForgeErrors.forIo(IllegalStateException("x")))
    }

    @Test fun theStoppedEarlyMessageIsTheAgreedOne() {
        assertEquals("Gemini stopped before finishing", ForgeErrors.STOPPED_EARLY)
    }
}
