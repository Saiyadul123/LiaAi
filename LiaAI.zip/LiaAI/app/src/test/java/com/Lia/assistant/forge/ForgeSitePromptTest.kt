package com.Lia.assistant.forge

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ForgeSitePromptTest {
    private val text = ForgeSitePrompt.THREE_D

    @Test fun asksForThreeDEverywhere() {
        assertTrue(text.contains("Three.js"))
        assertTrue(text.contains("CSS 3D"))
        assertTrue(text.contains("hero", ignoreCase = true))
        assertTrue(text.contains("call to action", ignoreCase = true))
    }

    @Test fun limitsPhotosAndKeepsContentVisible() {
        assertTrue(text.contains("at most two sections"))
        assertTrue(text.contains("dark gradient overlay"))
        assertTrue(text.contains("always visible"))
    }

    @Test fun isTrimmed() {
        assertFalse(text.startsWith(" "))
        assertFalse(text.startsWith("\n"))
    }
}
