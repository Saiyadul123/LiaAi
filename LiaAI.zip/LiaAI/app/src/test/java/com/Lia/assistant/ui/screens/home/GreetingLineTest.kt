package com.Lia.assistant.ui.screens.home

import org.junit.Assert.assertEquals
import org.junit.Test

class GreetingLineTest {
    @Test fun greetsByNameAndTimeOfDay() {
        assertEquals("Good morning, Asha", Greeting.line(8, "Asha"))
        assertEquals("Good afternoon, Asha", Greeting.line(14, "  Asha "))
        assertEquals("Good evening, Asha", Greeting.line(19, "Asha"))
    }

    @Test fun withoutANameItIsJustTheGreeting() {
        assertEquals("Good morning", Greeting.line(8, ""))
        assertEquals("Good evening", Greeting.line(19, "   "))
    }

    @Test fun lateAtNightItAsksIfYouAreStillUp() {
        assertEquals("Still up, Asha?", Greeting.line(23, "Asha"))
        assertEquals("Still up?", Greeting.line(2, ""))
    }
}
