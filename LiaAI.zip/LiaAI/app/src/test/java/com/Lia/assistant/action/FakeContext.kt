package com.Lia.assistant.action

import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager

/** A Context with no device behind it: scripted permissions, recorded startActivity calls. */
class FakeContext(private val granted: Set<String> = emptySet()) : ContextWrapper(null) {
    val started = mutableListOf<Intent>()

    override fun checkPermission(permission: String?, pid: Int, uid: Int): Int =
        if (permission in granted) PackageManager.PERMISSION_GRANTED else PackageManager.PERMISSION_DENIED

    override fun startActivity(intent: Intent?) {
        if (intent != null) started += intent
    }

    override fun getApplicationContext(): Context = this
    override fun getPackageName(): String = "com.Lia.assistant"
}
