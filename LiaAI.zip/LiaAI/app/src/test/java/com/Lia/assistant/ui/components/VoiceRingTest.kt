package com.Lia.assistant.ui.components

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceRingTest {
    @Test fun fortyEightBars() {
        assertEquals(48, RING_BARS)
        assertEquals(48, ringBarLengths(RING_BARS, 0.5f, 0f).size)
    }

    @Test fun silenceLeavesAThinEvenRing() {
        ringBarLengths(RING_BARS, 0f, 0.3f).forEach { assertEquals(RING_MIN, it, 1e-4f) }
    }

    @Test fun loudVoiceMakesTallBarsWithinRange() {
        val lengths = ringBarLengths(RING_BARS, 1f, 0f)
        lengths.forEach { assertTrue(it in 0.43f..1f) }
        assertTrue(lengths.max() > lengths.min())
    }

    @Test fun louderIsTallerOnAverage() {
        val quiet = ringBarLengths(RING_BARS, 0.2f, 0f).average()
        val loud = ringBarLengths(RING_BARS, 0.9f, 0f).average()
        assertTrue(loud > quiet)
    }

    @Test fun theWaveTravelsWithPhaseAndAmplitudeIsClamped() {
        val a = ringBarLengths(RING_BARS, 0.5f, 0f)
        val b = ringBarLengths(RING_BARS, 0.5f, 0.25f)
        assertTrue(a.indices.any { a[it] != b[it] })
        assertEquals(ringBarLengths(RING_BARS, 1f, 0f).toList(), ringBarLengths(RING_BARS, 7f, 0f).toList())
        assertEquals(ringBarLengths(RING_BARS, 0f, 0f).toList(), ringBarLengths(RING_BARS, -2f, 0f).toList())
    }
}
