package com.Lia.assistant.ui.fx

import com.Lia.assistant.ui.theme.NovaColorScheme
import com.Lia.assistant.voice.NovaOrbState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class AmbientGlowTest {
    @Test fun lightFieldFollowsTheState() {
        listOf(NovaColorScheme.Dark, NovaColorScheme.Light).forEach { s ->
            assertEquals(s.lagoon, ambientGlowColor(NovaOrbState.LISTENING, s))
            assertEquals(s.accent, ambientGlowColor(NovaOrbState.SPEAKING, s))
            assertEquals(s.accentSecondary, ambientGlowColor(NovaOrbState.CONNECTING, s))
            assertEquals(s.error, ambientGlowColor(NovaOrbState.ERROR, s))
            assertEquals(NovaGlowColors.Violet, ambientGlowColor(NovaOrbState.IDLE, s))
            assertEquals(NovaGlowColors.Violet, ambientGlowColor(NovaOrbState.THINKING, s))
        }
    }

    @Test fun listeningAndSpeakingLookDifferent() {
        val s = NovaColorScheme.Dark
        assertNotEquals(ambientGlowColor(NovaOrbState.LISTENING, s), ambientGlowColor(NovaOrbState.SPEAKING, s))
    }
}
