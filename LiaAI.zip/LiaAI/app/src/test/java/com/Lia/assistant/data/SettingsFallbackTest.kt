package com.Lia.assistant.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SettingsFallbackTest {

    @Test fun personalityPrefersDataStore() {
        assertEquals(Personality.FUNNY, SettingsFallback.personality("FUNNY", "TEACHER"))
    }

    @Test fun personalityFallsBackToLegacyWhenStoredMissingOrInvalid() {
        assertEquals(Personality.TEACHER, SettingsFallback.personality(null, "TEACHER"))
        assertEquals(Personality.TEACHER, SettingsFallback.personality("REMOVED_ENTRY", "TEACHER"))
    }

    @Test fun personalityFallsBackToDefault() {
        assertEquals(Personality.DEFAULT, SettingsFallback.personality(null, null))
        assertEquals(Personality.DEFAULT, SettingsFallback.personality("", "garbage"))
    }

    @Test fun languageFallbacksAndDefaultIsAuto() {
        assertEquals(LanguagePreference.HINDI, SettingsFallback.language("HINDI", "ENGLISH"))
        assertEquals(LanguagePreference.ENGLISH, SettingsFallback.language(null, "ENGLISH"))
        assertEquals(LanguagePreference.AUTO, SettingsFallback.language(null, null))
        assertEquals(LanguagePreference.AUTO, LanguagePreference.DEFAULT)
    }

    @Test fun assistantNameFallbacks() {
        assertEquals("Mia", SettingsFallback.assistantName(" Mia ", "Zed"))
        assertEquals("Zed", SettingsFallback.assistantName("  ", "Zed"))
        assertEquals(AssistantBrand.NAME, SettingsFallback.assistantName(null, ""))
    }

    @Test fun voiceNameFallbacks() {
        assertEquals("Puck", SettingsFallback.voiceName("Puck", "Kore"))
        assertEquals("Charon", SettingsFallback.voiceName(null, "Charon"))
        assertEquals(SettingsFallback.DEFAULT_VOICE_NAME, SettingsFallback.voiceName("", null))
    }

    @Test fun enumParsingIsStrict() {
        assertNull(Personality.fromName(null))
        assertNull(LanguagePreference.fromName("hindi"))
        assertEquals(ThemeMode.DARK, ThemeMode.fromName("nonsense"))
        assertEquals(ThemeMode.LIGHT, ThemeMode.fromName("LIGHT"))
    }

    @Test fun brandConstants() {
        assertEquals("Lia", AssistantBrand.NAME)
        assertEquals("Lia AI", AssistantBrand.FULL_NAME)
        assertEquals("Your Intelligent AI Companion", AssistantBrand.TAGLINE)
    }
}
