package com.Lia.assistant.forge

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ForgeSystemPromptTest {
    private val prompt = ForgeSystemPrompt.forNewSite("a landing page for a surf school")

    @Test fun theBriefIsIncluded() {
        assertTrue(prompt.endsWith("a landing page for a surf school"))
    }

    @Test fun aVeryLongBriefIsCut() {
        val p = ForgeSystemPrompt.forNewSite("x".repeat(5000))
        assertEquals(ForgeSystemPrompt.MAX_PROMPT, p.substringAfter("Build this website:\n").length)
    }

    @Test fun theLibrariesAreNamed() {
        listOf("cdn.tailwindcss.com", "GSAP", "ScrollTrigger", "Three.js", "importmap", "picsum.photos", "pravatar.cc").forEach {
            assertTrue(it, prompt.contains(it))
        }
    }

    @Test fun theDesignRulesAreThere() {
        listOf(
            "hero", "magnetic", "bento", "CSS variables", "Five or six sections", "Mobile-first", "hamburger",
            "prefers-reduced-motion", "at most two sections", "gradient overlay", "second Three.js scene", "CSS 3D",
            "explicit size", "Never hide content while waiting for an animation",
        ).forEach { assertTrue(it, prompt.contains(it, ignoreCase = true)) }
    }

    @Test fun theModelIsToReplyWithHtmlOnly() {
        assertTrue(prompt.contains("<!DOCTYPE html>"))
        assertTrue(prompt.contains("no Markdown fences"))
    }

    @Test fun anEditCarriesTheCurrentPageAndTheChange() {
        val p = ForgeSystemPrompt.forEdit("<html><body>OLD</body></html>", "  make the hero blue ")
        assertTrue(p.contains("make the hero blue"))
        assertTrue(p.endsWith("<html><body>OLD</body></html>"))
        assertTrue(p.contains("complete updated HTML"))
        assertFalse(p.contains("Build this website"))
    }

    @Test fun theRetryHintIsTheAgreedSentence() {
        assertEquals("Write completely original markup, copy and code; finish the whole page.", ForgeSystemPrompt.RETRY_HINT)
    }

    @Test fun nothingPrivateIsInThePrompt() {
        assertFalse(prompt.contains("AIza"))
        assertFalse(prompt.contains("api key", ignoreCase = true))
    }
}
