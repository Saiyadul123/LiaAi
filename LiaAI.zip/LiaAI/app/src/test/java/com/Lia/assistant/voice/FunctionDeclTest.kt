package com.Lia.assistant.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FunctionDeclTest {
    @Test fun buildsParamsInOrderWithRequiredFlags() {
        val d = functionDecl(
            "message_contact", "desc",
            linkedMapOf("contact" to "who", "message" to "what", "app" to "how"),
            listOf("contact", "message"),
        )
        assertEquals("message_contact", d.name)
        assertEquals(listOf("contact", "message", "app"), d.params.map { it.name })
        assertEquals(listOf(true, true, false), d.params.map { it.required })
    }

    @Test fun noParamsIsFine() {
        assertTrue(functionDecl("go_back", "Back").params.isEmpty())
    }

    @Test(expected = IllegalArgumentException::class)
    fun requiredMustBeDeclared() {
        functionDecl("x", "y", mapOf("a" to "b"), listOf("zzz"))
    }

    @Test fun catalogToolsAreUniqueAndNamedWithoutSpaces() {
        val names = LiaToolCatalog.declarations().map { it.name }
        assertEquals(names.size, names.toSet().size)
        assertFalse(names.any { it.contains(' ') })
    }
}
