@file:OptIn(ExperimentalCoroutinesApi::class)

package com.Lia.assistant.voice

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class EchoGuardTest {
    private lateinit var scope: TestScope

    @Before fun setUp() {
        scope = TestScope()
        EchoGuard.setScopeForTest(scope)
    }

    @After fun tearDown() {
        EchoGuard.setScopeForTest(null)
    }

    /** Advances virtual time, then runs anything due exactly at the new time. */
    private fun advance(ms: Long) {
        scope.testScheduler.advanceTimeBy(ms)
        scope.testScheduler.runCurrent()
    }

    @Test fun startsUnmuted() {
        assertFalse(EchoGuard.isMicMuted())
        assertEquals(0, EchoGuard.activeCount())
    }

    @Test fun startMutesImmediately() {
        EchoGuard.notifyPlaybackStarted()
        assertTrue(EchoGuard.isMicMuted())
        assertEquals(1, EchoGuard.activeCount())
    }

    @Test fun unmutesOnlyAfterEchoTail() {
        EchoGuard.notifyPlaybackStarted()
        EchoGuard.notifyPlaybackStopped()
        assertTrue(EchoGuard.isMicMuted())
        advance(EchoGuard.ECHO_TAIL_MS - 1)
        assertTrue(EchoGuard.isMicMuted())
        advance(1)
        assertFalse(EchoGuard.isMicMuted())
    }

    @Test fun counterRequiresAllPlaybacksToStop() {
        EchoGuard.notifyPlaybackStarted()
        EchoGuard.notifyPlaybackStarted()
        EchoGuard.notifyPlaybackStopped()
        assertEquals(1, EchoGuard.activeCount())
        advance(10_000)
        assertTrue(EchoGuard.isMicMuted())          // one playback still active
        EchoGuard.notifyPlaybackStopped()
        advance(EchoGuard.ECHO_TAIL_MS)
        assertFalse(EchoGuard.isMicMuted())
    }

    @Test fun unmatchedStopNeverGoesNegative() {
        EchoGuard.notifyPlaybackStopped()
        assertEquals(0, EchoGuard.activeCount())
        assertFalse(EchoGuard.isMicMuted())
        EchoGuard.notifyPlaybackStarted()
        EchoGuard.notifyPlaybackStopped()
        advance(EchoGuard.ECHO_TAIL_MS)
        assertFalse(EchoGuard.isMicMuted())
    }

    @Test fun newPlaybackDuringTailCancelsPendingUnmute() {
        EchoGuard.notifyPlaybackStarted()
        EchoGuard.notifyPlaybackStopped()
        advance(400)
        EchoGuard.notifyPlaybackStarted()
        advance(10_000)
        assertTrue(EchoGuard.isMicMuted())
        EchoGuard.notifyPlaybackStopped()
        advance(EchoGuard.ECHO_TAIL_MS - 1)
        assertTrue(EchoGuard.isMicMuted())
        advance(1)
        assertFalse(EchoGuard.isMicMuted())
    }

    @Test fun watchdogForceUnmutesAfter60s() {
        EchoGuard.notifyPlaybackStarted()
        advance(EchoGuard.WATCHDOG_MS - 1)
        assertTrue(EchoGuard.isMicMuted())
        advance(1)
        assertFalse(EchoGuard.isMicMuted())
        assertEquals(0, EchoGuard.activeCount())
        EchoGuard.notifyPlaybackStopped() // late stop is harmless
        assertEquals(0, EchoGuard.activeCount())
    }

    @Test fun watchdogIsRearmedByEachStart() {
        EchoGuard.notifyPlaybackStarted()
        advance(40_000)
        EchoGuard.notifyPlaybackStarted()
        advance(40_000)
        assertTrue(EchoGuard.isMicMuted())          // 80 s since first start, 40 s since last
        advance(20_000)
        assertFalse(EchoGuard.isMicMuted())
    }

    @Test fun normalUnmuteDisarmsWatchdog() {
        EchoGuard.notifyPlaybackStarted()
        EchoGuard.notifyPlaybackStopped()
        advance(EchoGuard.ECHO_TAIL_MS)
        assertFalse(EchoGuard.isMicMuted())
        EchoGuard.notifyPlaybackStarted()           // a fresh playback is muted again as usual
        assertTrue(EchoGuard.isMicMuted())
        advance(EchoGuard.WATCHDOG_MS - 1)
        assertTrue(EchoGuard.isMicMuted())
    }

    @Test fun resetClearsEverything() {
        EchoGuard.notifyPlaybackStarted()
        EchoGuard.notifyPlaybackStarted()
        EchoGuard.reset()
        assertFalse(EchoGuard.isMicMuted())
        assertEquals(0, EchoGuard.activeCount())
        advance(EchoGuard.WATCHDOG_MS)              // cancelled timers do nothing
        assertFalse(EchoGuard.isMicMuted())
    }
}
