package com.Lia.assistant.action

import android.Manifest
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneActionsTest {
    @After fun tearDown() = InstalledAppLabelCache.resetForTest()

    private fun args(vararg kv: Pair<String, String>) = JSONObject().also { o -> kv.forEach { o.put(it.first, it.second) } }
    private fun run(block: suspend () -> JSONObject) = runBlocking { block() }

    // ---- call_contact -----------------------------------------------------------------------

    @Test fun callingANumberWithoutCallPermissionOpensTheDialer() {
        val ctx = FakeContext()
        val r = run { PhoneActions.callContact(ctx, args("contact" to "98765 43210")) }
        assertEquals("dialer_opened_no_permission", r.getString("result"))
        assertEquals(1, ctx.started.size)
    }

    @Test fun callingANumberWithCallPermissionCallsDirectly() {
        val ctx = FakeContext(setOf(Manifest.permission.CALL_PHONE))
        val r = run { PhoneActions.callContact(ctx, args("contact" to "+91 98765 43210")) }
        assertEquals("calling", r.getString("result"))
        assertEquals(1, ctx.started.size)
    }

    @Test fun callingByNameWithoutContactsPermissionStartsNothing() {
        val ctx = FakeContext(setOf(Manifest.permission.CALL_PHONE))
        val r = run { PhoneActions.callContact(ctx, args("contact" to "Mom")) }
        assertEquals("no_contacts_permission", r.getString("result"))
        assertTrue(ctx.started.isEmpty())
    }

    @Test fun missingContactIsAnError() {
        val r = run { PhoneActions.callContact(FakeContext(), JSONObject()) }
        assertEquals("Missing parameter: contact", r.getString("error"))
    }

    // ---- message_contact --------------------------------------------------------------------

    @Test fun smsOpensTheComposerOnly() {
        val ctx = FakeContext()
        val c = run2 { PhoneActions.openComposer(ctx, args("contact" to "98765 43210", "message" to "hi")) }
        assertTrue(c is PhoneActions.Composer.Opened)
        assertEquals(1, ctx.started.size)
        val json = PhoneActions.composerOpenedJson(c as PhoneActions.Composer.Opened)
        assertEquals("composer_opened", json.getString("result"))
        assertEquals("sms", json.getString("app"))
    }

    @Test fun whatsAppNeedsAnInstalledPackage() {
        val a = args("contact" to "98765 43210", "message" to "hi", "app" to "whatsapp")
        val none = FakeContext()
        val missing = run2 { PhoneActions.openComposer(none, a) { false } }
        assertEquals("whatsapp_not_installed", (missing as PhoneActions.Composer.Failed).json.getString("result"))
        assertTrue(none.started.isEmpty())

        val ctx = FakeContext()
        val opened = run2 { PhoneActions.openComposer(ctx, a) { it == "com.whatsapp.w4b" } }
        assertTrue(opened is PhoneActions.Composer.Opened)
        assertEquals(1, ctx.started.size)
        assertEquals("whatsapp", PhoneActions.composerOpenedJson(opened as PhoneActions.Composer.Opened).getString("app"))
    }

    @Test fun messageNeedsContactAndText() {
        val ctx = FakeContext()
        val noText = run2 { PhoneActions.openComposer(ctx, args("contact" to "98765 43210")) }
        assertEquals("Missing parameter: message", (noText as PhoneActions.Composer.Failed).json.getString("error"))
        val noContact = run2 { PhoneActions.openComposer(ctx, args("message" to "hi")) }
        assertEquals("Missing parameter: contact", (noContact as PhoneActions.Composer.Failed).json.getString("error"))
        assertTrue(ctx.started.isEmpty())
    }

    @Test fun messageByNameWithoutPermissionDoesNothing() {
        val ctx = FakeContext()
        val c = run2 { PhoneActions.openComposer(ctx, args("contact" to "Mom", "message" to "hi")) }
        assertEquals("no_contacts_permission", (c as PhoneActions.Composer.Failed).json.getString("result"))
        assertTrue(ctx.started.isEmpty())
    }

    private fun run2(block: suspend () -> PhoneActions.Composer) = runBlocking { block() }

    // ---- open_app ---------------------------------------------------------------------------

    @Test fun openAppFallbacks() {
        InstalledAppLabelCache.resetForTest()
        InstalledAppLabelCache.loader = { mapOf("youtube" to "com.yt") }
        val ctx = FakeContext()

        assertEquals("Missing parameter: app_name", run { PhoneActions.openApp(ctx, JSONObject()) }.getString("error"))
        assertEquals("app_not_found", run { PhoneActions.openApp(ctx, args("app_name" to "tube")) }.getString("result"))

        // Found, but there is no package manager to launch it: reported, not crashed.
        val r = run { PhoneActions.openApp(ctx, args("app_name" to "YouTube")) }
        assertEquals("could_not_open", r.getString("result"))
        assertEquals("youtube", r.getString("app"))
        assertFalse(r.has("error"))
    }

    @Test fun unknownToolShape() {
        assertEquals("Unknown tool: nope", PhoneActions.unknownTool("nope").getString("error"))
    }
}
