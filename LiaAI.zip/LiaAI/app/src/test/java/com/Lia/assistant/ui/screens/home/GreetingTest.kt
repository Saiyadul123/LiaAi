package com.Lia.assistant.ui.screens.home

import org.junit.Assert.assertEquals
import org.junit.Test

class GreetingTest {
    @Test fun dayParts() {
        assertEquals(DayPart.NIGHT, Greeting.partOf(4))
        assertEquals(DayPart.MORNING, Greeting.partOf(5))
        assertEquals(DayPart.MORNING, Greeting.partOf(11))
        assertEquals(DayPart.AFTERNOON, Greeting.partOf(12))
        assertEquals(DayPart.AFTERNOON, Greeting.partOf(16))
        assertEquals(DayPart.EVENING, Greeting.partOf(17))
        assertEquals(DayPart.EVENING, Greeting.partOf(21))
        assertEquals(DayPart.NIGHT, Greeting.partOf(22))
        assertEquals(DayPart.NIGHT, Greeting.partOf(0))
    }

    @Test fun everyHourHasAGreeting() {
        (0..23).forEach { assertEquals(true, Greeting.text(it).isNotBlank()) }
        assertEquals("Good morning", Greeting.text(8))
        assertEquals("Good afternoon", Greeting.text(14))
        assertEquals("Good evening", Greeting.text(19))
    }

    @Test fun outOfRangeHoursWrapAround() {
        assertEquals(Greeting.partOf(1), Greeting.partOf(25))
        assertEquals(Greeting.partOf(23), Greeting.partOf(-1))
    }
}
