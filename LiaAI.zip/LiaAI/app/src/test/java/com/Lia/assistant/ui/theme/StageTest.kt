package com.Lia.assistant.ui.theme

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StageTest {
    @Test fun parallaxRunsFromTwoToTwelveDpDeeperMovesLess() {
        assertEquals(2f, parallaxShiftDp(0), 1e-4f)
        assertEquals(12f, parallaxShiftDp(4), 1e-4f)
        (0 until 4).forEach { assertTrue(parallaxShiftDp(it) < parallaxShiftDp(it + 1)) }
        assertEquals(2f, parallaxShiftDp(-3), 1e-4f)
        assertEquals(12f, parallaxShiftDp(9), 1e-4f)
    }

    @Test fun entranceSlices() {
        assertEquals(0f, entranceFraction(0.1f, 0.25f, 0.75f), 0f)
        assertEquals(0.5f, entranceFraction(0.5f, 0.25f, 0.75f), 1e-4f)
        assertEquals(1f, entranceFraction(0.9f, 0.25f, 0.75f), 0f)
        assertEquals(0f, entranceFraction(0.3f, 0.5f, 0.5f), 0f)   // empty slice
        assertEquals(1f, entranceFraction(0.7f, 0.5f, 0.5f), 0f)
        assertEquals(600, ENTRANCE_MS)
    }

    @Test fun pagerContentTravelsAtSixtyPercent() {
        // the page moves one width per page; adding 40 % of that back leaves 60 %
        assertEquals(400f, parallaxShift(1f, 1000f), 1e-3f)
        assertEquals(-400f, parallaxShift(-1f, 1000f), 1e-3f)
        assertEquals(0f, parallaxShift(0f, 1000f), 0f)
        assertEquals(0f, parallaxShift(1f, 1000f, factor = 1f), 0f)
    }

    @Test fun homeCardsTurnUpToSixDegrees() {
        assertEquals(0f, CardTilt.rowRotationY(0f), 1e-4f)
        assertEquals(-3f, CardTilt.rowRotationY(0.25f), 1e-4f)
        assertEquals(-6f, CardTilt.rowRotationY(1f), 1e-4f)
        assertEquals(6f, CardTilt.rowRotationY(-1f), 1e-4f)
        assertEquals(6f, CardTilt.rowRotationY(-5f), 1e-4f)
    }

    @Test fun historyRowsCompressAndTiltAsTheyLeaveTheTop() {
        assertEquals(0f, CardTilt.offTopFraction(10, 100), 0f)
        assertEquals(0.5f, CardTilt.offTopFraction(-50, 100), 1e-4f)
        assertEquals(1f, CardTilt.offTopFraction(-200, 100), 0f)
        assertEquals(0f, CardTilt.offTopFraction(-50, 0), 0f)
        assertEquals(0f, CardTilt.offTopRotationX(0f), 0f)
        assertEquals(35f, CardTilt.offTopRotationX(1f), 1e-4f)
        assertEquals(1f, CardTilt.offTopScale(0f), 0f)
        assertEquals(0.75f, CardTilt.offTopScale(1f), 1e-4f)
        assertEquals(0.3f, CardTilt.offTopAlpha(1f), 1e-4f)
    }

    @Test fun coverflowCentreIsLargestAndNeighboursTurn35Degrees() {
        val centre = CardTilt.coverflow(0f)
        assertEquals(0f, centre.rotationY, 1e-3f)
        assertEquals(1.3f, centre.scale, 1e-4f)
        assertEquals(1f, centre.alpha, 1e-4f)
        val right = CardTilt.coverflow(1f)
        assertEquals(-35f, right.rotationY, 1e-4f)
        assertEquals(1f, right.scale, 1e-4f)
        assertEquals(0.55f, right.alpha, 1e-4f)
        assertEquals(35f, CardTilt.coverflow(-1f).rotationY, 1e-4f)
        assertEquals(right, CardTilt.coverflow(3f)) // clamped
    }
}
