package com.Lia.assistant.forge

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ForgeProgressTest {
    @Test fun idleShowsWaiting() {
        val p = ForgeProgress.Idle
        assertFalse(p.isRunning)
        assertEquals("Waiting", p.stageName)
        assertEquals(0, p.litSegments)
        assertEquals("–", p.percentText)
        assertEquals(4, p.stats.size)
    }

    @Test fun sixStagesLightUpInOrder() {
        assertEquals(6, ForgeProgress.STAGES.size)
        val p = ForgeProgress(stage = 2, percent = 40)
        assertTrue(p.isRunning)
        assertEquals("3D scene", p.stageName)
        assertEquals(3, p.litSegments)
        assertEquals("40%", p.percentText)
        assertEquals(6, ForgeProgress(stage = 5, percent = 99).litSegments)
    }

    @Test fun percentIsClampedAndOutOfRangeStagesDoNotRun() {
        assertEquals("100%", ForgeProgress(stage = 0, percent = 150).percentText)
        assertEquals("0%", ForgeProgress(stage = 0, percent = -5).percentText)
        assertFalse(ForgeProgress(stage = 6).isRunning)
        assertFalse(ForgeProgress(stage = -1).isRunning)
    }
}
