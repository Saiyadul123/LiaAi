package com.Lia.assistant.action

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AppLauncherTest {
    private val apps = mapOf(
        "youtube" to "com.yt",
        "youtube music" to "com.ytm",
        "chrome" to "com.chrome",
        "whatsapp" to "com.wa",
        "whatsapp business" to "com.wab",
        "google maps" to "com.maps",
        "photo gallery" to "com.gallery",
        "ab" to "com.short",
    )

    private fun pkg(q: String) = AppLauncher.findApp(apps, q)?.packageName

    @Test fun exactMatchIsCaseInsensitiveAndWins() {
        assertEquals("com.yt", pkg("YouTube"))
        assertEquals("com.ytm", pkg("  YOUTUBE MUSIC "))
        assertEquals("com.short", pkg("ab"))          // exact match works even for 2-char labels
    }

    @Test fun prefixesPickTheClosestLabelLength() {
        assertEquals("com.wa", pkg("whats"))           // whatsapp (8) closer to 5 than business (17)
        assertEquals("com.ytm", pkg("youtube mus"))    // 'youtube music' (13) closer to 11 than 'youtube' (7)
    }

    @Test fun queryThatStartsWithTheLabelMatches() {
        assertEquals("com.chrome", pkg("chrome browser"))
    }

    @Test fun everyQueryWordMustPrefixSomeLabelWord() {
        assertEquals("com.maps", pkg("maps"))
        assertEquals("com.gallery", pkg("gallery photo"))
        assertNull(pkg("maps tube"))                   // 'tube' prefixes no word of 'google maps'
    }

    @Test fun neverUsesLooseSubstringMatching() {
        assertNull(pkg("tube"))
        assertNull(pkg("oogle"))
        assertNull(pkg("app"))
    }

    @Test fun shortLabelsAndQueriesAreNotFuzzyMatched() {
        assertNull(pkg("abc"))                         // 'ab' has length 2, ignored as a candidate
        assertNull(pkg("a"))
        assertNull(pkg(""))
        assertNull(pkg("   "))
    }

    @Test fun launchWithoutAPackageManagerFailsQuietly() {
        assertEquals(false, AppLauncher.launch(FakeContext(), "com.nothing"))
    }
}
