package com.Lia.assistant.ui.screens.voice

import org.junit.Assert.assertEquals
import org.junit.Test

class VoiceGateTest {
    private fun gate(voice: Boolean, mic: Boolean, key: Boolean) = VoiceGates.evaluate(voice, mic, key)

    @Test fun readyOnlyWhenEverythingIsInPlace() {
        assertEquals(VoiceGate.READY, gate(true, true, true))
    }

    @Test fun problemsAreReportedOneAtATimeInOrder() {
        assertEquals(VoiceGate.VOICE_DISABLED, gate(false, false, false))
        assertEquals(VoiceGate.VOICE_DISABLED, gate(false, true, true))
        assertEquals(VoiceGate.NEEDS_MIC, gate(true, false, false))
        assertEquals(VoiceGate.NEEDS_MIC, gate(true, false, true))
        assertEquals(VoiceGate.NEEDS_KEY, gate(true, true, false))
    }
}
