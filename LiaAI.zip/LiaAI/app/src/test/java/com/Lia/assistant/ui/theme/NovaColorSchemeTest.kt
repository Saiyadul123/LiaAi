package com.Lia.assistant.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NovaColorSchemeTest {
    private val schemes = listOf("Dark" to NovaColorScheme.Dark, "Light" to NovaColorScheme.Light)

    private fun assertContrast(name: String, label: String, fg: Color, bg: Color, min: Double) {
        val ratio = contrastRatio(fg, bg)
        assertTrue("$name $label: ${"%.2f".format(ratio)} < $min", ratio >= min)
    }

    @Test fun darkTokensMatchTheBrief() {
        val d = NovaColorScheme.Dark
        assertEquals(Color(0xFF06050E), d.background)
        assertEquals(Color(0xFF15113A), d.backgroundGradientTop)
        assertEquals(Color(0xFF17143A), d.surface)
        assertEquals(Color(0xFF221E4D), d.surfaceRaised)
        assertEquals(Color(0xFFFFB547), d.accent)
        assertEquals(Color(0xFFFF8A3D), d.accentSecondary)
        assertEquals(Color(0xFFEEE9FF), d.textPrimary)
        assertEquals(Color(0xFFA7A0CC), d.textSecondary)
    }

    @Test fun lightTokensMatchTheBrief() {
        val l = NovaColorScheme.Light
        assertEquals(Color(0xFFF3F0FB), l.background)
        assertEquals(Color(0xFFFFFFFF), l.surface)
        assertEquals(Color(0xFFB86A00), l.accent)
        assertEquals(Color(0xFF15112E), l.textPrimary)
    }

    @Test fun lotusAndLagoonAreTheSameInBothThemes() {
        schemes.forEach { (_, s) ->
            assertEquals(Color(0xFFFF6FAE), s.lotus)
            assertEquals(Color(0xFF3FE0D0), s.lagoon)
        }
    }

    @Test fun primaryTextIsAAAOnEverySurface() {
        schemes.forEach { (n, s) ->
            val glass = s.surfaceGlass.compositeOver(s.background)
            listOf(
                "background" to s.background, "surface" to s.surface, "raised" to s.surfaceRaised,
                "glass" to glass, "userBubble" to s.userBubble, "assistantBubble" to s.assistantBubble,
            ).forEach { (label, bg) -> assertContrast(n, "textPrimary on $label", s.textPrimary, bg, 7.0) }
        }
    }

    @Test fun secondaryAndTertiaryTextPassAA() {
        schemes.forEach { (n, s) ->
            val glass = s.surfaceGlass.compositeOver(s.background)
            listOf("background" to s.background, "surface" to s.surface, "raised" to s.surfaceRaised, "glass" to glass)
                .forEach { (label, bg) -> assertContrast(n, "textSecondary on $label", s.textSecondary, bg, 4.5) }
            listOf("background" to s.background, "surface" to s.surface, "assistantBubble" to s.assistantBubble)
                .forEach { (label, bg) -> assertContrast(n, "textTertiary on $label", s.textTertiary, bg, 4.5) }
        }
    }

    @Test fun buttonLabelsAreReadableOnBothAccentColours() {
        schemes.forEach { (n, s) ->
            assertContrast(n, "onAccent on accent", s.onAccent, s.accent, 4.5)
            assertContrast(n, "onAccent on accentSecondary", s.onAccent, s.accentSecondary, 4.5)
        }
    }

    @Test fun accentIsVisibleAsAControlAndReadableAsText() {
        schemes.forEach { (n, s) ->
            listOf("background" to s.background, "surface" to s.surface, "raised" to s.surfaceRaised).forEach { (label, bg) ->
                assertContrast(n, "accent (UI) on $label", s.accent, bg, 3.0)
                assertContrast(n, "accentText on $label", s.accentText, bg, 4.5)
            }
        }
    }

    @Test fun statusColoursPassAA() {
        schemes.forEach { (n, s) ->
            listOf("background" to s.background, "surface" to s.surface).forEach { (label, bg) ->
                assertContrast(n, "error on $label", s.error, bg, 4.5)
                assertContrast(n, "success on $label", s.success, bg, 4.5)
                assertContrast(n, "warning on $label", s.warning, bg, 4.5)
            }
        }
    }

    @Test fun contrastHelperKnownValues() {
        assertEquals(21.0, contrastRatio(Color.Black, Color.White), 0.01)
        assertEquals(1.0, contrastRatio(Color.White, Color.White), 0.001)
    }
}
