package com.Lia.assistant.ui.fx

import androidx.compose.ui.graphics.Color
import com.Lia.assistant.ui.theme.NovaColorScheme
import com.Lia.assistant.voice.NovaOrbState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OrbParamsTest {
    private val scheme = NovaColorScheme.Dark
    private fun p(s: NovaOrbState) = orbParams(s, scheme)

    @Test fun everyStateHasItsOwnPalette() {
        val palettes = NovaOrbState.entries.map { p(it).colors }
        assertEquals(palettes.size, palettes.toSet().size)
    }

    @Test fun paletteIdentities() {
        assertEquals(NovaGlowColors.Violet, p(NovaOrbState.IDLE).colors.core)
        assertEquals(scheme.lotus, p(NovaOrbState.IDLE).colors.rim)
        assertEquals(scheme.lagoon, p(NovaOrbState.LISTENING).colors.core)
        assertEquals(scheme.accent, p(NovaOrbState.SPEAKING).colors.core)
        assertEquals(scheme.lotus, p(NovaOrbState.SPEAKING).colors.rim)
        assertEquals(scheme.accent, p(NovaOrbState.CONNECTING).colors.core)
        assertEquals(scheme.error, p(NovaOrbState.ERROR).colors.core)
    }

    @Test fun thinkingSwirlsFasterAndConnectingSpinsSlowly() {
        assertTrue(p(NovaOrbState.THINKING).spin > p(NovaOrbState.IDLE).spin)
        assertTrue(p(NovaOrbState.THINKING).swirl > p(NovaOrbState.IDLE).swirl)
        assertTrue(p(NovaOrbState.CONNECTING).spin < p(NovaOrbState.IDLE).spin)
    }

    @Test fun listeningBreathesMostAndErrorIsDim() {
        val breath = NovaOrbState.entries.associateWith { p(it).breath }
        assertEquals(NovaOrbState.LISTENING, breath.maxByOrNull { it.value }!!.key)
        assertTrue(p(NovaOrbState.ERROR).brightness < 0.7f)
        NovaOrbState.entries.filter { it != NovaOrbState.ERROR }.forEach { assertTrue(p(it).brightness >= 1f) }
    }

    @Test fun glowColoursAreFixed() {
        assertEquals(Color(0xFF8B5CF6), NovaGlowColors.Violet)
        assertEquals(Color(0xFFFF6FAE), NovaGlowColors.Pink)
        assertEquals(Color(0xFFFF7A85), NovaGlowColors.Red)
    }
}
