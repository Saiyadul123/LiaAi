package com.Lia.assistant.ui.components

import androidx.compose.ui.graphics.Color
import com.Lia.assistant.voice.NovaOrbState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EdgeGlowSpecTest {
    @Test fun colours() {
        assertEquals(Color(0xFF8B5CF6), edgeGlowSpec(NovaOrbState.LISTENING, 0f, 0f).color)
        assertEquals(Color(0xFFFF6FAE), edgeGlowSpec(NovaOrbState.SPEAKING, 0f, 0f).color)
        assertEquals(Color(0xFFFF7A85), edgeGlowSpec(NovaOrbState.ERROR, 0f, 0f).color)
    }

    @Test fun idleIsInvisibleAndEverythingElseShows() {
        assertEquals(0f, edgeGlowSpec(NovaOrbState.IDLE, 1f, 1f).alpha, 0f)
        NovaOrbState.entries.filter { it != NovaOrbState.IDLE }.forEach {
            val a = edgeGlowSpec(it, 0.5f, 0.5f).alpha
            assertTrue("$it", a > 0f && a <= 1f)
        }
    }

    @Test fun speakingGlowFollowsTheVoice() {
        val quiet = edgeGlowSpec(NovaOrbState.SPEAKING, 0f, 0.5f).alpha
        val loud = edgeGlowSpec(NovaOrbState.SPEAKING, 1f, 0.5f).alpha
        assertTrue(loud > quiet)
        assertTrue(loud <= 1f)
    }

    @Test fun restingGlowBreathes() {
        assertTrue(edgeGlowSpec(NovaOrbState.LISTENING, 0f, 1f).alpha > edgeGlowSpec(NovaOrbState.LISTENING, 0f, 0f).alpha)
    }

    @Test fun inputsAreClamped() {
        assertEquals(edgeGlowSpec(NovaOrbState.SPEAKING, 1f, 0f), edgeGlowSpec(NovaOrbState.SPEAKING, 5f, -2f))
    }
}
