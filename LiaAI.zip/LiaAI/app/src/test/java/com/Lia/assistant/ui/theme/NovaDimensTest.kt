package com.Lia.assistant.ui.theme

import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.Density
import org.junit.Assert.assertEquals
import org.junit.Test

class NovaDimensTest {
    private val density = Density(1f)

    @Test fun spacingScale() {
        assertEquals(
            listOf(4f, 8f, 12f, 16f, 24f, 32f, 48f),
            listOf(NovaSpacing.xs, NovaSpacing.sm, NovaSpacing.md, NovaSpacing.lg, NovaSpacing.xl, NovaSpacing.xxl, NovaSpacing.xxxl).map { it.value }
        )
    }

    @Test fun shapeRadii() {
        val s = NovaShapes()
        val box = Size(200f, 200f)
        assertEquals(12f, s.small.topStart.toPx(box, density), 0.01f)
        assertEquals(20f, s.medium.topStart.toPx(box, density), 0.01f)
        assertEquals(28f, s.large.topStart.toPx(box, density), 0.01f)
        assertEquals(20f, s.pill.topStart.toPx(Size(200f, 40f), density), 0.01f) // fully rounded: half the height
    }

    @Test fun bubbleCornerNearestTheSpeakerIsTighter() {
        val s = NovaShapes()
        val box = Size(200f, 100f)
        assertEquals(6f, s.bubbleUser.bottomEnd.toPx(box, density), 0.01f)
        assertEquals(6f, s.bubbleAssistant.bottomStart.toPx(box, density), 0.01f)
    }

    @Test fun motionDurationsAndTouchTarget() {
        assertEquals(listOf(150, 300, 500), listOf(NovaMotion.FAST, NovaMotion.MEDIUM, NovaMotion.SLOW))
        assertEquals(48f, NovaSizes.MinTouch.value, 0f)
    }
}
