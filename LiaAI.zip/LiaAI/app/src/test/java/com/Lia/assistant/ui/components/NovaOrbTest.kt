package com.Lia.assistant.ui.components

import com.Lia.assistant.ui.theme.NovaColorScheme
import com.Lia.assistant.voice.NovaOrbState
import kotlin.math.abs
import kotlin.math.sqrt
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NovaOrbTest {
    @Test fun sevenStylesInOrder() {
        assertEquals(
            listOf("NOVA", "AURORA", "PLASMA", "GLASS", "ENERGY", "MINIMAL", "ARCHER"),
            NovaOrbStyle.entries.map { it.name }
        )
    }

    @Test fun styleIdsParseLeniently() {
        assertEquals(NovaOrbStyle.ARCHER, NovaOrbStyle.fromId(" archer "))
        assertEquals(NovaOrbStyle.GLASS, NovaOrbStyle.fromId("GLASS"))
        assertEquals(NovaOrbStyle.NOVA, NovaOrbStyle.fromId("classic"))   // legacy default value
        assertEquals(NovaOrbStyle.NOVA, NovaOrbStyle.fromId(null))
    }

    @Test fun particleCountsPerStyle() {
        fun n(s: NovaOrbStyle, st: NovaOrbState = NovaOrbState.IDLE) = orbParticleCount(s, st)
        assertEquals(8, n(NovaOrbStyle.ENERGY))
        assertEquals(6, n(NovaOrbStyle.PLASMA))
        assertEquals(3, n(NovaOrbStyle.GLASS))
        assertEquals(5, n(NovaOrbStyle.NOVA))
        assertEquals(5, n(NovaOrbStyle.AURORA))
        assertEquals(5, n(NovaOrbStyle.ARCHER))
        assertEquals(0, n(NovaOrbStyle.MINIMAL))
    }

    @Test fun noParticlesWhenInError() {
        NovaOrbStyle.entries.forEach { assertEquals(0, orbParticleCount(it, NovaOrbState.ERROR)) }
        assertEquals(8, orbParticleCount(NovaOrbStyle.ENERGY, NovaOrbState.SPEAKING))
    }

    @Test fun rotationPeriods() {
        assertEquals(9000, orbRotationMillis(NovaOrbState.IDLE))
        assertEquals(9000, orbRotationMillis(NovaOrbState.LISTENING))
        assertEquals(2600, orbRotationMillis(NovaOrbState.THINKING))
        assertEquals(1100, orbRotationMillis(NovaOrbState.CONNECTING))
    }

    @Test fun breathingIsASineOfPlusMinus3Point5Percent() {
        assertEquals(1f, breathScale(0f), 1e-6f)
        assertEquals(1.035f, breathScale(0.25f), 1e-5f)
        assertEquals(1f, breathScale(0.5f), 1e-5f)
        assertEquals(0.965f, breathScale(0.75f), 1e-5f)
        assertEquals(4200, ORB_BREATH_MS)
    }

    @Test fun descriptionNamesTheAssistantAndState() {
        assertEquals("Lia status: listening", orbStatusDescription("Lia", NovaOrbState.LISTENING))
        assertEquals("Mia status: error", orbStatusDescription("Mia", NovaOrbState.ERROR))
        val all = NovaOrbState.entries.map { orbStatusDescription("Lia", it) }
        assertEquals(all.size, all.toSet().size)
    }

    @Test fun goldenSphereHas400UnitVectorsSpreadOverTheSphere() {
        val pts = goldenSpherePoints(ARCHER_PARTICLES)
        assertEquals(400, pts.size)
        pts.forEach {
            assertEquals(1f, sqrt(it.x * it.x + it.y * it.y + it.z * it.z), 1e-3f)
            assertTrue(it.jitter in -1f..1f)
        }
        // evenly spread: the mean of the points sits near the centre and both hemispheres are filled
        assertTrue(abs(pts.map { it.x }.average()) < 0.05)
        assertTrue(abs(pts.map { it.y }.average()) < 0.01)
        assertTrue(abs(pts.map { it.z }.average()) < 0.05)
        assertTrue(pts.count { it.z > 0 } in 190..210)
    }

    @Test fun goldenSphereEdgeCases() {
        assertTrue(goldenSpherePoints(0).isEmpty())
        assertTrue(goldenSpherePoints(-3).isEmpty())
        assertEquals(goldenSpherePoints(50), goldenSpherePoints(50))
    }

    @Test fun errorOverridesEveryStyleAndStylesAreDistinct() {
        val scheme = NovaColorScheme.Dark
        NovaOrbStyle.entries.forEach {
            assertEquals(scheme.error, orbStyleColors(it, NovaOrbState.ERROR, scheme).inner)
        }
        val looks = NovaOrbStyle.entries.map {
            val c = orbStyleColors(it, NovaOrbState.IDLE, scheme)
            c.inner to c.outer
        }
        assertEquals(looks.size, looks.toSet().size)
    }
}
