package com.Lia.assistant.data

import android.content.Context
import android.content.ContextWrapper
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class NovaPreferencesTest {
    // Never touched: NovaPrefsFile.testOverride short-circuits before any Context call.
    private val ctx: Context = object : ContextWrapper(null) {}

    @Before fun setUp() { NovaPrefsFile.testOverride = FakeSharedPreferences() }
    @After fun tearDown() { NovaPrefsFile.testOverride = null }

    @Test fun missingValuesReturnDefaults() {
        assertEquals("fallback", NovaPreferences.getString(ctx, "nope", "fallback"))
        assertTrue(NovaPreferences.getBoolean(ctx, "nope", true))
        assertEquals(1.5f, NovaPreferences.getFloat(ctx, "nope", 1.5f), 0f)
    }

    @Test fun valuesRoundTrip() {
        val k = NovaPreferences.Keys
        NovaPreferences.putString(ctx, k.USER_NAME, "Asha")
        NovaPreferences.putBoolean(ctx, k.HAS_ONBOARDED, true)
        NovaPreferences.putFloat(ctx, k.SPEECH_SPEED, 1.25f)
        assertEquals("Asha", NovaPreferences.getString(ctx, k.USER_NAME))
        assertTrue(NovaPreferences.getBoolean(ctx, k.HAS_ONBOARDED))
        assertEquals(1.25f, NovaPreferences.getFloat(ctx, k.SPEECH_SPEED), 0f)
    }

    @Test fun keyNamesAreStable() {
        val k = NovaPreferences.Keys
        assertEquals("theme_mode", k.THEME_MODE)
        assertEquals("assistant_name", k.ASSISTANT_NAME)
        assertEquals("voice_volume", k.VOICE_VOLUME)
    }

    @Test fun apiKeyIsTrimmedAndBlankClears() {
        assertFalse(ApiKeyStore.hasKey(ctx))
        ApiKeyStore.saveKey(ctx, "  abc123  ")
        assertEquals("abc123", ApiKeyStore.getKey(ctx))
        assertTrue(ApiKeyStore.hasKey(ctx))
        ApiKeyStore.saveKey(ctx, "   ")
        assertEquals("", ApiKeyStore.getKey(ctx))
        assertFalse(ApiKeyStore.hasKey(ctx))
    }

    @Test fun apiKeySharesFileWithNovaPreferences() {
        ApiKeyStore.saveKey(ctx, "k")
        assertEquals("k", NovaPreferences.getString(ctx, "gemini_api_key"))
    }
}
