package com.Lia.assistant.voice

import java.util.concurrent.atomic.AtomicInteger
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolCallDeduplicatorTest {

    @Test fun firstSeenIsNewSecondIsDuplicate() {
        val d = ToolCallDeduplicator()
        assertTrue(d.markIfNew("call-1"))
        assertFalse(d.markIfNew("call-1"))
        assertTrue(d.markIfNew("call-2"))
        assertFalse(d.markIfNew("call-2"))
    }

    @Test fun boundedByForgettingOldest() {
        val d = ToolCallDeduplicator(maxSize = 3)
        listOf("a", "b", "c", "d").forEach { assertTrue(d.markIfNew(it)) }
        assertEquals(3, d.size())
        assertFalse(d.markIfNew("d"))   // recent ids are still remembered
        assertTrue(d.markIfNew("a"))    // oldest was evicted, so it counts as new again
        assertEquals(3, d.size())
    }

    @Test fun blankIdsAreAlwaysNewAndNotStored() {
        val d = ToolCallDeduplicator()
        assertTrue(d.markIfNew(""))
        assertTrue(d.markIfNew(""))
        assertTrue(d.markIfNew("  "))
        assertEquals(0, d.size())
    }

    @Test fun clearForgetsEverything() {
        val d = ToolCallDeduplicator()
        d.markIfNew("x")
        d.clear()
        assertEquals(0, d.size())
        assertTrue(d.markIfNew("x"))
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsNonPositiveSize() {
        ToolCallDeduplicator(maxSize = 0)
    }

    @Test fun exactlyOneThreadWinsEachId() {
        val d = ToolCallDeduplicator(maxSize = 1000)
        val wins = AtomicInteger()
        val threads = List(8) {
            Thread { repeat(100) { i -> if (d.markIfNew("id-$i")) wins.incrementAndGet() } }
        }
        threads.forEach { it.start() }
        threads.forEach { it.join() }
        assertEquals(100, wins.get())
    }
}
