package com.Lia.assistant.ui.screens.onboarding

import org.junit.Assert.assertEquals
import org.junit.Test

class OrbPoseTest {
    @Test fun eachPageHasItsOwnPose() {
        assertEquals(
            listOf(OrbPose.CENTER, OrbPose.ORBITING, OrbPose.SPLIT, OrbPose.SHIELDED),
            (0..3).map { poseFor(it) }
        )
    }
}
