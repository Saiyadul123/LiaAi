package com.Lia.assistant.ui.screens.chat

import com.Lia.assistant.data.LanguagePreference
import java.util.Locale
import org.junit.Assert.assertEquals
import org.junit.Test

class SpeechLocaleTest {
    @Test fun fixedLanguages() {
        assertEquals("hi-IN", speechLocale(LanguagePreference.HINDI, "anything").toLanguageTag())
        assertEquals("en-IN", speechLocale(LanguagePreference.HINGLISH, "anything").toLanguageTag())
        assertEquals("en-US", speechLocale(LanguagePreference.ENGLISH, "anything").toLanguageTag())
    }

    @Test fun autoFollowsTheText() {
        assertEquals("hi-IN", speechLocale(LanguagePreference.AUTO, "आज मौसम कैसा है").toLanguageTag())
        assertEquals("en-IN", speechLocale(LanguagePreference.AUTO, "kya haal hai yaar").toLanguageTag())
        assertEquals(Locale.getDefault(), speechLocale(LanguagePreference.AUTO, "what's the weather"))
    }
}
