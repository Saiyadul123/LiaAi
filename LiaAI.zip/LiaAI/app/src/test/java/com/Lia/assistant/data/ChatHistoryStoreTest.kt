package com.Lia.assistant.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatHistoryStoreTest {
    private fun conv(id: String, at: Long, vararg texts: String) = StoredConversation(
        id, "title $id", at, texts.mapIndexed { i, t -> StoredTurn(i % 2 == 0, t) }
    )

    @Test fun roundTripKeepsEverythingIncludingAwkwardText() {
        val original = listOf(
            conv("a", 100, "hello \"quoted\"", "line one\nline two", "नमस्ते 🙂"),
            conv("b", 50),
        )
        assertEquals(original, ChatHistoryStore.fromJson(ChatHistoryStore.toJson(original)))
    }

    @Test fun garbageOrWrongShapeReadsAsEmpty() {
        assertTrue(ChatHistoryStore.fromJson("not json").isEmpty())
        assertTrue(ChatHistoryStore.fromJson("{}").isEmpty())
        assertTrue(ChatHistoryStore.fromJson("""{"conversations":[{"title":"no id"}]}""").isEmpty())
    }

    @Test fun upsertReplacesTheOldCopyAndSortsNewestFirst() {
        val start = listOf(conv("a", 100, "x"), conv("b", 200, "y"))
        val result = ChatHistoryStore.upsert(start, conv("a", 300, "x", "z"), 50)
        assertEquals(listOf("a", "b"), result.map { it.id })
        assertEquals(2, result.first().turns.size)
    }

    @Test fun upsertKeepsOnlyTheNewestMax() {
        var list = emptyList<StoredConversation>()
        (1..5).forEach { list = ChatHistoryStore.upsert(list, conv("c$it", it.toLong(), "t"), 3) }
        assertEquals(listOf("c5", "c4", "c3"), list.map { it.id })
    }

    @Test fun titleIsTheFirstUserMessageShortened() {
        assertEquals("Hello there", ChatHistoryStore.titleFor(listOf(StoredTurn(false, "ignored"), StoredTurn(true, "  Hello\n  there  "))))
        val long = ChatHistoryStore.titleFor(listOf(StoredTurn(true, "word ".repeat(40))))
        assertEquals(48, long.length)
        assertTrue(long.endsWith("…"))
        assertEquals("New conversation", ChatHistoryStore.titleFor(emptyList()))
        assertEquals("New conversation", ChatHistoryStore.titleFor(listOf(StoredTurn(false, "only the assistant"))))
    }

    @Test fun limitConstant() {
        assertEquals(50, ChatHistoryStore.MAX_CONVERSATIONS)
    }
}
