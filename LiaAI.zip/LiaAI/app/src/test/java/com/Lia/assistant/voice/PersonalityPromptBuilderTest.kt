package com.Lia.assistant.voice

import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.Personality
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PersonalityPromptBuilderTest {

    private fun build(
        p: Personality = Personality.NORMAL,
        l: LanguagePreference = LanguagePreference.AUTO,
        d: DetectedLanguage = DetectedLanguage.UNKNOWN,
        recap: String? = null,
        name: String = "Lia",
    ) = PersonalityPromptBuilder.build(p, l, d, recap, name)

    @Test fun defaultsAndOrder() {
        assertEquals(Personality.NORMAL, Personality.DEFAULT)
        assertEquals(
            listOf("NORMAL", "FRIENDLY", "PROFESSIONAL", "FUNNY", "COMPANION", "GF_MODE",
                "TEACHER", "DEVELOPER", "HUNGRY", "NAUTANKI"),
            Personality.entries.map { it.name }
        )
    }

    @Test fun everyPersonalityTimesLanguageBuilds() {
        for (p in Personality.entries) for (l in LanguagePreference.entries) {
            for (d in DetectedLanguage.entries) {
                val out = build(p, l, d)
                assertTrue(out.startsWith("You are Lia, a persistent personal voice assistant"))
                assertTrue(out.contains(p.systemInstruction))
                assertTrue(out.contains(LiaCapabilityPrompts.toolInstruction("Lia")))
                assertTrue(out.contains("Language:"))
                assertTrue(out.contains("Safety:"))
                assertFalse(out.contains("continuing conversation"))
            }
        }
    }

    @Test fun instructionsStartWithPersonalityName() {
        for (p in Personality.entries) {
            assertTrue(p.name, p.systemInstruction.startsWith("Personality: ${p.displayName}. "))
        }
    }

    @Test fun companionAndGfModeCarryGuardrails() {
        for (p in listOf(Personality.COMPANION, Personality.GF_MODE)) {
            val s = p.systemInstruction
            assertTrue(s.contains("never claim to be human or to have a body"))
            assertTrue(s.contains("sexually explicit"))
            assertTrue(s.contains("change your tone or the topic"))
            assertTrue(s.contains("immediately respect"))
        }
    }

    @Test fun recapAppearsOnlyWithRecap() {
        assertFalse(build(recap = null).contains("continuing conversation"))
        assertFalse(build(recap = "   ").contains("continuing conversation"))
        val out = build(recap = "User: hi\nYou: hello")
        assertTrue(out.endsWith("Recap:\nUser: hi\nYou: hello"))
        assertTrue(out.contains("do not greet again"))
    }

    @Test fun sectionsAreOrderedAndBlankLineSeparated() {
        val out = build(Personality.TEACHER, recap = "User: x")
        val idx = listOf(
            "You are Lia", "Tools:", "Personality: Teacher.", "Language:", "Safety:", "This is a continuing"
        ).map { out.indexOf(it) }
        assertTrue(idx.all { it >= 0 })
        assertEquals(idx, idx.sorted())
        assertEquals(6, out.split("\n\n").size)
    }

    @Test fun languagePolicyVariants() {
        assertTrue(build(l = LanguagePreference.AUTO).contains("Never translate what the user said"))
        assertTrue(build(l = LanguagePreference.AUTO, d = DetectedLanguage.HINGLISH).contains("looks like Hinglish"))
        assertTrue(build(l = LanguagePreference.HINDI).contains("Always reply in Hindi"))
        assertTrue(build(l = LanguagePreference.HINGLISH).contains("Always reply in Hinglish"))
        assertTrue(build(l = LanguagePreference.ENGLISH).contains("Always reply in English"))
        // detected language is ignored for fixed modes
        assertFalse(build(l = LanguagePreference.ENGLISH, d = DetectedLanguage.HINDI).contains("looks like"))
    }

    @Test fun assistantNameIsUsedAndBlankFallsBack() {
        assertTrue(build(name = "Mia").startsWith("You are Mia,"))
        assertTrue(build(name = "  ").startsWith("You are Lia,"))
    }
}
