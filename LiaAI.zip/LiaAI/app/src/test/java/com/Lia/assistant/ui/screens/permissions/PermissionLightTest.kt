package com.Lia.assistant.ui.screens.permissions

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PermissionLightTest {
    @Test fun grantedIsGreenWhateverElseIsTrue() {
        assertEquals(PermissionLight.GRANTED, permissionLight(true, askedBefore = false, showRationale = false))
        assertEquals(PermissionLight.GRANTED, permissionLight(true, askedBefore = true, showRationale = true))
    }

    @Test fun notAskedYetIsAmber() {
        assertEquals(PermissionLight.CAN_ASK, permissionLight(false, askedBefore = false, showRationale = false))
    }

    @Test fun askedWithARationaleDueIsStillAmber() {
        assertEquals(PermissionLight.CAN_ASK, permissionLight(false, askedBefore = true, showRationale = true))
    }

    @Test fun askedWithNoDialogLeftIsRed() {
        assertEquals(PermissionLight.BLOCKED, permissionLight(false, askedBefore = true, showRationale = false))
    }

    @Test fun actionsAndSpokenStatesDifferPerLight() {
        val actions = PermissionLight.entries.map { permissionActionLabel(it) }
        val states = PermissionLight.entries.map { permissionStateText(it) }
        assertEquals(actions.size, actions.toSet().size)
        assertEquals(states.size, states.toSet().size)
        assertEquals("Allow", permissionActionLabel(PermissionLight.CAN_ASK))
        assertEquals("Open settings", permissionActionLabel(PermissionLight.BLOCKED))
        assertTrue(states.all { it.isNotBlank() })
    }
}
