package com.Lia.assistant.action

import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class InstalledAppLabelCacheTest {
    private val ctx = FakeContext()
    private val loads = AtomicInteger()
    private var now = 0L

    private fun install(result: () -> Map<String, String>) {
        InstalledAppLabelCache.resetForTest()
        InstalledAppLabelCache.clock = { now }
        InstalledAppLabelCache.loader = { loads.incrementAndGet(); Thread.sleep(30); result() }
    }

    @After fun tearDown() = InstalledAppLabelCache.resetForTest()

    @Test fun concurrentCallersShareOneLoad() = runBlocking {
        install { mapOf("youtube" to "com.yt") }
        val maps = coroutineScope {
            List(10) { async(Dispatchers.Default) { InstalledAppLabelCache.get(ctx) } }.awaitAll()
        }
        assertEquals(1, loads.get())
        assertTrue(maps.all { it == mapOf("youtube" to "com.yt") })
    }

    @Test fun cachedUntilTtlThenRebuilt() = runBlocking {
        install { mapOf("a" to "p") }
        InstalledAppLabelCache.get(ctx)
        now = InstalledAppLabelCache.TTL_MS - 1
        InstalledAppLabelCache.get(ctx)
        assertEquals(1, loads.get())
        now = InstalledAppLabelCache.TTL_MS
        InstalledAppLabelCache.get(ctx)
        assertEquals(2, loads.get())
    }

    @Test fun emptyResultIsNotCached() = runBlocking {
        install { emptyMap() }
        assertTrue(InstalledAppLabelCache.get(ctx).isEmpty())
        InstalledAppLabelCache.get(ctx)
        assertEquals(2, loads.get())
    }

    @Test fun invalidateForcesReload() = runBlocking {
        install { mapOf("a" to "p") }
        InstalledAppLabelCache.get(ctx)
        InstalledAppLabelCache.invalidate()
        InstalledAppLabelCache.get(ctx)
        assertEquals(2, loads.get())
    }
}
