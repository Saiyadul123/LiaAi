package com.Lia.assistant.voice

import org.junit.Assert.assertEquals
import org.junit.Test

class VoiceNamesTest {
    @Test fun knownNamesPassThroughCaseInsensitively() {
        assertEquals("Kore", VoiceNames.toGemini("Kore"))
        assertEquals("Puck", VoiceNames.toGemini("  puck "))
        assertEquals("Charon", VoiceNames.toGemini("CHARON"))
    }

    @Test fun decoratedNamesUseTheFirstWord() {
        assertEquals("Kore", VoiceNames.toGemini("Kore (Firm)"))
        assertEquals("Fenrir", VoiceNames.toGemini("Fenrir - excitable"))
    }

    @Test fun unknownBlankOrNullFallBackToAoede() {
        assertEquals("Aoede", VoiceNames.toGemini("Nova"))
        assertEquals("Aoede", VoiceNames.toGemini(""))
        assertEquals("Aoede", VoiceNames.toGemini(null))
        assertEquals("Aoede", VoiceNames.DEFAULT)
    }
}
