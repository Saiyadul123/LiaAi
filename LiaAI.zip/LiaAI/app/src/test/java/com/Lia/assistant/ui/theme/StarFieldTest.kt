package com.Lia.assistant.ui.theme

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StarFieldTest {
    @Test fun sameSeedGivesTheSameSky() {
        assertEquals(StarField.generate(70, 7), StarField.generate(70, 7))
        assertNotEquals(StarField.generate(70, 7), StarField.generate(70, 8))
    }

    @Test fun countAndRanges() {
        val stars = StarField.generate()
        assertEquals(70, stars.size)
        stars.forEach {
            assertTrue(it.x >= 0f && it.x < 1f && it.y >= 0f && it.y < 1f)
            assertTrue(it.radius in 0.6f..1.6f)
            assertTrue(it.alpha in 0.25f..0.9f)
            assertTrue(it.depth in 0.2f..1f)
            assertTrue(it.phase >= 0f && it.phase < 1f)
        }
    }

    @Test fun degenerateCounts() {
        assertTrue(StarField.generate(0).isEmpty())
        assertTrue(StarField.generate(-5).isEmpty())
    }
}
