package com.Lia.assistant.forge

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SseParserTest {
    @Test fun onlyDataLinesCarryAPayload() {
        assertEquals("""{"a":1}""", SseParser.dataPayload("""data: {"a":1}"""))
        assertEquals("""{"a":1}""", SseParser.dataPayload("""data:{"a":1}"""))
        assertNull(SseParser.dataPayload(""))
        assertNull(SseParser.dataPayload(": keep-alive"))
        assertNull(SseParser.dataPayload("event: message"))
        assertNull(SseParser.dataPayload("data:   "))
    }

    @Test fun theDoneMarkerIsRecognised() {
        assertEquals("[DONE]", SseParser.dataPayload("data: [DONE]"))
        assertTrue(SseParser.isDone("[DONE]"))
        assertFalse(SseParser.isDone("""{"candidates":[]}"""))
    }

    @Test fun textIsReadFromTheFirstCandidate() {
        val json = """{"candidates":[{"content":{"parts":[{"text":"<html>"}],"role":"model"}}]}"""
        assertEquals("<html>", SseParser.extractText(json))
    }

    @Test fun textFromSeveralPartsIsJoinedInOrder() {
        val json = """{"candidates":[{"content":{"parts":[{"text":"<!DOCTYPE "},{"text":"html>"},{"text":"<body>"}]}}]}"""
        assertEquals("<!DOCTYPE html><body>", SseParser.extractText(json))
    }

    @Test fun thinkingPartsAreLeftOut() {
        val json = """{"candidates":[{"content":{"parts":[{"text":"hmm","thought":true},{"text":"<p>"}]}}]}"""
        assertEquals("<p>", SseParser.extractText(json))
    }

    @Test fun eventsWithoutTextGiveAnEmptyString() {
        assertEquals("", SseParser.extractText("""{"usageMetadata":{"totalTokenCount":5}}"""))
        assertEquals("", SseParser.extractText("""{"candidates":[{"finishReason":"STOP"}]}"""))
        assertEquals("", SseParser.extractText("""{"candidates":[{"content":{"parts":[{"text":null}]}}]}"""))
        assertEquals("", SseParser.extractText("not json"))
        assertEquals("", SseParser.extractText(""))
    }

    @Test fun errorsAreReadWithCodeStatusAndMessage() {
        val json = """{"error":{"code":503,"message":"The model is overloaded.","status":"UNAVAILABLE"}}"""
        assertEquals(SseError(503, "UNAVAILABLE", "The model is overloaded."), SseParser.extractError(json))
    }

    @Test fun anEventThatIsNotAnErrorHasNone() {
        assertNull(SseParser.extractError("""{"candidates":[{"content":{"parts":[{"text":"x"}]}}]}"""))
        assertNull(SseParser.extractError("garbage"))
    }

    @Test fun anErrorMissingFieldsStillParses() {
        assertEquals(SseError(0, "", ""), SseParser.extractError("""{"error":{}}"""))
        assertEquals(SseError(400, "", "bad"), SseParser.extractError("""{"error":{"code":400,"message":"bad","status":null}}"""))
    }

    @Test fun theFinishReasonOnlyAppearsOnTheLastEvent() {
        assertNull(SseParser.extractFinishReason("""{"candidates":[{"content":{"parts":[{"text":"x"}]}}]}"""))
        assertEquals("STOP", SseParser.extractFinishReason("""{"candidates":[{"content":{"parts":[{"text":"x"}]},"finishReason":"STOP"}]}"""))
        assertEquals("RECITATION", SseParser.extractFinishReason("""{"candidates":[{"finishReason":"RECITATION"}]}"""))
        assertEquals("MAX_TOKENS", SseParser.extractFinishReason("""{"candidates":[{"finishReason":"MAX_TOKENS"}]}"""))
        assertNull(SseParser.extractFinishReason("""{"candidates":[{"finishReason":null}]}"""))
        assertNull(SseParser.extractFinishReason("nope"))
    }

    @Test fun aWholeStreamReadsLineByLine() {
        val stream = listOf(
            """data: {"candidates":[{"content":{"parts":[{"text":"<!DOCTYPE html>"}]}}]}""",
            "",
            """data: {"candidates":[{"content":{"parts":[{"text":"<body>hi"}]},"finishReason":"STOP"}]}""",
            "",
            "data: [DONE]",
        )
        val text = StringBuilder()
        var reason: String? = null
        for (line in stream) {
            val payload = SseParser.dataPayload(line) ?: continue
            if (SseParser.isDone(payload)) break
            text.append(SseParser.extractText(payload))
            SseParser.extractFinishReason(payload)?.let { reason = it }
        }
        assertEquals("<!DOCTYPE html><body>hi", text.toString())
        assertEquals("STOP", reason)
    }
}
