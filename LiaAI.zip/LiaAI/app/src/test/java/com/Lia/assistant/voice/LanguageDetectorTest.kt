package com.Lia.assistant.voice

import org.junit.Assert.assertEquals
import org.junit.Test

class LanguageDetectorTest {
    @Test fun devanagariIsHindi() {
        assertEquals(DetectedLanguage.HINDI, LanguageDetector.detect("आज मौसम कैसा है"))
        assertEquals(DetectedLanguage.HINDI, LanguageDetector.detect("hello नमस्ते"))
    }

    @Test fun shortHinglishNeedsOneHit() {
        assertEquals(DetectedLanguage.HINGLISH, LanguageDetector.detect("kya haal hai yaar"))
        assertEquals(DetectedLanguage.HINGLISH, LanguageDetector.detect("Batao"))
    }

    @Test fun englishIsEnglish() {
        assertEquals(DetectedLanguage.ENGLISH, LanguageDetector.detect("what's the weather"))
        assertEquals(DetectedLanguage.ENGLISH,
            LanguageDetector.detect("please set a reminder for my meeting tomorrow morning"))
    }

    @Test fun blankIsUnknown() {
        assertEquals(DetectedLanguage.UNKNOWN, LanguageDetector.detect(""))
        assertEquals(DetectedLanguage.UNKNOWN, LanguageDetector.detect("   \n"))
        assertEquals(DetectedLanguage.UNKNOWN, LanguageDetector.detect("123 !!!"))
    }

    @Test fun longTextUsesHitsOrRatio() {
        // 2 hits in 10 words
        assertEquals(DetectedLanguage.HINGLISH,
            LanguageDetector.detect("can you tell me kya time hai right now in london please"))
        // 1 hit in 5 words = 0.2 ratio
        assertEquals(DetectedLanguage.HINGLISH, LanguageDetector.detect("open the music app abhi"))
        // 1 hit in 12 words = 0.083 -> English
        assertEquals(DetectedLanguage.ENGLISH,
            LanguageDetector.detect("please summarize this long article about climate policy and bhai economics for school"))
    }
}
