package com.Lia.assistant.forge

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ForgeSectionsTest {
    private val head = "<!DOCTYPE html><html><head><title>t</title></head>"

    @Test fun nothingIsListedBeforeTheBody() {
        assertEquals(emptyList<String>(), ForgeSections.detect(""))
        assertEquals(emptyList<String>(), ForgeSections.detect("$head<section id=\"x\">")) // a "section" in the head is not a section
        assertEquals(emptyList<String>(), ForgeSections.detect("$head<body"))
    }

    @Test fun idsBecomeReadableNames() {
        val names = ForgeSections.detect("$head<body><section id=\"how-it-works\"></section><section id=\"pricing_plans\"></section>")
        assertEquals(listOf("How It Works", "Pricing Plans"), names)
    }

    @Test fun headingsNameSectionsWithoutIds() {
        val names = ForgeSections.detect("$head<body><section class=\"py-20\"><h2 class=\"text-4xl\">Our <span>Story</span></h2></section>")
        assertEquals(listOf("Our Story"), names)
    }

    @Test fun ariaLabelsAreUsed() {
        assertEquals(listOf("Customer reviews"), ForgeSections.detect("$head<body><section aria-label=\"Customer reviews\">x</section>"))
    }

    @Test fun landmarksHaveDefaultNames() {
        val names = ForgeSections.detect("$head<body><header><nav>m</nav></header><footer>f</footer>")
        assertEquals(listOf("Header", "Navigation", "Footer"), names)
    }

    @Test fun anIdBeatsAHeading() {
        assertEquals(listOf("Hero"), ForgeSections.detect("$head<body><header id=\"hero\"><h1>Welcome to the future</h1></header>"))
    }

    @Test fun aSectionWhoseNameIsStillArrivingIsNotListedYet() {
        assertEquals(emptyList<String>(), ForgeSections.detect("$head<body><section class=\"a\"><h2>Our Sto"))
        assertEquals(listOf("Our Story"), ForgeSections.detect("$head<body><section class=\"a\"><h2>Our Story</h2>"))
    }

    @Test fun aSectionWithNoNameAtAllGetsANumberOnceItIsClearlyDone() {
        val filler = "<p>" + "word ".repeat(200) + "</p>"
        val names = ForgeSections.detect("$head<body><section>$filler</section><section id=\"b\"></section>")
        assertEquals(listOf("Section 1", "B"), names)
    }

    @Test fun repeatedNamesAreNumbered() {
        val names = ForgeSections.detect("$head<body><section id=\"team\"></section><section id=\"team\"></section><section id=\"team\"></section>")
        assertEquals(listOf("Team", "Team 2", "Team 3"), names)
    }

    @Test fun namesAreKeptShort() {
        val long = "A".repeat(80)
        assertEquals(32, ForgeSections.detect("$head<body><section><h2>$long</h2></section>").single().length)
    }

    @Test fun atMostTwelveAreListed() {
        val many = (1..20).joinToString("") { "<section id=\"s$it\"></section>" }
        assertEquals(12, ForgeSections.detect("$head<body>$many").size)
    }

    @Test fun theListOnlyGrowsAsTheTextDoes() {
        val full = "$head<body><header id=\"top\"></header><section id=\"hero\"><h1>Hi</h1></section>" +
            "<section id=\"features\"></section><footer id=\"end\"></footer></body></html>"
        var prefix = emptyList<String>()
        for (cut in 0..full.length) {
            val names = ForgeSections.detect(full.substring(0, cut))
            assertEquals("a name changed at $cut", prefix, names.take(prefix.size))
            assertTrue("the list shrank at $cut", names.size >= prefix.size)
            prefix = names
        }
        assertEquals(listOf("Top", "Hero", "Features", "End"), prefix)
    }
}
