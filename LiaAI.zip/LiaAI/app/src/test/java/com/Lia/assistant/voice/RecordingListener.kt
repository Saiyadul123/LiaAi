package com.Lia.assistant.voice

import org.json.JSONObject

/** Records every callback as a short string so tests can assert on order. */
class RecordingListener : GeminiLiveClient.Listener {
    val events = mutableListOf<String>()
    val audio = mutableListOf<ByteArray>()
    val toolArgs = mutableListOf<JSONObject>()

    override fun onSetupComplete() { events += "setup" }
    override fun onAudioChunk(bytes: ByteArray) { events += "audio"; audio += bytes }
    override fun onInputTranscript(text: String) { events += "in:$text" }
    override fun onOutputTranscript(text: String) { events += "out:$text" }
    override fun onToolCall(id: String, name: String, args: JSONObject) {
        events += "tool:$id:$name"; toolArgs += args
    }
    override fun onTurnComplete() { events += "turn" }
    override fun onInterrupted() { events += "interrupted" }
    override fun onError(message: String) { events += "error:$message" }
    override fun onClosed() { events += "closed" }
}
