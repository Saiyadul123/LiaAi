package com.Lia.assistant.forge

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ForgeStageDetectorTest {
    private val head = """<!DOCTYPE html><html><head><script src="https://cdn.tailwindcss.com"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
        <style>@keyframes spin{to{transform:rotate(1turn)}}</style></head>"""

    private fun classes(n: Int) = (1..n).joinToString(" ") { "<p class=\"a$it\">x</p>" }

    @Test fun aHeadAloneStaysAtThePlanningStage() {
        assertEquals(ForgeStage.PLANNING, ForgeStageDetector.detect(""))
        assertEquals(ForgeStage.PLANNING, ForgeStageDetector.detect("<!DOCTYPE html><html"))
        assertEquals(ForgeStage.PLANNING, ForgeStageDetector.detect(head)) // lists gsap and keyframes, but that is only the head
        assertEquals(ForgeStage.PLANNING, ForgeStageDetector.detect("$head<body class=\"bg-black")) // body tag not finished
        assertEquals(ForgeStage.PLANNING, ForgeStageDetector.detect("$head<body class=\"bg-black\">"))
    }

    @Test fun landmarksMeanStructure() {
        assertEquals(ForgeStage.STRUCTURE, ForgeStageDetector.detect("$head<body><header><nav>x</nav></header><section id=\"hero\">"))
    }

    @Test fun lotsOfClassesOrAStyleBlockMeanStyling() {
        assertEquals(ForgeStage.STYLING, ForgeStageDetector.detect("$head<body><section>${classes(30)}"))
        assertEquals(ForgeStage.STYLING, ForgeStageDetector.detect("$head<body><style>.a{color:red}</style><section>x"))
        assertEquals(ForgeStage.STRUCTURE, ForgeStageDetector.detect("$head<body><section>${classes(5)}"))
    }

    @Test fun aCanvasCountsAsVisuals() {
        assertEquals(ForgeStage.VISUALS, ForgeStageDetector.detect("$head<body><section><canvas id=\"hero3d\"></canvas>"))
        assertEquals(ForgeStage.VISUALS, ForgeStageDetector.detect("$head<body><section><img src=\"https://picsum.photos/seed/sea/1600/900\">"))
        assertEquals(ForgeStage.VISUALS, ForgeStageDetector.detect("$head<body><section><svg viewBox=\"0 0 1 1\">"))
    }

    @Test fun animationCodeInTheBodyMeansMotion() {
        assertEquals(ForgeStage.MOTION, ForgeStageDetector.detect("$head<body><section><canvas></canvas></section><script>gsap.from('.x',{y:40})"))
        assertEquals(ForgeStage.MOTION, ForgeStageDetector.detect("$head<body><section>x</section><script>requestAnimationFrame(loop)"))
        assertEquals(ForgeStage.MOTION, ForgeStageDetector.detect("$head<body><section>x</section><style>@keyframes a{}"))
    }

    @Test fun aClosedBodyMeansFinishing() {
        assertEquals(ForgeStage.FINISHING, ForgeStageDetector.detect("$head<body><section>x</section></body></html>"))
        assertEquals(ForgeStage.FINISHING, ForgeStageDetector.detect("$head<body></body>"))
    }

    @Test fun stagesAdvanceInOrderAsAPageIsWritten() {
        val full = head + "<body class=\"bg-black\"><header><nav>menu</nav></header>" +
            "<section id=\"hero\">${classes(30)}<canvas id=\"c\"></canvas></section>" +
            "<section id=\"about\"><h2>About</h2></section>" +
            "<script>gsap.registerPlugin(ScrollTrigger);</script></body></html>"
        var last = ForgeStage.PLANNING
        val seen = mutableSetOf<ForgeStage>()
        for (cut in 0..full.length) {
            val stage = ForgeStageDetector.detect(full.substring(0, cut))
            assertTrue("went back at $cut: $last -> $stage", stage.ordinal >= last.ordinal)
            last = stage
            seen += stage
        }
        assertEquals(ForgeStage.FINISHING, last)
        assertEquals(ForgeStage.entries.toSet(), seen)
    }

    @Test fun thereAreSixStagesWithLabelsAndSegments() {
        assertEquals(6, ForgeStage.entries.size)
        assertEquals(listOf("Planning", "Structure", "Styling", "Visuals", "Motion", "Finishing"), ForgeStage.entries.map { it.label })
        assertEquals(listOf(1, 2, 3, 4, 5, 6), ForgeStage.entries.map { it.segments })
    }
}
