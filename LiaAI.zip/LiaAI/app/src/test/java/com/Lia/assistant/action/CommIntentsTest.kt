package com.Lia.assistant.action

import com.Lia.assistant.action.CommIntents.MessageApp
import org.junit.Assert.assertEquals
import org.junit.Test

class CommIntentsTest {
    @Test fun whatsAppUrlUsesDigitsAndPercentEncoding() {
        assertEquals(
            "https://wa.me/919876543210?text=Hello%20World%20%26%20more%2B1",
            CommIntents.whatsAppUrl("+91 98765-43210", "Hello World & more+1")
        )
    }

    @Test fun digitsOnlyStripsFormatting() {
        assertEquals("919876543210", CommIntents.digitsOnly("+91 (987) 654-3210"))
    }

    @Test fun messageAppParsing() {
        assertEquals(MessageApp.WHATSAPP, CommIntents.parseMessageApp("WhatsApp"))
        assertEquals(MessageApp.WHATSAPP, CommIntents.parseMessageApp("on whatsapp"))
        assertEquals(MessageApp.WHATSAPP, CommIntents.parseMessageApp("wa"))
        assertEquals(MessageApp.SMS, CommIntents.parseMessageApp("sms"))
        assertEquals(MessageApp.SMS, CommIntents.parseMessageApp("text"))
        assertEquals(MessageApp.SMS, CommIntents.parseMessageApp(null))
        assertEquals(MessageApp.SMS, CommIntents.parseMessageApp(""))
    }

    @Test fun callActions() {
        assertEquals("android.intent.action.CALL", CommIntents.callAction(true))
        assertEquals("android.intent.action.DIAL", CommIntents.callAction(false))
    }

    @Test fun whatsAppPackages() {
        assertEquals(listOf("com.whatsapp", "com.whatsapp.w4b"), CommIntents.WHATSAPP_PACKAGES)
    }
}
