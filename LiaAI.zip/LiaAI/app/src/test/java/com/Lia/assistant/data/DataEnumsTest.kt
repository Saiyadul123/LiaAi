package com.Lia.assistant.data

import com.Lia.assistant.voice.ToolDeclaration
import com.Lia.assistant.voice.ToolParam
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DataEnumsTest {
    @Test fun thereAreTenPersonalitiesWithUniqueNames() {
        assertEquals(
            listOf("NORMAL", "FRIENDLY", "PROFESSIONAL", "FUNNY", "COMPANION", "GF_MODE", "TEACHER", "DEVELOPER", "HUNGRY", "NAUTANKI"),
            Personality.entries.map { it.name },
        )
        assertEquals(10, Personality.entries.map { it.displayName }.toSet().size)
        Personality.entries.forEach { assertTrue(it.name, it.description.isNotBlank()) }
    }

    @Test fun everyInstructionStartsWithItsPersonalityName() {
        Personality.entries.forEach {
            assertTrue(it.name, it.systemInstruction.startsWith("Personality: ${it.displayName}."))
        }
    }

    @Test fun theCloseCompanionPersonalitiesCarryTheSafetyRules() {
        listOf(Personality.COMPANION, Personality.GF_MODE).forEach {
            val text = it.systemInstruction
            assertTrue(it.name, text.contains("never claim to be human"))
            assertTrue(it.name, text.contains("Never produce sexually explicit content"))
            assertTrue(it.name, text.contains("immediately respect that"))
        }
    }

    @Test fun personalitiesAreStoredByNameAndRoundTrip() {
        Personality.entries.forEach { assertEquals(it, Personality.valueOf(it.name)) }
    }

    @Test fun languageNamesParseAndUnknownOnesAreNull() {
        assertEquals(LanguagePreference.HINGLISH, LanguagePreference.fromName("HINGLISH"))
        assertNull(LanguagePreference.fromName(null))
        assertNull(LanguagePreference.fromName(""))
        assertNull(LanguagePreference.fromName("hinglish")) // names are stored exactly
        assertNull(LanguagePreference.fromName("KLINGON"))
        assertEquals(LanguagePreference.AUTO, LanguagePreference.DEFAULT)
    }

    @Test fun themeFallsBackToDark() {
        assertEquals(ThemeMode.LIGHT, ThemeMode.fromName("LIGHT"))
        assertEquals(ThemeMode.DARK, ThemeMode.fromName(null))
        assertEquals(ThemeMode.DARK, ThemeMode.fromName("SEPIA"))
        assertEquals(ThemeMode.DARK, ThemeMode.DEFAULT)
    }

    @Test fun theBrandIsLia() {
        assertEquals("Lia", AssistantBrand.NAME)
        assertEquals("Lia AI", AssistantBrand.FULL_NAME)
        assertTrue(AssistantBrand.TAGLINE.isNotBlank())
    }

    @Test fun toolParametersAreRequiredUnlessSaidOtherwise() {
        assertTrue(ToolParam("a", "b").required)
        assertFalse(ToolParam("a", "b", required = false).required)
        assertTrue(ToolDeclaration("t", "d").params.isEmpty())
    }
}
