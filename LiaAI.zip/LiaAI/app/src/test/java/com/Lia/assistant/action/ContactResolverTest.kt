package com.Lia.assistant.action

import com.Lia.assistant.action.ContactResolver.Candidate
import com.Lia.assistant.action.ContactResolver.Result
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ContactResolverTest {
    private fun c(name: String, number: String = "1") = Candidate(name, number)

    @Test fun phoneNumberDetection() {
        assertTrue(ContactResolver.looksLikePhoneNumber("98765 43210"))
        assertTrue(ContactResolver.looksLikePhoneNumber("+91 (987) 654-3210"))
        assertTrue(ContactResolver.looksLikePhoneNumber("555.123.4567"))
        assertFalse(ContactResolver.looksLikePhoneNumber("1234"))          // fewer than 5 digits
        assertFalse(ContactResolver.looksLikePhoneNumber("Mom 12345"))     // letters
        assertFalse(ContactResolver.looksLikePhoneNumber("++-- ()"))
        assertFalse(ContactResolver.looksLikePhoneNumber(""))
    }

    @Test fun rankingIsExactThenPrefixThenContains() {
        val ranked = ContactResolver.rank(
            "sam",
            listOf(c("Ansam"), c("Samantha"), c("SAM"), c("Sam Jones"), c("Rosamund"))
        ).map { it.name }
        assertEquals(listOf("SAM", "Samantha", "Sam Jones", "Ansam", "Rosamund"), ranked)
    }

    @Test fun ties_preferShorterNameThenKeepOrder() {
        val ranked = ContactResolver.rank("al", listOf(c("Alexander"), c("Alan"), c("Alice B"), c("Alan"))).map { it.name }
        assertEquals(listOf("Alan", "Alan", "Alice B", "Alexander"), ranked)
    }

    @Test fun numberQueryNeverNeedsPermissionOrSearch() {
        var searched = false
        val r = ContactResolver.lookup("98765 43210", hasPermission = { false }, search = { searched = true; emptyList() })
        assertEquals(Result.Found("98765 43210", "98765 43210"), r)
        assertFalse(searched)
    }

    @Test fun nameQueryWithoutPermissionIsNoPermission() {
        var searched = false
        val r = ContactResolver.lookup("Mom", hasPermission = { false }, search = { searched = true; emptyList() })
        assertEquals(Result.NoPermission, r)
        assertFalse(searched)
    }

    @Test fun noMatchesIsNotFoundAndBlankIsNotFound() {
        assertEquals(Result.NotFound, ContactResolver.lookup("Zed", { true }, { emptyList() }))
        assertEquals(Result.NotFound, ContactResolver.lookup("   ", { true }, { listOf(c("x")) }))
    }

    @Test fun bestRankedCandidateIsReturned() {
        val r = ContactResolver.lookup(
            "mom", { true },
            { listOf(Candidate("Tommy", "111"), Candidate("Mom", "222"), Candidate("Mommy Dearest", "333")) }
        )
        assertEquals(Result.Found("Mom", "222"), r)
    }

    @Test fun contextOverloadWithoutPermissionDoesNotTouchContacts() {
        assertEquals(Result.NoPermission, ContactResolver.lookup(FakeContext(), "Mom"))
        assertTrue(ContactResolver.lookup(FakeContext(), "+91 98765 43210") is Result.Found)
    }
}
