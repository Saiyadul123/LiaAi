package com.Lia.assistant.voice

import com.Lia.assistant.voice.VoiceLatencyTracker.Mark
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceLatencyHistoryTest {
    private var now = 0L
    private val tracker = VoiceLatencyTracker(clock = { now })

    private fun turn(firstAudioAfter: Long, audioFor: Long) {
        tracker.beginTurn()
        tracker.mark(Mark.USER_SPEECH_END)
        now += firstAudioAfter
        tracker.mark(Mark.FIRST_AUDIO)
        now += audioFor
        tracker.mark(Mark.TURN_COMPLETE)
        now += 10
    }

    @Test fun everyFinishedTurnIsRecordedWithItsNumber() {
        turn(300, 2000)
        turn(450, 1500)
        val h = tracker.history.value
        assertEquals(listOf(1, 2), h.map { it.number })
        assertEquals(300L, h[0].latency.timeToFirstAudioMs)
        assertEquals(2000L, h[0].latency.audioDurationMs)
        assertEquals(2300L, h[0].latency.totalMs)
        assertEquals(450L, h[1].latency.timeToFirstAudioMs)
        assertEquals(h.last().latency, tracker.lastTurn.value)
    }

    @Test fun aTurnInProgressIsNotInTheHistory() {
        tracker.beginTurn()
        tracker.mark(Mark.USER_SPEECH_END)
        tracker.mark(Mark.FIRST_AUDIO)
        assertTrue(tracker.history.value.isEmpty())
    }

    @Test fun beginningATurnKeepsTheHistory() {
        turn(100, 100)
        tracker.beginTurn()
        assertEquals(1, tracker.history.value.size)
    }

    @Test fun aRejectedMarkAddsNothing() {
        turn(100, 100)
        assertFalse(tracker.mark(Mark.TURN_COMPLETE)) // duplicate in the same turn
        assertEquals(1, tracker.history.value.size)
    }

    @Test fun aTurnThatSkippedAMarkStillCountsWithNullDeltas() {
        tracker.beginTurn()
        tracker.mark(Mark.USER_SPEECH_END)
        now += 900
        tracker.mark(Mark.TURN_COMPLETE) // no audio came
        val l = tracker.history.value.single().latency
        assertEquals(null, l.timeToFirstAudioMs)
        assertEquals(null, l.audioDurationMs)
        assertEquals(900L, l.totalMs)
    }

    @Test fun onlyTheLastTwentyAreKeptAndNumbersKeepCounting() {
        repeat(25) { turn(100, 100) }
        val h = tracker.history.value
        assertEquals(20, h.size)
        assertEquals(6, h.first().number)
        assertEquals(25, h.last().number)
    }

    @Test fun resetStartsTheCountAgain() {
        repeat(3) { turn(100, 100) }
        tracker.reset()
        assertTrue(tracker.history.value.isEmpty())
        turn(100, 100)
        assertEquals(listOf(1), tracker.history.value.map { it.number })
    }
}
