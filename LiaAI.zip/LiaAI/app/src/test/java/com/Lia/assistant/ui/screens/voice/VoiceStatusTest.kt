package com.Lia.assistant.ui.screens.voice

import com.Lia.assistant.voice.NovaOrbState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceStatusTest {
    private fun line(active: Boolean, state: NovaOrbState, muted: Boolean = false) =
        VoiceStatus.line("Lia", active, state, muted)

    @Test fun usesTheSavedName() {
        assertEquals("Lia is listening…", line(true, NovaOrbState.LISTENING))
        assertEquals("Mia is listening…", VoiceStatus.line("Mia", true, NovaOrbState.LISTENING, false))
    }

    @Test fun eachStateHasItsOwnLine() {
        val lines = NovaOrbState.entries.map { line(true, it) }
        assertEquals(lines.size, lines.toSet().size)
        assertEquals("Lia is speaking…", line(true, NovaOrbState.SPEAKING))
        assertEquals("Connecting to Lia…", line(true, NovaOrbState.CONNECTING))
        assertEquals("Lia is thinking…", line(true, NovaOrbState.THINKING))
    }

    @Test fun restingWhenNoSessionRuns() {
        NovaOrbState.entries.forEach { assertEquals("Lia is resting", line(false, it)) }
    }

    @Test fun mutedWhileListeningSaysSo() {
        assertTrue(line(true, NovaOrbState.LISTENING, muted = true).startsWith("Muted"))
        // muting does not change what it says while it is speaking
        assertEquals("Lia is speaking…", line(true, NovaOrbState.SPEAKING, muted = true))
    }
}
