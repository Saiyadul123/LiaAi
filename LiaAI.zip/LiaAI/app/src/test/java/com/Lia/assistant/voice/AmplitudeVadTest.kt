package com.Lia.assistant.voice

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AmplitudeVadTest {
    private var now = 0L
    private val vad = AmplitudeVad(threshold = 0.05f, holdMs = 500) { now }

    @Test fun quietStaysInactive() {
        assertFalse(vad.update(0.01f))
    }

    @Test fun loudActivatesAndHoldsThroughShortPauses() {
        now = 0; assertTrue(vad.update(0.2f))
        now = 400; assertTrue(vad.update(0.0f))      // inside hold time
        now = 500; assertFalse(vad.update(0.0f))     // hold elapsed
    }

    @Test fun loudAgainExtendsHoldAndResetClears() {
        now = 0; vad.update(0.2f)
        now = 400; vad.update(0.2f)
        now = 800; assertTrue(vad.update(0.0f))
        vad.reset()
        assertFalse(vad.active)
    }
}
