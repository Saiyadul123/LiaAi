package com.Lia.assistant.ui.screens.splash

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SplashTimingTest {
    @After fun tearDown() = SplashSession.resetForTest()

    @Test fun playedFlagStartsFalseAndSticks() {
        SplashSession.resetForTest()
        assertFalse(SplashSession.played)
        SplashSession.played = true
        assertTrue(SplashSession.played)
    }

    @Test fun waitsForReadinessAndTheMinimumTime() {
        val min = SplashTiming.MIN_MS
        assertFalse(SplashTiming.shouldFinish(min - 1, ready = true, reduced = false))   // ready, too early
        assertFalse(SplashTiming.shouldFinish(min + 500, ready = false, reduced = false)) // late, not ready
        assertTrue(SplashTiming.shouldFinish(min, ready = true, reduced = false))
    }

    @Test fun neverHangsPastTheHardMaximum() {
        assertTrue(SplashTiming.shouldFinish(SplashTiming.MAX_MS, ready = false, reduced = false))
        assertTrue(SplashTiming.shouldFinish(SplashTiming.MAX_MS, ready = false, reduced = true))
    }

    @Test fun reducedMotionIsShorter() {
        assertTrue(SplashTiming.minDuration(true) < SplashTiming.minDuration(false))
        assertTrue(SplashTiming.shouldFinish(SplashTiming.REDUCED_MIN_MS, ready = true, reduced = true))
        assertFalse(SplashTiming.shouldFinish(SplashTiming.REDUCED_MIN_MS, ready = true, reduced = false))
    }

    @Test fun progressIsClamped() {
        assertEquals(0f, SplashTiming.progress(0, false), 0f)
        assertEquals(0.5f, SplashTiming.progress(SplashTiming.MIN_MS / 2, false), 1e-3f)
        assertEquals(1f, SplashTiming.progress(10_000, false), 0f)
    }

    @Test fun orbGrowsFromSeventyPercentAndStaysPutWhenReduced() {
        assertEquals(0.7f, SplashTiming.orbScale(0f, false), 1e-5f)
        assertEquals(1f, SplashTiming.orbScale(1f, false), 1e-5f)
        assertTrue(SplashTiming.orbScale(0.3f, false) < SplashTiming.orbScale(0.6f, false))
        assertEquals(1f, SplashTiming.orbScale(0f, true), 0f)
    }

    @Test fun titleFadesInLate() {
        assertEquals(0f, SplashTiming.textAlpha(0.1f), 0f)
        assertEquals(1f, SplashTiming.textAlpha(1f), 0f)
        assertTrue(SplashTiming.textAlpha(0.5f) in 0.01f..0.99f)
    }
}
