package com.Lia.assistant.ui.screens.splash

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SplashTimingTest {
    @After fun tearDown() = SplashSession.resetForTest()

    @Test fun playedFlagStartsFalseAndSticks() {
        SplashSession.resetForTest()
        assertFalse(SplashSession.played)
        SplashSession.played = true
        assertTrue(SplashSession.played)
    }

    @Test fun waitsForReadinessAndTheMinimumTime() {
        val min = SplashTiming.MIN_MS
        assertFalse(SplashTiming.shouldFinish(min - 1, ready = true, reduced = false))    // ready, too early
        assertFalse(SplashTiming.shouldFinish(min + 100, ready = false, reduced = false)) // late, not ready
        assertTrue(SplashTiming.shouldFinish(min, ready = true, reduced = false))
    }

    @Test fun neverRunsPastTwoPointTwoSeconds() {
        assertEquals(2200L, SplashTiming.MAX_MS)
        assertFalse(SplashTiming.shouldFinish(SplashTiming.MAX_MS - 1, ready = false, reduced = false))
        assertTrue(SplashTiming.shouldFinish(SplashTiming.MAX_MS, ready = false, reduced = false))
        assertTrue(SplashTiming.shouldFinish(SplashTiming.MAX_MS, ready = false, reduced = true))
    }

    @Test fun aTapSkipsAtOnce() {
        assertTrue(SplashTiming.shouldFinish(0, ready = false, reduced = false, skipped = true))
        assertFalse(SplashTiming.shouldFinish(0, ready = false, reduced = false, skipped = false))
    }

    @Test fun reducedMotionIsShorter() {
        assertTrue(SplashTiming.minDuration(true) < SplashTiming.minDuration(false))
        assertTrue(SplashTiming.shouldFinish(SplashTiming.REDUCED_MIN_MS, ready = true, reduced = true))
        assertFalse(SplashTiming.shouldFinish(SplashTiming.REDUCED_MIN_MS, ready = true, reduced = false))
    }

    @Test fun progressIsClamped() {
        assertEquals(0f, SplashTiming.progress(0, false), 0f)
        assertEquals(0.5f, SplashTiming.progress(SplashTiming.MIN_MS / 2, false), 1e-3f)
        assertEquals(1f, SplashTiming.progress(10_000, false), 0f)
    }

    @Test fun starsStreakDuringTheFirstSixtyPercent() {
        assertEquals(0f, SplashTiming.streakPhase(0f), 0f)
        assertEquals(0.5f, SplashTiming.streakPhase(0.3f), 1e-4f)
        assertEquals(1f, SplashTiming.streakPhase(0.6f), 1e-4f)
        assertEquals(1f, SplashTiming.streakPhase(1f), 0f)
    }

    @Test fun particlesGatherBetweenFifteenAndSeventyPercent() {
        assertEquals(0f, SplashTiming.condense(0.05f), 0f)
        assertEquals(0f, SplashTiming.condense(0.15f), 1e-4f)
        assertTrue(SplashTiming.condense(0.3f) < SplashTiming.condense(0.5f))
        assertEquals(1f, SplashTiming.condense(0.7f), 1e-4f)
        assertEquals(1f, SplashTiming.condense(1f), 0f)
    }

    @Test fun theOrbCondensesInAfterTheParticles() {
        assertEquals(0f, SplashTiming.orbAppear(0.55f, false), 1e-4f)
        assertEquals(0.5f, SplashTiming.orbAppear(0.675f, false), 1e-4f)
        assertEquals(1f, SplashTiming.orbAppear(0.8f, false), 1e-4f)
        assertEquals(1f, SplashTiming.orbAppear(0f, true), 0f) // reduced motion: simply there
    }

    @Test fun orbGrowsFromHalfSizeAndStaysPutWhenReduced() {
        assertEquals(0.5f, SplashTiming.orbScale(0f, false), 1e-4f)
        assertEquals(1f, SplashTiming.orbScale(1f, false), 1e-4f)
        assertTrue(SplashTiming.orbScale(0.6f, false) < SplashTiming.orbScale(0.75f, false))
        assertEquals(1f, SplashTiming.orbScale(0f, true), 0f)
    }

    @Test fun nameFadesInLast() {
        assertEquals(0f, SplashTiming.textAlpha(0.6f), 1e-4f)
        assertEquals(0.5f, SplashTiming.textAlpha(0.75f), 1e-4f)
        assertEquals(1f, SplashTiming.textAlpha(0.9f), 1e-4f)
    }
}
