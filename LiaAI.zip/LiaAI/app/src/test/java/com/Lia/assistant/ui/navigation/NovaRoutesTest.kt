package com.Lia.assistant.ui.navigation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NovaRoutesTest {
    @Test fun startsAtHomeOnlyAfterOnboarding() {
        assertEquals("home", NovaRoutes.startRoute(true))
        assertEquals("onboarding", NovaRoutes.startRoute(false))
    }

    @Test fun routeNames() {
        assertEquals(
            listOf(
                "splash", "onboarding", "home", "chat", "history", "settings", "voice", "quick_actions",
                "profile", "personality", "orb_style", "privacy", "permissions", "about", "debug", "forge",
                "accessibility_disclosure",
            ),
            listOf(
                NovaRoutes.SPLASH, NovaRoutes.ONBOARDING, NovaRoutes.HOME, NovaRoutes.CHAT, NovaRoutes.HISTORY,
                NovaRoutes.SETTINGS, NovaRoutes.VOICE, NovaRoutes.QUICK_ACTIONS, NovaRoutes.PROFILE,
                NovaRoutes.PERSONALITY, NovaRoutes.ORB_STYLE, NovaRoutes.PRIVACY, NovaRoutes.PERMISSIONS,
                NovaRoutes.ABOUT, NovaRoutes.DEBUG, NovaRoutes.FORGE, NovaRoutes.ACCESSIBILITY_DISCLOSURE,
            )
        )
    }

    @Test fun bottomBarShowsOnExactlyTheFourTabs() {
        listOf(NovaRoutes.HOME, NovaRoutes.CHAT, NovaRoutes.HISTORY, NovaRoutes.SETTINGS).forEach {
            assertTrue(it, NovaRoutes.showsBottomBar(it))
        }
        // the chat destination's pattern and a concrete chat route are still the Chat tab
        assertTrue(NovaRoutes.showsBottomBar(NovaRoutes.CHAT_PATTERN))
        assertTrue(NovaRoutes.showsBottomBar("chat?conversation=abc"))
    }

    @Test fun bottomBarHidesEverywhereElse() {
        listOf(
            NovaRoutes.SPLASH, NovaRoutes.ONBOARDING, NovaRoutes.VOICE, NovaRoutes.QUICK_ACTIONS, NovaRoutes.PROFILE,
            NovaRoutes.PERSONALITY, NovaRoutes.ORB_STYLE, NovaRoutes.PRIVACY, NovaRoutes.PERMISSIONS, NovaRoutes.ABOUT,
            NovaRoutes.DEBUG, NovaRoutes.FORGE, NovaRoutes.ACCESSIBILITY_DISCLOSURE, "", "unknown",
        ).forEach { assertFalse(it, NovaRoutes.showsBottomBar(it)) }
        assertFalse(NovaRoutes.showsBottomBar(null))
    }

    @Test fun chatPatternHasTwoOptionalArguments() {
        assertEquals("chat?conversation={conversation}&prompt={prompt}", NovaRoutes.CHAT_PATTERN)
    }

    @Test fun chatRouteBuilder() {
        assertEquals("chat", NovaRoutes.chat())
        assertEquals("chat?conversation=a+b", NovaRoutes.chat(conversationId = "a b"))
        assertEquals("chat?prompt=hi+there%3F", NovaRoutes.chat(prompt = "hi there?"))
        assertEquals("chat?conversation=x&prompt=y", NovaRoutes.chat("x", "y"))
    }

    @Test fun baseRouteStripsArguments() {
        assertEquals("chat", NovaRoutes.baseRoute("chat?conversation={conversation}"))
        assertEquals("settings", NovaRoutes.baseRoute("settings"))
        assertEquals(null, NovaRoutes.baseRoute(null))
    }
}
