package com.Lia.assistant.ui.fx

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LiaOrbShaderTest {
    private val src = LiaOrbShader.SOURCE

    @Test fun declaresEveryUniformTheKotlinSideSets() {
        LiaOrbShader.UNIFORMS.forEach { name ->
            assertTrue("missing uniform $name", Regex("""uniform\s+\w+\s+$name\s*;""").containsMatchIn(src))
        }
    }

    @Test fun noUndeclaredUniformsLeftBehind() {
        val declared = Regex("""uniform\s+\w+\s+(\w+)\s*;""").findAll(src).map { it.groupValues[1] }.toList()
        assertEquals(LiaOrbShader.UNIFORMS.sorted(), declared.sorted())
    }

    @Test fun colourUniformsUseTheColourLayout() {
        listOf("coreColor", "rimColor", "haloColor").forEach {
            assertTrue(src.contains("layout(color) uniform half4 $it;"))
        }
    }

    @Test fun hasAnAgslEntryPointAndTheLightingTerms() {
        assertTrue(src.contains("half4 main(float2 fragCoord)"))
        listOf("fbm(", "fresnel", "spec", "diff", "lightDir", "tilt", "haloK").forEach {
            assertTrue("missing $it", src.contains(it))
        }
    }

    @Test fun usesNoTemplateSyntaxOrGlslOnlyBuiltins() {
        assertTrue(!src.contains("$"))
        assertTrue(!src.contains("gl_FragCoord"))
        assertTrue(!src.contains("#version"))
    }
}
