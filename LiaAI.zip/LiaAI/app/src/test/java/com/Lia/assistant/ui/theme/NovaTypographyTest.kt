package com.Lia.assistant.ui.theme

import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class NovaTypographyTest {
    private val t = NovaTypography.create(NovaFonts.Fallback)

    @Test fun sansStylesMatchTheSpec() {
        assertEquals(17.sp, t.title.fontSize); assertEquals(24.sp, t.title.lineHeight); assertEquals(FontWeight.SemiBold, t.title.fontWeight)
        assertEquals(15.sp, t.body.fontSize); assertEquals(22.sp, t.body.lineHeight)
        assertEquals(13.sp, t.label.fontSize); assertEquals(18.sp, t.label.lineHeight)
        assertEquals(12.sp, t.caption.fontSize); assertEquals(16.sp, t.caption.lineHeight)
    }

    @Test fun serifIsForDisplayHeadlineAndVoiceOnly() {
        assertEquals(FontFamily.Serif, t.display.fontFamily)
        assertEquals(FontFamily.Serif, t.headline.fontFamily)
        assertEquals(FontFamily.Serif, t.voice.fontFamily)
        assertEquals(FontStyle.Italic, t.voice.fontStyle)
        listOf(t.title, t.body, t.label, t.caption).forEach { assertEquals(FontFamily.SansSerif, it.fontFamily) }
    }

    @Test fun materialMappingKeepsTheFonts() {
        val m = t.toMaterial()
        assertEquals(t.display, m.displayLarge)
        assertEquals(FontFamily.Serif, m.headlineMedium.fontFamily)
        assertEquals(t.title, m.titleMedium)
        assertEquals(t.body, m.bodyMedium)
        assertEquals(FontFamily.SansSerif, m.labelLarge.fontFamily)
    }

    @Test fun missingFontFilesFallBackToSystemFamilies() {
        val none = NovaFonts.from { 0 }
        assertEquals(FontFamily.Serif, none.serif)
        assertEquals(FontFamily.SansSerif, none.sans)
    }

    @Test fun bundledFontFilesAreUsedWhenPresent() {
        val some = NovaFonts.from { 1 }
        assertNotEquals(FontFamily.Serif, some.serif)
        assertNotEquals(FontFamily.SansSerif, some.sans)
    }
}
