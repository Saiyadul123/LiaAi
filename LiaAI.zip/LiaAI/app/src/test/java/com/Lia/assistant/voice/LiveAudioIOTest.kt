package com.Lia.assistant.voice

import org.junit.Assert.assertEquals
import org.junit.Test

class LiveAudioIOTest {
    private fun pcm(vararg samples: Int): ByteArray {
        val out = ByteArray(samples.size * 2)
        samples.forEachIndexed { i, s ->
            out[i * 2] = (s and 0xFF).toByte()
            out[i * 2 + 1] = ((s shr 8) and 0xFF).toByte()
        }
        return out
    }

    @Test fun silenceAndEmptyAreZero() {
        assertEquals(0f, LiveAudioIO.rms(pcm(0, 0, 0, 0)), 0f)
        assertEquals(0f, LiveAudioIO.rms(ByteArray(0)), 0f)
        assertEquals(0f, LiveAudioIO.rms(byteArrayOf(5)), 0f)  // less than one sample
    }

    @Test fun littleEndianDecoding() {
        // bytes 00 40 -> 0x4000 = 16384 -> 0.5
        assertEquals(0.5f, LiveAudioIO.rms(byteArrayOf(0x00, 0x40)), 1e-6f)
        // bytes 00 80 -> -32768 -> 1.0
        assertEquals(1f, LiveAudioIO.rms(byteArrayOf(0x00, 0x80.toByte())), 1e-6f)
        // 0x0100 = 256 only when low byte first; 01 00 would be 1
        assertEquals(256f / 32768f, LiveAudioIO.rms(byteArrayOf(0x00, 0x01)), 1e-6f)
        assertEquals(1f / 32768f, LiveAudioIO.rms(byteArrayOf(0x01, 0x00)), 1e-9f)
    }

    @Test fun signDoesNotMatterAndIsRmsNotPeak() {
        assertEquals(0.5f, LiveAudioIO.rms(pcm(16384, -16384, 16384, -16384)), 1e-6f)
        // mean(s^2) of [0, 32768-ish] -> sqrt(0.5) of full scale
        assertEquals(0.70710678f, LiveAudioIO.rms(pcm(0, -32768)), 1e-5f)
    }

    @Test fun neverExceedsOne() {
        val v = LiveAudioIO.rms(pcm(-32768, -32768, 32767, 32767))
        assertEquals(true, v in 0f..1f)
    }

    @Test fun lengthLimitsSamplesUsedAndIgnoresPartialSample() {
        val data = pcm(16384, 0, 0, 0)
        assertEquals(0.5f, LiveAudioIO.rms(data, 2), 1e-6f)      // only first sample
        assertEquals(0.5f, LiveAudioIO.rms(data, 3), 1e-6f)      // trailing odd byte ignored
        assertEquals(0f, LiveAudioIO.rms(data, 0), 0f)
        assertEquals(0.25f, LiveAudioIO.rms(data, 8), 1e-6f)      // 1 of 4 samples loud: 0.5 / sqrt(4)
    }

    @Test fun bufferSizing() {
        assertEquals(4096, LiveAudioIO.micBufferSize(1280))
        assertEquals(8192, LiveAudioIO.micBufferSize(8192))
        assertEquals(4096, LiveAudioIO.micBufferSize(-1))    // error code
        assertEquals(4 * 3840, LiveAudioIO.speakerBufferSize(3840))
        assertEquals(4 * 4800, LiveAudioIO.speakerBufferSize(-2)) // error code fallback
    }

    @Test fun formatConstants() {
        assertEquals(16_000, LiveAudioIO.MIC_SAMPLE_RATE)
        assertEquals(24_000, LiveAudioIO.SPEAKER_SAMPLE_RATE)
        assertEquals(2048, LiveAudioIO.MIC_CHUNK_BYTES)
    }
}
