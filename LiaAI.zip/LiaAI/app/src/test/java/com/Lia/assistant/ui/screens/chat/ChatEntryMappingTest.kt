package com.Lia.assistant.ui.screens.chat

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatEntryMappingTest {
    @Test fun streamingEntryShowsTheRevealedPrefixAndIsStreaming() {
        val ui = ChatEntry(1, isUser = false, text = "one two three", shownWords = 2).toUi()
        assertEquals("one two", ui.text)
        assertTrue(ui.isStreaming)
        assertFalse(ui.isError)
        assertFalse(ui.isUser)
    }

    @Test fun finishedEntryIsNotStreaming() {
        val ui = ChatEntry(2, isUser = false, text = "done").toUi()
        assertEquals("done", ui.text)
        assertFalse(ui.isStreaming)
    }

    @Test fun errorKindMapsToIsError() {
        assertTrue(ChatEntry(3, isUser = false, text = "oops", kind = ChatEntry.Kind.ERROR).toUi().isError)
        assertFalse(ChatEntry(4, isUser = false, text = "ok", kind = ChatEntry.Kind.FORGE).toUi().isError)
    }

    @Test fun userEntryKeepsItsSide() {
        val ui = ChatEntry(5, isUser = true, text = "hi there").toUi()
        assertTrue(ui.isUser)
        assertEquals(5L, ui.id)
    }
}
