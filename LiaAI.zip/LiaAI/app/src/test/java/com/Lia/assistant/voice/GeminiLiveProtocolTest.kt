package com.Lia.assistant.voice

import java.util.Base64
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GeminiLiveProtocolTest {

    private fun setup(tools: List<ToolDeclaration> = LiaToolCatalog.declarations()): JSONObject =
        JSONObject(
            GeminiLiveProtocol.setupMessage(GeminiLiveClient.MODEL, "Aoede", "Be brief.", tools)
        ).getJSONObject("setup")

    private fun parse(raw: String, l: RecordingListener, d: ToolCallDeduplicator = ToolCallDeduplicator()) =
        GeminiLiveProtocol.parse(raw, l, d)

    // ---- constants --------------------------------------------------------------------------

    @Test fun constants() {
        assertEquals("models/gemini-3.1-flash-live-preview", GeminiLiveClient.MODEL)
        assertTrue(GeminiLiveClient.WS_URL.startsWith("wss://generativelanguage.googleapis.com/ws/"))
        assertTrue(GeminiLiveClient.WS_URL.endsWith("BidiGenerateContent?key=<API_KEY>"))
        assertEquals(
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta." +
                "GenerativeService.BidiGenerateContent?key=a%2Bb",
            GeminiLiveClient.buildUrl("a+b")
        )
    }

    @Test fun httpClientTimeouts() {
        val c = GeminiLiveClient.defaultHttpClient()
        assertEquals(0, c.readTimeoutMillis)
        assertEquals(20_000, c.connectTimeoutMillis)
        assertEquals(20_000, c.pingIntervalMillis)
    }

    // ---- setup ------------------------------------------------------------------------------

    @Test fun setupHasRequiredFields() {
        val s = setup()
        assertEquals(GeminiLiveClient.MODEL, s.getString("model"))
        val gen = s.getJSONObject("generationConfig")
        assertEquals("AUDIO", gen.getJSONArray("responseModalities").getString(0))
        assertEquals(
            "Aoede",
            gen.getJSONObject("speechConfig").getJSONObject("voiceConfig")
                .getJSONObject("prebuiltVoiceConfig").getString("voiceName")
        )
        assertEquals(
            "Be brief.",
            s.getJSONObject("systemInstruction").getJSONArray("parts").getJSONObject(0).getString("text")
        )
        assertEquals(0, s.getJSONObject("inputAudioTranscription").length())
        assertEquals(0, s.getJSONObject("outputAudioTranscription").length())
    }

    @Test fun setupDoesNotSetActivityDetection() {
        val s = setup()
        assertFalse(s.has("realtimeInputConfig"))
        assertFalse(s.toString().contains("automaticActivityDetection"))
    }

    @Test fun setupToolsComeFromCatalogWithStringParams() {
        val expected = LiaToolCatalog.declarations()
        val decls = setup().getJSONArray("tools").getJSONObject(0).getJSONArray("functionDeclarations")
        assertEquals(expected.size, decls.length())
        for (i in expected.indices) {
            val d = decls.getJSONObject(i)
            assertEquals(expected[i].name, d.getString("name"))
            if (expected[i].params.isEmpty()) {
                assertFalse(d.has("parameters"))
            } else {
                val params = d.getJSONObject("parameters")
                assertEquals("OBJECT", params.getString("type"))
                val props = params.getJSONObject("properties")
                expected[i].params.forEach { assertEquals("STRING", props.getJSONObject(it.name).getString("type")) }
            }
        }
    }

    @Test fun setupOmitsToolsWhenNoneAndMarksRequired() {
        assertFalse(setup(emptyList()).has("tools"))
        val t = ToolDeclaration("t", "d", listOf(ToolParam("a", "x"), ToolParam("b", "y", required = false)))
        val params = setup(listOf(t)).getJSONArray("tools").getJSONObject(0)
            .getJSONArray("functionDeclarations").getJSONObject(0).getJSONObject("parameters")
        assertEquals(1, params.getJSONArray("required").length())
        assertEquals("a", params.getJSONArray("required").getString(0))
    }

    @Test fun catalogIsWellFormed() {
        val decls = LiaToolCatalog.declarations()
        assertTrue(decls.isNotEmpty())
        assertEquals(decls.size, decls.map { it.name }.toSet().size)
        assertTrue(decls.all { it.name.isNotBlank() && it.description.isNotBlank() })
    }

    // ---- outgoing ---------------------------------------------------------------------------

    @Test fun audioMessageExactShapeAndNoWrap() {
        assertEquals(
            """{"realtimeInput":{"audio":{"mimeType":"audio/pcm;rate=16000","data":"AQID"}}}""",
            GeminiLiveProtocol.audioMessage(byteArrayOf(1, 2, 3))
        )
        val big = GeminiLiveProtocol.audioMessage(ByteArray(4000) { it.toByte() })
        assertFalse(big.contains("\n"))
        val data = JSONObject(big).getJSONObject("realtimeInput").getJSONObject("audio").getString("data")
        assertEquals(4000, Base64.getDecoder().decode(data).size)
    }

    @Test fun toolResponseShape() {
        val fr = JSONObject(GeminiLiveProtocol.toolResponseMessage("c1", "call_contact", """{"ok":true}"""))
            .getJSONObject("toolResponse").getJSONArray("functionResponses").getJSONObject(0)
        assertEquals("c1", fr.getString("id"))
        assertEquals("call_contact", fr.getString("name"))
        assertTrue(fr.getJSONObject("response").getBoolean("ok"))
    }

    @Test fun nonObjectToolResultIsWrapped() {
        val fr = JSONObject(GeminiLiveProtocol.toolResponseMessage("c1", "f", "done, not json"))
            .getJSONObject("toolResponse").getJSONArray("functionResponses").getJSONObject(0)
        assertEquals("done, not json", fr.getJSONObject("response").getString("result"))
    }

    // ---- incoming ---------------------------------------------------------------------------

    @Test fun setupComplete() {
        val l = RecordingListener()
        parse("""{"setupComplete":{}}""", l)
        assertEquals(listOf("setup"), l.events)
    }

    @Test fun audioChunkIsDecodedAndNonAudioIgnored() {
        val l = RecordingListener()
        parse(
            """{"serverContent":{"modelTurn":{"parts":[
                {"inlineData":{"mimeType":"audio/pcm;rate=24000","data":"AQID"}},
                {"inlineData":{"mimeType":"image/png","data":"AQID"}},
                {"text":"hello"}]}}}""", l
        )
        assertEquals(listOf("audio"), l.events)
        assertArrayEquals(byteArrayOf(1, 2, 3), l.audio.single())
    }

    private fun assertArrayEquals(a: ByteArray, b: ByteArray) =
        org.junit.Assert.assertArrayEquals(a, b)

    @Test fun transcriptsKeepSpacing() {
        val l = RecordingListener()
        parse(
            """{"serverContent":{"inputTranscription":{"text":"hi "},"outputTranscription":{"text":" there"}}}""", l
        )
        assertEquals(listOf("in:hi ", "out: there"), l.events)
    }

    @Test fun turnCompleteAndInterrupted() {
        val l = RecordingListener()
        parse("""{"serverContent":{"turnComplete":true}}""", l)
        parse("""{"serverContent":{"interrupted":true}}""", l)
        assertEquals(listOf("turn", "interrupted"), l.events)
    }

    @Test fun interruptedIsDeliveredBeforeAudioAndTurnCompleteLast() {
        val l = RecordingListener()
        parse(
            """{"serverContent":{"turnComplete":true,"interrupted":true,
                "modelTurn":{"parts":[{"inlineData":{"mimeType":"audio/pcm","data":"AQ=="}}]}}}""", l
        )
        assertEquals(listOf("interrupted", "audio", "turn"), l.events)
    }

    @Test fun toolCallIsParsedAndDuplicatesSkipped() {
        val l = RecordingListener()
        val d = ToolCallDeduplicator()
        val msg = """{"toolCall":{"functionCalls":[{"id":"c1","name":"call_contact","args":{"name":"Asha"}}]}}"""
        parse(msg, l, d)
        parse(msg, l, d)
        assertEquals(listOf("tool:c1:call_contact"), l.events)
        assertEquals("Asha", l.toolArgs.single().getString("name"))
    }

    @Test fun multipleCallsInOneMessageAndMissingArgs() {
        val l = RecordingListener()
        parse(
            """{"toolCall":{"functionCalls":[{"id":"a","name":"go_back"},{"id":"b","name":"go_home"},{"id":"a","name":"go_back"}]}}""",
            l
        )
        assertEquals(listOf("tool:a:go_back", "tool:b:go_home"), l.events)
        assertEquals(0, l.toolArgs[0].length())
    }

    @Test fun ignorableAndMalformedMessagesAreSilent() {
        val l = RecordingListener()
        parse("""{"sessionResumptionUpdate":{"newHandle":"x","resumable":true}}""", l)
        parse("""{"goAway":{"timeLeft":"50s"}}""", l)
        parse("""{"usageMetadata":{"totalTokenCount":5}}""", l)
        parse("not json at all {{{", l)
        parse("", l)
        assertTrue(l.events.isEmpty())
    }

    // ---- redaction --------------------------------------------------------------------------

    @Test fun redactionRemovesKey() {
        val key = "AIzaSECRET123"
        val out = GeminiLiveProtocol.redact("failed wss://host/x?key=$key&b=1 using $key", key)
        assertFalse(out.contains(key))
        assertTrue(out.contains("key=***"))
        assertFalse(GeminiLiveProtocol.redact("plain", "").contains("***"))
    }
}
