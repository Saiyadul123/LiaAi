package com.Lia.assistant.voice

import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.Personality
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatPromptBuilderTest {
    @Test fun everyPersonalityAndLanguageBuildsInOrder() {
        for (p in Personality.entries) for (l in LanguagePreference.entries) {
            val out = ChatPromptBuilder.build(p, l, "Lia")
            val idx = listOf("You are Lia,", "This is typed chat", p.systemInstruction, "Language:", "Safety:")
                .map { out.indexOf(it) }
            assertTrue("$p/$l", idx.all { it >= 0 })
            assertEquals(idx, idx.sorted())
            assertEquals(5, out.split("\n\n").size)
        }
    }

    @Test fun typedChatNeverMentionsTappingListeningOrSpeakingToTheUser() {
        val out = ChatPromptBuilder.build(Personality.NORMAL, LanguagePreference.AUTO, "Lia")
        assertTrue(out.contains("Never mention tapping, listening or speaking."))
    }

    @Test fun hasNoToolInstructionsAndNoRecap() {
        val out = ChatPromptBuilder.build(Personality.DEVELOPER, LanguagePreference.ENGLISH, "Lia")
        assertFalse(out.contains("Tools:"))
        assertFalse(out.contains("continuing conversation"))
    }

    @Test fun languagePoliciesAreTypedNotSpoken() {
        assertTrue(ChatPromptBuilder.build(Personality.NORMAL, LanguagePreference.AUTO, "Lia").contains("language the user writes in"))
        assertTrue(ChatPromptBuilder.languagePolicy(LanguagePreference.HINDI).contains("Always reply in Hindi"))
        assertTrue(ChatPromptBuilder.languagePolicy(LanguagePreference.HINGLISH).contains("Always reply in Hinglish"))
        assertTrue(ChatPromptBuilder.languagePolicy(LanguagePreference.ENGLISH).contains("Always reply in English"))
    }

    @Test fun assistantNameIsUsedAndBlankFallsBack() {
        assertTrue(ChatPromptBuilder.build(Personality.NORMAL, LanguagePreference.AUTO, "Mia").startsWith("You are Mia,"))
        assertTrue(ChatPromptBuilder.build(Personality.NORMAL, LanguagePreference.AUTO, "  ").startsWith("You are Lia,"))
    }
}
