package com.Lia.assistant.ui.screens.debug

import com.Lia.assistant.voice.NovaOrbState
import com.Lia.assistant.voice.VoiceLatencyTracker.TurnLatency
import com.Lia.assistant.voice.VoiceLatencyTracker.TurnRecord
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DebugModelTest {
    private fun turn(n: Int, first: Long?, audio: Long?, total: Long?) = TurnRecord(n, TurnLatency(first, audio, total))

    @Test fun connectionStateFollowsTheSession() {
        val s = DebugModel::connectionState
        assertEquals(ConnectionState.DISCONNECTED, s(false, NovaOrbState.IDLE, 0, null, null))
        assertEquals(ConnectionState.ERROR, s(false, NovaOrbState.IDLE, 0, null, "Connection lost"))
        assertEquals(ConnectionState.CONNECTING, s(true, NovaOrbState.CONNECTING, 0, null, null))
        assertEquals(ConnectionState.RECONNECTING, s(true, NovaOrbState.CONNECTING, 2, null, null))
        assertEquals(ConnectionState.CONNECTING, s(true, NovaOrbState.CONNECTING, 2, 300L, null)) // first connect of a fresh link
        assertEquals(ConnectionState.ERROR, s(true, NovaOrbState.ERROR, 0, 300L, "x"))
        listOf(NovaOrbState.IDLE, NovaOrbState.LISTENING, NovaOrbState.THINKING, NovaOrbState.SPEAKING).forEach {
            assertEquals(it.name, ConnectionState.CONNECTED, s(true, it, 0, 250L, null))
        }
    }

    @Test fun micStateOrderOfPrecedence() {
        assertEquals(MicState.OFF, DebugModel.micState(false, true, true))
        assertEquals(MicState.MUTED_BY_USER, DebugModel.micState(true, true, true))
        assertEquals(MicState.PAUSED_ECHO_GUARD, DebugModel.micState(true, false, true))
        assertEquals(MicState.LIVE, DebugModel.micState(true, false, false))
    }

    @Test fun millisecondsAreFormattedForPeople() {
        assertEquals("n/a", DebugModel.formatMs(null))
        assertEquals("0 ms", DebugModel.formatMs(0))
        assertEquals("999 ms", DebugModel.formatMs(999))
        assertEquals("1.0 s", DebugModel.formatMs(1000))
        assertEquals("1.3 s", DebugModel.formatMs(1349))
        assertEquals("12.5 s", DebugModel.formatMs(12_500))
    }

    @Test fun rowsAreNewestFirstAndCapped() {
        val history = (1..12).map { turn(it, it * 100L, 2000L, 2000L + it) }
        val rows = DebugModel.rows(history)
        assertEquals(8, rows.size)
        assertEquals(12, rows.first().number)
        assertEquals(5, rows.last().number)
        assertEquals(TurnRow(12, "1.2 s", "2.0 s", "2.0 s"), rows.first())
        assertEquals(3, DebugModel.rows(history, max = 3).size)
        assertEquals(emptyList<TurnRow>(), DebugModel.rows(emptyList()))
    }

    @Test fun missingMarksShowAsNotAvailable() {
        assertEquals(TurnRow(1, "n/a", "n/a", "n/a"), DebugModel.rows(listOf(turn(1, null, null, null))).single())
    }

    @Test fun theSummaryIgnoresTurnsWithoutAFirstAudio() {
        val s = DebugModel.summary(listOf(turn(1, 400, 1, 1), turn(2, null, 1, 1), turn(3, 700, 1, 1)))
        assertEquals(LatencySummary(turns = 3, averageFirstAudioMs = 550, worstFirstAudioMs = 700), s)
        val none = DebugModel.summary(emptyList())
        assertEquals(0, none.turns)
        assertNull(none.averageFirstAudioMs)
        assertNull(none.worstFirstAudioMs)
    }
}
