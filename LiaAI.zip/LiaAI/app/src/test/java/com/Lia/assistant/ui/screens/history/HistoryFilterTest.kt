package com.Lia.assistant.ui.screens.history

import com.Lia.assistant.data.StoredConversation
import com.Lia.assistant.data.StoredTurn
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoryFilterTest {
    private val trip = StoredConversation("1", "Trip to Goa", 3, listOf(StoredTurn(true, "Plan a beach holiday"), StoredTurn(false, "Sure! Start with Palolem.")))
    private val code = StoredConversation("2", "Kotlin help", 2, listOf(StoredTurn(true, "What is a coroutine?")))
    private val all = listOf(trip, code)

    @Test fun blankQueryKeepsEverything() {
        assertSame(all, filterConversations(all, ""))
        assertSame(all, filterConversations(all, "   "))
    }

    @Test fun matchesTheTitleIgnoringCase() {
        assertEquals(listOf(trip), filterConversations(all, "goa"))
    }

    @Test fun matchesAnyMessageText() {
        assertEquals(listOf(code), filterConversations(all, "COROUTINE"))
        assertEquals(listOf(trip), filterConversations(all, "palolem"))
    }

    @Test fun noMatchGivesAnEmptyList() {
        assertTrue(filterConversations(all, "zzz").isEmpty())
    }

    @Test fun queryIsTrimmed() {
        assertEquals(listOf(code), filterConversations(all, "  kotlin "))
    }
}
