package com.Lia.assistant.ui.screens.quickactions

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class QuickActionsTest {
    private val message = QuickActions.common().first { it.id == "message" }

    @Test fun commonTilesAreTheThreeRealTools() {
        assertEquals(listOf("open_app", "call_contact", "message_contact"), QuickActions.common().map { it.tool })
    }

    @Test fun everyTileHasAnIdTitleAndUniqueId() {
        val all = QuickActions.all()
        assertEquals(all.size, all.map { it.id }.toSet().size)
        assertTrue(all.all { it.title.isNotBlank() && it.subtitle.isNotBlank() && it.tool.isNotBlank() })
        assertTrue(all.containsAll(QuickActions.common()))
    }

    @Test fun messageOffersSmsOrWhatsApp() {
        val app = message.params.first { it.key == "app" }
        assertEquals(listOf("sms", "whatsapp"), app.options)
    }

    @Test fun missingRequiredInputIsFoundInOrder() {
        assertEquals("contact", QuickActions.firstMissing(message, emptyMap())?.key)
        assertEquals("message", QuickActions.firstMissing(message, mapOf("contact" to "Asha"))?.key)
        assertEquals("message", QuickActions.firstMissing(message, mapOf("contact" to "Asha", "message" to "   "))?.key)
        assertNull(QuickActions.firstMissing(message, mapOf("contact" to "Asha", "message" to "hi")))
    }

    @Test fun anActionWithoutInputsCanAlwaysRun() {
        val none = QuickActionSpec("x", "t", "s", message.icon, "go_home")
        assertNull(QuickActions.firstMissing(none, emptyMap()))
    }

    @Test fun argsAreTrimmedAndPickersDefaultToTheirFirstOption() {
        val args = QuickActions.argsFor(message, mapOf("contact" to "  Asha ", "message" to "running late"))
        assertEquals("Asha", args.getString("contact"))
        assertEquals("running late", args.getString("message"))
        assertEquals("sms", args.getString("app"))
        val wa = QuickActions.argsFor(message, mapOf("contact" to "1", "message" to "m", "app" to "whatsapp"))
        assertEquals("whatsapp", wa.getString("app"))
    }

    @Test fun blankOptionalValuesAreLeftOut() {
        val open = QuickActions.common().first { it.id == "open_app" }
        assertFalse(QuickActions.argsFor(open, emptyMap()).has("app_name"))
    }

    // ---- result sentences ---------------------------------------------------------------------

    private fun describe(json: String) = QuickActionResults.describe(JSONObject(json))

    @Test fun errorsWinOverResults() {
        assertEquals("Missing parameter: contact", describe("""{"error":"Missing parameter: contact","result":"opened"}"""))
    }

    @Test fun knownResultsReadNaturally() {
        assertEquals("Opened youtube.", describe("""{"result":"opened","app":"youtube"}"""))
        assertEquals("Calling Asha.", describe("""{"result":"calling","contact":"Asha"}"""))
        assertEquals("The message is ready: tap Send.", describe("""{"result":"composer_opened"}"""))
        assertEquals("Message sent.", describe("""{"result":"sent"}"""))
        assertEquals("I couldn't find that app.", describe("""{"result":"app_not_found"}"""))
        assertEquals("Allow contacts access in Permissions first.", describe("""{"result":"no_contacts_permission"}"""))
        assertEquals("Turn on screen control first.", describe("""{"result":"accessibility_not_enabled"}"""))
        assertEquals("Done.", describe("""{"result":"done"}"""))
    }

    @Test fun readScreenShowsTheScreenText() {
        assertEquals("[button] Send", describe("""{"result":"ok","screen":"[button] Send"}"""))
        assertEquals("The screen has nothing to read.", describe("""{"result":"empty","screen":""}"""))
    }

    @Test fun unknownResultsAreHumanised() {
        assertEquals("Some new thing.", describe("""{"result":"some_new_thing"}"""))
        assertEquals("No result.", describe("{}"))
    }
}
