package com.Lia.assistant.forge

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ForgeControllerTest {
    @Before fun setUp() = ForgeController.resetForTest()
    @After fun tearDown() = ForgeController.resetForTest()

    @Test fun nothingPendingAtFirst() {
        assertFalse(ForgeController.pendingOpen.value)
        assertFalse(ForgeController.consume())
    }

    @Test fun aRequestIsConsumedExactlyOnce() {
        ForgeController.requestOpen()
        assertTrue(ForgeController.pendingOpen.value)
        assertTrue(ForgeController.consume())
        assertFalse(ForgeController.pendingOpen.value)
        assertFalse(ForgeController.consume())
    }

    @Test fun repeatedRequestsCollapseIntoOne() {
        ForgeController.requestOpen()
        ForgeController.requestOpen()
        assertTrue(ForgeController.consume())
        assertFalse(ForgeController.consume())
    }

    @Test fun theBriefIsKeptTrimmedAndBlankDoesNotEraseIt() {
        ForgeController.requestOpen("  a site for my bakery ")
        assertEquals("a site for my bakery", ForgeController.brief.value)
        ForgeController.requestOpen("   ")
        ForgeController.requestOpen(null)
        assertEquals("a site for my bakery", ForgeController.brief.value)
    }

    @Test fun briefStartsEmptyAndExtraKeyIsStable() {
        assertNull(ForgeController.brief.value)
        assertEquals("com.Lia.assistant.extra.OPEN_FORGE", ForgeController.EXTRA_OPEN_FORGE)
    }

    @Test fun setBriefSavesTheRequestWithoutOpeningAnything() {
        ForgeController.setBrief("  a site for my gym ")
        assertEquals("a site for my gym", ForgeController.brief.value)
        assertFalse(ForgeController.pendingOpen.value)
        assertFalse(ForgeController.consume())
    }

    @Test fun progressStartsIdleAndFollowsUpdates() {
        assertFalse(ForgeController.progress.value.isRunning)
        ForgeController.updateProgress(ForgeProgress(stage = 1, percent = 30))
        assertTrue(ForgeController.progress.value.isRunning)
        assertEquals(30, ForgeController.progress.value.percent)
    }

    @Test fun cancelForgetsEverything() {
        ForgeController.requestOpen("a site")
        ForgeController.updateProgress(ForgeProgress(stage = 2, percent = 50))
        ForgeController.cancel()
        assertFalse(ForgeController.pendingOpen.value)
        assertNull(ForgeController.brief.value)
        assertFalse(ForgeController.progress.value.isRunning)
    }
}
