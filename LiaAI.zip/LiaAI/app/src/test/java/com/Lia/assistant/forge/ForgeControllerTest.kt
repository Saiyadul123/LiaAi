package com.Lia.assistant.forge

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ForgeControllerTest {
    @Before fun setUp() = ForgeController.resetForTest()
    @After fun tearDown() = ForgeController.resetForTest()

    @Test fun nothingPendingAtFirst() {
        assertFalse(ForgeController.pendingOpen.value)
        assertFalse(ForgeController.consume())
    }

    @Test fun aRequestIsConsumedExactlyOnce() {
        ForgeController.requestOpen()
        assertTrue(ForgeController.pendingOpen.value)
        assertTrue(ForgeController.consume())
        assertFalse(ForgeController.pendingOpen.value)
        assertFalse(ForgeController.consume())
    }

    @Test fun repeatedRequestsCollapseIntoOne() {
        ForgeController.requestOpen()
        ForgeController.requestOpen()
        assertTrue(ForgeController.consume())
        assertFalse(ForgeController.consume())
    }

    @Test fun theBriefIsKeptTrimmedAndBlankDoesNotEraseIt() {
        ForgeController.requestOpen("  a site for my bakery ")
        assertEquals("a site for my bakery", ForgeController.brief.value)
        ForgeController.requestOpen("   ")
        ForgeController.requestOpen(null)
        assertEquals("a site for my bakery", ForgeController.brief.value)
    }

    @Test fun briefStartsEmptyAndExtraKeyIsStable() {
        assertNull(ForgeController.brief.value)
        assertEquals("com.Lia.assistant.extra.OPEN_FORGE", ForgeController.EXTRA_OPEN_FORGE)
    }
}
