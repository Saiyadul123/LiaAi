package com.Lia.assistant.forge

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ForgeHtmlTest {
    private val page = "<!DOCTYPE html>\n<html><head><title>x</title></head><body><p>hi</p></body></html>"

    // ---- fences ----
    @Test fun aFencedPageIsUnwrapped() {
        assertEquals(page, ForgeHtml.stripFences("```html\n$page\n```"))
        assertEquals(page, ForgeHtml.stripFences("```\n$page\n```"))
        assertEquals(page, ForgeHtml.stripFences("  ```HTML\r\n$page\r\n```  "))
    }

    @Test fun anUnfencedPageIsLeftAlone() {
        assertEquals(page, ForgeHtml.stripFences(page))
        assertEquals(page, ForgeHtml.stripFences("\n\n$page\n"))
    }

    @Test fun chatterAroundTheFenceIsDropped() {
        assertEquals(page, ForgeHtml.stripFences("Here is your site:\n```html\n$page\n```\nEnjoy!"))
    }

    @Test fun markupBeforeALaterFenceIsNeverCut() {
        val withFenceInside = "<!DOCTYPE html><html><body><pre>```</pre></body></html>"
        assertEquals(withFenceInside, ForgeHtml.stripFences(withFenceInside))
    }

    @Test fun aStrayClosingFenceAtTheEndIsDropped() {
        assertEquals(page, ForgeHtml.stripFences("$page\n```"))
    }

    @Test fun aFencedAnswerLosesOnlyTheChatterAfterItsLastFence() {
        val inner = "<!DOCTYPE html><html><body><pre>x</pre></body></html>"
        assertEquals(inner, ForgeHtml.stripFences("```html\n$inner\n```\nHope you like it"))
    }

    @Test fun aFenceThatHasNotFinishedStreamingGivesNothingYet() {
        assertEquals("", ForgeHtml.stripFences("```"))
        assertEquals("", ForgeHtml.stripFences("```html"))
        assertEquals("<!DOCTYPE", ForgeHtml.stripFences("```html\n<!DOCTYPE"))
    }

    // ---- looksLikeHtml ----
    @Test fun aRealPageLooksLikeHtml() {
        assertTrue(ForgeHtml.looksLikeHtml(page))
        assertTrue(ForgeHtml.looksLikeHtml("```html\n$page\n```"))
        assertTrue(ForgeHtml.looksLikeHtml("<html><BODY>x"))
        assertTrue(ForgeHtml.looksLikeHtml("<!doctype HTML><body>"))
    }

    @Test fun otherTextDoesNot() {
        assertFalse(ForgeHtml.looksLikeHtml(""))
        assertFalse(ForgeHtml.looksLikeHtml("Sorry, I cannot help with that."))
        assertFalse(ForgeHtml.looksLikeHtml("<div>just a fragment</div>"))
        assertFalse(ForgeHtml.looksLikeHtml("<!DOCTYPE html><html><head></head>")) // no body yet
    }

    // ---- repair ----
    @Test fun aCompletePageIsNotChanged() {
        assertEquals(page, ForgeHtml.repairTruncated(page))
    }

    @Test fun missingClosingTagsAreAdded() {
        val r = ForgeHtml.repairTruncated("<!DOCTYPE html><html><head></head><body><p>hello</p>")
        assertTrue(r.endsWith("</body>\n</html>"))
        assertEquals(1, Regex("</body>").findAll(r).count())
    }

    @Test fun aTagCutInHalfIsRemoved() {
        val r = ForgeHtml.repairTruncated("<html><body><p>hi</p><div class=\"flex ite")
        assertFalse(r.contains("flex ite"))
        assertTrue(r.contains("<p>hi</p>"))
    }

    @Test fun anOpenScriptIsClosedBeforeTheBody() {
        val r = ForgeHtml.repairTruncated("<html><body><p>x</p><script>const a = 1;\nfunction f(){")
        val script = r.indexOf("</script>")
        assertTrue(script > 0 && script < r.indexOf("</body>"))
    }

    @Test fun anOpenStyleIsClosed() {
        val r = ForgeHtml.repairTruncated("<html><body><style>.a{color:red}.b{")
        assertTrue(r.indexOf("</style>") in 1 until r.indexOf("</body>"))
    }

    @Test fun aScriptThatWasClosedIsNotClosedAgain() {
        val r = ForgeHtml.repairTruncated("<html><body><script>a()</script><p>x")
        assertEquals(1, Regex("</script>").findAll(r).count())
    }

    @Test fun repairingTwiceChangesNothingMore() {
        val once = ForgeHtml.repairTruncated("<html><body><div><script>x(")
        assertEquals(once, ForgeHtml.repairTruncated(once))
    }

    // ---- safety net ----
    @Test fun theSafetyNetIsAddedBeforeTheClosingBody() {
        val r = ForgeHtml.withSafetyNet(page)
        assertTrue(r.contains("id=\"lia-safety-net\""))
        assertTrue(r.indexOf("lia-safety-net") < r.indexOf("</body>"))
    }

    @Test fun theSafetyNetIsIdempotent() {
        val once = ForgeHtml.withSafetyNet(page)
        assertEquals(once, ForgeHtml.withSafetyNet(once))
        assertEquals(1, Regex("id=\"lia-safety-net\"").findAll(ForgeHtml.withSafetyNet(once)).count())
    }

    @Test fun aPageWithoutABodyEndGetsTheNetAtTheEnd() {
        assertTrue(ForgeHtml.withSafetyNet("<html><body><p>x").endsWith("</script>"))
    }

    @Test fun theSafetyNetKeepsToItsRules() {
        val r = ForgeHtml.withSafetyNet(page)
        assertTrue(r.contains("1400"))
        assertTrue(r.contains("aria-hidden"))
        assertTrue(r.contains("pointerEvents"))
        assertTrue(r.contains("'fixed'"))
        assertTrue(r.contains("CANVAS"))
        assertTrue(r.contains("innerHeight")) // only things inside the viewport
    }
}
