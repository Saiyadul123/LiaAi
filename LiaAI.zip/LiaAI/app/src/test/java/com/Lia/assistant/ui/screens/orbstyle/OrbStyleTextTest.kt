package com.Lia.assistant.ui.screens.orbstyle

import com.Lia.assistant.ui.components.NovaOrbStyle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OrbStyleTextTest {
    @Test fun everyStyleHasATitleAndABlurb() {
        NovaOrbStyle.entries.forEach {
            assertTrue(orbStyleTitle(it).isNotBlank())
            assertTrue(orbStyleBlurb(it).isNotBlank())
        }
        assertEquals("Nova", orbStyleTitle(NovaOrbStyle.NOVA))
        assertEquals("Archer", orbStyleTitle(NovaOrbStyle.ARCHER))
        val blurbs = NovaOrbStyle.entries.map { orbStyleBlurb(it) }
        assertEquals(blurbs.size, blurbs.toSet().size)
    }
}
