package com.Lia.assistant.ui.fx

import android.content.Context
import android.content.Intent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * PLAY flavor: no system overlay windows (Play policy), so everything here is a no-op.
 * The same object, with the same signatures, exists in src/direct.
 */
object OverlayEdgeGlowController {
    private val _showing = MutableStateFlow(false)
    val showing: StateFlow<Boolean> = _showing.asStateFlow()

    fun canDraw(context: Context): Boolean = false
    fun permissionIntent(context: Context): Intent? = null
    fun start(context: Context) = Unit
    fun stop() = Unit
}
