package com.Lia.assistant.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import com.Lia.assistant.data.NovaAppState

/** PLAY flavor: there is no accessibility service, so there is no disclosure screen to register. */
@Suppress("UNUSED_PARAMETER")
fun NavGraphBuilder.registerAccessibilityDisclosureRoute(navController: NavHostController, appState: NovaAppState) = Unit
