package com.Lia.assistant.ui.screens.permissions

import androidx.compose.runtime.Composable

/** PLAY flavor: no extra permissions beyond the common ones. */
@Suppress("UNUSED_PARAMETER")
@Composable
fun FlavorPermissionRows(refreshKey: Int, assistantName: String, onOpenDisclosure: () -> Unit) = Unit
