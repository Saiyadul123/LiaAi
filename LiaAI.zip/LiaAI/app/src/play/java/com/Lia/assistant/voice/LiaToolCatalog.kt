package com.Lia.assistant.voice

/** PLAY flavor: no screen control, only contact lookup and calling. Same object exists in src/direct. */
object LiaToolCatalog {
    fun declarations(): List<ToolDeclaration> = listOf(
        ToolDeclaration(
            "call_contact", "Place a phone call to a saved contact by name.",
            listOf(ToolParam("name", "Contact name to call"))
        ),
        ToolDeclaration(
            "find_contact", "Look up a saved contact's name and number by name.",
            listOf(ToolParam("name", "Contact name to search for"))
        ),
    )
}
