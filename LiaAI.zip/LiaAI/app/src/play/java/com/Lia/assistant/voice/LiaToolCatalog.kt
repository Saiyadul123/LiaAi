package com.Lia.assistant.voice

/** PLAY flavor: exactly three tools. The same object exists in src/direct with more. */
object LiaToolCatalog {
    fun declarations(): List<ToolDeclaration> = listOf(
        functionDecl(
            "open_app", "Open an installed app by its name.",
            mapOf("app_name" to "Name of the app, for example YouTube"),
            listOf("app_name"),
        ),
        functionDecl(
            "call_contact", "Call a saved contact by name, or a phone number.",
            mapOf("contact" to "Contact name or phone number"),
            listOf("contact"),
        ),
        functionDecl(
            "message_contact",
            "Open a message composer (SMS or WhatsApp) with the text filled in. The user taps Send.",
            mapOf(
                "contact" to "Contact name or phone number",
                "message" to "Text of the message",
                "app" to "sms or whatsapp (default sms)",
            ),
            listOf("contact", "message"),
        ),
    )
}
