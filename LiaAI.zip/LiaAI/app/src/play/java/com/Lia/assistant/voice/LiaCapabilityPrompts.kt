package com.Lia.assistant.voice

/** PLAY flavor stub. The same object exists in src/direct with full screen-control capabilities. */
object LiaCapabilityPrompts {
    fun toolInstruction(assistantName: String): String =
        "Tools: As $assistantName you can use the provided tools to look up a contact and place a " +
            "phone call when the user asks. You cannot operate other apps, read the screen, send " +
            "messages or read notifications on this version; if asked, say so plainly and offer " +
            "what you can do instead. If several contacts match, confirm which one before calling, " +
            "and never claim a call was placed unless the tool result confirms it."
}
