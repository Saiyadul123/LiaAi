package com.Lia.assistant.voice

/** PLAY flavor. The same object exists in src/direct with the full capability description. */
object LiaCapabilityPrompts {
    fun toolInstruction(assistantName: String): String =
        "Tools: As $assistantName you can use the provided tools to open an app, call a saved contact " +
            "or a phone number, and open a message composer (SMS or WhatsApp) with the text filled in. " +
            "You never send anything yourself: the user taps Send, so say the composer is open rather " +
            "than that the message was sent. You cannot read or control the screen, you cannot tap or " +
            "type in other apps, and you cannot post to social apps. If asked for any of that, say so " +
            "plainly and offer what you can do instead. Before message_contact, confirm the recipient " +
            "and the text. Never claim an action succeeded unless the tool result confirms it."
}
