package com.Lia.assistant.action

import android.content.Context
import kotlinx.coroutines.CancellationException
import org.json.JSONObject

/**
 * PLAY flavor: open_app, call_contact and message_contact only. No screen access, and messages are
 * only opened in a composer for the user to send. The same object exists in src/direct.
 */
object ActionExecutor {
    suspend fun execute(context: Context, name: String, args: JSONObject): JSONObject = try {
        when (name) {
            "open_app" -> PhoneActions.openApp(context, args)
            "call_contact" -> PhoneActions.callContact(context, args)
            "message_contact" -> when (val c = PhoneActions.openComposer(context, args)) {
                is PhoneActions.Composer.Failed -> c.json
                is PhoneActions.Composer.Opened -> PhoneActions.composerOpenedJson(c)
            }
            else -> PhoneActions.unknownTool(name)
        }
    } catch (e: CancellationException) {
        throw e
    } catch (_: Exception) {
        PhoneActions.error("Tool failed: $name")
    }
}
