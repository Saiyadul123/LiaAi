package com.Lia.assistant

/** Same object exists in src/direct; this is the Play-policy-safe stub. */
object FlavorRoutes {
    const val screenControlAvailable = false
    const val flavorLabel = "Play build"
}
