package com.Lia.assistant

import com.Lia.assistant.ui.screens.quickactions.QuickActionSpec

/** Same object exists in src/direct; this is the Play-policy-safe stub. */
object FlavorRoutes {
    const val screenControlAvailable = false
    const val flavorLabel = "Play build"

    /** No flavor-only tools on Play. */
    fun extraQuickActions(): List<QuickActionSpec> = emptyList()
}
