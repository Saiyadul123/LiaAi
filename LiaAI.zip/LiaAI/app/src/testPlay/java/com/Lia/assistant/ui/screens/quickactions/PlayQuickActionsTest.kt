package com.Lia.assistant.ui.screens.quickactions

import org.junit.Assert.assertEquals
import org.junit.Test

class PlayQuickActionsTest {
    @Test fun playHasOnlyTheCommonTiles() {
        assertEquals(QuickActions.common(), QuickActions.all())
    }
}
