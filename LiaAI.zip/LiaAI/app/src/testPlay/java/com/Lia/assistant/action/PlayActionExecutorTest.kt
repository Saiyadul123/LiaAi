package com.Lia.assistant.action

import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PlayActionExecutorTest {
    private fun exec(ctx: FakeContext, name: String, vararg kv: Pair<String, String>) = runBlocking {
        ActionExecutor.execute(ctx, name, JSONObject().also { o -> kv.forEach { o.put(it.first, it.second) } })
    }

    @Test fun unknownToolReturnsError() {
        assertEquals("Unknown tool: bogus", exec(FakeContext(), "bogus").getString("error"))
    }

    @Test fun screenToolsDoNotExistInPlay() {
        listOf("read_screen", "tap_text", "type_text", "scroll_screen", "go_back", "go_home").forEach {
            assertEquals("Unknown tool: $it", exec(FakeContext(), it).getString("error"))
        }
    }

    @Test fun messageOpensComposerAndNeverClaimsSent() {
        val ctx = FakeContext()
        val r = exec(ctx, "message_contact", "contact" to "98765 43210", "message" to "hi")
        assertEquals("composer_opened", r.getString("result"))
        assertEquals(1, ctx.started.size)
    }

    @Test fun callByNumberFallsBackToDialer() {
        val r = exec(FakeContext(), "call_contact", "contact" to "98765 43210")
        assertEquals("dialer_opened_no_permission", r.getString("result"))
    }

    @Test fun missingArgumentsAreReported() {
        assertTrue(exec(FakeContext(), "open_app").getString("error").startsWith("Missing parameter"))
    }
}
