package com.Lia.assistant.voice

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LiaCapabilityPromptsPlayTest {
    @Test fun playStatesItsLimitsPlainly() {
        val s = LiaCapabilityPrompts.toolInstruction("Lia")
        assertTrue(s.contains("cannot read or control the screen"))
        assertTrue(s.contains("cannot post to social apps"))
        assertTrue(s.contains("the user taps Send"))
        assertFalse(s.contains("operate the screen"))
    }
}
