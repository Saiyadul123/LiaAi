package com.Lia.assistant.voice

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LiaCapabilityPromptsPlayTest {
    @Test fun playDoesNotAdvertiseScreenControl() {
        val s = LiaCapabilityPrompts.toolInstruction("Lia")
        assertFalse(s.contains("operate the screen"))
        assertFalse(s.contains("tap, type, scroll"))
        assertTrue(s.contains("cannot operate other apps"))
    }
}
