package com.Lia.assistant.voice

import org.junit.Assert.assertEquals
import org.junit.Test

class LiaToolCatalogPlayTest {
    @Test fun playListsExactlyThreeTools() {
        assertEquals(
            listOf("open_app", "call_contact", "message_contact"),
            LiaToolCatalog.declarations().map { it.name }
        )
    }
}
