package com.Lia.assistant.voice

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LiaToolCatalogPlayTest {
    @Test fun playHasNoScreenControlTools() {
        val names = LiaToolCatalog.declarations().map { it.name }
        assertTrue(names.contains("call_contact"))
        listOf("read_screen", "tap", "type_text", "scroll", "open_app").forEach {
            assertFalse(it, names.contains(it))
        }
    }
}
