# Lia AI release rules (R8). Keep this file small: add a rule only for a crash you have seen in a release build.

# ---- general -------------------------------------------------------------------------------
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# ---- org.json -------------------------------------------------------------------------------
# It is part of the Android framework (the voice protocol, tool calls and chat history all use it).
# Never let R8 rename or strip it, and ignore references to a desktop copy used by unit tests.
-keep class org.json.** { *; }
-dontwarn org.json.**

# ---- Compose --------------------------------------------------------------------------------
# Compose ships its own consumer rules; these only cover what they read from annotations and tooling.
-keepattributes RuntimeVisibleAnnotations,RuntimeVisibleParameterAnnotations,AnnotationDefault
-dontwarn androidx.compose.ui.tooling.**

# ---- Enums stored or parsed by name (Personality, LanguagePreference, ThemeMode, ...) ---------------
-keepclassmembers enum com.Lia.assistant.** {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ---- WebView bridges (the Website Forge's scene talks to Kotlin through @JavascriptInterface) ---
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# ---- OkHttp (WebSocket and SSE) ---------------------------------------------------------------
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
