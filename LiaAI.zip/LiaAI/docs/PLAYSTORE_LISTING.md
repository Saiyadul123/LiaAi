# Lia AI: Google Play listing and submission guide

Everything here describes the **play** flavor (`com.Lia.assistant`, `app-play-release.aab`). The **direct**
flavor (screen control, Instagram/Facebook/WhatsApp agent, overlay) is **not** for Google Play.

Items marked **VERIFY** are answers I could not confirm from the code alone. Check them against the
current Play policy text before you submit. This file is guidance, not legal advice. No secrets belong in this
repository: the keystore, its passwords and any API key stay outside it (`keystore.properties` and `*.jks`
are git-ignored).

---

## 1. What to upload

| | |
|---|---|
| Artifact | **Android App Bundle (AAB)**, play flavor, release build |
| Build | `./gradlew bundlePlayRelease` |
| Output | `app/build/outputs/bundle/playRelease/app-play-release.aab` |
| Signing | Upload key from `keystore.properties` (see `keystore.properties.example`). Enrol in **Play App Signing**. |
| Version | `-PliaVersionCode=<n> -PliaVersionName=<x.y.z>` (versionCode must go up with every upload; default is 1 / 0.1.0) |
| Target | targetSdk 36, minSdk 26, no native libraries |

Do not upload an APK, and do not upload the `direct` flavor.

---

## 2. Listing copy

**App name** (30 max): `Lia AI: Voice Assistant` (23)

**Short description** (80 max): `Talk to Lia, a voice AI that opens apps, makes calls and drafts messages.` (73)

**Full description** (4000 max):

> Lia is a voice assistant you can simply talk to. Tap the orb, speak the way you normally do (English, Hindi
> or Hinglish) and Lia answers out loud, in real time.
>
> WHAT LIA CAN DO
> • Have a natural spoken conversation, or type if you prefer
> • Open an app on your phone ("open Maps")
> • Call a contact or a phone number ("call Mum")
> • Open a text or WhatsApp message with the words already filled in. You always tap Send yourself
> • Switch between ten personalities: Normal, Friendly, Professional, Funny, Companion, GF Mode, Teacher,
>   Developer, Hungry and Nautanki
> • Choose how Lia looks: seven orb styles and light, dark or system themes
>
> YOU STAY IN CONTROL
> • Lia only listens while a voice session is on, and shows a notification while it does
> • Lia never sends a message by itself: it opens the composer and you decide
> • Your chat history is stored on your phone and you can delete it
>
> BRING YOUR OWN KEY
> Lia runs on Google's Gemini and uses **your own Gemini API key**, which you enter once in Settings. You can get
> one from Google AI Studio. Use of the Gemini service is subject to Google's terms.
>
> Lia is an AI. It can be wrong, so check anything important. It is not a substitute for professional advice.

**Reviewer note (put in Play Console, "App access")**: the app needs a Gemini API key to talk. Provide a
**temporary** key in the Console's access instructions only (never in the repository or the listing), and revoke it
after review.

**Graphics to prepare**: 512×512 icon, 1024×500 feature graphic, 2–8 phone screenshots (Home, Voice, Chat,
Personality, Settings). Do not use real contact names or a visible API key in screenshots.

---

## 3. Data safety form (recommended answers)

How the app handles data, from the code:

* Voice audio is streamed to **Google's Gemini Live API** (WebSocket) with the user's own key while a session
  runs. Typed chat messages go to the Gemini API over HTTPS.
* There is **no Lia server**: nothing is sent to the developer.
* Contacts are read **on the device** to turn a spoken name into a number. The contact list is never uploaded. The
  name of the contact Lia acted on (for example "calling Priya") is returned to Gemini as part of the conversation.
* The API key, settings and chat history are kept in the app's private storage. Backups are off
  (`allowBackup=false`). The API key is stored in app-private preferences and is **not** additionally encrypted by
  the app. **VERIFY** whether you want to move it to the Android Keystore before launch.
* No ads, no analytics, no crash-reporting SDK, no advertising ID.

| Question | Answer |
|---|---|
| Does the app collect or share user data? | **Yes** (audio and messages go to Google's Gemini service) |
| Audio files / voice or sound recordings | Collected: **yes**. Shared with a third party (Google, Gemini): **yes**. Purpose: **App functionality**. Optional: no (it is the core feature). |
| Other in-app messages (typed chats) | Collected: **yes**. Shared (Google, Gemini): **yes**. Purpose: **App functionality**. |
| Contacts | Name of a contact the user asked Lia to call or message is passed into the conversation: **declare as collected and shared (Google, Gemini), App functionality**. **VERIFY** wording against Play's definitions. |
| Location, financial, health, photos/videos, files, calendar, SMS, call log, device IDs | **Not collected** |
| App activity, web browsing | **Not collected** |
| Data encrypted in transit | **Yes** (TLS: `wss://` and `https://`) |
| Can users request deletion? | Chats can be deleted inside the app and everything is removed on uninstall. There is no developer server holding data. Answer per the form's wording: **VERIFY**. |
| Independent security review | No |
| Families / child-directed | **No.** Target audience 13+ (see the content-rating note below) |

Add a **privacy policy URL** (required because the app reads contacts and uses the microphone). It must say, in
plain words, what the table above says and name Google's Gemini as the recipient. **I have not written the policy or
chosen a URL: you must host one before submitting.**

---

## 4. Permission justifications

Use these in the Play Console permission and foreground-service declarations.

| Permission | Why the app needs it | User control |
|---|---|---|
| `RECORD_AUDIO` | Hears the user speak so Lia can answer in a voice conversation. Used only while a voice session is on. | Asked on the Voice screen the first time the user starts a session (an "Allow microphone" button). Mute and Stop buttons are always on screen. |
| `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_MICROPHONE` (service type `microphone`) | Keeps an active voice conversation alive when the screen turns off or the user switches app, with an ongoing notification that says the microphone is in use. | Starts only after the user starts a session and stops when they press Stop. **Console form:** you must complete the foreground-service declaration for `microphone`, usually with a short screen recording of starting and stopping a session. |
| `READ_CONTACTS` | Turns a name the user says ("call Priya") into a phone number, on the device, so the call or message goes to the right person. | Asked the first time the user uses a contact command. Without it Lia still works for everything else. The contact list is not uploaded. |
| `CALL_PHONE` | Places the call when the user explicitly asks to call someone. | Asked the first time. If refused, Lia opens the dialer with the number filled in instead. |
| `POST_NOTIFICATIONS` | Shows the "voice session is on" notification required for the foreground service (Android 13+). | The user can decline: the session still runs, but may not show the notification. **VERIFY** this behaviour on a device. |
| `INTERNET` | Talks to Google's Gemini service. | n/a |

Package visibility: the app declares `<queries>` for launcher, SMS and dial intents to find the app the user asked
to open. It does **not** use `QUERY_ALL_PACKAGES`.

Not in the play flavor (and so nothing to declare): AccessibilityService, notification listener, display-over-other-apps,
SMS or call-log permissions.

---

## 5. Policy points to check before you submit

* **AI-generated content.** Play's policy for apps that generate content with AI expects users to be able to report
  or flag offensive output from inside the app. **The app does not have this today: add it before submitting. VERIFY.**
* **Content rating (IARC questionnaire).** Answer honestly about generated content and the "Companion" and "GF Mode"
  personalities. They carry hard rules (no claims to be human, no sexually explicit content), but rating answers
  are yours to make.
* **Target audience.** Choose 13+ or higher. Do not select children.
* **Misleading claims.** Do not describe Lia as a person or as medical, legal or financial advice.
* **Ads:** none. Say "No" to "contains ads".

---

## 6. Submission checklist

**Before building**
- [ ] `./gradlew testDirectDebugUnitTest testPlayDebugUnitTest` passes (this has never been run on this codebase)
- [ ] Bump `liaVersionCode` (must be higher than any earlier upload)
- [ ] `keystore.properties` exists locally with real values; it and the `.jks` are not committed
- [ ] `git status` shows no keys, passwords or `.jks` files

**Build and test the release**
- [ ] `./gradlew bundlePlayRelease`
- [ ] Install the **release** build (R8 on) from the AAB with `bundletool`, and test: first-run, API key entry, voice session start/stop, mute, reconnect after turning Wi-Fi off and on, open app, call (with and without permission), message composer, chat, history, all personalities, theme switch, rotate, background and return
- [ ] Look for crashes caused by shrinking (org.json, Compose, enums, WebView); add a rule to `proguard-rules.pro` only for a crash you actually see
- [ ] Check the notification and microphone indicator appear during a session and disappear after Stop

**Play Console**
- [ ] App content: privacy policy URL, ads = no, app access instructions (temporary key), target audience, content rating, data safety (section 3), foreground-service declaration (section 4), AI-generated content declaration
- [ ] Store listing: name, short and full description (section 2), icon, feature graphic, screenshots
- [ ] Upload `app-play-release.aab` to **Internal testing** first, then Closed/Production
- [ ] Pre-launch report reviewed
- [ ] Revoke the temporary reviewer key after review
